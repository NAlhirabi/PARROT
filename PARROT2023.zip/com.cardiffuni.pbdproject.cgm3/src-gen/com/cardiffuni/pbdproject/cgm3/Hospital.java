/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hospital</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getPatient <em>Patient</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getDoctor <em>Doctor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getResearcher <em>Researcher</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getNurse <em>Nurse</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCloud <em>Cloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getWebsite <em>Website</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getSmartphone <em>Smartphone</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCgmsensor <em>Cgmsensor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getMedicalrecord <em>Medicalrecord</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getConsent_checkedlist <em>Consent checkedlist</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getStoragelocation <em>Storagelocation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getUserlocation <em>Userlocation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getRiskcode <em>Riskcode</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getEncryption <em>Encryption</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getDatasharing <em>Datasharing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getWarning <em>Warning</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getTest_on_dummy <em>Test on dummy</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getContainerisation <em>Containerisation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getAggregation <em>Aggregation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getComputerbrowser <em>Computerbrowser</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getPharmacycloud <em>Pharmacycloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getShippingcloud <em>Shippingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getWebhostingcloud <em>Webhostingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getPaymentcloud <em>Paymentcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getSocialnetworkcloud <em>Socialnetworkcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getWebbrowser <em>Webbrowser</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCloudforpharmacy <em>Cloudforpharmacy</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getRealtimebiddingcloud <em>Realtimebiddingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getGpstracker <em>Gpstracker</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getBus <em>Bus</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getDriver <em>Driver</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCustomer <em>Customer</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getVideoanalytics <em>Videoanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getAnalytics <em>Analytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getBlurring <em>Blurring</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getVideoprocessingcloud <em>Videoprocessingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getVideowithoutanalytics <em>Videowithoutanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getClient <em>Client</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCloudservice <em>Cloudservice</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getLightsensor <em>Lightsensor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getPhone <em>Phone</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getThermostat <em>Thermostat</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getDoorlock <em>Doorlock</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCamera <em>Camera</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCookies <em>Cookies</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital()
 * @model
 * @generated
 */
public interface Hospital extends GeneralEntity {
	/**
	 * Returns the value of the '<em><b>Patient</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Patient}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Patient</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Patient()
	 * @model containment="true"
	 * @generated
	 */
	EList<Patient> getPatient();

	/**
	 * Returns the value of the '<em><b>Doctor</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Doctor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Doctor</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Doctor()
	 * @model containment="true"
	 * @generated
	 */
	EList<Doctor> getDoctor();

	/**
	 * Returns the value of the '<em><b>Researcher</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Researcher}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Researcher</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Researcher()
	 * @model containment="true"
	 * @generated
	 */
	EList<Researcher> getResearcher();

	/**
	 * Returns the value of the '<em><b>Nurse</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Nurse}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nurse</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Nurse()
	 * @model containment="true"
	 * @generated
	 */
	EList<Nurse> getNurse();

	/**
	 * Returns the value of the '<em><b>Cloud</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Cloud}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cloud</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Cloud()
	 * @model containment="true"
	 * @generated
	 */
	EList<Cloud> getCloud();

	/**
	 * Returns the value of the '<em><b>Website</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Website}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Website</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Website()
	 * @model containment="true"
	 * @generated
	 */
	EList<Website> getWebsite();

	/**
	 * Returns the value of the '<em><b>Smartphone</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.SmartPhone}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Smartphone</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Smartphone()
	 * @model containment="true"
	 * @generated
	 */
	EList<SmartPhone> getSmartphone();

	/**
	 * Returns the value of the '<em><b>Cgmsensor</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.CGMsensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cgmsensor</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Cgmsensor()
	 * @model containment="true"
	 * @generated
	 */
	EList<CGMsensor> getCgmsensor();

	/**
	 * Returns the value of the '<em><b>Medicalrecord</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.MedicalRecord}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Medicalrecord</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Medicalrecord()
	 * @model containment="true"
	 * @generated
	 */
	EList<MedicalRecord> getMedicalrecord();

	/**
	 * Returns the value of the '<em><b>Consent checkedlist</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Consent checkedlist</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Consent_checkedlist()
	 * @model containment="true"
	 * @generated
	 */
	EList<Consent_CheckedList> getConsent_checkedlist();

	/**
	 * Returns the value of the '<em><b>Storagelocation</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.StorageLocation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Storagelocation</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Storagelocation()
	 * @model containment="true"
	 * @generated
	 */
	EList<StorageLocation> getStoragelocation();

	/**
	 * Returns the value of the '<em><b>Userlocation</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.UserLocation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Userlocation</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Userlocation()
	 * @model containment="true"
	 * @generated
	 */
	EList<UserLocation> getUserlocation();

	/**
	 * Returns the value of the '<em><b>Riskcode</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.RiskCode}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Riskcode</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Riskcode()
	 * @model containment="true"
	 * @generated
	 */
	EList<RiskCode> getRiskcode();

	/**
	 * Returns the value of the '<em><b>Encryption</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Encryption}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Encryption</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Encryption()
	 * @model containment="true"
	 * @generated
	 */
	EList<Encryption> getEncryption();

	/**
	 * Returns the value of the '<em><b>Datasharing</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.DataSharing}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Datasharing</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Datasharing()
	 * @model containment="true"
	 * @generated
	 */
	EList<DataSharing> getDatasharing();

	/**
	 * Returns the value of the '<em><b>Warning</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Warning}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Warning</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Warning()
	 * @model containment="true"
	 * @generated
	 */
	EList<Warning> getWarning();

	/**
	 * Returns the value of the '<em><b>Test on dummy</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Test_on_dummy}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Test on dummy</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Test_on_dummy()
	 * @model containment="true"
	 * @generated
	 */
	EList<Test_on_dummy> getTest_on_dummy();

	/**
	 * Returns the value of the '<em><b>Containerisation</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Containerisation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Containerisation</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Containerisation()
	 * @model containment="true"
	 * @generated
	 */
	EList<Containerisation> getContainerisation();

	/**
	 * Returns the value of the '<em><b>Aggregation</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Aggregation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Aggregation</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Aggregation()
	 * @model containment="true"
	 * @generated
	 */
	EList<Aggregation> getAggregation();

	/**
	 * Returns the value of the '<em><b>Computerbrowser</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Computerbrowser</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Computerbrowser()
	 * @model containment="true"
	 * @generated
	 */
	EList<ComputerBrowser> getComputerbrowser();

	/**
	 * Returns the value of the '<em><b>Pharmacycloud</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pharmacycloud</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Pharmacycloud()
	 * @model containment="true"
	 * @generated
	 */
	EList<PharmacyCloudold> getPharmacycloud();

	/**
	 * Returns the value of the '<em><b>Shippingcloud</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.ShippingCloud}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Shippingcloud</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Shippingcloud()
	 * @model containment="true"
	 * @generated
	 */
	EList<ShippingCloud> getShippingcloud();

	/**
	 * Returns the value of the '<em><b>Webhostingcloud</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Webhostingcloud</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Webhostingcloud()
	 * @model containment="true"
	 * @generated
	 */
	EList<WebhostingCloud> getWebhostingcloud();

	/**
	 * Returns the value of the '<em><b>Paymentcloud</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.PaymentCloud}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Paymentcloud</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Paymentcloud()
	 * @model containment="true"
	 * @generated
	 */
	EList<PaymentCloud> getPaymentcloud();

	/**
	 * Returns the value of the '<em><b>Socialnetworkcloud</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Socialnetworkcloud</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Socialnetworkcloud()
	 * @model containment="true"
	 * @generated
	 */
	EList<SocialNetworkCloud> getSocialnetworkcloud();

	/**
	 * Returns the value of the '<em><b>Webbrowser</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.WebBrowser}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Webbrowser</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Webbrowser()
	 * @model containment="true"
	 * @generated
	 */
	EList<WebBrowser> getWebbrowser();

	/**
	 * Returns the value of the '<em><b>Cloudforpharmacy</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cloudforpharmacy</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Cloudforpharmacy()
	 * @model containment="true"
	 * @generated
	 */
	EList<CloudForPharmacy> getCloudforpharmacy();

	/**
	 * Returns the value of the '<em><b>Realtimebiddingcloud</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Realtimebiddingcloud</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Realtimebiddingcloud()
	 * @model containment="true"
	 * @generated
	 */
	EList<RealTimeBiddingCloud> getRealtimebiddingcloud();

	/**
	 * Returns the value of the '<em><b>Gpstracker</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.GPSTracker}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Gpstracker</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Gpstracker()
	 * @model containment="true"
	 * @generated
	 */
	EList<GPSTracker> getGpstracker();

	/**
	 * Returns the value of the '<em><b>Bus</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Bus}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bus</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Bus()
	 * @model containment="true"
	 * @generated
	 */
	EList<Bus> getBus();

	/**
	 * Returns the value of the '<em><b>Driver</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Driver}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Driver</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Driver()
	 * @model containment="true"
	 * @generated
	 */
	EList<Driver> getDriver();

	/**
	 * Returns the value of the '<em><b>Customer</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Customer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Customer</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Customer()
	 * @model containment="true"
	 * @generated
	 */
	EList<Customer> getCustomer();

	/**
	 * Returns the value of the '<em><b>Videoanalytics</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Videoanalytics</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Videoanalytics()
	 * @model containment="true"
	 * @generated
	 */
	EList<VideoAnalytics> getVideoanalytics();

	/**
	 * Returns the value of the '<em><b>Analytics</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Analytics}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Analytics</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Analytics()
	 * @model containment="true"
	 * @generated
	 */
	EList<Analytics> getAnalytics();

	/**
	 * Returns the value of the '<em><b>Blurring</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Blurring}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Blurring</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Blurring()
	 * @model containment="true"
	 * @generated
	 */
	EList<Blurring> getBlurring();

	/**
	 * Returns the value of the '<em><b>Videoprocessingcloud</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Videoprocessingcloud</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Videoprocessingcloud()
	 * @model containment="true"
	 * @generated
	 */
	EList<VideoProcessingCloud> getVideoprocessingcloud();

	/**
	 * Returns the value of the '<em><b>Videowithoutanalytics</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Videowithoutanalytics</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Videowithoutanalytics()
	 * @model containment="true"
	 * @generated
	 */
	EList<VideoWithoutAnalytics> getVideowithoutanalytics();

	/**
	 * Returns the value of the '<em><b>Client</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Client}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Client</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Client()
	 * @model containment="true"
	 * @generated
	 */
	EList<Client> getClient();

	/**
	 * Returns the value of the '<em><b>Cloudservice</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.CloudService}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cloudservice</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Cloudservice()
	 * @model containment="true"
	 * @generated
	 */
	EList<CloudService> getCloudservice();

	/**
	 * Returns the value of the '<em><b>Lightsensor</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.LightSensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lightsensor</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Lightsensor()
	 * @model containment="true"
	 * @generated
	 */
	EList<LightSensor> getLightsensor();

	/**
	 * Returns the value of the '<em><b>Phone</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Phone}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Phone</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Phone()
	 * @model containment="true"
	 * @generated
	 */
	EList<Phone> getPhone();

	/**
	 * Returns the value of the '<em><b>Thermostat</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Thermostat}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Thermostat</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Thermostat()
	 * @model containment="true"
	 * @generated
	 */
	EList<Thermostat> getThermostat();

	/**
	 * Returns the value of the '<em><b>Doorlock</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.DoorLock}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Doorlock</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Doorlock()
	 * @model containment="true"
	 * @generated
	 */
	EList<DoorLock> getDoorlock();

	/**
	 * Returns the value of the '<em><b>Camera</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Camera}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Camera</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Camera()
	 * @model containment="true"
	 * @generated
	 */
	EList<Camera> getCamera();

	/**
	 * Returns the value of the '<em><b>Cookies</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Cookies}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cookies</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getHospital_Cookies()
	 * @model containment="true"
	 * @generated
	 */
	EList<Cookies> getCookies();

} // Hospital
