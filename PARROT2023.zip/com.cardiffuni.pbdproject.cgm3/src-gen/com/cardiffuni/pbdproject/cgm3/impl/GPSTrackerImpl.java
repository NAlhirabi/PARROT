/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.DataRetentionEnum;
import com.cardiffuni.pbdproject.cgm3.GPSTracker;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>GPS Tracker</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl#getID <em>ID</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl#getCoordinates <em>Coordinates</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl#getSpeed <em>Speed</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl#getDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks <em>Does the use of GPS is fully explained in company policies and staff handbooks</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl#getRecord_retention_period <em>Record retention period</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl#getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles <em>Does consent have been gathered from the staff who used these vehicles</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl#getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl#getDoes_the_staff_aware_of_the_use_of_the_GPS_systems <em>Does the staff aware of the use of the GPS systems</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl#getDoes_the_system_record_information_other_than_the_purpose <em>Does the system record information other than the purpose</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GPSTrackerImpl extends GeneralEntityImpl implements GPSTracker {
	/**
	 * The default value of the '{@link #getID() <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getID()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getID() <em>ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getID()
	 * @generated
	 * @ordered
	 */
	protected String id = ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getCoordinates() <em>Coordinates</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCoordinates()
	 * @generated
	 * @ordered
	 */
	protected static final String COORDINATES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCoordinates() <em>Coordinates</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCoordinates()
	 * @generated
	 * @ordered
	 */
	protected String coordinates = COORDINATES_EDEFAULT;

	/**
	 * The default value of the '{@link #getSpeed() <em>Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpeed()
	 * @generated
	 * @ordered
	 */
	protected static final String SPEED_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSpeed() <em>Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpeed()
	 * @generated
	 * @ordered
	 */
	protected String speed = SPEED_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks() <em>Does the use of GPS is fully explained in company policies and staff handbooks</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks() <em>Does the use of GPS is fully explained in company policies and staff handbooks</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks()
	 * @generated
	 * @ordered
	 */
	protected Answer does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks = DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS_EDEFAULT;

	/**
	 * The default value of the '{@link #getRecord_retention_period() <em>Record retention period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecord_retention_period()
	 * @generated
	 * @ordered
	 */
	protected static final DataRetentionEnum RECORD_RETENTION_PERIOD_EDEFAULT = DataRetentionEnum.NOT_ACCEPTED;

	/**
	 * The cached value of the '{@link #getRecord_retention_period() <em>Record retention period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecord_retention_period()
	 * @generated
	 * @ordered
	 */
	protected DataRetentionEnum record_retention_period = RECORD_RETENTION_PERIOD_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles() <em>Does consent have been gathered from the staff who used these vehicles</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles() <em>Does consent have been gathered from the staff who used these vehicles</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles()
	 * @generated
	 * @ordered
	 */
	protected Answer does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles = DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT;

	/**
	 * The default value of the '{@link #getIs_data_against_accidental_loss_or_destruction_or_damage() <em>Is data against accidental loss or destruction or damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @generated
	 * @ordered
	 */
	protected static final Answer IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getIs_data_against_accidental_loss_or_destruction_or_damage() <em>Is data against accidental loss or destruction or damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @generated
	 * @ordered
	 */
	protected Answer is_data_against_accidental_loss_or_destruction_or_damage = IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() <em>Are you using appropriate technical or organisational measures to protect the data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() <em>Are you using appropriate technical or organisational measures to protect the data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring() <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring() <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring = ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_the_staff_aware_of_the_use_of_the_GPS_systems() <em>Does the staff aware of the use of the GPS systems</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_staff_aware_of_the_use_of_the_GPS_systems()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_the_staff_aware_of_the_use_of_the_GPS_systems() <em>Does the staff aware of the use of the GPS systems</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_staff_aware_of_the_use_of_the_GPS_systems()
	 * @generated
	 * @ordered
	 */
	protected Answer does_the_staff_aware_of_the_use_of_the_GPS_systems = DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_the_system_record_information_other_than_the_purpose() <em>Does the system record information other than the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_system_record_information_other_than_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_the_system_record_information_other_than_the_purpose() <em>Does the system record information other than the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_system_record_information_other_than_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected Answer does_the_system_record_information_other_than_the_purpose = DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GPSTrackerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.GPS_TRACKER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getID() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setID(String newID) {
		String oldID = id;
		id = newID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.GPS_TRACKER__ID, oldID, id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCoordinates() {
		return coordinates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCoordinates(String newCoordinates) {
		String oldCoordinates = coordinates;
		coordinates = newCoordinates;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.GPS_TRACKER__COORDINATES, oldCoordinates,
					coordinates));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSpeed() {
		return speed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSpeed(String newSpeed) {
		String oldSpeed = speed;
		speed = newSpeed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.GPS_TRACKER__SPEED, oldSpeed, speed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks() {
		return does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks(
			Answer newDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks) {
		Answer oldDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks = does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks;
		does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks = newDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks == null
				? DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS_EDEFAULT
				: newDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.GPS_TRACKER__DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS,
					oldDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks,
					does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataRetentionEnum getRecord_retention_period() {
		return record_retention_period;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRecord_retention_period(DataRetentionEnum newRecord_retention_period) {
		DataRetentionEnum oldRecord_retention_period = record_retention_period;
		record_retention_period = newRecord_retention_period == null ? RECORD_RETENTION_PERIOD_EDEFAULT
				: newRecord_retention_period;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.GPS_TRACKER__RECORD_RETENTION_PERIOD,
					oldRecord_retention_period, record_retention_period));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles() {
		return does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles(
			Answer newDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles) {
		Answer oldDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles = does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles;
		does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles = newDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles == null
				? DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT
				: newDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.GPS_TRACKER__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES,
					oldDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles,
					does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getIs_data_against_accidental_loss_or_destruction_or_damage() {
		return is_data_against_accidental_loss_or_destruction_or_damage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIs_data_against_accidental_loss_or_destruction_or_damage(
			Answer newIs_data_against_accidental_loss_or_destruction_or_damage) {
		Answer oldIs_data_against_accidental_loss_or_destruction_or_damage = is_data_against_accidental_loss_or_destruction_or_damage;
		is_data_against_accidental_loss_or_destruction_or_damage = newIs_data_against_accidental_loss_or_destruction_or_damage == null
				? IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT
				: newIs_data_against_accidental_loss_or_destruction_or_damage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.GPS_TRACKER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE,
					oldIs_data_against_accidental_loss_or_destruction_or_damage,
					is_data_against_accidental_loss_or_destruction_or_damage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() {
		return are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(
			Answer newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data) {
		Answer oldAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
		are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data == null
				? ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT
				: newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.GPS_TRACKER__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA,
					oldAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data,
					are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
			Answer newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes) {
		Answer oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes = are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes == null
				? ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT
				: newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.GPS_TRACKER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
					oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes,
					are_you_storing_the_data_longer_than_is_necessary_for_the_purposes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring() {
		return are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring(
			Answer newAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring) {
		Answer oldAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring = are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring;
		are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring = newAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring == null
				? ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT
				: newAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.GPS_TRACKER__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING,
					oldAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring,
					are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_the_staff_aware_of_the_use_of_the_GPS_systems() {
		return does_the_staff_aware_of_the_use_of_the_GPS_systems;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_the_staff_aware_of_the_use_of_the_GPS_systems(
			Answer newDoes_the_staff_aware_of_the_use_of_the_GPS_systems) {
		Answer oldDoes_the_staff_aware_of_the_use_of_the_GPS_systems = does_the_staff_aware_of_the_use_of_the_GPS_systems;
		does_the_staff_aware_of_the_use_of_the_GPS_systems = newDoes_the_staff_aware_of_the_use_of_the_GPS_systems == null
				? DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS_EDEFAULT
				: newDoes_the_staff_aware_of_the_use_of_the_GPS_systems;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.GPS_TRACKER__DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS,
					oldDoes_the_staff_aware_of_the_use_of_the_GPS_systems,
					does_the_staff_aware_of_the_use_of_the_GPS_systems));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_the_system_record_information_other_than_the_purpose() {
		return does_the_system_record_information_other_than_the_purpose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_the_system_record_information_other_than_the_purpose(
			Answer newDoes_the_system_record_information_other_than_the_purpose) {
		Answer oldDoes_the_system_record_information_other_than_the_purpose = does_the_system_record_information_other_than_the_purpose;
		does_the_system_record_information_other_than_the_purpose = newDoes_the_system_record_information_other_than_the_purpose == null
				? DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT
				: newDoes_the_system_record_information_other_than_the_purpose;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.GPS_TRACKER__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE,
					oldDoes_the_system_record_information_other_than_the_purpose,
					does_the_system_record_information_other_than_the_purpose));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.GPS_TRACKER__ID:
			return getID();
		case Cgm3Package.GPS_TRACKER__COORDINATES:
			return getCoordinates();
		case Cgm3Package.GPS_TRACKER__SPEED:
			return getSpeed();
		case Cgm3Package.GPS_TRACKER__DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS:
			return getDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks();
		case Cgm3Package.GPS_TRACKER__RECORD_RETENTION_PERIOD:
			return getRecord_retention_period();
		case Cgm3Package.GPS_TRACKER__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES:
			return getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles();
		case Cgm3Package.GPS_TRACKER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			return getIs_data_against_accidental_loss_or_destruction_or_damage();
		case Cgm3Package.GPS_TRACKER__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			return getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();
		case Cgm3Package.GPS_TRACKER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();
		case Cgm3Package.GPS_TRACKER__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING:
			return getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring();
		case Cgm3Package.GPS_TRACKER__DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS:
			return getDoes_the_staff_aware_of_the_use_of_the_GPS_systems();
		case Cgm3Package.GPS_TRACKER__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			return getDoes_the_system_record_information_other_than_the_purpose();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.GPS_TRACKER__ID:
			setID((String) newValue);
			return;
		case Cgm3Package.GPS_TRACKER__COORDINATES:
			setCoordinates((String) newValue);
			return;
		case Cgm3Package.GPS_TRACKER__SPEED:
			setSpeed((String) newValue);
			return;
		case Cgm3Package.GPS_TRACKER__DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS:
			setDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks((Answer) newValue);
			return;
		case Cgm3Package.GPS_TRACKER__RECORD_RETENTION_PERIOD:
			setRecord_retention_period((DataRetentionEnum) newValue);
			return;
		case Cgm3Package.GPS_TRACKER__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES:
			setDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles((Answer) newValue);
			return;
		case Cgm3Package.GPS_TRACKER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			setIs_data_against_accidental_loss_or_destruction_or_damage((Answer) newValue);
			return;
		case Cgm3Package.GPS_TRACKER__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data((Answer) newValue);
			return;
		case Cgm3Package.GPS_TRACKER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes((Answer) newValue);
			return;
		case Cgm3Package.GPS_TRACKER__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING:
			setAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring((Answer) newValue);
			return;
		case Cgm3Package.GPS_TRACKER__DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS:
			setDoes_the_staff_aware_of_the_use_of_the_GPS_systems((Answer) newValue);
			return;
		case Cgm3Package.GPS_TRACKER__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			setDoes_the_system_record_information_other_than_the_purpose((Answer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.GPS_TRACKER__ID:
			setID(ID_EDEFAULT);
			return;
		case Cgm3Package.GPS_TRACKER__COORDINATES:
			setCoordinates(COORDINATES_EDEFAULT);
			return;
		case Cgm3Package.GPS_TRACKER__SPEED:
			setSpeed(SPEED_EDEFAULT);
			return;
		case Cgm3Package.GPS_TRACKER__DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS:
			setDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks(
					DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS_EDEFAULT);
			return;
		case Cgm3Package.GPS_TRACKER__RECORD_RETENTION_PERIOD:
			setRecord_retention_period(RECORD_RETENTION_PERIOD_EDEFAULT);
			return;
		case Cgm3Package.GPS_TRACKER__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES:
			setDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles(
					DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT);
			return;
		case Cgm3Package.GPS_TRACKER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			setIs_data_against_accidental_loss_or_destruction_or_damage(
					IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT);
			return;
		case Cgm3Package.GPS_TRACKER__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(
					ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT);
			return;
		case Cgm3Package.GPS_TRACKER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
					ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT);
			return;
		case Cgm3Package.GPS_TRACKER__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING:
			setAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring(
					ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT);
			return;
		case Cgm3Package.GPS_TRACKER__DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS:
			setDoes_the_staff_aware_of_the_use_of_the_GPS_systems(
					DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS_EDEFAULT);
			return;
		case Cgm3Package.GPS_TRACKER__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			setDoes_the_system_record_information_other_than_the_purpose(
					DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.GPS_TRACKER__ID:
			return ID_EDEFAULT == null ? id != null : !ID_EDEFAULT.equals(id);
		case Cgm3Package.GPS_TRACKER__COORDINATES:
			return COORDINATES_EDEFAULT == null ? coordinates != null : !COORDINATES_EDEFAULT.equals(coordinates);
		case Cgm3Package.GPS_TRACKER__SPEED:
			return SPEED_EDEFAULT == null ? speed != null : !SPEED_EDEFAULT.equals(speed);
		case Cgm3Package.GPS_TRACKER__DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS:
			return does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks != DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS_EDEFAULT;
		case Cgm3Package.GPS_TRACKER__RECORD_RETENTION_PERIOD:
			return record_retention_period != RECORD_RETENTION_PERIOD_EDEFAULT;
		case Cgm3Package.GPS_TRACKER__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES:
			return does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles != DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT;
		case Cgm3Package.GPS_TRACKER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			return is_data_against_accidental_loss_or_destruction_or_damage != IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT;
		case Cgm3Package.GPS_TRACKER__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			return are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data != ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT;
		case Cgm3Package.GPS_TRACKER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes != ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;
		case Cgm3Package.GPS_TRACKER__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING:
			return are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring != ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT;
		case Cgm3Package.GPS_TRACKER__DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS:
			return does_the_staff_aware_of_the_use_of_the_GPS_systems != DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS_EDEFAULT;
		case Cgm3Package.GPS_TRACKER__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			return does_the_system_record_information_other_than_the_purpose != DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (ID: ");
		result.append(id);
		result.append(", Coordinates: ");
		result.append(coordinates);
		result.append(", Speed: ");
		result.append(speed);
		result.append(", Does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks: ");
		result.append(does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks);
		result.append(", Record_retention_period: ");
		result.append(record_retention_period);
		result.append(", Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles: ");
		result.append(does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles);
		result.append(", Is_data_against_accidental_loss_or_destruction_or_damage: ");
		result.append(is_data_against_accidental_loss_or_destruction_or_damage);
		result.append(", Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data: ");
		result.append(are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data);
		result.append(", Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes: ");
		result.append(are_you_storing_the_data_longer_than_is_necessary_for_the_purposes);
		result.append(", Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring: ");
		result.append(are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring);
		result.append(", Does_the_staff_aware_of_the_use_of_the_GPS_systems: ");
		result.append(does_the_staff_aware_of_the_use_of_the_GPS_systems);
		result.append(", Does_the_system_record_information_other_than_the_purpose: ");
		result.append(does_the_system_record_information_other_than_the_purpose);
		result.append(')');
		return result.toString();
	}

} //GPSTrackerImpl
