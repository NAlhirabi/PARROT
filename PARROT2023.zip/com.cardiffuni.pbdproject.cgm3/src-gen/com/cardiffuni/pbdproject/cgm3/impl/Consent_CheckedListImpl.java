/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked_Consent;
import com.cardiffuni.pbdproject.cgm3.Consent_CheckedList;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Consent Checked List</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.Consent_CheckedListImpl#getCapture_age_authorization_if_age_is_less_than_16 <em>Capture age authorization if age is less than 16</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.Consent_CheckedListImpl#getCapture_withdrawal_log <em>Capture withdrawal log</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.Consent_CheckedListImpl#getCapture_log_Terms_of_use_AND_consent_to_process <em>Capture log Terms of use AND consent to process</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.Consent_CheckedListImpl#getCapture_consent_to_process_special_category_data <em>Capture consent to process special category data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.Consent_CheckedListImpl#getCapture_consent_to_term_of_use <em>Capture consent to term of use</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.Consent_CheckedListImpl#getSurface_privacy_notice <em>Surface privacy notice</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.Consent_CheckedListImpl#getCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used <em>Capture consent to the type of marketing if electronic marketing is used</em>}</li>
 * </ul>
 *
 * @generated
 */
public class Consent_CheckedListImpl extends GeneralEntityImpl implements Consent_CheckedList {
	/**
	 * The default value of the '{@link #getCapture_age_authorization_if_age_is_less_than_16() <em>Capture age authorization if age is less than 16</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_age_authorization_if_age_is_less_than_16()
	 * @generated
	 * @ordered
	 */
	protected static final Checked_Consent CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16_EDEFAULT = Checked_Consent.NO;

	/**
	 * The cached value of the '{@link #getCapture_age_authorization_if_age_is_less_than_16() <em>Capture age authorization if age is less than 16</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_age_authorization_if_age_is_less_than_16()
	 * @generated
	 * @ordered
	 */
	protected Checked_Consent capture_age_authorization_if_age_is_less_than_16 = CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16_EDEFAULT;

	/**
	 * The default value of the '{@link #getCapture_withdrawal_log() <em>Capture withdrawal log</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_withdrawal_log()
	 * @generated
	 * @ordered
	 */
	protected static final Checked_Consent CAPTURE_WITHDRAWAL_LOG_EDEFAULT = Checked_Consent.NO;

	/**
	 * The cached value of the '{@link #getCapture_withdrawal_log() <em>Capture withdrawal log</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_withdrawal_log()
	 * @generated
	 * @ordered
	 */
	protected Checked_Consent capture_withdrawal_log = CAPTURE_WITHDRAWAL_LOG_EDEFAULT;

	/**
	 * The default value of the '{@link #getCapture_log_Terms_of_use_AND_consent_to_process() <em>Capture log Terms of use AND consent to process</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_log_Terms_of_use_AND_consent_to_process()
	 * @generated
	 * @ordered
	 */
	protected static final Checked_Consent CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS_EDEFAULT = Checked_Consent.NO;

	/**
	 * The cached value of the '{@link #getCapture_log_Terms_of_use_AND_consent_to_process() <em>Capture log Terms of use AND consent to process</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_log_Terms_of_use_AND_consent_to_process()
	 * @generated
	 * @ordered
	 */
	protected Checked_Consent capture_log_Terms_of_use_AND_consent_to_process = CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS_EDEFAULT;

	/**
	 * The default value of the '{@link #getCapture_consent_to_process_special_category_data() <em>Capture consent to process special category data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_consent_to_process_special_category_data()
	 * @generated
	 * @ordered
	 */
	protected static final Checked_Consent CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA_EDEFAULT = Checked_Consent.NO;

	/**
	 * The cached value of the '{@link #getCapture_consent_to_process_special_category_data() <em>Capture consent to process special category data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_consent_to_process_special_category_data()
	 * @generated
	 * @ordered
	 */
	protected Checked_Consent capture_consent_to_process_special_category_data = CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #getCapture_consent_to_term_of_use() <em>Capture consent to term of use</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_consent_to_term_of_use()
	 * @generated
	 * @ordered
	 */
	protected static final Checked_Consent CAPTURE_CONSENT_TO_TERM_OF_USE_EDEFAULT = Checked_Consent.NO;

	/**
	 * The cached value of the '{@link #getCapture_consent_to_term_of_use() <em>Capture consent to term of use</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_consent_to_term_of_use()
	 * @generated
	 * @ordered
	 */
	protected Checked_Consent capture_consent_to_term_of_use = CAPTURE_CONSENT_TO_TERM_OF_USE_EDEFAULT;

	/**
	 * The default value of the '{@link #getSurface_privacy_notice() <em>Surface privacy notice</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSurface_privacy_notice()
	 * @generated
	 * @ordered
	 */
	protected static final Checked_Consent SURFACE_PRIVACY_NOTICE_EDEFAULT = Checked_Consent.NO;

	/**
	 * The cached value of the '{@link #getSurface_privacy_notice() <em>Surface privacy notice</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSurface_privacy_notice()
	 * @generated
	 * @ordered
	 */
	protected Checked_Consent surface_privacy_notice = SURFACE_PRIVACY_NOTICE_EDEFAULT;

	/**
	 * The default value of the '{@link #getCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used() <em>Capture consent to the type of marketing if electronic marketing is used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used()
	 * @generated
	 * @ordered
	 */
	protected static final Checked_Consent CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED_EDEFAULT = Checked_Consent.NO;

	/**
	 * The cached value of the '{@link #getCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used() <em>Capture consent to the type of marketing if electronic marketing is used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used()
	 * @generated
	 * @ordered
	 */
	protected Checked_Consent capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used = CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Consent_CheckedListImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.CONSENT_CHECKED_LIST;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked_Consent getCapture_age_authorization_if_age_is_less_than_16() {
		return capture_age_authorization_if_age_is_less_than_16;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCapture_age_authorization_if_age_is_less_than_16(
			Checked_Consent newCapture_age_authorization_if_age_is_less_than_16) {
		Checked_Consent oldCapture_age_authorization_if_age_is_less_than_16 = capture_age_authorization_if_age_is_less_than_16;
		capture_age_authorization_if_age_is_less_than_16 = newCapture_age_authorization_if_age_is_less_than_16 == null
				? CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16_EDEFAULT
				: newCapture_age_authorization_if_age_is_less_than_16;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16,
					oldCapture_age_authorization_if_age_is_less_than_16,
					capture_age_authorization_if_age_is_less_than_16));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked_Consent getCapture_withdrawal_log() {
		return capture_withdrawal_log;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCapture_withdrawal_log(Checked_Consent newCapture_withdrawal_log) {
		Checked_Consent oldCapture_withdrawal_log = capture_withdrawal_log;
		capture_withdrawal_log = newCapture_withdrawal_log == null ? CAPTURE_WITHDRAWAL_LOG_EDEFAULT
				: newCapture_withdrawal_log;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_WITHDRAWAL_LOG, oldCapture_withdrawal_log,
					capture_withdrawal_log));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked_Consent getCapture_log_Terms_of_use_AND_consent_to_process() {
		return capture_log_Terms_of_use_AND_consent_to_process;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCapture_log_Terms_of_use_AND_consent_to_process(
			Checked_Consent newCapture_log_Terms_of_use_AND_consent_to_process) {
		Checked_Consent oldCapture_log_Terms_of_use_AND_consent_to_process = capture_log_Terms_of_use_AND_consent_to_process;
		capture_log_Terms_of_use_AND_consent_to_process = newCapture_log_Terms_of_use_AND_consent_to_process == null
				? CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS_EDEFAULT
				: newCapture_log_Terms_of_use_AND_consent_to_process;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS,
					oldCapture_log_Terms_of_use_AND_consent_to_process,
					capture_log_Terms_of_use_AND_consent_to_process));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked_Consent getCapture_consent_to_process_special_category_data() {
		return capture_consent_to_process_special_category_data;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCapture_consent_to_process_special_category_data(
			Checked_Consent newCapture_consent_to_process_special_category_data) {
		Checked_Consent oldCapture_consent_to_process_special_category_data = capture_consent_to_process_special_category_data;
		capture_consent_to_process_special_category_data = newCapture_consent_to_process_special_category_data == null
				? CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA_EDEFAULT
				: newCapture_consent_to_process_special_category_data;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA,
					oldCapture_consent_to_process_special_category_data,
					capture_consent_to_process_special_category_data));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked_Consent getCapture_consent_to_term_of_use() {
		return capture_consent_to_term_of_use;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCapture_consent_to_term_of_use(Checked_Consent newCapture_consent_to_term_of_use) {
		Checked_Consent oldCapture_consent_to_term_of_use = capture_consent_to_term_of_use;
		capture_consent_to_term_of_use = newCapture_consent_to_term_of_use == null
				? CAPTURE_CONSENT_TO_TERM_OF_USE_EDEFAULT
				: newCapture_consent_to_term_of_use;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_TERM_OF_USE, oldCapture_consent_to_term_of_use,
					capture_consent_to_term_of_use));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked_Consent getSurface_privacy_notice() {
		return surface_privacy_notice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSurface_privacy_notice(Checked_Consent newSurface_privacy_notice) {
		Checked_Consent oldSurface_privacy_notice = surface_privacy_notice;
		surface_privacy_notice = newSurface_privacy_notice == null ? SURFACE_PRIVACY_NOTICE_EDEFAULT
				: newSurface_privacy_notice;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CONSENT_CHECKED_LIST__SURFACE_PRIVACY_NOTICE, oldSurface_privacy_notice,
					surface_privacy_notice));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked_Consent getCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used() {
		return capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used(
			Checked_Consent newCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used) {
		Checked_Consent oldCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used = capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used;
		capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used = newCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used == null
				? CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED_EDEFAULT
				: newCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED,
					oldCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used,
					capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16:
			return getCapture_age_authorization_if_age_is_less_than_16();
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_WITHDRAWAL_LOG:
			return getCapture_withdrawal_log();
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS:
			return getCapture_log_Terms_of_use_AND_consent_to_process();
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA:
			return getCapture_consent_to_process_special_category_data();
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_TERM_OF_USE:
			return getCapture_consent_to_term_of_use();
		case Cgm3Package.CONSENT_CHECKED_LIST__SURFACE_PRIVACY_NOTICE:
			return getSurface_privacy_notice();
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED:
			return getCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16:
			setCapture_age_authorization_if_age_is_less_than_16((Checked_Consent) newValue);
			return;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_WITHDRAWAL_LOG:
			setCapture_withdrawal_log((Checked_Consent) newValue);
			return;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS:
			setCapture_log_Terms_of_use_AND_consent_to_process((Checked_Consent) newValue);
			return;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA:
			setCapture_consent_to_process_special_category_data((Checked_Consent) newValue);
			return;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_TERM_OF_USE:
			setCapture_consent_to_term_of_use((Checked_Consent) newValue);
			return;
		case Cgm3Package.CONSENT_CHECKED_LIST__SURFACE_PRIVACY_NOTICE:
			setSurface_privacy_notice((Checked_Consent) newValue);
			return;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED:
			setCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used((Checked_Consent) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16:
			setCapture_age_authorization_if_age_is_less_than_16(
					CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16_EDEFAULT);
			return;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_WITHDRAWAL_LOG:
			setCapture_withdrawal_log(CAPTURE_WITHDRAWAL_LOG_EDEFAULT);
			return;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS:
			setCapture_log_Terms_of_use_AND_consent_to_process(
					CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS_EDEFAULT);
			return;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA:
			setCapture_consent_to_process_special_category_data(
					CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA_EDEFAULT);
			return;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_TERM_OF_USE:
			setCapture_consent_to_term_of_use(CAPTURE_CONSENT_TO_TERM_OF_USE_EDEFAULT);
			return;
		case Cgm3Package.CONSENT_CHECKED_LIST__SURFACE_PRIVACY_NOTICE:
			setSurface_privacy_notice(SURFACE_PRIVACY_NOTICE_EDEFAULT);
			return;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED:
			setCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used(
					CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16:
			return capture_age_authorization_if_age_is_less_than_16 != CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16_EDEFAULT;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_WITHDRAWAL_LOG:
			return capture_withdrawal_log != CAPTURE_WITHDRAWAL_LOG_EDEFAULT;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS:
			return capture_log_Terms_of_use_AND_consent_to_process != CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS_EDEFAULT;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA:
			return capture_consent_to_process_special_category_data != CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA_EDEFAULT;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_TERM_OF_USE:
			return capture_consent_to_term_of_use != CAPTURE_CONSENT_TO_TERM_OF_USE_EDEFAULT;
		case Cgm3Package.CONSENT_CHECKED_LIST__SURFACE_PRIVACY_NOTICE:
			return surface_privacy_notice != SURFACE_PRIVACY_NOTICE_EDEFAULT;
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED:
			return capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used != CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Capture_age_authorization_if_age_is_less_than_16: ");
		result.append(capture_age_authorization_if_age_is_less_than_16);
		result.append(", Capture_withdrawal_log: ");
		result.append(capture_withdrawal_log);
		result.append(", Capture_log_Terms_of_use_AND_consent_to_process: ");
		result.append(capture_log_Terms_of_use_AND_consent_to_process);
		result.append(", Capture_consent_to_process_special_category_data: ");
		result.append(capture_consent_to_process_special_category_data);
		result.append(", Capture_consent_to_term_of_use: ");
		result.append(capture_consent_to_term_of_use);
		result.append(", Surface_privacy_notice: ");
		result.append(surface_privacy_notice);
		result.append(", Capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used: ");
		result.append(capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used);
		result.append(')');
		return result.toString();
	}

} //Consent_CheckedListImpl
