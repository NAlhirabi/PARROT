/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.Cookies;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Cookies</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CookiesImpl#getUse_the_surface_cookies_banner_if_cookies_are_placed <em>Use the surface cookies banner if cookies are placed</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CookiesImpl#getThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added <em>The cookie banner must be resurfaced if new cookies are added</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CookiesImpl#getThe_cookie_banner_must_be_resurfaced_if_browser_settings_change <em>The cookie banner must be resurfaced if browser settings change</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CookiesImpl#getCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used <em>Capture consent or acceptance if necessary OR Analytics OR Ad targeting cookies are used</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CookiesImpl#getPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used <em>Place cookies according to consent if necessary OR Analytics OR Ad targeting cookies are used</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CookiesImpl#getConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc <em>Consider the option of using athird party tool such as One Trus or Trust Arc</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CookiesImpl extends GeneralEntityImpl implements Cookies {
	/**
	 * The default value of the '{@link #getUse_the_surface_cookies_banner_if_cookies_are_placed() <em>Use the surface cookies banner if cookies are placed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUse_the_surface_cookies_banner_if_cookies_are_placed()
	 * @generated
	 * @ordered
	 */
	protected static final Checked USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getUse_the_surface_cookies_banner_if_cookies_are_placed() <em>Use the surface cookies banner if cookies are placed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUse_the_surface_cookies_banner_if_cookies_are_placed()
	 * @generated
	 * @ordered
	 */
	protected Checked use_the_surface_cookies_banner_if_cookies_are_placed = USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED_EDEFAULT;

	/**
	 * The default value of the '{@link #getThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added() <em>The cookie banner must be resurfaced if new cookies are added</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added()
	 * @generated
	 * @ordered
	 */
	protected static final Checked THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added() <em>The cookie banner must be resurfaced if new cookies are added</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added()
	 * @generated
	 * @ordered
	 */
	protected Checked the_cookie_banner_must_be_resurfaced_if_new_cookies_are_added = THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED_EDEFAULT;

	/**
	 * The default value of the '{@link #getThe_cookie_banner_must_be_resurfaced_if_browser_settings_change() <em>The cookie banner must be resurfaced if browser settings change</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThe_cookie_banner_must_be_resurfaced_if_browser_settings_change()
	 * @generated
	 * @ordered
	 */
	protected static final Checked THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getThe_cookie_banner_must_be_resurfaced_if_browser_settings_change() <em>The cookie banner must be resurfaced if browser settings change</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThe_cookie_banner_must_be_resurfaced_if_browser_settings_change()
	 * @generated
	 * @ordered
	 */
	protected Checked the_cookie_banner_must_be_resurfaced_if_browser_settings_change = THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used() <em>Capture consent or acceptance if necessary OR Analytics OR Ad targeting cookies are used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used()
	 * @generated
	 * @ordered
	 */
	protected static final Checked CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used() <em>Capture consent or acceptance if necessary OR Analytics OR Ad targeting cookies are used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used()
	 * @generated
	 * @ordered
	 */
	protected Checked capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used = CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED_EDEFAULT;

	/**
	 * The default value of the '{@link #getPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used() <em>Place cookies according to consent if necessary OR Analytics OR Ad targeting cookies are used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used()
	 * @generated
	 * @ordered
	 */
	protected static final Checked PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used() <em>Place cookies according to consent if necessary OR Analytics OR Ad targeting cookies are used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used()
	 * @generated
	 * @ordered
	 */
	protected Checked place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used = PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED_EDEFAULT;

	/**
	 * The default value of the '{@link #getConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc() <em>Consider the option of using athird party tool such as One Trus or Trust Arc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc()
	 * @generated
	 * @ordered
	 */
	protected static final String CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC_EDEFAULT = "No";

	/**
	 * The cached value of the '{@link #getConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc() <em>Consider the option of using athird party tool such as One Trus or Trust Arc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc()
	 * @generated
	 * @ordered
	 */
	protected String consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc = CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CookiesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.COOKIES;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getUse_the_surface_cookies_banner_if_cookies_are_placed() {
		return use_the_surface_cookies_banner_if_cookies_are_placed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUse_the_surface_cookies_banner_if_cookies_are_placed(
			Checked newUse_the_surface_cookies_banner_if_cookies_are_placed) {
		Checked oldUse_the_surface_cookies_banner_if_cookies_are_placed = use_the_surface_cookies_banner_if_cookies_are_placed;
		use_the_surface_cookies_banner_if_cookies_are_placed = newUse_the_surface_cookies_banner_if_cookies_are_placed == null
				? USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED_EDEFAULT
				: newUse_the_surface_cookies_banner_if_cookies_are_placed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.COOKIES__USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED,
					oldUse_the_surface_cookies_banner_if_cookies_are_placed,
					use_the_surface_cookies_banner_if_cookies_are_placed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added() {
		return the_cookie_banner_must_be_resurfaced_if_new_cookies_are_added;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added(
			Checked newThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added) {
		Checked oldThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added = the_cookie_banner_must_be_resurfaced_if_new_cookies_are_added;
		the_cookie_banner_must_be_resurfaced_if_new_cookies_are_added = newThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added == null
				? THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED_EDEFAULT
				: newThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED,
					oldThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added,
					the_cookie_banner_must_be_resurfaced_if_new_cookies_are_added));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getThe_cookie_banner_must_be_resurfaced_if_browser_settings_change() {
		return the_cookie_banner_must_be_resurfaced_if_browser_settings_change;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setThe_cookie_banner_must_be_resurfaced_if_browser_settings_change(
			Checked newThe_cookie_banner_must_be_resurfaced_if_browser_settings_change) {
		Checked oldThe_cookie_banner_must_be_resurfaced_if_browser_settings_change = the_cookie_banner_must_be_resurfaced_if_browser_settings_change;
		the_cookie_banner_must_be_resurfaced_if_browser_settings_change = newThe_cookie_banner_must_be_resurfaced_if_browser_settings_change == null
				? THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE_EDEFAULT
				: newThe_cookie_banner_must_be_resurfaced_if_browser_settings_change;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE,
					oldThe_cookie_banner_must_be_resurfaced_if_browser_settings_change,
					the_cookie_banner_must_be_resurfaced_if_browser_settings_change));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used() {
		return capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used(
			Checked newCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used) {
		Checked oldCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used = capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used;
		capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used = newCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used == null
				? CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED_EDEFAULT
				: newCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.COOKIES__CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED,
					oldCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used,
					capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used() {
		return place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used(
			Checked newPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used) {
		Checked oldPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used = place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used;
		place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used = newPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used == null
				? PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED_EDEFAULT
				: newPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.COOKIES__PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED,
					oldPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used,
					place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc() {
		return consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc(
			String newConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc) {
		String oldConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc = consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc;
		consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc = newConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.COOKIES__CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC,
					oldConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc,
					consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.COOKIES__USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED:
			return getUse_the_surface_cookies_banner_if_cookies_are_placed();
		case Cgm3Package.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED:
			return getThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added();
		case Cgm3Package.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE:
			return getThe_cookie_banner_must_be_resurfaced_if_browser_settings_change();
		case Cgm3Package.COOKIES__CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED:
			return getCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used();
		case Cgm3Package.COOKIES__PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED:
			return getPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used();
		case Cgm3Package.COOKIES__CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC:
			return getConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.COOKIES__USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED:
			setUse_the_surface_cookies_banner_if_cookies_are_placed((Checked) newValue);
			return;
		case Cgm3Package.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED:
			setThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added((Checked) newValue);
			return;
		case Cgm3Package.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE:
			setThe_cookie_banner_must_be_resurfaced_if_browser_settings_change((Checked) newValue);
			return;
		case Cgm3Package.COOKIES__CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED:
			setCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used(
					(Checked) newValue);
			return;
		case Cgm3Package.COOKIES__PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED:
			setPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used(
					(Checked) newValue);
			return;
		case Cgm3Package.COOKIES__CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC:
			setConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.COOKIES__USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED:
			setUse_the_surface_cookies_banner_if_cookies_are_placed(
					USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED_EDEFAULT);
			return;
		case Cgm3Package.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED:
			setThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added(
					THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED_EDEFAULT);
			return;
		case Cgm3Package.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE:
			setThe_cookie_banner_must_be_resurfaced_if_browser_settings_change(
					THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE_EDEFAULT);
			return;
		case Cgm3Package.COOKIES__CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED:
			setCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used(
					CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED_EDEFAULT);
			return;
		case Cgm3Package.COOKIES__PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED:
			setPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used(
					PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED_EDEFAULT);
			return;
		case Cgm3Package.COOKIES__CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC:
			setConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc(
					CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.COOKIES__USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED:
			return use_the_surface_cookies_banner_if_cookies_are_placed != USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED_EDEFAULT;
		case Cgm3Package.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED:
			return the_cookie_banner_must_be_resurfaced_if_new_cookies_are_added != THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED_EDEFAULT;
		case Cgm3Package.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE:
			return the_cookie_banner_must_be_resurfaced_if_browser_settings_change != THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE_EDEFAULT;
		case Cgm3Package.COOKIES__CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED:
			return capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used != CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED_EDEFAULT;
		case Cgm3Package.COOKIES__PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED:
			return place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used != PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED_EDEFAULT;
		case Cgm3Package.COOKIES__CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC:
			return CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC_EDEFAULT == null
					? consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc != null
					: !CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC_EDEFAULT
							.equals(consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Use_the_surface_cookies_banner_if_cookies_are_placed: ");
		result.append(use_the_surface_cookies_banner_if_cookies_are_placed);
		result.append(", The_cookie_banner_must_be_resurfaced_if_new_cookies_are_added: ");
		result.append(the_cookie_banner_must_be_resurfaced_if_new_cookies_are_added);
		result.append(", The_cookie_banner_must_be_resurfaced_if_browser_settings_change: ");
		result.append(the_cookie_banner_must_be_resurfaced_if_browser_settings_change);
		result.append(", Capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used: ");
		result.append(capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used);
		result.append(
				", Place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used: ");
		result.append(place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used);
		result.append(", Consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc: ");
		result.append(consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc);
		result.append(')');
		return result.toString();
	}

} //CookiesImpl
