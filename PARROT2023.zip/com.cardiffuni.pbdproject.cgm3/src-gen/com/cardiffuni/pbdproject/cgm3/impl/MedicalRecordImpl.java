/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.DataRetentionEnum;
import com.cardiffuni.pbdproject.cgm3.MedicalRecord;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Medical Record</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.MedicalRecordImpl#getRecordRetentionPeriod <em>Record Retention Period</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MedicalRecordImpl extends GeneralEntityImpl implements MedicalRecord {
	/**
	 * The default value of the '{@link #getRecordRetentionPeriod() <em>Record Retention Period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecordRetentionPeriod()
	 * @generated
	 * @ordered
	 */
	protected static final DataRetentionEnum RECORD_RETENTION_PERIOD_EDEFAULT = DataRetentionEnum.NOT_ACCEPTED;

	/**
	 * The cached value of the '{@link #getRecordRetentionPeriod() <em>Record Retention Period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecordRetentionPeriod()
	 * @generated
	 * @ordered
	 */
	protected DataRetentionEnum recordRetentionPeriod = RECORD_RETENTION_PERIOD_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MedicalRecordImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.MEDICAL_RECORD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataRetentionEnum getRecordRetentionPeriod() {
		return recordRetentionPeriod;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRecordRetentionPeriod(DataRetentionEnum newRecordRetentionPeriod) {
		DataRetentionEnum oldRecordRetentionPeriod = recordRetentionPeriod;
		recordRetentionPeriod = newRecordRetentionPeriod == null ? RECORD_RETENTION_PERIOD_EDEFAULT
				: newRecordRetentionPeriod;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.MEDICAL_RECORD__RECORD_RETENTION_PERIOD,
					oldRecordRetentionPeriod, recordRetentionPeriod));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.MEDICAL_RECORD__RECORD_RETENTION_PERIOD:
			return getRecordRetentionPeriod();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.MEDICAL_RECORD__RECORD_RETENTION_PERIOD:
			setRecordRetentionPeriod((DataRetentionEnum) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.MEDICAL_RECORD__RECORD_RETENTION_PERIOD:
			setRecordRetentionPeriod(RECORD_RETENTION_PERIOD_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.MEDICAL_RECORD__RECORD_RETENTION_PERIOD:
			return recordRetentionPeriod != RECORD_RETENTION_PERIOD_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (RecordRetentionPeriod: ");
		result.append(recordRetentionPeriod);
		result.append(')');
		return result.toString();
	}

} //MedicalRecordImpl
