/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Camera;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.CloudService;
import com.cardiffuni.pbdproject.cgm3.DataRetentionEnum;

import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.Privacy_patterns;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Camera</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getEncryptedData <em>Encrypted Data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getPrivacy_patterns <em>Privacy patterns</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getAre_you_sending_data_without_anonymisation <em>Are you sending data without anonymisation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV <em>Does the sign has abrief explanation about the purpose of CCTV</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getDo_people_aware_of_being_recorded <em>Do people aware of being recorded</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getAre_you_storing_the_footage_in_a_secure_location <em>Are you storing the footage in asecure location</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getEnsure_data_minimisation_is_aplied <em>Ensure data minimisation is aplied</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getDo_you_use_signs_that_say_CCTV_is_in_operation <em>Do you use signs that say CCTV is in operation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getDoes_the_system_record_information_other_than_the_purpose <em>Does the system record information other than the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getRecord_retention_period <em>Record retention period</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getAre_you_allowing_data_unauthorised_access <em>Are you allowing data unauthorised access</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl#getCloudservice <em>Cloudservice</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CameraImpl extends GeneralEntityImpl implements Camera {
	/**
	 * The default value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENCRYPTED_DATA_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected Checked encryptedData = ENCRYPTED_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected static final String PRIVACY_PATTERNS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected String privacy_patterns = PRIVACY_PATTERNS_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_sending_data_without_anonymisation() <em>Are you sending data without anonymisation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_sending_data_without_anonymisation()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_sending_data_without_anonymisation() <em>Are you sending data without anonymisation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_sending_data_without_anonymisation()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_sending_data_without_anonymisation = ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV() <em>Does the sign has abrief explanation about the purpose of CCTV</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV() <em>Does the sign has abrief explanation about the purpose of CCTV</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV()
	 * @generated
	 * @ordered
	 */
	protected Answer does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV = DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT;

	/**
	 * The default value of the '{@link #getDo_people_aware_of_being_recorded() <em>Do people aware of being recorded</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_people_aware_of_being_recorded()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDo_people_aware_of_being_recorded() <em>Do people aware of being recorded</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_people_aware_of_being_recorded()
	 * @generated
	 * @ordered
	 */
	protected Answer do_people_aware_of_being_recorded = DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() <em>Are you using appropriate technical or organisational measures to protect the data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() <em>Are you using appropriate technical or organisational measures to protect the data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_storing_the_footage_in_a_secure_location() <em>Are you storing the footage in asecure location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_footage_in_a_secure_location()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_storing_the_footage_in_a_secure_location() <em>Are you storing the footage in asecure location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_footage_in_a_secure_location()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_storing_the_footage_in_a_secure_location = ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getEnsure_data_minimisation_is_aplied() <em>Ensure data minimisation is aplied</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnsure_data_minimisation_is_aplied()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ENSURE_DATA_MINIMISATION_IS_APLIED_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getEnsure_data_minimisation_is_aplied() <em>Ensure data minimisation is aplied</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnsure_data_minimisation_is_aplied()
	 * @generated
	 * @ordered
	 */
	protected Answer ensure_data_minimisation_is_aplied = ENSURE_DATA_MINIMISATION_IS_APLIED_EDEFAULT;

	/**
	 * The default value of the '{@link #getDo_you_use_signs_that_say_CCTV_is_in_operation() <em>Do you use signs that say CCTV is in operation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_you_use_signs_that_say_CCTV_is_in_operation()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDo_you_use_signs_that_say_CCTV_is_in_operation() <em>Do you use signs that say CCTV is in operation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_you_use_signs_that_say_CCTV_is_in_operation()
	 * @generated
	 * @ordered
	 */
	protected Answer do_you_use_signs_that_say_CCTV_is_in_operation = DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_the_system_record_information_other_than_the_purpose() <em>Does the system record information other than the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_system_record_information_other_than_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_the_system_record_information_other_than_the_purpose() <em>Does the system record information other than the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_system_record_information_other_than_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected Answer does_the_system_record_information_other_than_the_purpose = DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT;

	/**
	 * The default value of the '{@link #getRecord_retention_period() <em>Record retention period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecord_retention_period()
	 * @generated
	 * @ordered
	 */
	protected static final DataRetentionEnum RECORD_RETENTION_PERIOD_EDEFAULT = DataRetentionEnum.NOT_ACCEPTED;

	/**
	 * The cached value of the '{@link #getRecord_retention_period() <em>Record retention period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecord_retention_period()
	 * @generated
	 * @ordered
	 */
	protected DataRetentionEnum record_retention_period = RECORD_RETENTION_PERIOD_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_allowing_data_unauthorised_access() <em>Are you allowing data unauthorised access</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_allowing_data_unauthorised_access()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_allowing_data_unauthorised_access() <em>Are you allowing data unauthorised access</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_allowing_data_unauthorised_access()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_allowing_data_unauthorised_access = ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;

	/**
	 * The default value of the '{@link #getIs_data_against_accidental_loss_or_destruction_or_damage() <em>Is data against accidental loss or destruction or damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @generated
	 * @ordered
	 */
	protected static final Answer IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getIs_data_against_accidental_loss_or_destruction_or_damage() <em>Is data against accidental loss or destruction or damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @generated
	 * @ordered
	 */
	protected Answer is_data_against_accidental_loss_or_destruction_or_damage = IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCloudservice() <em>Cloudservice</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCloudservice()
	 * @generated
	 * @ordered
	 */
	protected CloudService cloudservice;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CameraImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.CAMERA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEncryptedData() {
		return encryptedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncryptedData(Checked newEncryptedData) {
		Checked oldEncryptedData = encryptedData;
		encryptedData = newEncryptedData == null ? ENCRYPTED_DATA_EDEFAULT : newEncryptedData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CAMERA__ENCRYPTED_DATA, oldEncryptedData,
					encryptedData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPrivacy_patterns() {
		return privacy_patterns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrivacy_patterns(String newPrivacy_patterns) {
		String oldPrivacy_patterns = privacy_patterns;
		privacy_patterns = newPrivacy_patterns;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CAMERA__PRIVACY_PATTERNS,
					oldPrivacy_patterns, privacy_patterns));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_sending_data_without_anonymisation() {
		return are_you_sending_data_without_anonymisation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_sending_data_without_anonymisation(Answer newAre_you_sending_data_without_anonymisation) {
		Answer oldAre_you_sending_data_without_anonymisation = are_you_sending_data_without_anonymisation;
		are_you_sending_data_without_anonymisation = newAre_you_sending_data_without_anonymisation == null
				? ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION_EDEFAULT
				: newAre_you_sending_data_without_anonymisation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CAMERA__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION,
					oldAre_you_sending_data_without_anonymisation, are_you_sending_data_without_anonymisation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV() {
		return does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV(
			Answer newDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV) {
		Answer oldDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV = does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV;
		does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV = newDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV == null
				? DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT
				: newDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CAMERA__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV,
					oldDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV,
					does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDo_people_aware_of_being_recorded() {
		return do_people_aware_of_being_recorded;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDo_people_aware_of_being_recorded(Answer newDo_people_aware_of_being_recorded) {
		Answer oldDo_people_aware_of_being_recorded = do_people_aware_of_being_recorded;
		do_people_aware_of_being_recorded = newDo_people_aware_of_being_recorded == null
				? DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT
				: newDo_people_aware_of_being_recorded;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CAMERA__DO_PEOPLE_AWARE_OF_BEING_RECORDED,
					oldDo_people_aware_of_being_recorded, do_people_aware_of_being_recorded));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() {
		return are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(
			Answer newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data) {
		Answer oldAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
		are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data == null
				? ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT
				: newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CAMERA__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA,
					oldAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data,
					are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_storing_the_footage_in_a_secure_location() {
		return are_you_storing_the_footage_in_a_secure_location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_storing_the_footage_in_a_secure_location(
			Answer newAre_you_storing_the_footage_in_a_secure_location) {
		Answer oldAre_you_storing_the_footage_in_a_secure_location = are_you_storing_the_footage_in_a_secure_location;
		are_you_storing_the_footage_in_a_secure_location = newAre_you_storing_the_footage_in_a_secure_location == null
				? ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION_EDEFAULT
				: newAre_you_storing_the_footage_in_a_secure_location;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CAMERA__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION,
					oldAre_you_storing_the_footage_in_a_secure_location,
					are_you_storing_the_footage_in_a_secure_location));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getEnsure_data_minimisation_is_aplied() {
		return ensure_data_minimisation_is_aplied;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEnsure_data_minimisation_is_aplied(Answer newEnsure_data_minimisation_is_aplied) {
		Answer oldEnsure_data_minimisation_is_aplied = ensure_data_minimisation_is_aplied;
		ensure_data_minimisation_is_aplied = newEnsure_data_minimisation_is_aplied == null
				? ENSURE_DATA_MINIMISATION_IS_APLIED_EDEFAULT
				: newEnsure_data_minimisation_is_aplied;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CAMERA__ENSURE_DATA_MINIMISATION_IS_APLIED, oldEnsure_data_minimisation_is_aplied,
					ensure_data_minimisation_is_aplied));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDo_you_use_signs_that_say_CCTV_is_in_operation() {
		return do_you_use_signs_that_say_CCTV_is_in_operation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDo_you_use_signs_that_say_CCTV_is_in_operation(
			Answer newDo_you_use_signs_that_say_CCTV_is_in_operation) {
		Answer oldDo_you_use_signs_that_say_CCTV_is_in_operation = do_you_use_signs_that_say_CCTV_is_in_operation;
		do_you_use_signs_that_say_CCTV_is_in_operation = newDo_you_use_signs_that_say_CCTV_is_in_operation == null
				? DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT
				: newDo_you_use_signs_that_say_CCTV_is_in_operation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CAMERA__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION,
					oldDo_you_use_signs_that_say_CCTV_is_in_operation, do_you_use_signs_that_say_CCTV_is_in_operation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_the_system_record_information_other_than_the_purpose() {
		return does_the_system_record_information_other_than_the_purpose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_the_system_record_information_other_than_the_purpose(
			Answer newDoes_the_system_record_information_other_than_the_purpose) {
		Answer oldDoes_the_system_record_information_other_than_the_purpose = does_the_system_record_information_other_than_the_purpose;
		does_the_system_record_information_other_than_the_purpose = newDoes_the_system_record_information_other_than_the_purpose == null
				? DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT
				: newDoes_the_system_record_information_other_than_the_purpose;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CAMERA__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE,
					oldDoes_the_system_record_information_other_than_the_purpose,
					does_the_system_record_information_other_than_the_purpose));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataRetentionEnum getRecord_retention_period() {
		return record_retention_period;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRecord_retention_period(DataRetentionEnum newRecord_retention_period) {
		DataRetentionEnum oldRecord_retention_period = record_retention_period;
		record_retention_period = newRecord_retention_period == null ? RECORD_RETENTION_PERIOD_EDEFAULT
				: newRecord_retention_period;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CAMERA__RECORD_RETENTION_PERIOD,
					oldRecord_retention_period, record_retention_period));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_allowing_data_unauthorised_access() {
		return are_you_allowing_data_unauthorised_access;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_allowing_data_unauthorised_access(Answer newAre_you_allowing_data_unauthorised_access) {
		Answer oldAre_you_allowing_data_unauthorised_access = are_you_allowing_data_unauthorised_access;
		are_you_allowing_data_unauthorised_access = newAre_you_allowing_data_unauthorised_access == null
				? ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS_EDEFAULT
				: newAre_you_allowing_data_unauthorised_access;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CAMERA__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS,
					oldAre_you_allowing_data_unauthorised_access, are_you_allowing_data_unauthorised_access));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
			Answer newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes) {
		Answer oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes = are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes == null
				? ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT
				: newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CAMERA__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
					oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes,
					are_you_storing_the_data_longer_than_is_necessary_for_the_purposes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getIs_data_against_accidental_loss_or_destruction_or_damage() {
		return is_data_against_accidental_loss_or_destruction_or_damage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIs_data_against_accidental_loss_or_destruction_or_damage(
			Answer newIs_data_against_accidental_loss_or_destruction_or_damage) {
		Answer oldIs_data_against_accidental_loss_or_destruction_or_damage = is_data_against_accidental_loss_or_destruction_or_damage;
		is_data_against_accidental_loss_or_destruction_or_damage = newIs_data_against_accidental_loss_or_destruction_or_damage == null
				? IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT
				: newIs_data_against_accidental_loss_or_destruction_or_damage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CAMERA__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE,
					oldIs_data_against_accidental_loss_or_destruction_or_damage,
					is_data_against_accidental_loss_or_destruction_or_damage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudService getCloudservice() {
		if (cloudservice != null && cloudservice.eIsProxy()) {
			InternalEObject oldCloudservice = (InternalEObject) cloudservice;
			cloudservice = (CloudService) eResolveProxy(oldCloudservice);
			if (cloudservice != oldCloudservice) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.CAMERA__CLOUDSERVICE,
							oldCloudservice, cloudservice));
			}
		}
		return cloudservice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudService basicGetCloudservice() {
		return cloudservice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCloudservice(CloudService newCloudservice, NotificationChain msgs) {
		CloudService oldCloudservice = cloudservice;
		cloudservice = newCloudservice;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CAMERA__CLOUDSERVICE, oldCloudservice, newCloudservice);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCloudservice(CloudService newCloudservice) {
		if (newCloudservice != cloudservice) {
			NotificationChain msgs = null;
			if (cloudservice != null)
				msgs = ((InternalEObject) cloudservice).eInverseRemove(this, Cgm3Package.CLOUD_SERVICE__CAMERA,
						CloudService.class, msgs);
			if (newCloudservice != null)
				msgs = ((InternalEObject) newCloudservice).eInverseAdd(this, Cgm3Package.CLOUD_SERVICE__CAMERA,
						CloudService.class, msgs);
			msgs = basicSetCloudservice(newCloudservice, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CAMERA__CLOUDSERVICE, newCloudservice,
					newCloudservice));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.CAMERA__CLOUDSERVICE:
			if (cloudservice != null)
				msgs = ((InternalEObject) cloudservice).eInverseRemove(this, Cgm3Package.CLOUD_SERVICE__CAMERA,
						CloudService.class, msgs);
			return basicSetCloudservice((CloudService) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.CAMERA__CLOUDSERVICE:
			return basicSetCloudservice(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.CAMERA__ENCRYPTED_DATA:
			return getEncryptedData();
		case Cgm3Package.CAMERA__PRIVACY_PATTERNS:
			return getPrivacy_patterns();
		case Cgm3Package.CAMERA__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION:
			return getAre_you_sending_data_without_anonymisation();
		case Cgm3Package.CAMERA__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV:
			return getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV();
		case Cgm3Package.CAMERA__DO_PEOPLE_AWARE_OF_BEING_RECORDED:
			return getDo_people_aware_of_being_recorded();
		case Cgm3Package.CAMERA__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			return getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();
		case Cgm3Package.CAMERA__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION:
			return getAre_you_storing_the_footage_in_a_secure_location();
		case Cgm3Package.CAMERA__ENSURE_DATA_MINIMISATION_IS_APLIED:
			return getEnsure_data_minimisation_is_aplied();
		case Cgm3Package.CAMERA__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION:
			return getDo_you_use_signs_that_say_CCTV_is_in_operation();
		case Cgm3Package.CAMERA__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			return getDoes_the_system_record_information_other_than_the_purpose();
		case Cgm3Package.CAMERA__RECORD_RETENTION_PERIOD:
			return getRecord_retention_period();
		case Cgm3Package.CAMERA__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS:
			return getAre_you_allowing_data_unauthorised_access();
		case Cgm3Package.CAMERA__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();
		case Cgm3Package.CAMERA__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			return getIs_data_against_accidental_loss_or_destruction_or_damage();
		case Cgm3Package.CAMERA__CLOUDSERVICE:
			if (resolve)
				return getCloudservice();
			return basicGetCloudservice();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.CAMERA__ENCRYPTED_DATA:
			setEncryptedData((Checked) newValue);
			return;
		case Cgm3Package.CAMERA__PRIVACY_PATTERNS:
			setPrivacy_patterns((String) newValue);
			return;
		case Cgm3Package.CAMERA__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION:
			setAre_you_sending_data_without_anonymisation((Answer) newValue);
			return;
		case Cgm3Package.CAMERA__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV:
			setDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV((Answer) newValue);
			return;
		case Cgm3Package.CAMERA__DO_PEOPLE_AWARE_OF_BEING_RECORDED:
			setDo_people_aware_of_being_recorded((Answer) newValue);
			return;
		case Cgm3Package.CAMERA__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data((Answer) newValue);
			return;
		case Cgm3Package.CAMERA__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION:
			setAre_you_storing_the_footage_in_a_secure_location((Answer) newValue);
			return;
		case Cgm3Package.CAMERA__ENSURE_DATA_MINIMISATION_IS_APLIED:
			setEnsure_data_minimisation_is_aplied((Answer) newValue);
			return;
		case Cgm3Package.CAMERA__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION:
			setDo_you_use_signs_that_say_CCTV_is_in_operation((Answer) newValue);
			return;
		case Cgm3Package.CAMERA__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			setDoes_the_system_record_information_other_than_the_purpose((Answer) newValue);
			return;
		case Cgm3Package.CAMERA__RECORD_RETENTION_PERIOD:
			setRecord_retention_period((DataRetentionEnum) newValue);
			return;
		case Cgm3Package.CAMERA__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS:
			setAre_you_allowing_data_unauthorised_access((Answer) newValue);
			return;
		case Cgm3Package.CAMERA__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes((Answer) newValue);
			return;
		case Cgm3Package.CAMERA__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			setIs_data_against_accidental_loss_or_destruction_or_damage((Answer) newValue);
			return;
		case Cgm3Package.CAMERA__CLOUDSERVICE:
			setCloudservice((CloudService) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.CAMERA__ENCRYPTED_DATA:
			setEncryptedData(ENCRYPTED_DATA_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__PRIVACY_PATTERNS:
			setPrivacy_patterns(PRIVACY_PATTERNS_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION:
			setAre_you_sending_data_without_anonymisation(ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV:
			setDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV(
					DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__DO_PEOPLE_AWARE_OF_BEING_RECORDED:
			setDo_people_aware_of_being_recorded(DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(
					ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION:
			setAre_you_storing_the_footage_in_a_secure_location(
					ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__ENSURE_DATA_MINIMISATION_IS_APLIED:
			setEnsure_data_minimisation_is_aplied(ENSURE_DATA_MINIMISATION_IS_APLIED_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION:
			setDo_you_use_signs_that_say_CCTV_is_in_operation(DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			setDoes_the_system_record_information_other_than_the_purpose(
					DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__RECORD_RETENTION_PERIOD:
			setRecord_retention_period(RECORD_RETENTION_PERIOD_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS:
			setAre_you_allowing_data_unauthorised_access(ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
					ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			setIs_data_against_accidental_loss_or_destruction_or_damage(
					IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT);
			return;
		case Cgm3Package.CAMERA__CLOUDSERVICE:
			setCloudservice((CloudService) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.CAMERA__ENCRYPTED_DATA:
			return encryptedData != ENCRYPTED_DATA_EDEFAULT;
		case Cgm3Package.CAMERA__PRIVACY_PATTERNS:
			return PRIVACY_PATTERNS_EDEFAULT == null ? privacy_patterns != null
					: !PRIVACY_PATTERNS_EDEFAULT.equals(privacy_patterns);
		case Cgm3Package.CAMERA__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION:
			return are_you_sending_data_without_anonymisation != ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION_EDEFAULT;
		case Cgm3Package.CAMERA__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV:
			return does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV != DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT;
		case Cgm3Package.CAMERA__DO_PEOPLE_AWARE_OF_BEING_RECORDED:
			return do_people_aware_of_being_recorded != DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT;
		case Cgm3Package.CAMERA__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			return are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data != ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT;
		case Cgm3Package.CAMERA__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION:
			return are_you_storing_the_footage_in_a_secure_location != ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION_EDEFAULT;
		case Cgm3Package.CAMERA__ENSURE_DATA_MINIMISATION_IS_APLIED:
			return ensure_data_minimisation_is_aplied != ENSURE_DATA_MINIMISATION_IS_APLIED_EDEFAULT;
		case Cgm3Package.CAMERA__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION:
			return do_you_use_signs_that_say_CCTV_is_in_operation != DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT;
		case Cgm3Package.CAMERA__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			return does_the_system_record_information_other_than_the_purpose != DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT;
		case Cgm3Package.CAMERA__RECORD_RETENTION_PERIOD:
			return record_retention_period != RECORD_RETENTION_PERIOD_EDEFAULT;
		case Cgm3Package.CAMERA__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS:
			return are_you_allowing_data_unauthorised_access != ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS_EDEFAULT;
		case Cgm3Package.CAMERA__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes != ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;
		case Cgm3Package.CAMERA__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			return is_data_against_accidental_loss_or_destruction_or_damage != IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT;
		case Cgm3Package.CAMERA__CLOUDSERVICE:
			return cloudservice != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.CAMERA__ENCRYPTED_DATA:
				return Cgm3Package.ENCRYPTION__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.CAMERA__PRIVACY_PATTERNS:
				return Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (baseFeatureID) {
			case Cgm3Package.ENCRYPTION__ENCRYPTED_DATA:
				return Cgm3Package.CAMERA__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (baseFeatureID) {
			case Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS:
				return Cgm3Package.CAMERA__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (EncryptedData: ");
		result.append(encryptedData);
		result.append(", Privacy_patterns: ");
		result.append(privacy_patterns);
		result.append(", Are_you_sending_data_without_anonymisation: ");
		result.append(are_you_sending_data_without_anonymisation);
		result.append(", Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV: ");
		result.append(does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV);
		result.append(", Do_people_aware_of_being_recorded: ");
		result.append(do_people_aware_of_being_recorded);
		result.append(", Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data: ");
		result.append(are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data);
		result.append(", Are_you_storing_the_footage_in_a_secure_location: ");
		result.append(are_you_storing_the_footage_in_a_secure_location);
		result.append(", Ensure_data_minimisation_is_aplied: ");
		result.append(ensure_data_minimisation_is_aplied);
		result.append(", Do_you_use_signs_that_say_CCTV_is_in_operation: ");
		result.append(do_you_use_signs_that_say_CCTV_is_in_operation);
		result.append(", Does_the_system_record_information_other_than_the_purpose: ");
		result.append(does_the_system_record_information_other_than_the_purpose);
		result.append(", Record_retention_period: ");
		result.append(record_retention_period);
		result.append(", Are_you_allowing_data_unauthorised_access: ");
		result.append(are_you_allowing_data_unauthorised_access);
		result.append(", Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes: ");
		result.append(are_you_storing_the_data_longer_than_is_necessary_for_the_purposes);
		result.append(", Is_data_against_accidental_loss_or_destruction_or_damage: ");
		result.append(is_data_against_accidental_loss_or_destruction_or_damage);
		result.append(')');
		return result.toString();
	}

} //CameraImpl
