/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Authentication;
import com.cardiffuni.pbdproject.cgm3.Authorization;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.Doctor;

import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.Patient;
import com.cardiffuni.pbdproject.cgm3.Website;
import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Doctor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoctorImpl#getEncryptedData <em>Encrypted Data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoctorImpl#getPatient <em>Patient</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoctorImpl#getWebsite <em>Website</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoctorImpl#getSpecialty <em>Specialty</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoctorImpl#getAuthentication <em>Authentication</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoctorImpl#getAuthorization <em>Authorization</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoctorImpl#getAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data <em>Are you allowing unauthorised doctors to access or process the data subject health data</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DoctorImpl extends GeneralEntityImpl implements Doctor {
	/**
	 * The default value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENCRYPTED_DATA_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected Checked encryptedData = ENCRYPTED_DATA_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPatient() <em>Patient</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatient()
	 * @generated
	 * @ordered
	 */
	protected Patient patient;

	/**
	 * The cached value of the '{@link #getWebsite() <em>Website</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWebsite()
	 * @generated
	 * @ordered
	 */
	protected Website website;
	/**
	 * The default value of the '{@link #getSpecialty() <em>Specialty</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpecialty()
	 * @generated
	 * @ordered
	 */
	protected static final String SPECIALTY_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getSpecialty() <em>Specialty</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSpecialty()
	 * @generated
	 * @ordered
	 */
	protected String specialty = SPECIALTY_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAuthentication() <em>Authentication</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAuthentication()
	 * @generated
	 * @ordered
	 */
	protected EList<Authentication> authentication;

	/**
	 * The cached value of the '{@link #getAuthorization() <em>Authorization</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAuthorization()
	 * @generated
	 * @ordered
	 */
	protected EList<Authorization> authorization;

	/**
	 * The default value of the '{@link #getAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data() <em>Are you allowing unauthorised doctors to access or process the data subject health data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_ALLOWING_UNAUTHORISED_DOCTORS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_HEALTH_DATA_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data() <em>Are you allowing unauthorised doctors to access or process the data subject health data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data = ARE_YOU_ALLOWING_UNAUTHORISED_DOCTORS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_HEALTH_DATA_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DoctorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.DOCTOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEncryptedData() {
		return encryptedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncryptedData(Checked newEncryptedData) {
		Checked oldEncryptedData = encryptedData;
		encryptedData = newEncryptedData == null ? ENCRYPTED_DATA_EDEFAULT : newEncryptedData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.DOCTOR__ENCRYPTED_DATA, oldEncryptedData,
					encryptedData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Patient getPatient() {
		if (patient != null && patient.eIsProxy()) {
			InternalEObject oldPatient = (InternalEObject) patient;
			patient = (Patient) eResolveProxy(oldPatient);
			if (patient != oldPatient) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.DOCTOR__PATIENT, oldPatient,
							patient));
			}
		}
		return patient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Patient basicGetPatient() {
		return patient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPatient(Patient newPatient, NotificationChain msgs) {
		Patient oldPatient = patient;
		patient = newPatient;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Cgm3Package.DOCTOR__PATIENT,
					oldPatient, newPatient);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPatient(Patient newPatient) {
		if (newPatient != patient) {
			NotificationChain msgs = null;
			if (patient != null)
				msgs = ((InternalEObject) patient).eInverseRemove(this, Cgm3Package.PATIENT__DOCTOR, Patient.class,
						msgs);
			if (newPatient != null)
				msgs = ((InternalEObject) newPatient).eInverseAdd(this, Cgm3Package.PATIENT__DOCTOR, Patient.class,
						msgs);
			msgs = basicSetPatient(newPatient, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.DOCTOR__PATIENT, newPatient, newPatient));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Website getWebsite() {
		if (website != null && website.eIsProxy()) {
			InternalEObject oldWebsite = (InternalEObject) website;
			website = (Website) eResolveProxy(oldWebsite);
			if (website != oldWebsite) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.DOCTOR__WEBSITE, oldWebsite,
							website));
			}
		}
		return website;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Website basicGetWebsite() {
		return website;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetWebsite(Website newWebsite, NotificationChain msgs) {
		Website oldWebsite = website;
		website = newWebsite;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Cgm3Package.DOCTOR__WEBSITE,
					oldWebsite, newWebsite);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWebsite(Website newWebsite) {
		if (newWebsite != website) {
			NotificationChain msgs = null;
			if (website != null)
				msgs = ((InternalEObject) website).eInverseRemove(this, Cgm3Package.WEBSITE__DOCTOR, Website.class,
						msgs);
			if (newWebsite != null)
				msgs = ((InternalEObject) newWebsite).eInverseAdd(this, Cgm3Package.WEBSITE__DOCTOR, Website.class,
						msgs);
			msgs = basicSetWebsite(newWebsite, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.DOCTOR__WEBSITE, newWebsite, newWebsite));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSpecialty() {
		return specialty;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSpecialty(String newSpecialty) {
		String oldSpecialty = specialty;
		specialty = newSpecialty;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.DOCTOR__SPECIALTY, oldSpecialty,
					specialty));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Authentication> getAuthentication() {
		if (authentication == null) {
			authentication = new EObjectContainmentEList<Authentication>(Authentication.class, this,
					Cgm3Package.DOCTOR__AUTHENTICATION);
		}
		return authentication;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Authorization> getAuthorization() {
		if (authorization == null) {
			authorization = new EObjectContainmentEList<Authorization>(Authorization.class, this,
					Cgm3Package.DOCTOR__AUTHORIZATION);
		}
		return authorization;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data() {
		return are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data(
			Answer newAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data) {
		Answer oldAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data = are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data;
		are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data = newAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data == null
				? ARE_YOU_ALLOWING_UNAUTHORISED_DOCTORS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_HEALTH_DATA_EDEFAULT
				: newAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.DOCTOR__ARE_YOU_ALLOWING_UNAUTHORISED_DOCTORS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_HEALTH_DATA,
					oldAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data,
					are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.DOCTOR__PATIENT:
			if (patient != null)
				msgs = ((InternalEObject) patient).eInverseRemove(this, Cgm3Package.PATIENT__DOCTOR, Patient.class,
						msgs);
			return basicSetPatient((Patient) otherEnd, msgs);
		case Cgm3Package.DOCTOR__WEBSITE:
			if (website != null)
				msgs = ((InternalEObject) website).eInverseRemove(this, Cgm3Package.WEBSITE__DOCTOR, Website.class,
						msgs);
			return basicSetWebsite((Website) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.DOCTOR__PATIENT:
			return basicSetPatient(null, msgs);
		case Cgm3Package.DOCTOR__WEBSITE:
			return basicSetWebsite(null, msgs);
		case Cgm3Package.DOCTOR__AUTHENTICATION:
			return ((InternalEList<?>) getAuthentication()).basicRemove(otherEnd, msgs);
		case Cgm3Package.DOCTOR__AUTHORIZATION:
			return ((InternalEList<?>) getAuthorization()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.DOCTOR__ENCRYPTED_DATA:
			return getEncryptedData();
		case Cgm3Package.DOCTOR__PATIENT:
			if (resolve)
				return getPatient();
			return basicGetPatient();
		case Cgm3Package.DOCTOR__WEBSITE:
			if (resolve)
				return getWebsite();
			return basicGetWebsite();
		case Cgm3Package.DOCTOR__SPECIALTY:
			return getSpecialty();
		case Cgm3Package.DOCTOR__AUTHENTICATION:
			return getAuthentication();
		case Cgm3Package.DOCTOR__AUTHORIZATION:
			return getAuthorization();
		case Cgm3Package.DOCTOR__ARE_YOU_ALLOWING_UNAUTHORISED_DOCTORS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_HEALTH_DATA:
			return getAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.DOCTOR__ENCRYPTED_DATA:
			setEncryptedData((Checked) newValue);
			return;
		case Cgm3Package.DOCTOR__PATIENT:
			setPatient((Patient) newValue);
			return;
		case Cgm3Package.DOCTOR__WEBSITE:
			setWebsite((Website) newValue);
			return;
		case Cgm3Package.DOCTOR__SPECIALTY:
			setSpecialty((String) newValue);
			return;
		case Cgm3Package.DOCTOR__AUTHENTICATION:
			getAuthentication().clear();
			getAuthentication().addAll((Collection<? extends Authentication>) newValue);
			return;
		case Cgm3Package.DOCTOR__AUTHORIZATION:
			getAuthorization().clear();
			getAuthorization().addAll((Collection<? extends Authorization>) newValue);
			return;
		case Cgm3Package.DOCTOR__ARE_YOU_ALLOWING_UNAUTHORISED_DOCTORS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_HEALTH_DATA:
			setAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data(
					(Answer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.DOCTOR__ENCRYPTED_DATA:
			setEncryptedData(ENCRYPTED_DATA_EDEFAULT);
			return;
		case Cgm3Package.DOCTOR__PATIENT:
			setPatient((Patient) null);
			return;
		case Cgm3Package.DOCTOR__WEBSITE:
			setWebsite((Website) null);
			return;
		case Cgm3Package.DOCTOR__SPECIALTY:
			setSpecialty(SPECIALTY_EDEFAULT);
			return;
		case Cgm3Package.DOCTOR__AUTHENTICATION:
			getAuthentication().clear();
			return;
		case Cgm3Package.DOCTOR__AUTHORIZATION:
			getAuthorization().clear();
			return;
		case Cgm3Package.DOCTOR__ARE_YOU_ALLOWING_UNAUTHORISED_DOCTORS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_HEALTH_DATA:
			setAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data(
					ARE_YOU_ALLOWING_UNAUTHORISED_DOCTORS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_HEALTH_DATA_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.DOCTOR__ENCRYPTED_DATA:
			return encryptedData != ENCRYPTED_DATA_EDEFAULT;
		case Cgm3Package.DOCTOR__PATIENT:
			return patient != null;
		case Cgm3Package.DOCTOR__WEBSITE:
			return website != null;
		case Cgm3Package.DOCTOR__SPECIALTY:
			return SPECIALTY_EDEFAULT == null ? specialty != null : !SPECIALTY_EDEFAULT.equals(specialty);
		case Cgm3Package.DOCTOR__AUTHENTICATION:
			return authentication != null && !authentication.isEmpty();
		case Cgm3Package.DOCTOR__AUTHORIZATION:
			return authorization != null && !authorization.isEmpty();
		case Cgm3Package.DOCTOR__ARE_YOU_ALLOWING_UNAUTHORISED_DOCTORS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_HEALTH_DATA:
			return are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data != ARE_YOU_ALLOWING_UNAUTHORISED_DOCTORS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_HEALTH_DATA_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.DOCTOR__ENCRYPTED_DATA:
				return Cgm3Package.ENCRYPTION__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (baseFeatureID) {
			case Cgm3Package.ENCRYPTION__ENCRYPTED_DATA:
				return Cgm3Package.DOCTOR__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (EncryptedData: ");
		result.append(encryptedData);
		result.append(", Specialty: ");
		result.append(specialty);
		result.append(", Are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data: ");
		result.append(are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data);
		result.append(')');
		return result.toString();
	}

} //DoctorImpl
