/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.TestOnDummyData;
import com.cardiffuni.pbdproject.cgm3.Test_on_dummy;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Test on dummy</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.Test_on_dummyImpl#getTesting_on_dummy_data <em>Testing on dummy data</em>}</li>
 * </ul>
 *
 * @generated
 */
public class Test_on_dummyImpl extends GeneralEntityImpl implements Test_on_dummy {
	/**
	 * The default value of the '{@link #getTesting_on_dummy_data() <em>Testing on dummy data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTesting_on_dummy_data()
	 * @generated
	 * @ordered
	 */
	protected static final TestOnDummyData TESTING_ON_DUMMY_DATA_EDEFAULT = TestOnDummyData.TESTING_PHASE_AND_DUMMY_DATA;

	/**
	 * The cached value of the '{@link #getTesting_on_dummy_data() <em>Testing on dummy data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTesting_on_dummy_data()
	 * @generated
	 * @ordered
	 */
	protected TestOnDummyData testing_on_dummy_data = TESTING_ON_DUMMY_DATA_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Test_on_dummyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.TEST_ON_DUMMY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TestOnDummyData getTesting_on_dummy_data() {
		return testing_on_dummy_data;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTesting_on_dummy_data(TestOnDummyData newTesting_on_dummy_data) {
		TestOnDummyData oldTesting_on_dummy_data = testing_on_dummy_data;
		testing_on_dummy_data = newTesting_on_dummy_data == null ? TESTING_ON_DUMMY_DATA_EDEFAULT
				: newTesting_on_dummy_data;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.TEST_ON_DUMMY__TESTING_ON_DUMMY_DATA,
					oldTesting_on_dummy_data, testing_on_dummy_data));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.TEST_ON_DUMMY__TESTING_ON_DUMMY_DATA:
			return getTesting_on_dummy_data();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.TEST_ON_DUMMY__TESTING_ON_DUMMY_DATA:
			setTesting_on_dummy_data((TestOnDummyData) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.TEST_ON_DUMMY__TESTING_ON_DUMMY_DATA:
			setTesting_on_dummy_data(TESTING_ON_DUMMY_DATA_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.TEST_ON_DUMMY__TESTING_ON_DUMMY_DATA:
			return testing_on_dummy_data != TESTING_ON_DUMMY_DATA_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Testing_on_dummy_data: ");
		result.append(testing_on_dummy_data);
		result.append(')');
		return result.toString();
	}

} //Test_on_dummyImpl
