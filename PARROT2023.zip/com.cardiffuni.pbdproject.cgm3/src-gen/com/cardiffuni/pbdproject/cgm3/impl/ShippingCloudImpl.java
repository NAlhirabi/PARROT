/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Aggregation;
import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.CloudForPharmacy;
import com.cardiffuni.pbdproject.cgm3.Containerisation;
import com.cardiffuni.pbdproject.cgm3.DataRetentionEnum;
import com.cardiffuni.pbdproject.cgm3.DataSharing;
import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.Privacy_patterns;
import com.cardiffuni.pbdproject.cgm3.ShippingCloud;
import com.cardiffuni.pbdproject.cgm3.SmartPhone;
import com.cardiffuni.pbdproject.cgm3.StorageLocation;
import com.cardiffuni.pbdproject.cgm3.Test_on_dummy;
import com.cardiffuni.pbdproject.cgm3.Website;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Shipping Cloud</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getEncryptedData <em>Encrypted Data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getPrivacy_patterns <em>Privacy patterns</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getSmartphone <em>Smartphone</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getWebsite <em>Website</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getDataRetention <em>Data Retention</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getStoragelocation <em>Storagelocation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getDatasharing <em>Datasharing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getTest_on_dummy <em>Test on dummy</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getContainerisation <em>Containerisation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getAggregation <em>Aggregation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl#getCloudforpharmacy <em>Cloudforpharmacy</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ShippingCloudImpl extends GeneralEntityImpl implements ShippingCloud {
	/**
	 * The default value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENCRYPTED_DATA_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected Checked encryptedData = ENCRYPTED_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected static final String PRIVACY_PATTERNS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected String privacy_patterns = PRIVACY_PATTERNS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSmartphone() <em>Smartphone</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSmartphone()
	 * @generated
	 * @ordered
	 */
	protected SmartPhone smartphone;

	/**
	 * The cached value of the '{@link #getWebsite() <em>Website</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWebsite()
	 * @generated
	 * @ordered
	 */
	protected EList<Website> website;

	/**
	 * The default value of the '{@link #getDataRetention() <em>Data Retention</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataRetention()
	 * @generated
	 * @ordered
	 */
	protected static final DataRetentionEnum DATA_RETENTION_EDEFAULT = DataRetentionEnum.NOT_ACCEPTED;

	/**
	 * The cached value of the '{@link #getDataRetention() <em>Data Retention</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataRetention()
	 * @generated
	 * @ordered
	 */
	protected DataRetentionEnum dataRetention = DATA_RETENTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getStoragelocation() <em>Storagelocation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStoragelocation()
	 * @generated
	 * @ordered
	 */
	protected EList<StorageLocation> storagelocation;

	/**
	 * The cached value of the '{@link #getDatasharing() <em>Datasharing</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDatasharing()
	 * @generated
	 * @ordered
	 */
	protected EList<DataSharing> datasharing;

	/**
	 * The cached value of the '{@link #getTest_on_dummy() <em>Test on dummy</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTest_on_dummy()
	 * @generated
	 * @ordered
	 */
	protected EList<Test_on_dummy> test_on_dummy;

	/**
	 * The cached value of the '{@link #getContainerisation() <em>Containerisation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContainerisation()
	 * @generated
	 * @ordered
	 */
	protected EList<Containerisation> containerisation;

	/**
	 * The cached value of the '{@link #getAggregation() <em>Aggregation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAggregation()
	 * @generated
	 * @ordered
	 */
	protected EList<Aggregation> aggregation;

	/**
	 * The default value of the '{@link #getAre_you_collecting_data_that_are_not_needed_for_the_purpose() <em>Are you collecting data that are not needed for the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_collecting_data_that_are_not_needed_for_the_purpose() <em>Are you collecting data that are not needed for the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_collecting_data_that_are_not_needed_for_the_purpose = ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() <em>Are you processing data in an incompatible way with the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() <em>Are you processing data in an incompatible way with the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_processing_data_in_an_incompatible_way_with_the_purpose = ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent() <em>Are you sharing data with other parties without having data subject consent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent() <em>Are you sharing data with other parties without having data subject consent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_sharing_data_with_other_parties_without_having_data_subject_consent = ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing = ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT;

	/**
	 * The default value of the '{@link #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 * @ordered
	 */
	protected static final Answer IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 * @ordered
	 */
	protected Answer is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCloudforpharmacy() <em>Cloudforpharmacy</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCloudforpharmacy()
	 * @generated
	 * @ordered
	 */
	protected CloudForPharmacy cloudforpharmacy;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ShippingCloudImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.SHIPPING_CLOUD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEncryptedData() {
		return encryptedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncryptedData(Checked newEncryptedData) {
		Checked oldEncryptedData = encryptedData;
		encryptedData = newEncryptedData == null ? ENCRYPTED_DATA_EDEFAULT : newEncryptedData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.SHIPPING_CLOUD__ENCRYPTED_DATA,
					oldEncryptedData, encryptedData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPrivacy_patterns() {
		return privacy_patterns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrivacy_patterns(String newPrivacy_patterns) {
		String oldPrivacy_patterns = privacy_patterns;
		privacy_patterns = newPrivacy_patterns;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.SHIPPING_CLOUD__PRIVACY_PATTERNS,
					oldPrivacy_patterns, privacy_patterns));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartPhone getSmartphone() {
		if (smartphone != null && smartphone.eIsProxy()) {
			InternalEObject oldSmartphone = (InternalEObject) smartphone;
			smartphone = (SmartPhone) eResolveProxy(oldSmartphone);
			if (smartphone != oldSmartphone) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.SHIPPING_CLOUD__SMARTPHONE,
							oldSmartphone, smartphone));
			}
		}
		return smartphone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartPhone basicGetSmartphone() {
		return smartphone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSmartphone(SmartPhone newSmartphone) {
		SmartPhone oldSmartphone = smartphone;
		smartphone = newSmartphone;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.SHIPPING_CLOUD__SMARTPHONE, oldSmartphone,
					smartphone));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Website> getWebsite() {
		if (website == null) {
			website = new EObjectResolvingEList<Website>(Website.class, this, Cgm3Package.SHIPPING_CLOUD__WEBSITE);
		}
		return website;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataRetentionEnum getDataRetention() {
		return dataRetention;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataRetention(DataRetentionEnum newDataRetention) {
		DataRetentionEnum oldDataRetention = dataRetention;
		dataRetention = newDataRetention == null ? DATA_RETENTION_EDEFAULT : newDataRetention;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.SHIPPING_CLOUD__DATA_RETENTION,
					oldDataRetention, dataRetention));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<StorageLocation> getStoragelocation() {
		if (storagelocation == null) {
			storagelocation = new EObjectContainmentEList<StorageLocation>(StorageLocation.class, this,
					Cgm3Package.SHIPPING_CLOUD__STORAGELOCATION);
		}
		return storagelocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DataSharing> getDatasharing() {
		if (datasharing == null) {
			datasharing = new EObjectContainmentEList<DataSharing>(DataSharing.class, this,
					Cgm3Package.SHIPPING_CLOUD__DATASHARING);
		}
		return datasharing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Test_on_dummy> getTest_on_dummy() {
		if (test_on_dummy == null) {
			test_on_dummy = new EObjectContainmentEList<Test_on_dummy>(Test_on_dummy.class, this,
					Cgm3Package.SHIPPING_CLOUD__TEST_ON_DUMMY);
		}
		return test_on_dummy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Containerisation> getContainerisation() {
		if (containerisation == null) {
			containerisation = new EObjectContainmentEList<Containerisation>(Containerisation.class, this,
					Cgm3Package.SHIPPING_CLOUD__CONTAINERISATION);
		}
		return containerisation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Aggregation> getAggregation() {
		if (aggregation == null) {
			aggregation = new EObjectContainmentEList<Aggregation>(Aggregation.class, this,
					Cgm3Package.SHIPPING_CLOUD__AGGREGATION);
		}
		return aggregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_collecting_data_that_are_not_needed_for_the_purpose() {
		return are_you_collecting_data_that_are_not_needed_for_the_purpose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_collecting_data_that_are_not_needed_for_the_purpose(
			Answer newAre_you_collecting_data_that_are_not_needed_for_the_purpose) {
		Answer oldAre_you_collecting_data_that_are_not_needed_for_the_purpose = are_you_collecting_data_that_are_not_needed_for_the_purpose;
		are_you_collecting_data_that_are_not_needed_for_the_purpose = newAre_you_collecting_data_that_are_not_needed_for_the_purpose == null
				? ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT
				: newAre_you_collecting_data_that_are_not_needed_for_the_purpose;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.SHIPPING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE,
					oldAre_you_collecting_data_that_are_not_needed_for_the_purpose,
					are_you_collecting_data_that_are_not_needed_for_the_purpose));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return are_you_processing_data_in_an_incompatible_way_with_the_purpose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(
			Answer newAre_you_processing_data_in_an_incompatible_way_with_the_purpose) {
		Answer oldAre_you_processing_data_in_an_incompatible_way_with_the_purpose = are_you_processing_data_in_an_incompatible_way_with_the_purpose;
		are_you_processing_data_in_an_incompatible_way_with_the_purpose = newAre_you_processing_data_in_an_incompatible_way_with_the_purpose == null
				? ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT
				: newAre_you_processing_data_in_an_incompatible_way_with_the_purpose;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.SHIPPING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE,
					oldAre_you_processing_data_in_an_incompatible_way_with_the_purpose,
					are_you_processing_data_in_an_incompatible_way_with_the_purpose));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent() {
		return are_you_sharing_data_with_other_parties_without_having_data_subject_consent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_sharing_data_with_other_parties_without_having_data_subject_consent(
			Answer newAre_you_sharing_data_with_other_parties_without_having_data_subject_consent) {
		Answer oldAre_you_sharing_data_with_other_parties_without_having_data_subject_consent = are_you_sharing_data_with_other_parties_without_having_data_subject_consent;
		are_you_sharing_data_with_other_parties_without_having_data_subject_consent = newAre_you_sharing_data_with_other_parties_without_having_data_subject_consent == null
				? ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT
				: newAre_you_sharing_data_with_other_parties_without_having_data_subject_consent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.SHIPPING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT,
					oldAre_you_sharing_data_with_other_parties_without_having_data_subject_consent,
					are_you_sharing_data_with_other_parties_without_having_data_subject_consent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
			Answer newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes) {
		Answer oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes = are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes == null
				? ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT
				: newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.SHIPPING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
					oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes,
					are_you_storing_the_data_longer_than_is_necessary_for_the_purposes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() {
		return are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(
			Answer newAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing) {
		Answer oldAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing = are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing;
		are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing = newAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing == null
				? ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT
				: newAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.SHIPPING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING,
					oldAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing,
					are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
			Answer newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures) {
		Answer oldIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
		is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures == null
				? IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT
				: newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.SHIPPING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES,
					oldIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures,
					is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudForPharmacy getCloudforpharmacy() {
		if (cloudforpharmacy != null && cloudforpharmacy.eIsProxy()) {
			InternalEObject oldCloudforpharmacy = (InternalEObject) cloudforpharmacy;
			cloudforpharmacy = (CloudForPharmacy) eResolveProxy(oldCloudforpharmacy);
			if (cloudforpharmacy != oldCloudforpharmacy) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Cgm3Package.SHIPPING_CLOUD__CLOUDFORPHARMACY, oldCloudforpharmacy, cloudforpharmacy));
			}
		}
		return cloudforpharmacy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudForPharmacy basicGetCloudforpharmacy() {
		return cloudforpharmacy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCloudforpharmacy(CloudForPharmacy newCloudforpharmacy, NotificationChain msgs) {
		CloudForPharmacy oldCloudforpharmacy = cloudforpharmacy;
		cloudforpharmacy = newCloudforpharmacy;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.SHIPPING_CLOUD__CLOUDFORPHARMACY, oldCloudforpharmacy, newCloudforpharmacy);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCloudforpharmacy(CloudForPharmacy newCloudforpharmacy) {
		if (newCloudforpharmacy != cloudforpharmacy) {
			NotificationChain msgs = null;
			if (cloudforpharmacy != null)
				msgs = ((InternalEObject) cloudforpharmacy).eInverseRemove(this,
						Cgm3Package.CLOUD_FOR_PHARMACY__SHIPPINGCLOUD, CloudForPharmacy.class, msgs);
			if (newCloudforpharmacy != null)
				msgs = ((InternalEObject) newCloudforpharmacy).eInverseAdd(this,
						Cgm3Package.CLOUD_FOR_PHARMACY__SHIPPINGCLOUD, CloudForPharmacy.class, msgs);
			msgs = basicSetCloudforpharmacy(newCloudforpharmacy, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.SHIPPING_CLOUD__CLOUDFORPHARMACY,
					newCloudforpharmacy, newCloudforpharmacy));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.SHIPPING_CLOUD__CLOUDFORPHARMACY:
			if (cloudforpharmacy != null)
				msgs = ((InternalEObject) cloudforpharmacy).eInverseRemove(this,
						Cgm3Package.CLOUD_FOR_PHARMACY__SHIPPINGCLOUD, CloudForPharmacy.class, msgs);
			return basicSetCloudforpharmacy((CloudForPharmacy) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.SHIPPING_CLOUD__STORAGELOCATION:
			return ((InternalEList<?>) getStoragelocation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.SHIPPING_CLOUD__DATASHARING:
			return ((InternalEList<?>) getDatasharing()).basicRemove(otherEnd, msgs);
		case Cgm3Package.SHIPPING_CLOUD__TEST_ON_DUMMY:
			return ((InternalEList<?>) getTest_on_dummy()).basicRemove(otherEnd, msgs);
		case Cgm3Package.SHIPPING_CLOUD__CONTAINERISATION:
			return ((InternalEList<?>) getContainerisation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.SHIPPING_CLOUD__AGGREGATION:
			return ((InternalEList<?>) getAggregation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.SHIPPING_CLOUD__CLOUDFORPHARMACY:
			return basicSetCloudforpharmacy(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.SHIPPING_CLOUD__ENCRYPTED_DATA:
			return getEncryptedData();
		case Cgm3Package.SHIPPING_CLOUD__PRIVACY_PATTERNS:
			return getPrivacy_patterns();
		case Cgm3Package.SHIPPING_CLOUD__SMARTPHONE:
			if (resolve)
				return getSmartphone();
			return basicGetSmartphone();
		case Cgm3Package.SHIPPING_CLOUD__WEBSITE:
			return getWebsite();
		case Cgm3Package.SHIPPING_CLOUD__DATA_RETENTION:
			return getDataRetention();
		case Cgm3Package.SHIPPING_CLOUD__STORAGELOCATION:
			return getStoragelocation();
		case Cgm3Package.SHIPPING_CLOUD__DATASHARING:
			return getDatasharing();
		case Cgm3Package.SHIPPING_CLOUD__TEST_ON_DUMMY:
			return getTest_on_dummy();
		case Cgm3Package.SHIPPING_CLOUD__CONTAINERISATION:
			return getContainerisation();
		case Cgm3Package.SHIPPING_CLOUD__AGGREGATION:
			return getAggregation();
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE:
			return getAre_you_collecting_data_that_are_not_needed_for_the_purpose();
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			return getAre_you_processing_data_in_an_incompatible_way_with_the_purpose();
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT:
			return getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent();
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING:
			return getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();
		case Cgm3Package.SHIPPING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			return getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();
		case Cgm3Package.SHIPPING_CLOUD__CLOUDFORPHARMACY:
			if (resolve)
				return getCloudforpharmacy();
			return basicGetCloudforpharmacy();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.SHIPPING_CLOUD__ENCRYPTED_DATA:
			setEncryptedData((Checked) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__PRIVACY_PATTERNS:
			setPrivacy_patterns((String) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__SMARTPHONE:
			setSmartphone((SmartPhone) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__WEBSITE:
			getWebsite().clear();
			getWebsite().addAll((Collection<? extends Website>) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__DATA_RETENTION:
			setDataRetention((DataRetentionEnum) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__STORAGELOCATION:
			getStoragelocation().clear();
			getStoragelocation().addAll((Collection<? extends StorageLocation>) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__DATASHARING:
			getDatasharing().clear();
			getDatasharing().addAll((Collection<? extends DataSharing>) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__TEST_ON_DUMMY:
			getTest_on_dummy().clear();
			getTest_on_dummy().addAll((Collection<? extends Test_on_dummy>) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__CONTAINERISATION:
			getContainerisation().clear();
			getContainerisation().addAll((Collection<? extends Containerisation>) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__AGGREGATION:
			getAggregation().clear();
			getAggregation().addAll((Collection<? extends Aggregation>) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE:
			setAre_you_collecting_data_that_are_not_needed_for_the_purpose((Answer) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			setAre_you_processing_data_in_an_incompatible_way_with_the_purpose((Answer) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT:
			setAre_you_sharing_data_with_other_parties_without_having_data_subject_consent((Answer) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes((Answer) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING:
			setAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(
					(Answer) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
					(Answer) newValue);
			return;
		case Cgm3Package.SHIPPING_CLOUD__CLOUDFORPHARMACY:
			setCloudforpharmacy((CloudForPharmacy) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.SHIPPING_CLOUD__ENCRYPTED_DATA:
			setEncryptedData(ENCRYPTED_DATA_EDEFAULT);
			return;
		case Cgm3Package.SHIPPING_CLOUD__PRIVACY_PATTERNS:
			setPrivacy_patterns(PRIVACY_PATTERNS_EDEFAULT);
			return;
		case Cgm3Package.SHIPPING_CLOUD__SMARTPHONE:
			setSmartphone((SmartPhone) null);
			return;
		case Cgm3Package.SHIPPING_CLOUD__WEBSITE:
			getWebsite().clear();
			return;
		case Cgm3Package.SHIPPING_CLOUD__DATA_RETENTION:
			setDataRetention(DATA_RETENTION_EDEFAULT);
			return;
		case Cgm3Package.SHIPPING_CLOUD__STORAGELOCATION:
			getStoragelocation().clear();
			return;
		case Cgm3Package.SHIPPING_CLOUD__DATASHARING:
			getDatasharing().clear();
			return;
		case Cgm3Package.SHIPPING_CLOUD__TEST_ON_DUMMY:
			getTest_on_dummy().clear();
			return;
		case Cgm3Package.SHIPPING_CLOUD__CONTAINERISATION:
			getContainerisation().clear();
			return;
		case Cgm3Package.SHIPPING_CLOUD__AGGREGATION:
			getAggregation().clear();
			return;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE:
			setAre_you_collecting_data_that_are_not_needed_for_the_purpose(
					ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT);
			return;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(
					ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT);
			return;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT:
			setAre_you_sharing_data_with_other_parties_without_having_data_subject_consent(
					ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT);
			return;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
					ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT);
			return;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING:
			setAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(
					ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT);
			return;
		case Cgm3Package.SHIPPING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
					IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT);
			return;
		case Cgm3Package.SHIPPING_CLOUD__CLOUDFORPHARMACY:
			setCloudforpharmacy((CloudForPharmacy) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.SHIPPING_CLOUD__ENCRYPTED_DATA:
			return encryptedData != ENCRYPTED_DATA_EDEFAULT;
		case Cgm3Package.SHIPPING_CLOUD__PRIVACY_PATTERNS:
			return PRIVACY_PATTERNS_EDEFAULT == null ? privacy_patterns != null
					: !PRIVACY_PATTERNS_EDEFAULT.equals(privacy_patterns);
		case Cgm3Package.SHIPPING_CLOUD__SMARTPHONE:
			return smartphone != null;
		case Cgm3Package.SHIPPING_CLOUD__WEBSITE:
			return website != null && !website.isEmpty();
		case Cgm3Package.SHIPPING_CLOUD__DATA_RETENTION:
			return dataRetention != DATA_RETENTION_EDEFAULT;
		case Cgm3Package.SHIPPING_CLOUD__STORAGELOCATION:
			return storagelocation != null && !storagelocation.isEmpty();
		case Cgm3Package.SHIPPING_CLOUD__DATASHARING:
			return datasharing != null && !datasharing.isEmpty();
		case Cgm3Package.SHIPPING_CLOUD__TEST_ON_DUMMY:
			return test_on_dummy != null && !test_on_dummy.isEmpty();
		case Cgm3Package.SHIPPING_CLOUD__CONTAINERISATION:
			return containerisation != null && !containerisation.isEmpty();
		case Cgm3Package.SHIPPING_CLOUD__AGGREGATION:
			return aggregation != null && !aggregation.isEmpty();
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE:
			return are_you_collecting_data_that_are_not_needed_for_the_purpose != ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			return are_you_processing_data_in_an_incompatible_way_with_the_purpose != ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT:
			return are_you_sharing_data_with_other_parties_without_having_data_subject_consent != ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes != ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;
		case Cgm3Package.SHIPPING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING:
			return are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing != ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT;
		case Cgm3Package.SHIPPING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			return is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures != IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT;
		case Cgm3Package.SHIPPING_CLOUD__CLOUDFORPHARMACY:
			return cloudforpharmacy != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.SHIPPING_CLOUD__ENCRYPTED_DATA:
				return Cgm3Package.ENCRYPTION__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.SHIPPING_CLOUD__PRIVACY_PATTERNS:
				return Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (baseFeatureID) {
			case Cgm3Package.ENCRYPTION__ENCRYPTED_DATA:
				return Cgm3Package.SHIPPING_CLOUD__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (baseFeatureID) {
			case Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS:
				return Cgm3Package.SHIPPING_CLOUD__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (EncryptedData: ");
		result.append(encryptedData);
		result.append(", Privacy_patterns: ");
		result.append(privacy_patterns);
		result.append(", DataRetention: ");
		result.append(dataRetention);
		result.append(", Are_you_collecting_data_that_are_not_needed_for_the_purpose: ");
		result.append(are_you_collecting_data_that_are_not_needed_for_the_purpose);
		result.append(", Are_you_processing_data_in_an_incompatible_way_with_the_purpose: ");
		result.append(are_you_processing_data_in_an_incompatible_way_with_the_purpose);
		result.append(", Are_you_sharing_data_with_other_parties_without_having_data_subject_consent: ");
		result.append(are_you_sharing_data_with_other_parties_without_having_data_subject_consent);
		result.append(", Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes: ");
		result.append(are_you_storing_the_data_longer_than_is_necessary_for_the_purposes);
		result.append(", Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing: ");
		result.append(are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing);
		result.append(
				", Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures: ");
		result.append(
				is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures);
		result.append(')');
		return result.toString();
	}

} //ShippingCloudImpl
