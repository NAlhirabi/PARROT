/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Aggregation;
import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.CloudForPharmacy;
import com.cardiffuni.pbdproject.cgm3.Containerisation;
import com.cardiffuni.pbdproject.cgm3.DataRetentionEnum;
import com.cardiffuni.pbdproject.cgm3.DataSharing;
import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.PaymentCloud;
import com.cardiffuni.pbdproject.cgm3.Privacy_patterns;
import com.cardiffuni.pbdproject.cgm3.ShippingCloud;
import com.cardiffuni.pbdproject.cgm3.SmartPhone;
import com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud;
import com.cardiffuni.pbdproject.cgm3.StorageLocation;
import com.cardiffuni.pbdproject.cgm3.Test_on_dummy;
import com.cardiffuni.pbdproject.cgm3.WebBrowser;

import com.cardiffuni.pbdproject.cgm3.WebhostingCloud;
import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Cloud For Pharmacy</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getPrivacy_patterns <em>Privacy patterns</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getEncryptedData <em>Encrypted Data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getSmartphone <em>Smartphone</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getWebbrowser <em>Webbrowser</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getStoragelocation <em>Storagelocation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getTest_on_dummy <em>Test on dummy</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getContainerisation <em>Containerisation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getAggregation <em>Aggregation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getDatasharing <em>Datasharing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getDataRetention <em>Data Retention</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getPaymentcloud <em>Paymentcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getSocialnetworkcloud <em>Socialnetworkcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getShippingcloud <em>Shippingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl#getWebhostingcloud <em>Webhostingcloud</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CloudForPharmacyImpl extends GeneralEntityImpl implements CloudForPharmacy {
	/**
	 * The default value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected static final String PRIVACY_PATTERNS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected String privacy_patterns = PRIVACY_PATTERNS_EDEFAULT;

	/**
	 * The default value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENCRYPTED_DATA_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected Checked encryptedData = ENCRYPTED_DATA_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSmartphone() <em>Smartphone</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSmartphone()
	 * @generated
	 * @ordered
	 */
	protected SmartPhone smartphone;

	/**
	 * The cached value of the '{@link #getWebbrowser() <em>Webbrowser</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWebbrowser()
	 * @generated
	 * @ordered
	 */
	protected WebBrowser webbrowser;

	/**
	 * The cached value of the '{@link #getStoragelocation() <em>Storagelocation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStoragelocation()
	 * @generated
	 * @ordered
	 */
	protected EList<StorageLocation> storagelocation;

	/**
	 * The cached value of the '{@link #getTest_on_dummy() <em>Test on dummy</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTest_on_dummy()
	 * @generated
	 * @ordered
	 */
	protected EList<Test_on_dummy> test_on_dummy;

	/**
	 * The cached value of the '{@link #getContainerisation() <em>Containerisation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContainerisation()
	 * @generated
	 * @ordered
	 */
	protected EList<Containerisation> containerisation;

	/**
	 * The cached value of the '{@link #getAggregation() <em>Aggregation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAggregation()
	 * @generated
	 * @ordered
	 */
	protected EList<Aggregation> aggregation;

	/**
	 * The cached value of the '{@link #getDatasharing() <em>Datasharing</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDatasharing()
	 * @generated
	 * @ordered
	 */
	protected EList<DataSharing> datasharing;

	/**
	 * The default value of the '{@link #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing = ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() <em>Are you processing data in an incompatible way with the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() <em>Are you processing data in an incompatible way with the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_processing_data_in_an_incompatible_way_with_the_purpose = ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent() <em>Are you sharing data with other parties without having data subject consent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent() <em>Are you sharing data with other parties without having data subject consent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_sharing_data_with_other_parties_without_having_data_subject_consent = ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT;

	/**
	 * The default value of the '{@link #getDataRetention() <em>Data Retention</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataRetention()
	 * @generated
	 * @ordered
	 */
	protected static final DataRetentionEnum DATA_RETENTION_EDEFAULT = DataRetentionEnum.NOT_ACCEPTED;

	/**
	 * The cached value of the '{@link #getDataRetention() <em>Data Retention</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataRetention()
	 * @generated
	 * @ordered
	 */
	protected DataRetentionEnum dataRetention = DATA_RETENTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 * @ordered
	 */
	protected static final Answer IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 * @ordered
	 */
	protected Answer is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_collecting_data_that_are_not_needed_for_the_purpose() <em>Are you collecting data that are not needed for the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_collecting_data_that_are_not_needed_for_the_purpose() <em>Are you collecting data that are not needed for the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_collecting_data_that_are_not_needed_for_the_purpose = ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPaymentcloud() <em>Paymentcloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPaymentcloud()
	 * @generated
	 * @ordered
	 */
	protected PaymentCloud paymentcloud;

	/**
	 * The cached value of the '{@link #getSocialnetworkcloud() <em>Socialnetworkcloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSocialnetworkcloud()
	 * @generated
	 * @ordered
	 */
	protected SocialNetworkCloud socialnetworkcloud;

	/**
	 * The cached value of the '{@link #getShippingcloud() <em>Shippingcloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getShippingcloud()
	 * @generated
	 * @ordered
	 */
	protected ShippingCloud shippingcloud;

	/**
	 * The cached value of the '{@link #getWebhostingcloud() <em>Webhostingcloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWebhostingcloud()
	 * @generated
	 * @ordered
	 */
	protected WebhostingCloud webhostingcloud;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CloudForPharmacyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.CLOUD_FOR_PHARMACY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPrivacy_patterns() {
		return privacy_patterns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrivacy_patterns(String newPrivacy_patterns) {
		String oldPrivacy_patterns = privacy_patterns;
		privacy_patterns = newPrivacy_patterns;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_FOR_PHARMACY__PRIVACY_PATTERNS,
					oldPrivacy_patterns, privacy_patterns));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEncryptedData() {
		return encryptedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncryptedData(Checked newEncryptedData) {
		Checked oldEncryptedData = encryptedData;
		encryptedData = newEncryptedData == null ? ENCRYPTED_DATA_EDEFAULT : newEncryptedData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_FOR_PHARMACY__ENCRYPTED_DATA,
					oldEncryptedData, encryptedData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartPhone getSmartphone() {
		if (smartphone != null && smartphone.eIsProxy()) {
			InternalEObject oldSmartphone = (InternalEObject) smartphone;
			smartphone = (SmartPhone) eResolveProxy(oldSmartphone);
			if (smartphone != oldSmartphone) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Cgm3Package.CLOUD_FOR_PHARMACY__SMARTPHONE, oldSmartphone, smartphone));
			}
		}
		return smartphone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartPhone basicGetSmartphone() {
		return smartphone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSmartphone(SmartPhone newSmartphone, NotificationChain msgs) {
		SmartPhone oldSmartphone = smartphone;
		smartphone = newSmartphone;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_FOR_PHARMACY__SMARTPHONE, oldSmartphone, newSmartphone);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSmartphone(SmartPhone newSmartphone) {
		if (newSmartphone != smartphone) {
			NotificationChain msgs = null;
			if (smartphone != null)
				msgs = ((InternalEObject) smartphone).eInverseRemove(this, Cgm3Package.SMART_PHONE__CLOUDFORPHARMACY,
						SmartPhone.class, msgs);
			if (newSmartphone != null)
				msgs = ((InternalEObject) newSmartphone).eInverseAdd(this, Cgm3Package.SMART_PHONE__CLOUDFORPHARMACY,
						SmartPhone.class, msgs);
			msgs = basicSetSmartphone(newSmartphone, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_FOR_PHARMACY__SMARTPHONE,
					newSmartphone, newSmartphone));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebBrowser getWebbrowser() {
		if (webbrowser != null && webbrowser.eIsProxy()) {
			InternalEObject oldWebbrowser = (InternalEObject) webbrowser;
			webbrowser = (WebBrowser) eResolveProxy(oldWebbrowser);
			if (webbrowser != oldWebbrowser) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Cgm3Package.CLOUD_FOR_PHARMACY__WEBBROWSER, oldWebbrowser, webbrowser));
			}
		}
		return webbrowser;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebBrowser basicGetWebbrowser() {
		return webbrowser;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetWebbrowser(WebBrowser newWebbrowser, NotificationChain msgs) {
		WebBrowser oldWebbrowser = webbrowser;
		webbrowser = newWebbrowser;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_FOR_PHARMACY__WEBBROWSER, oldWebbrowser, newWebbrowser);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWebbrowser(WebBrowser newWebbrowser) {
		if (newWebbrowser != webbrowser) {
			NotificationChain msgs = null;
			if (webbrowser != null)
				msgs = ((InternalEObject) webbrowser).eInverseRemove(this, Cgm3Package.WEB_BROWSER__CLOUDFORPHARMACY,
						WebBrowser.class, msgs);
			if (newWebbrowser != null)
				msgs = ((InternalEObject) newWebbrowser).eInverseAdd(this, Cgm3Package.WEB_BROWSER__CLOUDFORPHARMACY,
						WebBrowser.class, msgs);
			msgs = basicSetWebbrowser(newWebbrowser, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_FOR_PHARMACY__WEBBROWSER,
					newWebbrowser, newWebbrowser));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<StorageLocation> getStoragelocation() {
		if (storagelocation == null) {
			storagelocation = new EObjectContainmentEList<StorageLocation>(StorageLocation.class, this,
					Cgm3Package.CLOUD_FOR_PHARMACY__STORAGELOCATION);
		}
		return storagelocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Test_on_dummy> getTest_on_dummy() {
		if (test_on_dummy == null) {
			test_on_dummy = new EObjectContainmentEList<Test_on_dummy>(Test_on_dummy.class, this,
					Cgm3Package.CLOUD_FOR_PHARMACY__TEST_ON_DUMMY);
		}
		return test_on_dummy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Containerisation> getContainerisation() {
		if (containerisation == null) {
			containerisation = new EObjectContainmentEList<Containerisation>(Containerisation.class, this,
					Cgm3Package.CLOUD_FOR_PHARMACY__CONTAINERISATION);
		}
		return containerisation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Aggregation> getAggregation() {
		if (aggregation == null) {
			aggregation = new EObjectContainmentEList<Aggregation>(Aggregation.class, this,
					Cgm3Package.CLOUD_FOR_PHARMACY__AGGREGATION);
		}
		return aggregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DataSharing> getDatasharing() {
		if (datasharing == null) {
			datasharing = new EObjectContainmentEList<DataSharing>(DataSharing.class, this,
					Cgm3Package.CLOUD_FOR_PHARMACY__DATASHARING);
		}
		return datasharing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() {
		return are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(
			Answer newAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing) {
		Answer oldAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing = are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing;
		are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing = newAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing == null
				? ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT
				: newAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING,
					oldAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing,
					are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return are_you_processing_data_in_an_incompatible_way_with_the_purpose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(
			Answer newAre_you_processing_data_in_an_incompatible_way_with_the_purpose) {
		Answer oldAre_you_processing_data_in_an_incompatible_way_with_the_purpose = are_you_processing_data_in_an_incompatible_way_with_the_purpose;
		are_you_processing_data_in_an_incompatible_way_with_the_purpose = newAre_you_processing_data_in_an_incompatible_way_with_the_purpose == null
				? ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT
				: newAre_you_processing_data_in_an_incompatible_way_with_the_purpose;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE,
					oldAre_you_processing_data_in_an_incompatible_way_with_the_purpose,
					are_you_processing_data_in_an_incompatible_way_with_the_purpose));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
			Answer newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes) {
		Answer oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes = are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes == null
				? ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT
				: newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
					oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes,
					are_you_storing_the_data_longer_than_is_necessary_for_the_purposes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent() {
		return are_you_sharing_data_with_other_parties_without_having_data_subject_consent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_sharing_data_with_other_parties_without_having_data_subject_consent(
			Answer newAre_you_sharing_data_with_other_parties_without_having_data_subject_consent) {
		Answer oldAre_you_sharing_data_with_other_parties_without_having_data_subject_consent = are_you_sharing_data_with_other_parties_without_having_data_subject_consent;
		are_you_sharing_data_with_other_parties_without_having_data_subject_consent = newAre_you_sharing_data_with_other_parties_without_having_data_subject_consent == null
				? ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT
				: newAre_you_sharing_data_with_other_parties_without_having_data_subject_consent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT,
					oldAre_you_sharing_data_with_other_parties_without_having_data_subject_consent,
					are_you_sharing_data_with_other_parties_without_having_data_subject_consent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataRetentionEnum getDataRetention() {
		return dataRetention;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataRetention(DataRetentionEnum newDataRetention) {
		DataRetentionEnum oldDataRetention = dataRetention;
		dataRetention = newDataRetention == null ? DATA_RETENTION_EDEFAULT : newDataRetention;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_FOR_PHARMACY__DATA_RETENTION,
					oldDataRetention, dataRetention));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
			Answer newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures) {
		Answer oldIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
		is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures == null
				? IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT
				: newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_FOR_PHARMACY__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES,
					oldIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures,
					is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_collecting_data_that_are_not_needed_for_the_purpose() {
		return are_you_collecting_data_that_are_not_needed_for_the_purpose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_collecting_data_that_are_not_needed_for_the_purpose(
			Answer newAre_you_collecting_data_that_are_not_needed_for_the_purpose) {
		Answer oldAre_you_collecting_data_that_are_not_needed_for_the_purpose = are_you_collecting_data_that_are_not_needed_for_the_purpose;
		are_you_collecting_data_that_are_not_needed_for_the_purpose = newAre_you_collecting_data_that_are_not_needed_for_the_purpose == null
				? ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT
				: newAre_you_collecting_data_that_are_not_needed_for_the_purpose;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE,
					oldAre_you_collecting_data_that_are_not_needed_for_the_purpose,
					are_you_collecting_data_that_are_not_needed_for_the_purpose));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaymentCloud getPaymentcloud() {
		if (paymentcloud != null && paymentcloud.eIsProxy()) {
			InternalEObject oldPaymentcloud = (InternalEObject) paymentcloud;
			paymentcloud = (PaymentCloud) eResolveProxy(oldPaymentcloud);
			if (paymentcloud != oldPaymentcloud) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Cgm3Package.CLOUD_FOR_PHARMACY__PAYMENTCLOUD, oldPaymentcloud, paymentcloud));
			}
		}
		return paymentcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaymentCloud basicGetPaymentcloud() {
		return paymentcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPaymentcloud(PaymentCloud newPaymentcloud, NotificationChain msgs) {
		PaymentCloud oldPaymentcloud = paymentcloud;
		paymentcloud = newPaymentcloud;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_FOR_PHARMACY__PAYMENTCLOUD, oldPaymentcloud, newPaymentcloud);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPaymentcloud(PaymentCloud newPaymentcloud) {
		if (newPaymentcloud != paymentcloud) {
			NotificationChain msgs = null;
			if (paymentcloud != null)
				msgs = ((InternalEObject) paymentcloud).eInverseRemove(this,
						Cgm3Package.PAYMENT_CLOUD__CLOUDFORPHARMACY, PaymentCloud.class, msgs);
			if (newPaymentcloud != null)
				msgs = ((InternalEObject) newPaymentcloud).eInverseAdd(this,
						Cgm3Package.PAYMENT_CLOUD__CLOUDFORPHARMACY, PaymentCloud.class, msgs);
			msgs = basicSetPaymentcloud(newPaymentcloud, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_FOR_PHARMACY__PAYMENTCLOUD,
					newPaymentcloud, newPaymentcloud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SocialNetworkCloud getSocialnetworkcloud() {
		if (socialnetworkcloud != null && socialnetworkcloud.eIsProxy()) {
			InternalEObject oldSocialnetworkcloud = (InternalEObject) socialnetworkcloud;
			socialnetworkcloud = (SocialNetworkCloud) eResolveProxy(oldSocialnetworkcloud);
			if (socialnetworkcloud != oldSocialnetworkcloud) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Cgm3Package.CLOUD_FOR_PHARMACY__SOCIALNETWORKCLOUD, oldSocialnetworkcloud,
							socialnetworkcloud));
			}
		}
		return socialnetworkcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SocialNetworkCloud basicGetSocialnetworkcloud() {
		return socialnetworkcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSocialnetworkcloud(SocialNetworkCloud newSocialnetworkcloud,
			NotificationChain msgs) {
		SocialNetworkCloud oldSocialnetworkcloud = socialnetworkcloud;
		socialnetworkcloud = newSocialnetworkcloud;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_FOR_PHARMACY__SOCIALNETWORKCLOUD, oldSocialnetworkcloud, newSocialnetworkcloud);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSocialnetworkcloud(SocialNetworkCloud newSocialnetworkcloud) {
		if (newSocialnetworkcloud != socialnetworkcloud) {
			NotificationChain msgs = null;
			if (socialnetworkcloud != null)
				msgs = ((InternalEObject) socialnetworkcloud).eInverseRemove(this,
						Cgm3Package.SOCIAL_NETWORK_CLOUD__CLOUDFORPHARMACY, SocialNetworkCloud.class, msgs);
			if (newSocialnetworkcloud != null)
				msgs = ((InternalEObject) newSocialnetworkcloud).eInverseAdd(this,
						Cgm3Package.SOCIAL_NETWORK_CLOUD__CLOUDFORPHARMACY, SocialNetworkCloud.class, msgs);
			msgs = basicSetSocialnetworkcloud(newSocialnetworkcloud, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_FOR_PHARMACY__SOCIALNETWORKCLOUD,
					newSocialnetworkcloud, newSocialnetworkcloud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ShippingCloud getShippingcloud() {
		if (shippingcloud != null && shippingcloud.eIsProxy()) {
			InternalEObject oldShippingcloud = (InternalEObject) shippingcloud;
			shippingcloud = (ShippingCloud) eResolveProxy(oldShippingcloud);
			if (shippingcloud != oldShippingcloud) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Cgm3Package.CLOUD_FOR_PHARMACY__SHIPPINGCLOUD, oldShippingcloud, shippingcloud));
			}
		}
		return shippingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ShippingCloud basicGetShippingcloud() {
		return shippingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetShippingcloud(ShippingCloud newShippingcloud, NotificationChain msgs) {
		ShippingCloud oldShippingcloud = shippingcloud;
		shippingcloud = newShippingcloud;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_FOR_PHARMACY__SHIPPINGCLOUD, oldShippingcloud, newShippingcloud);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setShippingcloud(ShippingCloud newShippingcloud) {
		if (newShippingcloud != shippingcloud) {
			NotificationChain msgs = null;
			if (shippingcloud != null)
				msgs = ((InternalEObject) shippingcloud).eInverseRemove(this,
						Cgm3Package.SHIPPING_CLOUD__CLOUDFORPHARMACY, ShippingCloud.class, msgs);
			if (newShippingcloud != null)
				msgs = ((InternalEObject) newShippingcloud).eInverseAdd(this,
						Cgm3Package.SHIPPING_CLOUD__CLOUDFORPHARMACY, ShippingCloud.class, msgs);
			msgs = basicSetShippingcloud(newShippingcloud, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_FOR_PHARMACY__SHIPPINGCLOUD,
					newShippingcloud, newShippingcloud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebhostingCloud getWebhostingcloud() {
		if (webhostingcloud != null && webhostingcloud.eIsProxy()) {
			InternalEObject oldWebhostingcloud = (InternalEObject) webhostingcloud;
			webhostingcloud = (WebhostingCloud) eResolveProxy(oldWebhostingcloud);
			if (webhostingcloud != oldWebhostingcloud) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Cgm3Package.CLOUD_FOR_PHARMACY__WEBHOSTINGCLOUD, oldWebhostingcloud, webhostingcloud));
			}
		}
		return webhostingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebhostingCloud basicGetWebhostingcloud() {
		return webhostingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetWebhostingcloud(WebhostingCloud newWebhostingcloud, NotificationChain msgs) {
		WebhostingCloud oldWebhostingcloud = webhostingcloud;
		webhostingcloud = newWebhostingcloud;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_FOR_PHARMACY__WEBHOSTINGCLOUD, oldWebhostingcloud, newWebhostingcloud);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWebhostingcloud(WebhostingCloud newWebhostingcloud) {
		if (newWebhostingcloud != webhostingcloud) {
			NotificationChain msgs = null;
			if (webhostingcloud != null)
				msgs = ((InternalEObject) webhostingcloud).eInverseRemove(this,
						Cgm3Package.WEBHOSTING_CLOUD__CLOUDFORPHARMACY, WebhostingCloud.class, msgs);
			if (newWebhostingcloud != null)
				msgs = ((InternalEObject) newWebhostingcloud).eInverseAdd(this,
						Cgm3Package.WEBHOSTING_CLOUD__CLOUDFORPHARMACY, WebhostingCloud.class, msgs);
			msgs = basicSetWebhostingcloud(newWebhostingcloud, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_FOR_PHARMACY__WEBHOSTINGCLOUD,
					newWebhostingcloud, newWebhostingcloud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.CLOUD_FOR_PHARMACY__SMARTPHONE:
			if (smartphone != null)
				msgs = ((InternalEObject) smartphone).eInverseRemove(this, Cgm3Package.SMART_PHONE__CLOUDFORPHARMACY,
						SmartPhone.class, msgs);
			return basicSetSmartphone((SmartPhone) otherEnd, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__WEBBROWSER:
			if (webbrowser != null)
				msgs = ((InternalEObject) webbrowser).eInverseRemove(this, Cgm3Package.WEB_BROWSER__CLOUDFORPHARMACY,
						WebBrowser.class, msgs);
			return basicSetWebbrowser((WebBrowser) otherEnd, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__PAYMENTCLOUD:
			if (paymentcloud != null)
				msgs = ((InternalEObject) paymentcloud).eInverseRemove(this,
						Cgm3Package.PAYMENT_CLOUD__CLOUDFORPHARMACY, PaymentCloud.class, msgs);
			return basicSetPaymentcloud((PaymentCloud) otherEnd, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__SOCIALNETWORKCLOUD:
			if (socialnetworkcloud != null)
				msgs = ((InternalEObject) socialnetworkcloud).eInverseRemove(this,
						Cgm3Package.SOCIAL_NETWORK_CLOUD__CLOUDFORPHARMACY, SocialNetworkCloud.class, msgs);
			return basicSetSocialnetworkcloud((SocialNetworkCloud) otherEnd, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__SHIPPINGCLOUD:
			if (shippingcloud != null)
				msgs = ((InternalEObject) shippingcloud).eInverseRemove(this,
						Cgm3Package.SHIPPING_CLOUD__CLOUDFORPHARMACY, ShippingCloud.class, msgs);
			return basicSetShippingcloud((ShippingCloud) otherEnd, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__WEBHOSTINGCLOUD:
			if (webhostingcloud != null)
				msgs = ((InternalEObject) webhostingcloud).eInverseRemove(this,
						Cgm3Package.WEBHOSTING_CLOUD__CLOUDFORPHARMACY, WebhostingCloud.class, msgs);
			return basicSetWebhostingcloud((WebhostingCloud) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.CLOUD_FOR_PHARMACY__SMARTPHONE:
			return basicSetSmartphone(null, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__WEBBROWSER:
			return basicSetWebbrowser(null, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__STORAGELOCATION:
			return ((InternalEList<?>) getStoragelocation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__TEST_ON_DUMMY:
			return ((InternalEList<?>) getTest_on_dummy()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__CONTAINERISATION:
			return ((InternalEList<?>) getContainerisation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__AGGREGATION:
			return ((InternalEList<?>) getAggregation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__DATASHARING:
			return ((InternalEList<?>) getDatasharing()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__PAYMENTCLOUD:
			return basicSetPaymentcloud(null, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__SOCIALNETWORKCLOUD:
			return basicSetSocialnetworkcloud(null, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__SHIPPINGCLOUD:
			return basicSetShippingcloud(null, msgs);
		case Cgm3Package.CLOUD_FOR_PHARMACY__WEBHOSTINGCLOUD:
			return basicSetWebhostingcloud(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.CLOUD_FOR_PHARMACY__PRIVACY_PATTERNS:
			return getPrivacy_patterns();
		case Cgm3Package.CLOUD_FOR_PHARMACY__ENCRYPTED_DATA:
			return getEncryptedData();
		case Cgm3Package.CLOUD_FOR_PHARMACY__SMARTPHONE:
			if (resolve)
				return getSmartphone();
			return basicGetSmartphone();
		case Cgm3Package.CLOUD_FOR_PHARMACY__WEBBROWSER:
			if (resolve)
				return getWebbrowser();
			return basicGetWebbrowser();
		case Cgm3Package.CLOUD_FOR_PHARMACY__STORAGELOCATION:
			return getStoragelocation();
		case Cgm3Package.CLOUD_FOR_PHARMACY__TEST_ON_DUMMY:
			return getTest_on_dummy();
		case Cgm3Package.CLOUD_FOR_PHARMACY__CONTAINERISATION:
			return getContainerisation();
		case Cgm3Package.CLOUD_FOR_PHARMACY__AGGREGATION:
			return getAggregation();
		case Cgm3Package.CLOUD_FOR_PHARMACY__DATASHARING:
			return getDatasharing();
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING:
			return getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			return getAre_you_processing_data_in_an_incompatible_way_with_the_purpose();
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT:
			return getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent();
		case Cgm3Package.CLOUD_FOR_PHARMACY__DATA_RETENTION:
			return getDataRetention();
		case Cgm3Package.CLOUD_FOR_PHARMACY__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			return getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE:
			return getAre_you_collecting_data_that_are_not_needed_for_the_purpose();
		case Cgm3Package.CLOUD_FOR_PHARMACY__PAYMENTCLOUD:
			if (resolve)
				return getPaymentcloud();
			return basicGetPaymentcloud();
		case Cgm3Package.CLOUD_FOR_PHARMACY__SOCIALNETWORKCLOUD:
			if (resolve)
				return getSocialnetworkcloud();
			return basicGetSocialnetworkcloud();
		case Cgm3Package.CLOUD_FOR_PHARMACY__SHIPPINGCLOUD:
			if (resolve)
				return getShippingcloud();
			return basicGetShippingcloud();
		case Cgm3Package.CLOUD_FOR_PHARMACY__WEBHOSTINGCLOUD:
			if (resolve)
				return getWebhostingcloud();
			return basicGetWebhostingcloud();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.CLOUD_FOR_PHARMACY__PRIVACY_PATTERNS:
			setPrivacy_patterns((String) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ENCRYPTED_DATA:
			setEncryptedData((Checked) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__SMARTPHONE:
			setSmartphone((SmartPhone) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__WEBBROWSER:
			setWebbrowser((WebBrowser) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__STORAGELOCATION:
			getStoragelocation().clear();
			getStoragelocation().addAll((Collection<? extends StorageLocation>) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__TEST_ON_DUMMY:
			getTest_on_dummy().clear();
			getTest_on_dummy().addAll((Collection<? extends Test_on_dummy>) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__CONTAINERISATION:
			getContainerisation().clear();
			getContainerisation().addAll((Collection<? extends Containerisation>) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__AGGREGATION:
			getAggregation().clear();
			getAggregation().addAll((Collection<? extends Aggregation>) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__DATASHARING:
			getDatasharing().clear();
			getDatasharing().addAll((Collection<? extends DataSharing>) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING:
			setAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(
					(Answer) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			setAre_you_processing_data_in_an_incompatible_way_with_the_purpose((Answer) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes((Answer) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT:
			setAre_you_sharing_data_with_other_parties_without_having_data_subject_consent((Answer) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__DATA_RETENTION:
			setDataRetention((DataRetentionEnum) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
					(Answer) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE:
			setAre_you_collecting_data_that_are_not_needed_for_the_purpose((Answer) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__PAYMENTCLOUD:
			setPaymentcloud((PaymentCloud) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__SOCIALNETWORKCLOUD:
			setSocialnetworkcloud((SocialNetworkCloud) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__SHIPPINGCLOUD:
			setShippingcloud((ShippingCloud) newValue);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__WEBHOSTINGCLOUD:
			setWebhostingcloud((WebhostingCloud) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.CLOUD_FOR_PHARMACY__PRIVACY_PATTERNS:
			setPrivacy_patterns(PRIVACY_PATTERNS_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ENCRYPTED_DATA:
			setEncryptedData(ENCRYPTED_DATA_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__SMARTPHONE:
			setSmartphone((SmartPhone) null);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__WEBBROWSER:
			setWebbrowser((WebBrowser) null);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__STORAGELOCATION:
			getStoragelocation().clear();
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__TEST_ON_DUMMY:
			getTest_on_dummy().clear();
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__CONTAINERISATION:
			getContainerisation().clear();
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__AGGREGATION:
			getAggregation().clear();
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__DATASHARING:
			getDatasharing().clear();
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING:
			setAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(
					ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(
					ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
					ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT:
			setAre_you_sharing_data_with_other_parties_without_having_data_subject_consent(
					ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__DATA_RETENTION:
			setDataRetention(DATA_RETENTION_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
					IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE:
			setAre_you_collecting_data_that_are_not_needed_for_the_purpose(
					ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__PAYMENTCLOUD:
			setPaymentcloud((PaymentCloud) null);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__SOCIALNETWORKCLOUD:
			setSocialnetworkcloud((SocialNetworkCloud) null);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__SHIPPINGCLOUD:
			setShippingcloud((ShippingCloud) null);
			return;
		case Cgm3Package.CLOUD_FOR_PHARMACY__WEBHOSTINGCLOUD:
			setWebhostingcloud((WebhostingCloud) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.CLOUD_FOR_PHARMACY__PRIVACY_PATTERNS:
			return PRIVACY_PATTERNS_EDEFAULT == null ? privacy_patterns != null
					: !PRIVACY_PATTERNS_EDEFAULT.equals(privacy_patterns);
		case Cgm3Package.CLOUD_FOR_PHARMACY__ENCRYPTED_DATA:
			return encryptedData != ENCRYPTED_DATA_EDEFAULT;
		case Cgm3Package.CLOUD_FOR_PHARMACY__SMARTPHONE:
			return smartphone != null;
		case Cgm3Package.CLOUD_FOR_PHARMACY__WEBBROWSER:
			return webbrowser != null;
		case Cgm3Package.CLOUD_FOR_PHARMACY__STORAGELOCATION:
			return storagelocation != null && !storagelocation.isEmpty();
		case Cgm3Package.CLOUD_FOR_PHARMACY__TEST_ON_DUMMY:
			return test_on_dummy != null && !test_on_dummy.isEmpty();
		case Cgm3Package.CLOUD_FOR_PHARMACY__CONTAINERISATION:
			return containerisation != null && !containerisation.isEmpty();
		case Cgm3Package.CLOUD_FOR_PHARMACY__AGGREGATION:
			return aggregation != null && !aggregation.isEmpty();
		case Cgm3Package.CLOUD_FOR_PHARMACY__DATASHARING:
			return datasharing != null && !datasharing.isEmpty();
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING:
			return are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing != ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			return are_you_processing_data_in_an_incompatible_way_with_the_purpose != ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes != ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT:
			return are_you_sharing_data_with_other_parties_without_having_data_subject_consent != ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT;
		case Cgm3Package.CLOUD_FOR_PHARMACY__DATA_RETENTION:
			return dataRetention != DATA_RETENTION_EDEFAULT;
		case Cgm3Package.CLOUD_FOR_PHARMACY__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			return is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures != IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT;
		case Cgm3Package.CLOUD_FOR_PHARMACY__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE:
			return are_you_collecting_data_that_are_not_needed_for_the_purpose != ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT;
		case Cgm3Package.CLOUD_FOR_PHARMACY__PAYMENTCLOUD:
			return paymentcloud != null;
		case Cgm3Package.CLOUD_FOR_PHARMACY__SOCIALNETWORKCLOUD:
			return socialnetworkcloud != null;
		case Cgm3Package.CLOUD_FOR_PHARMACY__SHIPPINGCLOUD:
			return shippingcloud != null;
		case Cgm3Package.CLOUD_FOR_PHARMACY__WEBHOSTINGCLOUD:
			return webhostingcloud != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == Privacy_patterns.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.CLOUD_FOR_PHARMACY__PRIVACY_PATTERNS:
				return Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		if (baseClass == Encryption.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.CLOUD_FOR_PHARMACY__ENCRYPTED_DATA:
				return Cgm3Package.ENCRYPTION__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == Privacy_patterns.class) {
			switch (baseFeatureID) {
			case Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS:
				return Cgm3Package.CLOUD_FOR_PHARMACY__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		if (baseClass == Encryption.class) {
			switch (baseFeatureID) {
			case Cgm3Package.ENCRYPTION__ENCRYPTED_DATA:
				return Cgm3Package.CLOUD_FOR_PHARMACY__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Privacy_patterns: ");
		result.append(privacy_patterns);
		result.append(", EncryptedData: ");
		result.append(encryptedData);
		result.append(", Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing: ");
		result.append(are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing);
		result.append(", Are_you_processing_data_in_an_incompatible_way_with_the_purpose: ");
		result.append(are_you_processing_data_in_an_incompatible_way_with_the_purpose);
		result.append(", Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes: ");
		result.append(are_you_storing_the_data_longer_than_is_necessary_for_the_purposes);
		result.append(", Are_you_sharing_data_with_other_parties_without_having_data_subject_consent: ");
		result.append(are_you_sharing_data_with_other_parties_without_having_data_subject_consent);
		result.append(", DataRetention: ");
		result.append(dataRetention);
		result.append(
				", Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures: ");
		result.append(
				is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures);
		result.append(", Are_you_collecting_data_that_are_not_needed_for_the_purpose: ");
		result.append(are_you_collecting_data_that_are_not_needed_for_the_purpose);
		result.append(')');
		return result.toString();
	}

} //CloudForPharmacyImpl
