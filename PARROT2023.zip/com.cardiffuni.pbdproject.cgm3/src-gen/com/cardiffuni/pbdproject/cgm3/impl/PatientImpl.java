/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Authentication;
import com.cardiffuni.pbdproject.cgm3.Authorization;
import com.cardiffuni.pbdproject.cgm3.CGMsensor;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.ComputerBrowser;
import com.cardiffuni.pbdproject.cgm3.Consent_CheckedList;
import com.cardiffuni.pbdproject.cgm3.DataSharing;
import com.cardiffuni.pbdproject.cgm3.Doctor;
import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.MedicalRecord;
import com.cardiffuni.pbdproject.cgm3.Patient;
import com.cardiffuni.pbdproject.cgm3.Privacy_patterns;
import com.cardiffuni.pbdproject.cgm3.SmartPhone;
import com.cardiffuni.pbdproject.cgm3.WebBrowser;
import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Patient</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getEncryptedData <em>Encrypted Data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getPrivacy_patterns <em>Privacy patterns</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getSmartphone <em>Smartphone</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getCgmsensor <em>Cgmsensor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getDoctor <em>Doctor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getMedicalrecord <em>Medicalrecord</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getAge <em>Age</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getConsent_checkedlist <em>Consent checkedlist</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getPhoneNumber <em>Phone Number</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getAuthentication <em>Authentication</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getAuthorization <em>Authorization</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getDatasharing <em>Datasharing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getComputerbrowser <em>Computerbrowser</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl#getWebbrowser <em>Webbrowser</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PatientImpl extends GeneralEntityImpl implements Patient {
	/**
	 * The default value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENCRYPTED_DATA_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected Checked encryptedData = ENCRYPTED_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected static final String PRIVACY_PATTERNS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected String privacy_patterns = PRIVACY_PATTERNS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSmartphone() <em>Smartphone</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSmartphone()
	 * @generated
	 * @ordered
	 */
	protected EList<SmartPhone> smartphone;

	/**
	 * The cached value of the '{@link #getCgmsensor() <em>Cgmsensor</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCgmsensor()
	 * @generated
	 * @ordered
	 */
	protected EList<CGMsensor> cgmsensor;

	/**
	 * The cached value of the '{@link #getDoctor() <em>Doctor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoctor()
	 * @generated
	 * @ordered
	 */
	protected Doctor doctor;

	/**
	 * The cached value of the '{@link #getMedicalrecord() <em>Medicalrecord</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMedicalrecord()
	 * @generated
	 * @ordered
	 */
	protected EList<MedicalRecord> medicalrecord;

	/**
	 * The default value of the '{@link #getAge() <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAge()
	 * @generated
	 * @ordered
	 */
	protected static final int AGE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getAge() <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAge()
	 * @generated
	 * @ordered
	 */
	protected int age = AGE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getConsent_checkedlist() <em>Consent checkedlist</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConsent_checkedlist()
	 * @generated
	 * @ordered
	 */
	protected EList<Consent_CheckedList> consent_checkedlist;

	/**
	 * The default value of the '{@link #getPhoneNumber() <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhoneNumber()
	 * @generated
	 * @ordered
	 */
	protected static final String PHONE_NUMBER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPhoneNumber() <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhoneNumber()
	 * @generated
	 * @ordered
	 */
	protected String phoneNumber = PHONE_NUMBER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAuthentication() <em>Authentication</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAuthentication()
	 * @generated
	 * @ordered
	 */
	protected EList<Authentication> authentication;

	/**
	 * The cached value of the '{@link #getAuthorization() <em>Authorization</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAuthorization()
	 * @generated
	 * @ordered
	 */
	protected EList<Authorization> authorization;

	/**
	 * The cached value of the '{@link #getDatasharing() <em>Datasharing</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDatasharing()
	 * @generated
	 * @ordered
	 */
	protected EList<DataSharing> datasharing;

	/**
	 * The cached value of the '{@link #getComputerbrowser() <em>Computerbrowser</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComputerbrowser()
	 * @generated
	 * @ordered
	 */
	protected EList<ComputerBrowser> computerbrowser;

	/**
	 * The cached value of the '{@link #getWebbrowser() <em>Webbrowser</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWebbrowser()
	 * @generated
	 * @ordered
	 */
	protected EList<WebBrowser> webbrowser;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PatientImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.PATIENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEncryptedData() {
		return encryptedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncryptedData(Checked newEncryptedData) {
		Checked oldEncryptedData = encryptedData;
		encryptedData = newEncryptedData == null ? ENCRYPTED_DATA_EDEFAULT : newEncryptedData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.PATIENT__ENCRYPTED_DATA, oldEncryptedData,
					encryptedData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPrivacy_patterns() {
		return privacy_patterns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrivacy_patterns(String newPrivacy_patterns) {
		String oldPrivacy_patterns = privacy_patterns;
		privacy_patterns = newPrivacy_patterns;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.PATIENT__PRIVACY_PATTERNS,
					oldPrivacy_patterns, privacy_patterns));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SmartPhone> getSmartphone() {
		if (smartphone == null) {
			smartphone = new EObjectContainmentEList<SmartPhone>(SmartPhone.class, this,
					Cgm3Package.PATIENT__SMARTPHONE);
		}
		return smartphone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CGMsensor> getCgmsensor() {
		if (cgmsensor == null) {
			cgmsensor = new EObjectContainmentEList<CGMsensor>(CGMsensor.class, this, Cgm3Package.PATIENT__CGMSENSOR);
		}
		return cgmsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Doctor getDoctor() {
		if (doctor != null && doctor.eIsProxy()) {
			InternalEObject oldDoctor = (InternalEObject) doctor;
			doctor = (Doctor) eResolveProxy(oldDoctor);
			if (doctor != oldDoctor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.PATIENT__DOCTOR, oldDoctor,
							doctor));
			}
		}
		return doctor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Doctor basicGetDoctor() {
		return doctor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDoctor(Doctor newDoctor, NotificationChain msgs) {
		Doctor oldDoctor = doctor;
		doctor = newDoctor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Cgm3Package.PATIENT__DOCTOR,
					oldDoctor, newDoctor);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoctor(Doctor newDoctor) {
		if (newDoctor != doctor) {
			NotificationChain msgs = null;
			if (doctor != null)
				msgs = ((InternalEObject) doctor).eInverseRemove(this, Cgm3Package.DOCTOR__PATIENT, Doctor.class, msgs);
			if (newDoctor != null)
				msgs = ((InternalEObject) newDoctor).eInverseAdd(this, Cgm3Package.DOCTOR__PATIENT, Doctor.class, msgs);
			msgs = basicSetDoctor(newDoctor, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.PATIENT__DOCTOR, newDoctor, newDoctor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<MedicalRecord> getMedicalrecord() {
		if (medicalrecord == null) {
			medicalrecord = new EObjectContainmentEList<MedicalRecord>(MedicalRecord.class, this,
					Cgm3Package.PATIENT__MEDICALRECORD);
		}
		return medicalrecord;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getAge() {
		return age;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAge(int newAge) {
		int oldAge = age;
		age = newAge;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.PATIENT__AGE, oldAge, age));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Consent_CheckedList> getConsent_checkedlist() {
		if (consent_checkedlist == null) {
			consent_checkedlist = new EObjectContainmentEList<Consent_CheckedList>(Consent_CheckedList.class, this,
					Cgm3Package.PATIENT__CONSENT_CHECKEDLIST);
		}
		return consent_checkedlist;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPhoneNumber(String newPhoneNumber) {
		String oldPhoneNumber = phoneNumber;
		phoneNumber = newPhoneNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.PATIENT__PHONE_NUMBER, oldPhoneNumber,
					phoneNumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Authentication> getAuthentication() {
		if (authentication == null) {
			authentication = new EObjectContainmentEList<Authentication>(Authentication.class, this,
					Cgm3Package.PATIENT__AUTHENTICATION);
		}
		return authentication;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Authorization> getAuthorization() {
		if (authorization == null) {
			authorization = new EObjectContainmentEList<Authorization>(Authorization.class, this,
					Cgm3Package.PATIENT__AUTHORIZATION);
		}
		return authorization;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DataSharing> getDatasharing() {
		if (datasharing == null) {
			datasharing = new EObjectContainmentEList<DataSharing>(DataSharing.class, this,
					Cgm3Package.PATIENT__DATASHARING);
		}
		return datasharing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ComputerBrowser> getComputerbrowser() {
		if (computerbrowser == null) {
			computerbrowser = new EObjectContainmentEList<ComputerBrowser>(ComputerBrowser.class, this,
					Cgm3Package.PATIENT__COMPUTERBROWSER);
		}
		return computerbrowser;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<WebBrowser> getWebbrowser() {
		if (webbrowser == null) {
			webbrowser = new EObjectContainmentEList<WebBrowser>(WebBrowser.class, this,
					Cgm3Package.PATIENT__WEBBROWSER);
		}
		return webbrowser;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.PATIENT__DOCTOR:
			if (doctor != null)
				msgs = ((InternalEObject) doctor).eInverseRemove(this, Cgm3Package.DOCTOR__PATIENT, Doctor.class, msgs);
			return basicSetDoctor((Doctor) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.PATIENT__SMARTPHONE:
			return ((InternalEList<?>) getSmartphone()).basicRemove(otherEnd, msgs);
		case Cgm3Package.PATIENT__CGMSENSOR:
			return ((InternalEList<?>) getCgmsensor()).basicRemove(otherEnd, msgs);
		case Cgm3Package.PATIENT__DOCTOR:
			return basicSetDoctor(null, msgs);
		case Cgm3Package.PATIENT__MEDICALRECORD:
			return ((InternalEList<?>) getMedicalrecord()).basicRemove(otherEnd, msgs);
		case Cgm3Package.PATIENT__CONSENT_CHECKEDLIST:
			return ((InternalEList<?>) getConsent_checkedlist()).basicRemove(otherEnd, msgs);
		case Cgm3Package.PATIENT__AUTHENTICATION:
			return ((InternalEList<?>) getAuthentication()).basicRemove(otherEnd, msgs);
		case Cgm3Package.PATIENT__AUTHORIZATION:
			return ((InternalEList<?>) getAuthorization()).basicRemove(otherEnd, msgs);
		case Cgm3Package.PATIENT__DATASHARING:
			return ((InternalEList<?>) getDatasharing()).basicRemove(otherEnd, msgs);
		case Cgm3Package.PATIENT__COMPUTERBROWSER:
			return ((InternalEList<?>) getComputerbrowser()).basicRemove(otherEnd, msgs);
		case Cgm3Package.PATIENT__WEBBROWSER:
			return ((InternalEList<?>) getWebbrowser()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.PATIENT__ENCRYPTED_DATA:
			return getEncryptedData();
		case Cgm3Package.PATIENT__PRIVACY_PATTERNS:
			return getPrivacy_patterns();
		case Cgm3Package.PATIENT__SMARTPHONE:
			return getSmartphone();
		case Cgm3Package.PATIENT__CGMSENSOR:
			return getCgmsensor();
		case Cgm3Package.PATIENT__DOCTOR:
			if (resolve)
				return getDoctor();
			return basicGetDoctor();
		case Cgm3Package.PATIENT__MEDICALRECORD:
			return getMedicalrecord();
		case Cgm3Package.PATIENT__AGE:
			return getAge();
		case Cgm3Package.PATIENT__CONSENT_CHECKEDLIST:
			return getConsent_checkedlist();
		case Cgm3Package.PATIENT__PHONE_NUMBER:
			return getPhoneNumber();
		case Cgm3Package.PATIENT__AUTHENTICATION:
			return getAuthentication();
		case Cgm3Package.PATIENT__AUTHORIZATION:
			return getAuthorization();
		case Cgm3Package.PATIENT__DATASHARING:
			return getDatasharing();
		case Cgm3Package.PATIENT__COMPUTERBROWSER:
			return getComputerbrowser();
		case Cgm3Package.PATIENT__WEBBROWSER:
			return getWebbrowser();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.PATIENT__ENCRYPTED_DATA:
			setEncryptedData((Checked) newValue);
			return;
		case Cgm3Package.PATIENT__PRIVACY_PATTERNS:
			setPrivacy_patterns((String) newValue);
			return;
		case Cgm3Package.PATIENT__SMARTPHONE:
			getSmartphone().clear();
			getSmartphone().addAll((Collection<? extends SmartPhone>) newValue);
			return;
		case Cgm3Package.PATIENT__CGMSENSOR:
			getCgmsensor().clear();
			getCgmsensor().addAll((Collection<? extends CGMsensor>) newValue);
			return;
		case Cgm3Package.PATIENT__DOCTOR:
			setDoctor((Doctor) newValue);
			return;
		case Cgm3Package.PATIENT__MEDICALRECORD:
			getMedicalrecord().clear();
			getMedicalrecord().addAll((Collection<? extends MedicalRecord>) newValue);
			return;
		case Cgm3Package.PATIENT__AGE:
			setAge((Integer) newValue);
			return;
		case Cgm3Package.PATIENT__CONSENT_CHECKEDLIST:
			getConsent_checkedlist().clear();
			getConsent_checkedlist().addAll((Collection<? extends Consent_CheckedList>) newValue);
			return;
		case Cgm3Package.PATIENT__PHONE_NUMBER:
			setPhoneNumber((String) newValue);
			return;
		case Cgm3Package.PATIENT__AUTHENTICATION:
			getAuthentication().clear();
			getAuthentication().addAll((Collection<? extends Authentication>) newValue);
			return;
		case Cgm3Package.PATIENT__AUTHORIZATION:
			getAuthorization().clear();
			getAuthorization().addAll((Collection<? extends Authorization>) newValue);
			return;
		case Cgm3Package.PATIENT__DATASHARING:
			getDatasharing().clear();
			getDatasharing().addAll((Collection<? extends DataSharing>) newValue);
			return;
		case Cgm3Package.PATIENT__COMPUTERBROWSER:
			getComputerbrowser().clear();
			getComputerbrowser().addAll((Collection<? extends ComputerBrowser>) newValue);
			return;
		case Cgm3Package.PATIENT__WEBBROWSER:
			getWebbrowser().clear();
			getWebbrowser().addAll((Collection<? extends WebBrowser>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.PATIENT__ENCRYPTED_DATA:
			setEncryptedData(ENCRYPTED_DATA_EDEFAULT);
			return;
		case Cgm3Package.PATIENT__PRIVACY_PATTERNS:
			setPrivacy_patterns(PRIVACY_PATTERNS_EDEFAULT);
			return;
		case Cgm3Package.PATIENT__SMARTPHONE:
			getSmartphone().clear();
			return;
		case Cgm3Package.PATIENT__CGMSENSOR:
			getCgmsensor().clear();
			return;
		case Cgm3Package.PATIENT__DOCTOR:
			setDoctor((Doctor) null);
			return;
		case Cgm3Package.PATIENT__MEDICALRECORD:
			getMedicalrecord().clear();
			return;
		case Cgm3Package.PATIENT__AGE:
			setAge(AGE_EDEFAULT);
			return;
		case Cgm3Package.PATIENT__CONSENT_CHECKEDLIST:
			getConsent_checkedlist().clear();
			return;
		case Cgm3Package.PATIENT__PHONE_NUMBER:
			setPhoneNumber(PHONE_NUMBER_EDEFAULT);
			return;
		case Cgm3Package.PATIENT__AUTHENTICATION:
			getAuthentication().clear();
			return;
		case Cgm3Package.PATIENT__AUTHORIZATION:
			getAuthorization().clear();
			return;
		case Cgm3Package.PATIENT__DATASHARING:
			getDatasharing().clear();
			return;
		case Cgm3Package.PATIENT__COMPUTERBROWSER:
			getComputerbrowser().clear();
			return;
		case Cgm3Package.PATIENT__WEBBROWSER:
			getWebbrowser().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.PATIENT__ENCRYPTED_DATA:
			return encryptedData != ENCRYPTED_DATA_EDEFAULT;
		case Cgm3Package.PATIENT__PRIVACY_PATTERNS:
			return PRIVACY_PATTERNS_EDEFAULT == null ? privacy_patterns != null
					: !PRIVACY_PATTERNS_EDEFAULT.equals(privacy_patterns);
		case Cgm3Package.PATIENT__SMARTPHONE:
			return smartphone != null && !smartphone.isEmpty();
		case Cgm3Package.PATIENT__CGMSENSOR:
			return cgmsensor != null && !cgmsensor.isEmpty();
		case Cgm3Package.PATIENT__DOCTOR:
			return doctor != null;
		case Cgm3Package.PATIENT__MEDICALRECORD:
			return medicalrecord != null && !medicalrecord.isEmpty();
		case Cgm3Package.PATIENT__AGE:
			return age != AGE_EDEFAULT;
		case Cgm3Package.PATIENT__CONSENT_CHECKEDLIST:
			return consent_checkedlist != null && !consent_checkedlist.isEmpty();
		case Cgm3Package.PATIENT__PHONE_NUMBER:
			return PHONE_NUMBER_EDEFAULT == null ? phoneNumber != null : !PHONE_NUMBER_EDEFAULT.equals(phoneNumber);
		case Cgm3Package.PATIENT__AUTHENTICATION:
			return authentication != null && !authentication.isEmpty();
		case Cgm3Package.PATIENT__AUTHORIZATION:
			return authorization != null && !authorization.isEmpty();
		case Cgm3Package.PATIENT__DATASHARING:
			return datasharing != null && !datasharing.isEmpty();
		case Cgm3Package.PATIENT__COMPUTERBROWSER:
			return computerbrowser != null && !computerbrowser.isEmpty();
		case Cgm3Package.PATIENT__WEBBROWSER:
			return webbrowser != null && !webbrowser.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.PATIENT__ENCRYPTED_DATA:
				return Cgm3Package.ENCRYPTION__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.PATIENT__PRIVACY_PATTERNS:
				return Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (baseFeatureID) {
			case Cgm3Package.ENCRYPTION__ENCRYPTED_DATA:
				return Cgm3Package.PATIENT__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (baseFeatureID) {
			case Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS:
				return Cgm3Package.PATIENT__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (EncryptedData: ");
		result.append(encryptedData);
		result.append(", Privacy_patterns: ");
		result.append(privacy_patterns);
		result.append(", Age: ");
		result.append(age);
		result.append(", PhoneNumber: ");
		result.append(phoneNumber);
		result.append(')');
		return result.toString();
	}

} //PatientImpl
