/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Bus;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Customer;
import com.cardiffuni.pbdproject.cgm3.Driver;
import com.cardiffuni.pbdproject.cgm3.GPSTracker;

import com.cardiffuni.pbdproject.cgm3.VideoAnalytics;
import com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud;
import com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics;
import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bus</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.BusImpl#getGpstracker <em>Gpstracker</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.BusImpl#getPlate_number <em>Plate number</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.BusImpl#getRoute_number <em>Route number</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.BusImpl#getDriver_name <em>Driver name</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.BusImpl#getVideowithoutanalytics <em>Videowithoutanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.BusImpl#getDriver <em>Driver</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.BusImpl#getVideoanalytics <em>Videoanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.BusImpl#getVideoprocessingcloud <em>Videoprocessingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.BusImpl#getCustomer <em>Customer</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BusImpl extends GeneralEntityImpl implements Bus {
	/**
	 * The cached value of the '{@link #getGpstracker() <em>Gpstracker</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGpstracker()
	 * @generated
	 * @ordered
	 */
	protected EList<GPSTracker> gpstracker;

	/**
	 * The default value of the '{@link #getPlate_number() <em>Plate number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlate_number()
	 * @generated
	 * @ordered
	 */
	protected static final String PLATE_NUMBER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPlate_number() <em>Plate number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlate_number()
	 * @generated
	 * @ordered
	 */
	protected String plate_number = PLATE_NUMBER_EDEFAULT;

	/**
	 * The default value of the '{@link #getRoute_number() <em>Route number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoute_number()
	 * @generated
	 * @ordered
	 */
	protected static final String ROUTE_NUMBER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getRoute_number() <em>Route number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoute_number()
	 * @generated
	 * @ordered
	 */
	protected String route_number = ROUTE_NUMBER_EDEFAULT;

	/**
	 * The default value of the '{@link #getDriver_name() <em>Driver name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDriver_name()
	 * @generated
	 * @ordered
	 */
	protected static final String DRIVER_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDriver_name() <em>Driver name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDriver_name()
	 * @generated
	 * @ordered
	 */
	protected String driver_name = DRIVER_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getVideowithoutanalytics() <em>Videowithoutanalytics</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVideowithoutanalytics()
	 * @generated
	 * @ordered
	 */
	protected EList<VideoWithoutAnalytics> videowithoutanalytics;

	/**
	 * The cached value of the '{@link #getDriver() <em>Driver</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDriver()
	 * @generated
	 * @ordered
	 */
	protected EList<Driver> driver;

	/**
	 * The cached value of the '{@link #getVideoanalytics() <em>Videoanalytics</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVideoanalytics()
	 * @generated
	 * @ordered
	 */
	protected EList<VideoAnalytics> videoanalytics;

	/**
	 * The cached value of the '{@link #getVideoprocessingcloud() <em>Videoprocessingcloud</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVideoprocessingcloud()
	 * @generated
	 * @ordered
	 */
	protected EList<VideoProcessingCloud> videoprocessingcloud;

	/**
	 * The cached value of the '{@link #getCustomer() <em>Customer</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustomer()
	 * @generated
	 * @ordered
	 */
	protected EList<Customer> customer;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BusImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.BUS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<GPSTracker> getGpstracker() {
		if (gpstracker == null) {
			gpstracker = new EObjectContainmentEList<GPSTracker>(GPSTracker.class, this, Cgm3Package.BUS__GPSTRACKER);
		}
		return gpstracker;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPlate_number() {
		return plate_number;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlate_number(String newPlate_number) {
		String oldPlate_number = plate_number;
		plate_number = newPlate_number;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.BUS__PLATE_NUMBER, oldPlate_number,
					plate_number));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getRoute_number() {
		return route_number;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRoute_number(String newRoute_number) {
		String oldRoute_number = route_number;
		route_number = newRoute_number;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.BUS__ROUTE_NUMBER, oldRoute_number,
					route_number));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDriver_name() {
		return driver_name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDriver_name(String newDriver_name) {
		String oldDriver_name = driver_name;
		driver_name = newDriver_name;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.BUS__DRIVER_NAME, oldDriver_name,
					driver_name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Driver> getDriver() {
		if (driver == null) {
			driver = new EObjectContainmentEList<Driver>(Driver.class, this, Cgm3Package.BUS__DRIVER);
		}
		return driver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<VideoAnalytics> getVideoanalytics() {
		if (videoanalytics == null) {
			videoanalytics = new EObjectContainmentEList<VideoAnalytics>(VideoAnalytics.class, this,
					Cgm3Package.BUS__VIDEOANALYTICS);
		}
		return videoanalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<VideoProcessingCloud> getVideoprocessingcloud() {
		if (videoprocessingcloud == null) {
			videoprocessingcloud = new EObjectContainmentEList<VideoProcessingCloud>(VideoProcessingCloud.class, this,
					Cgm3Package.BUS__VIDEOPROCESSINGCLOUD);
		}
		return videoprocessingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Customer> getCustomer() {
		if (customer == null) {
			customer = new EObjectContainmentEList<Customer>(Customer.class, this, Cgm3Package.BUS__CUSTOMER);
		}
		return customer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<VideoWithoutAnalytics> getVideowithoutanalytics() {
		if (videowithoutanalytics == null) {
			videowithoutanalytics = new EObjectContainmentEList<VideoWithoutAnalytics>(VideoWithoutAnalytics.class,
					this, Cgm3Package.BUS__VIDEOWITHOUTANALYTICS);
		}
		return videowithoutanalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.BUS__GPSTRACKER:
			return ((InternalEList<?>) getGpstracker()).basicRemove(otherEnd, msgs);
		case Cgm3Package.BUS__VIDEOWITHOUTANALYTICS:
			return ((InternalEList<?>) getVideowithoutanalytics()).basicRemove(otherEnd, msgs);
		case Cgm3Package.BUS__DRIVER:
			return ((InternalEList<?>) getDriver()).basicRemove(otherEnd, msgs);
		case Cgm3Package.BUS__VIDEOANALYTICS:
			return ((InternalEList<?>) getVideoanalytics()).basicRemove(otherEnd, msgs);
		case Cgm3Package.BUS__VIDEOPROCESSINGCLOUD:
			return ((InternalEList<?>) getVideoprocessingcloud()).basicRemove(otherEnd, msgs);
		case Cgm3Package.BUS__CUSTOMER:
			return ((InternalEList<?>) getCustomer()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.BUS__GPSTRACKER:
			return getGpstracker();
		case Cgm3Package.BUS__PLATE_NUMBER:
			return getPlate_number();
		case Cgm3Package.BUS__ROUTE_NUMBER:
			return getRoute_number();
		case Cgm3Package.BUS__DRIVER_NAME:
			return getDriver_name();
		case Cgm3Package.BUS__VIDEOWITHOUTANALYTICS:
			return getVideowithoutanalytics();
		case Cgm3Package.BUS__DRIVER:
			return getDriver();
		case Cgm3Package.BUS__VIDEOANALYTICS:
			return getVideoanalytics();
		case Cgm3Package.BUS__VIDEOPROCESSINGCLOUD:
			return getVideoprocessingcloud();
		case Cgm3Package.BUS__CUSTOMER:
			return getCustomer();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.BUS__GPSTRACKER:
			getGpstracker().clear();
			getGpstracker().addAll((Collection<? extends GPSTracker>) newValue);
			return;
		case Cgm3Package.BUS__PLATE_NUMBER:
			setPlate_number((String) newValue);
			return;
		case Cgm3Package.BUS__ROUTE_NUMBER:
			setRoute_number((String) newValue);
			return;
		case Cgm3Package.BUS__DRIVER_NAME:
			setDriver_name((String) newValue);
			return;
		case Cgm3Package.BUS__VIDEOWITHOUTANALYTICS:
			getVideowithoutanalytics().clear();
			getVideowithoutanalytics().addAll((Collection<? extends VideoWithoutAnalytics>) newValue);
			return;
		case Cgm3Package.BUS__DRIVER:
			getDriver().clear();
			getDriver().addAll((Collection<? extends Driver>) newValue);
			return;
		case Cgm3Package.BUS__VIDEOANALYTICS:
			getVideoanalytics().clear();
			getVideoanalytics().addAll((Collection<? extends VideoAnalytics>) newValue);
			return;
		case Cgm3Package.BUS__VIDEOPROCESSINGCLOUD:
			getVideoprocessingcloud().clear();
			getVideoprocessingcloud().addAll((Collection<? extends VideoProcessingCloud>) newValue);
			return;
		case Cgm3Package.BUS__CUSTOMER:
			getCustomer().clear();
			getCustomer().addAll((Collection<? extends Customer>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.BUS__GPSTRACKER:
			getGpstracker().clear();
			return;
		case Cgm3Package.BUS__PLATE_NUMBER:
			setPlate_number(PLATE_NUMBER_EDEFAULT);
			return;
		case Cgm3Package.BUS__ROUTE_NUMBER:
			setRoute_number(ROUTE_NUMBER_EDEFAULT);
			return;
		case Cgm3Package.BUS__DRIVER_NAME:
			setDriver_name(DRIVER_NAME_EDEFAULT);
			return;
		case Cgm3Package.BUS__VIDEOWITHOUTANALYTICS:
			getVideowithoutanalytics().clear();
			return;
		case Cgm3Package.BUS__DRIVER:
			getDriver().clear();
			return;
		case Cgm3Package.BUS__VIDEOANALYTICS:
			getVideoanalytics().clear();
			return;
		case Cgm3Package.BUS__VIDEOPROCESSINGCLOUD:
			getVideoprocessingcloud().clear();
			return;
		case Cgm3Package.BUS__CUSTOMER:
			getCustomer().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.BUS__GPSTRACKER:
			return gpstracker != null && !gpstracker.isEmpty();
		case Cgm3Package.BUS__PLATE_NUMBER:
			return PLATE_NUMBER_EDEFAULT == null ? plate_number != null : !PLATE_NUMBER_EDEFAULT.equals(plate_number);
		case Cgm3Package.BUS__ROUTE_NUMBER:
			return ROUTE_NUMBER_EDEFAULT == null ? route_number != null : !ROUTE_NUMBER_EDEFAULT.equals(route_number);
		case Cgm3Package.BUS__DRIVER_NAME:
			return DRIVER_NAME_EDEFAULT == null ? driver_name != null : !DRIVER_NAME_EDEFAULT.equals(driver_name);
		case Cgm3Package.BUS__VIDEOWITHOUTANALYTICS:
			return videowithoutanalytics != null && !videowithoutanalytics.isEmpty();
		case Cgm3Package.BUS__DRIVER:
			return driver != null && !driver.isEmpty();
		case Cgm3Package.BUS__VIDEOANALYTICS:
			return videoanalytics != null && !videoanalytics.isEmpty();
		case Cgm3Package.BUS__VIDEOPROCESSINGCLOUD:
			return videoprocessingcloud != null && !videoprocessingcloud.isEmpty();
		case Cgm3Package.BUS__CUSTOMER:
			return customer != null && !customer.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Plate_number: ");
		result.append(plate_number);
		result.append(", Route_number: ");
		result.append(route_number);
		result.append(", Driver_name: ");
		result.append(driver_name);
		result.append(')');
		return result.toString();
	}

} //BusImpl
