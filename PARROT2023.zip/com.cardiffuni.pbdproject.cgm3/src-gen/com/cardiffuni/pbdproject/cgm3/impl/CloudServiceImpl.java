/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Aggregation;
import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Camera;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.CloudService;
import com.cardiffuni.pbdproject.cgm3.Containerisation;
import com.cardiffuni.pbdproject.cgm3.DataRetentionEnum;
import com.cardiffuni.pbdproject.cgm3.DataSharing;
import com.cardiffuni.pbdproject.cgm3.DoorLock;
import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.GPSTracker;
import com.cardiffuni.pbdproject.cgm3.LightSensor;
import com.cardiffuni.pbdproject.cgm3.Phone;
import com.cardiffuni.pbdproject.cgm3.Privacy_patterns;
import com.cardiffuni.pbdproject.cgm3.StorageLocation;
import com.cardiffuni.pbdproject.cgm3.Test_on_dummy;
import com.cardiffuni.pbdproject.cgm3.Thermostat;
import com.cardiffuni.pbdproject.cgm3.VideoAnalytics;
import com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Cloud Service</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getEncryptedData <em>Encrypted Data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getPrivacy_patterns <em>Privacy patterns</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getDataRetention <em>Data Retention</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getStoragelocation <em>Storagelocation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getDatasharing <em>Datasharing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getTest_on_dummy <em>Test on dummy</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getContainerisation <em>Containerisation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getAggregation <em>Aggregation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getGpstracker <em>Gpstracker</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getVideoanalytics <em>Videoanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getVideowithoutanalytics <em>Videowithoutanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getLightsensor <em>Lightsensor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getPhone <em>Phone</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getCamera <em>Camera</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getDoorlock <em>Doorlock</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl#getThermostat <em>Thermostat</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CloudServiceImpl extends GeneralEntityImpl implements CloudService {
	/**
	 * The default value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENCRYPTED_DATA_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected Checked encryptedData = ENCRYPTED_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected static final String PRIVACY_PATTERNS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected String privacy_patterns = PRIVACY_PATTERNS_EDEFAULT;

	/**
	 * The default value of the '{@link #getDataRetention() <em>Data Retention</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataRetention()
	 * @generated
	 * @ordered
	 */
	protected static final DataRetentionEnum DATA_RETENTION_EDEFAULT = DataRetentionEnum.NOT_ACCEPTED;

	/**
	 * The cached value of the '{@link #getDataRetention() <em>Data Retention</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataRetention()
	 * @generated
	 * @ordered
	 */
	protected DataRetentionEnum dataRetention = DATA_RETENTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getStoragelocation() <em>Storagelocation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStoragelocation()
	 * @generated
	 * @ordered
	 */
	protected EList<StorageLocation> storagelocation;

	/**
	 * The cached value of the '{@link #getDatasharing() <em>Datasharing</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDatasharing()
	 * @generated
	 * @ordered
	 */
	protected EList<DataSharing> datasharing;

	/**
	 * The cached value of the '{@link #getTest_on_dummy() <em>Test on dummy</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTest_on_dummy()
	 * @generated
	 * @ordered
	 */
	protected EList<Test_on_dummy> test_on_dummy;

	/**
	 * The cached value of the '{@link #getContainerisation() <em>Containerisation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContainerisation()
	 * @generated
	 * @ordered
	 */
	protected EList<Containerisation> containerisation;

	/**
	 * The cached value of the '{@link #getAggregation() <em>Aggregation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAggregation()
	 * @generated
	 * @ordered
	 */
	protected EList<Aggregation> aggregation;

	/**
	 * The default value of the '{@link #getAre_you_collecting_data_that_are_not_needed_for_the_purpose() <em>Are you collecting data that are not needed for the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_collecting_data_that_are_not_needed_for_the_purpose() <em>Are you collecting data that are not needed for the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_collecting_data_that_are_not_needed_for_the_purpose = ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() <em>Are you processing data in an incompatible way with the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() <em>Are you processing data in an incompatible way with the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_processing_data_in_an_incompatible_way_with_the_purpose = ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent() <em>Are you sharing data with other parties without having data subject consent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent() <em>Are you sharing data with other parties without having data subject consent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_sharing_data_with_other_parties_without_having_data_subject_consent = ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing = ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT;

	/**
	 * The default value of the '{@link #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 * @ordered
	 */
	protected static final Answer IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 * @ordered
	 */
	protected Answer is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT;

	/**
	 * The cached value of the '{@link #getGpstracker() <em>Gpstracker</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGpstracker()
	 * @generated
	 * @ordered
	 */
	protected EList<GPSTracker> gpstracker;

	/**
	 * The cached value of the '{@link #getVideoanalytics() <em>Videoanalytics</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVideoanalytics()
	 * @generated
	 * @ordered
	 */
	protected VideoAnalytics videoanalytics;

	/**
	 * The cached value of the '{@link #getVideowithoutanalytics() <em>Videowithoutanalytics</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVideowithoutanalytics()
	 * @generated
	 * @ordered
	 */
	protected VideoWithoutAnalytics videowithoutanalytics;

	/**
	 * The cached value of the '{@link #getLightsensor() <em>Lightsensor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLightsensor()
	 * @generated
	 * @ordered
	 */
	protected LightSensor lightsensor;

	/**
	 * The cached value of the '{@link #getPhone() <em>Phone</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhone()
	 * @generated
	 * @ordered
	 */
	protected Phone phone;

	/**
	 * The cached value of the '{@link #getCamera() <em>Camera</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCamera()
	 * @generated
	 * @ordered
	 */
	protected Camera camera;

	/**
	 * The cached value of the '{@link #getDoorlock() <em>Doorlock</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoorlock()
	 * @generated
	 * @ordered
	 */
	protected DoorLock doorlock;

	/**
	 * The cached value of the '{@link #getThermostat() <em>Thermostat</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThermostat()
	 * @generated
	 * @ordered
	 */
	protected Thermostat thermostat;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CloudServiceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.CLOUD_SERVICE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEncryptedData() {
		return encryptedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncryptedData(Checked newEncryptedData) {
		Checked oldEncryptedData = encryptedData;
		encryptedData = newEncryptedData == null ? ENCRYPTED_DATA_EDEFAULT : newEncryptedData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_SERVICE__ENCRYPTED_DATA,
					oldEncryptedData, encryptedData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPrivacy_patterns() {
		return privacy_patterns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrivacy_patterns(String newPrivacy_patterns) {
		String oldPrivacy_patterns = privacy_patterns;
		privacy_patterns = newPrivacy_patterns;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_SERVICE__PRIVACY_PATTERNS,
					oldPrivacy_patterns, privacy_patterns));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataRetentionEnum getDataRetention() {
		return dataRetention;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataRetention(DataRetentionEnum newDataRetention) {
		DataRetentionEnum oldDataRetention = dataRetention;
		dataRetention = newDataRetention == null ? DATA_RETENTION_EDEFAULT : newDataRetention;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_SERVICE__DATA_RETENTION,
					oldDataRetention, dataRetention));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<StorageLocation> getStoragelocation() {
		if (storagelocation == null) {
			storagelocation = new EObjectContainmentEList<StorageLocation>(StorageLocation.class, this,
					Cgm3Package.CLOUD_SERVICE__STORAGELOCATION);
		}
		return storagelocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DataSharing> getDatasharing() {
		if (datasharing == null) {
			datasharing = new EObjectContainmentEList<DataSharing>(DataSharing.class, this,
					Cgm3Package.CLOUD_SERVICE__DATASHARING);
		}
		return datasharing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Test_on_dummy> getTest_on_dummy() {
		if (test_on_dummy == null) {
			test_on_dummy = new EObjectContainmentEList<Test_on_dummy>(Test_on_dummy.class, this,
					Cgm3Package.CLOUD_SERVICE__TEST_ON_DUMMY);
		}
		return test_on_dummy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Containerisation> getContainerisation() {
		if (containerisation == null) {
			containerisation = new EObjectContainmentEList<Containerisation>(Containerisation.class, this,
					Cgm3Package.CLOUD_SERVICE__CONTAINERISATION);
		}
		return containerisation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Aggregation> getAggregation() {
		if (aggregation == null) {
			aggregation = new EObjectContainmentEList<Aggregation>(Aggregation.class, this,
					Cgm3Package.CLOUD_SERVICE__AGGREGATION);
		}
		return aggregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_collecting_data_that_are_not_needed_for_the_purpose() {
		return are_you_collecting_data_that_are_not_needed_for_the_purpose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_collecting_data_that_are_not_needed_for_the_purpose(
			Answer newAre_you_collecting_data_that_are_not_needed_for_the_purpose) {
		Answer oldAre_you_collecting_data_that_are_not_needed_for_the_purpose = are_you_collecting_data_that_are_not_needed_for_the_purpose;
		are_you_collecting_data_that_are_not_needed_for_the_purpose = newAre_you_collecting_data_that_are_not_needed_for_the_purpose == null
				? ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT
				: newAre_you_collecting_data_that_are_not_needed_for_the_purpose;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_SERVICE__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE,
					oldAre_you_collecting_data_that_are_not_needed_for_the_purpose,
					are_you_collecting_data_that_are_not_needed_for_the_purpose));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return are_you_processing_data_in_an_incompatible_way_with_the_purpose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(
			Answer newAre_you_processing_data_in_an_incompatible_way_with_the_purpose) {
		Answer oldAre_you_processing_data_in_an_incompatible_way_with_the_purpose = are_you_processing_data_in_an_incompatible_way_with_the_purpose;
		are_you_processing_data_in_an_incompatible_way_with_the_purpose = newAre_you_processing_data_in_an_incompatible_way_with_the_purpose == null
				? ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT
				: newAre_you_processing_data_in_an_incompatible_way_with_the_purpose;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_SERVICE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE,
					oldAre_you_processing_data_in_an_incompatible_way_with_the_purpose,
					are_you_processing_data_in_an_incompatible_way_with_the_purpose));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent() {
		return are_you_sharing_data_with_other_parties_without_having_data_subject_consent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_sharing_data_with_other_parties_without_having_data_subject_consent(
			Answer newAre_you_sharing_data_with_other_parties_without_having_data_subject_consent) {
		Answer oldAre_you_sharing_data_with_other_parties_without_having_data_subject_consent = are_you_sharing_data_with_other_parties_without_having_data_subject_consent;
		are_you_sharing_data_with_other_parties_without_having_data_subject_consent = newAre_you_sharing_data_with_other_parties_without_having_data_subject_consent == null
				? ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT
				: newAre_you_sharing_data_with_other_parties_without_having_data_subject_consent;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_SERVICE__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT,
					oldAre_you_sharing_data_with_other_parties_without_having_data_subject_consent,
					are_you_sharing_data_with_other_parties_without_having_data_subject_consent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
			Answer newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes) {
		Answer oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes = are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes == null
				? ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT
				: newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_SERVICE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
					oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes,
					are_you_storing_the_data_longer_than_is_necessary_for_the_purposes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() {
		return are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(
			Answer newAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing) {
		Answer oldAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing = are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing;
		are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing = newAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing == null
				? ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT
				: newAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_SERVICE__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING,
					oldAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing,
					are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
			Answer newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures) {
		Answer oldIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
		is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures == null
				? IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT
				: newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_SERVICE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES,
					oldIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures,
					is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<GPSTracker> getGpstracker() {
		if (gpstracker == null) {
			gpstracker = new EObjectContainmentEList<GPSTracker>(GPSTracker.class, this,
					Cgm3Package.CLOUD_SERVICE__GPSTRACKER);
		}
		return gpstracker;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoAnalytics getVideoanalytics() {
		if (videoanalytics != null && videoanalytics.eIsProxy()) {
			InternalEObject oldVideoanalytics = (InternalEObject) videoanalytics;
			videoanalytics = (VideoAnalytics) eResolveProxy(oldVideoanalytics);
			if (videoanalytics != oldVideoanalytics) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.CLOUD_SERVICE__VIDEOANALYTICS,
							oldVideoanalytics, videoanalytics));
			}
		}
		return videoanalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoAnalytics basicGetVideoanalytics() {
		return videoanalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVideoanalytics(VideoAnalytics newVideoanalytics) {
		VideoAnalytics oldVideoanalytics = videoanalytics;
		videoanalytics = newVideoanalytics;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_SERVICE__VIDEOANALYTICS,
					oldVideoanalytics, videoanalytics));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoWithoutAnalytics getVideowithoutanalytics() {
		if (videowithoutanalytics != null && videowithoutanalytics.eIsProxy()) {
			InternalEObject oldVideowithoutanalytics = (InternalEObject) videowithoutanalytics;
			videowithoutanalytics = (VideoWithoutAnalytics) eResolveProxy(oldVideowithoutanalytics);
			if (videowithoutanalytics != oldVideowithoutanalytics) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Cgm3Package.CLOUD_SERVICE__VIDEOWITHOUTANALYTICS, oldVideowithoutanalytics,
							videowithoutanalytics));
			}
		}
		return videowithoutanalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoWithoutAnalytics basicGetVideowithoutanalytics() {
		return videowithoutanalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVideowithoutanalytics(VideoWithoutAnalytics newVideowithoutanalytics) {
		VideoWithoutAnalytics oldVideowithoutanalytics = videowithoutanalytics;
		videowithoutanalytics = newVideowithoutanalytics;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_SERVICE__VIDEOWITHOUTANALYTICS,
					oldVideowithoutanalytics, videowithoutanalytics));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LightSensor getLightsensor() {
		if (lightsensor != null && lightsensor.eIsProxy()) {
			InternalEObject oldLightsensor = (InternalEObject) lightsensor;
			lightsensor = (LightSensor) eResolveProxy(oldLightsensor);
			if (lightsensor != oldLightsensor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.CLOUD_SERVICE__LIGHTSENSOR,
							oldLightsensor, lightsensor));
			}
		}
		return lightsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LightSensor basicGetLightsensor() {
		return lightsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLightsensor(LightSensor newLightsensor, NotificationChain msgs) {
		LightSensor oldLightsensor = lightsensor;
		lightsensor = newLightsensor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_SERVICE__LIGHTSENSOR, oldLightsensor, newLightsensor);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLightsensor(LightSensor newLightsensor) {
		if (newLightsensor != lightsensor) {
			NotificationChain msgs = null;
			if (lightsensor != null)
				msgs = ((InternalEObject) lightsensor).eInverseRemove(this, Cgm3Package.LIGHT_SENSOR__CLOUDSERVICE,
						LightSensor.class, msgs);
			if (newLightsensor != null)
				msgs = ((InternalEObject) newLightsensor).eInverseAdd(this, Cgm3Package.LIGHT_SENSOR__CLOUDSERVICE,
						LightSensor.class, msgs);
			msgs = basicSetLightsensor(newLightsensor, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_SERVICE__LIGHTSENSOR,
					newLightsensor, newLightsensor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Phone getPhone() {
		if (phone != null && phone.eIsProxy()) {
			InternalEObject oldPhone = (InternalEObject) phone;
			phone = (Phone) eResolveProxy(oldPhone);
			if (phone != oldPhone) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.CLOUD_SERVICE__PHONE,
							oldPhone, phone));
			}
		}
		return phone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Phone basicGetPhone() {
		return phone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPhone(Phone newPhone, NotificationChain msgs) {
		Phone oldPhone = phone;
		phone = newPhone;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_SERVICE__PHONE, oldPhone, newPhone);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPhone(Phone newPhone) {
		if (newPhone != phone) {
			NotificationChain msgs = null;
			if (phone != null)
				msgs = ((InternalEObject) phone).eInverseRemove(this, Cgm3Package.PHONE__CLOUDSERVICE, Phone.class,
						msgs);
			if (newPhone != null)
				msgs = ((InternalEObject) newPhone).eInverseAdd(this, Cgm3Package.PHONE__CLOUDSERVICE, Phone.class,
						msgs);
			msgs = basicSetPhone(newPhone, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_SERVICE__PHONE, newPhone,
					newPhone));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Camera getCamera() {
		if (camera != null && camera.eIsProxy()) {
			InternalEObject oldCamera = (InternalEObject) camera;
			camera = (Camera) eResolveProxy(oldCamera);
			if (camera != oldCamera) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.CLOUD_SERVICE__CAMERA,
							oldCamera, camera));
			}
		}
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Camera basicGetCamera() {
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCamera(Camera newCamera, NotificationChain msgs) {
		Camera oldCamera = camera;
		camera = newCamera;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_SERVICE__CAMERA, oldCamera, newCamera);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCamera(Camera newCamera) {
		if (newCamera != camera) {
			NotificationChain msgs = null;
			if (camera != null)
				msgs = ((InternalEObject) camera).eInverseRemove(this, Cgm3Package.CAMERA__CLOUDSERVICE, Camera.class,
						msgs);
			if (newCamera != null)
				msgs = ((InternalEObject) newCamera).eInverseAdd(this, Cgm3Package.CAMERA__CLOUDSERVICE, Camera.class,
						msgs);
			msgs = basicSetCamera(newCamera, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_SERVICE__CAMERA, newCamera,
					newCamera));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DoorLock getDoorlock() {
		if (doorlock != null && doorlock.eIsProxy()) {
			InternalEObject oldDoorlock = (InternalEObject) doorlock;
			doorlock = (DoorLock) eResolveProxy(oldDoorlock);
			if (doorlock != oldDoorlock) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.CLOUD_SERVICE__DOORLOCK,
							oldDoorlock, doorlock));
			}
		}
		return doorlock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DoorLock basicGetDoorlock() {
		return doorlock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDoorlock(DoorLock newDoorlock, NotificationChain msgs) {
		DoorLock oldDoorlock = doorlock;
		doorlock = newDoorlock;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_SERVICE__DOORLOCK, oldDoorlock, newDoorlock);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoorlock(DoorLock newDoorlock) {
		if (newDoorlock != doorlock) {
			NotificationChain msgs = null;
			if (doorlock != null)
				msgs = ((InternalEObject) doorlock).eInverseRemove(this, Cgm3Package.DOOR_LOCK__CLOUDSERVICE,
						DoorLock.class, msgs);
			if (newDoorlock != null)
				msgs = ((InternalEObject) newDoorlock).eInverseAdd(this, Cgm3Package.DOOR_LOCK__CLOUDSERVICE,
						DoorLock.class, msgs);
			msgs = basicSetDoorlock(newDoorlock, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_SERVICE__DOORLOCK, newDoorlock,
					newDoorlock));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Thermostat getThermostat() {
		if (thermostat != null && thermostat.eIsProxy()) {
			InternalEObject oldThermostat = (InternalEObject) thermostat;
			thermostat = (Thermostat) eResolveProxy(oldThermostat);
			if (thermostat != oldThermostat) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.CLOUD_SERVICE__THERMOSTAT,
							oldThermostat, thermostat));
			}
		}
		return thermostat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Thermostat basicGetThermostat() {
		return thermostat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetThermostat(Thermostat newThermostat, NotificationChain msgs) {
		Thermostat oldThermostat = thermostat;
		thermostat = newThermostat;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CLOUD_SERVICE__THERMOSTAT, oldThermostat, newThermostat);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setThermostat(Thermostat newThermostat) {
		if (newThermostat != thermostat) {
			NotificationChain msgs = null;
			if (thermostat != null)
				msgs = ((InternalEObject) thermostat).eInverseRemove(this, Cgm3Package.THERMOSTAT__CLOUDSERVICE,
						Thermostat.class, msgs);
			if (newThermostat != null)
				msgs = ((InternalEObject) newThermostat).eInverseAdd(this, Cgm3Package.THERMOSTAT__CLOUDSERVICE,
						Thermostat.class, msgs);
			msgs = basicSetThermostat(newThermostat, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLOUD_SERVICE__THERMOSTAT, newThermostat,
					newThermostat));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.CLOUD_SERVICE__LIGHTSENSOR:
			if (lightsensor != null)
				msgs = ((InternalEObject) lightsensor).eInverseRemove(this, Cgm3Package.LIGHT_SENSOR__CLOUDSERVICE,
						LightSensor.class, msgs);
			return basicSetLightsensor((LightSensor) otherEnd, msgs);
		case Cgm3Package.CLOUD_SERVICE__PHONE:
			if (phone != null)
				msgs = ((InternalEObject) phone).eInverseRemove(this, Cgm3Package.PHONE__CLOUDSERVICE, Phone.class,
						msgs);
			return basicSetPhone((Phone) otherEnd, msgs);
		case Cgm3Package.CLOUD_SERVICE__CAMERA:
			if (camera != null)
				msgs = ((InternalEObject) camera).eInverseRemove(this, Cgm3Package.CAMERA__CLOUDSERVICE, Camera.class,
						msgs);
			return basicSetCamera((Camera) otherEnd, msgs);
		case Cgm3Package.CLOUD_SERVICE__DOORLOCK:
			if (doorlock != null)
				msgs = ((InternalEObject) doorlock).eInverseRemove(this, Cgm3Package.DOOR_LOCK__CLOUDSERVICE,
						DoorLock.class, msgs);
			return basicSetDoorlock((DoorLock) otherEnd, msgs);
		case Cgm3Package.CLOUD_SERVICE__THERMOSTAT:
			if (thermostat != null)
				msgs = ((InternalEObject) thermostat).eInverseRemove(this, Cgm3Package.THERMOSTAT__CLOUDSERVICE,
						Thermostat.class, msgs);
			return basicSetThermostat((Thermostat) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.CLOUD_SERVICE__STORAGELOCATION:
			return ((InternalEList<?>) getStoragelocation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLOUD_SERVICE__DATASHARING:
			return ((InternalEList<?>) getDatasharing()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLOUD_SERVICE__TEST_ON_DUMMY:
			return ((InternalEList<?>) getTest_on_dummy()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLOUD_SERVICE__CONTAINERISATION:
			return ((InternalEList<?>) getContainerisation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLOUD_SERVICE__AGGREGATION:
			return ((InternalEList<?>) getAggregation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLOUD_SERVICE__GPSTRACKER:
			return ((InternalEList<?>) getGpstracker()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLOUD_SERVICE__LIGHTSENSOR:
			return basicSetLightsensor(null, msgs);
		case Cgm3Package.CLOUD_SERVICE__PHONE:
			return basicSetPhone(null, msgs);
		case Cgm3Package.CLOUD_SERVICE__CAMERA:
			return basicSetCamera(null, msgs);
		case Cgm3Package.CLOUD_SERVICE__DOORLOCK:
			return basicSetDoorlock(null, msgs);
		case Cgm3Package.CLOUD_SERVICE__THERMOSTAT:
			return basicSetThermostat(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.CLOUD_SERVICE__ENCRYPTED_DATA:
			return getEncryptedData();
		case Cgm3Package.CLOUD_SERVICE__PRIVACY_PATTERNS:
			return getPrivacy_patterns();
		case Cgm3Package.CLOUD_SERVICE__DATA_RETENTION:
			return getDataRetention();
		case Cgm3Package.CLOUD_SERVICE__STORAGELOCATION:
			return getStoragelocation();
		case Cgm3Package.CLOUD_SERVICE__DATASHARING:
			return getDatasharing();
		case Cgm3Package.CLOUD_SERVICE__TEST_ON_DUMMY:
			return getTest_on_dummy();
		case Cgm3Package.CLOUD_SERVICE__CONTAINERISATION:
			return getContainerisation();
		case Cgm3Package.CLOUD_SERVICE__AGGREGATION:
			return getAggregation();
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE:
			return getAre_you_collecting_data_that_are_not_needed_for_the_purpose();
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			return getAre_you_processing_data_in_an_incompatible_way_with_the_purpose();
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT:
			return getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent();
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING:
			return getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();
		case Cgm3Package.CLOUD_SERVICE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			return getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();
		case Cgm3Package.CLOUD_SERVICE__GPSTRACKER:
			return getGpstracker();
		case Cgm3Package.CLOUD_SERVICE__VIDEOANALYTICS:
			if (resolve)
				return getVideoanalytics();
			return basicGetVideoanalytics();
		case Cgm3Package.CLOUD_SERVICE__VIDEOWITHOUTANALYTICS:
			if (resolve)
				return getVideowithoutanalytics();
			return basicGetVideowithoutanalytics();
		case Cgm3Package.CLOUD_SERVICE__LIGHTSENSOR:
			if (resolve)
				return getLightsensor();
			return basicGetLightsensor();
		case Cgm3Package.CLOUD_SERVICE__PHONE:
			if (resolve)
				return getPhone();
			return basicGetPhone();
		case Cgm3Package.CLOUD_SERVICE__CAMERA:
			if (resolve)
				return getCamera();
			return basicGetCamera();
		case Cgm3Package.CLOUD_SERVICE__DOORLOCK:
			if (resolve)
				return getDoorlock();
			return basicGetDoorlock();
		case Cgm3Package.CLOUD_SERVICE__THERMOSTAT:
			if (resolve)
				return getThermostat();
			return basicGetThermostat();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.CLOUD_SERVICE__ENCRYPTED_DATA:
			setEncryptedData((Checked) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__PRIVACY_PATTERNS:
			setPrivacy_patterns((String) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__DATA_RETENTION:
			setDataRetention((DataRetentionEnum) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__STORAGELOCATION:
			getStoragelocation().clear();
			getStoragelocation().addAll((Collection<? extends StorageLocation>) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__DATASHARING:
			getDatasharing().clear();
			getDatasharing().addAll((Collection<? extends DataSharing>) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__TEST_ON_DUMMY:
			getTest_on_dummy().clear();
			getTest_on_dummy().addAll((Collection<? extends Test_on_dummy>) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__CONTAINERISATION:
			getContainerisation().clear();
			getContainerisation().addAll((Collection<? extends Containerisation>) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__AGGREGATION:
			getAggregation().clear();
			getAggregation().addAll((Collection<? extends Aggregation>) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE:
			setAre_you_collecting_data_that_are_not_needed_for_the_purpose((Answer) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			setAre_you_processing_data_in_an_incompatible_way_with_the_purpose((Answer) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT:
			setAre_you_sharing_data_with_other_parties_without_having_data_subject_consent((Answer) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes((Answer) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING:
			setAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(
					(Answer) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
					(Answer) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__GPSTRACKER:
			getGpstracker().clear();
			getGpstracker().addAll((Collection<? extends GPSTracker>) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__VIDEOANALYTICS:
			setVideoanalytics((VideoAnalytics) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__VIDEOWITHOUTANALYTICS:
			setVideowithoutanalytics((VideoWithoutAnalytics) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__LIGHTSENSOR:
			setLightsensor((LightSensor) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__PHONE:
			setPhone((Phone) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__CAMERA:
			setCamera((Camera) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__DOORLOCK:
			setDoorlock((DoorLock) newValue);
			return;
		case Cgm3Package.CLOUD_SERVICE__THERMOSTAT:
			setThermostat((Thermostat) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.CLOUD_SERVICE__ENCRYPTED_DATA:
			setEncryptedData(ENCRYPTED_DATA_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_SERVICE__PRIVACY_PATTERNS:
			setPrivacy_patterns(PRIVACY_PATTERNS_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_SERVICE__DATA_RETENTION:
			setDataRetention(DATA_RETENTION_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_SERVICE__STORAGELOCATION:
			getStoragelocation().clear();
			return;
		case Cgm3Package.CLOUD_SERVICE__DATASHARING:
			getDatasharing().clear();
			return;
		case Cgm3Package.CLOUD_SERVICE__TEST_ON_DUMMY:
			getTest_on_dummy().clear();
			return;
		case Cgm3Package.CLOUD_SERVICE__CONTAINERISATION:
			getContainerisation().clear();
			return;
		case Cgm3Package.CLOUD_SERVICE__AGGREGATION:
			getAggregation().clear();
			return;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE:
			setAre_you_collecting_data_that_are_not_needed_for_the_purpose(
					ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(
					ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT:
			setAre_you_sharing_data_with_other_parties_without_having_data_subject_consent(
					ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
					ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING:
			setAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(
					ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_SERVICE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
					IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT);
			return;
		case Cgm3Package.CLOUD_SERVICE__GPSTRACKER:
			getGpstracker().clear();
			return;
		case Cgm3Package.CLOUD_SERVICE__VIDEOANALYTICS:
			setVideoanalytics((VideoAnalytics) null);
			return;
		case Cgm3Package.CLOUD_SERVICE__VIDEOWITHOUTANALYTICS:
			setVideowithoutanalytics((VideoWithoutAnalytics) null);
			return;
		case Cgm3Package.CLOUD_SERVICE__LIGHTSENSOR:
			setLightsensor((LightSensor) null);
			return;
		case Cgm3Package.CLOUD_SERVICE__PHONE:
			setPhone((Phone) null);
			return;
		case Cgm3Package.CLOUD_SERVICE__CAMERA:
			setCamera((Camera) null);
			return;
		case Cgm3Package.CLOUD_SERVICE__DOORLOCK:
			setDoorlock((DoorLock) null);
			return;
		case Cgm3Package.CLOUD_SERVICE__THERMOSTAT:
			setThermostat((Thermostat) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.CLOUD_SERVICE__ENCRYPTED_DATA:
			return encryptedData != ENCRYPTED_DATA_EDEFAULT;
		case Cgm3Package.CLOUD_SERVICE__PRIVACY_PATTERNS:
			return PRIVACY_PATTERNS_EDEFAULT == null ? privacy_patterns != null
					: !PRIVACY_PATTERNS_EDEFAULT.equals(privacy_patterns);
		case Cgm3Package.CLOUD_SERVICE__DATA_RETENTION:
			return dataRetention != DATA_RETENTION_EDEFAULT;
		case Cgm3Package.CLOUD_SERVICE__STORAGELOCATION:
			return storagelocation != null && !storagelocation.isEmpty();
		case Cgm3Package.CLOUD_SERVICE__DATASHARING:
			return datasharing != null && !datasharing.isEmpty();
		case Cgm3Package.CLOUD_SERVICE__TEST_ON_DUMMY:
			return test_on_dummy != null && !test_on_dummy.isEmpty();
		case Cgm3Package.CLOUD_SERVICE__CONTAINERISATION:
			return containerisation != null && !containerisation.isEmpty();
		case Cgm3Package.CLOUD_SERVICE__AGGREGATION:
			return aggregation != null && !aggregation.isEmpty();
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE:
			return are_you_collecting_data_that_are_not_needed_for_the_purpose != ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_EDEFAULT;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			return are_you_processing_data_in_an_incompatible_way_with_the_purpose != ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT:
			return are_you_sharing_data_with_other_parties_without_having_data_subject_consent != ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT_EDEFAULT;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes != ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;
		case Cgm3Package.CLOUD_SERVICE__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING:
			return are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing != ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING_EDEFAULT;
		case Cgm3Package.CLOUD_SERVICE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			return is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures != IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT;
		case Cgm3Package.CLOUD_SERVICE__GPSTRACKER:
			return gpstracker != null && !gpstracker.isEmpty();
		case Cgm3Package.CLOUD_SERVICE__VIDEOANALYTICS:
			return videoanalytics != null;
		case Cgm3Package.CLOUD_SERVICE__VIDEOWITHOUTANALYTICS:
			return videowithoutanalytics != null;
		case Cgm3Package.CLOUD_SERVICE__LIGHTSENSOR:
			return lightsensor != null;
		case Cgm3Package.CLOUD_SERVICE__PHONE:
			return phone != null;
		case Cgm3Package.CLOUD_SERVICE__CAMERA:
			return camera != null;
		case Cgm3Package.CLOUD_SERVICE__DOORLOCK:
			return doorlock != null;
		case Cgm3Package.CLOUD_SERVICE__THERMOSTAT:
			return thermostat != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.CLOUD_SERVICE__ENCRYPTED_DATA:
				return Cgm3Package.ENCRYPTION__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.CLOUD_SERVICE__PRIVACY_PATTERNS:
				return Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (baseFeatureID) {
			case Cgm3Package.ENCRYPTION__ENCRYPTED_DATA:
				return Cgm3Package.CLOUD_SERVICE__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (baseFeatureID) {
			case Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS:
				return Cgm3Package.CLOUD_SERVICE__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (EncryptedData: ");
		result.append(encryptedData);
		result.append(", Privacy_patterns: ");
		result.append(privacy_patterns);
		result.append(", DataRetention: ");
		result.append(dataRetention);
		result.append(", Are_you_collecting_data_that_are_not_needed_for_the_purpose: ");
		result.append(are_you_collecting_data_that_are_not_needed_for_the_purpose);
		result.append(", Are_you_processing_data_in_an_incompatible_way_with_the_purpose: ");
		result.append(are_you_processing_data_in_an_incompatible_way_with_the_purpose);
		result.append(", Are_you_sharing_data_with_other_parties_without_having_data_subject_consent: ");
		result.append(are_you_sharing_data_with_other_parties_without_having_data_subject_consent);
		result.append(", Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes: ");
		result.append(are_you_storing_the_data_longer_than_is_necessary_for_the_purposes);
		result.append(", Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing: ");
		result.append(are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing);
		result.append(
				", Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures: ");
		result.append(
				is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures);
		result.append(')');
		return result.toString();
	}

} //CloudServiceImpl
