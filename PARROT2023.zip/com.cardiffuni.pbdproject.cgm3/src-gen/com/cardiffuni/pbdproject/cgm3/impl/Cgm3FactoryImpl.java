/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Cgm3FactoryImpl extends EFactoryImpl implements Cgm3Factory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Cgm3Factory init() {
		try {
			Cgm3Factory theCgm3Factory = (Cgm3Factory) EPackage.Registry.INSTANCE.getEFactory(Cgm3Package.eNS_URI);
			if (theCgm3Factory != null) {
				return theCgm3Factory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new Cgm3FactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cgm3FactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case Cgm3Package.CG_MSENSOR:
			return createCGMsensor();
		case Cgm3Package.SMART_PHONE:
			return createSmartPhone();
		case Cgm3Package.PATIENT:
			return createPatient();
		case Cgm3Package.NURSE:
			return createNurse();
		case Cgm3Package.DOCTOR:
			return createDoctor();
		case Cgm3Package.NEW_ECLASS7:
			return createNewEClass7();
		case Cgm3Package.CLOUD:
			return createCloud();
		case Cgm3Package.WEBSITE:
			return createWebsite();
		case Cgm3Package.HOSPITAL:
			return createHospital();
		case Cgm3Package.RESEARCHER:
			return createResearcher();
		case Cgm3Package.MEDICAL_RECORD:
			return createMedicalRecord();
		case Cgm3Package.CONSENT_CHECKED_LIST:
			return createConsent_CheckedList();
		case Cgm3Package.STORAGE_LOCATION:
			return createStorageLocation();
		case Cgm3Package.USER_LOCATION:
			return createUserLocation();
		case Cgm3Package.RISK_CODE:
			return createRiskCode();
		case Cgm3Package.AUTHENTICATION:
			return createAuthentication();
		case Cgm3Package.AUTHORIZATION:
			return createAuthorization();
		case Cgm3Package.FIREWALL:
			return createFirewall();
		case Cgm3Package.DATA_SHARING:
			return createDataSharing();
		case Cgm3Package.WARNING:
			return createWarning();
		case Cgm3Package.TEST_ON_DUMMY:
			return createTest_on_dummy();
		case Cgm3Package.CONTAINERISATION:
			return createContainerisation();
		case Cgm3Package.AGGREGATION:
			return createAggregation();
		case Cgm3Package.NEW_ECLASS26:
			return createNewEClass26();
		case Cgm3Package.COMPUTER_BROWSER:
			return createComputerBrowser();
		case Cgm3Package.NEW_ECLASS28:
			return createNewEClass28();
		case Cgm3Package.PHARMACY_CLOUDOLD:
			return createPharmacyCloudold();
		case Cgm3Package.SHIPPING_CLOUD:
			return createShippingCloud();
		case Cgm3Package.WEBHOSTING_CLOUD:
			return createWebhostingCloud();
		case Cgm3Package.PAYMENT_CLOUD:
			return createPaymentCloud();
		case Cgm3Package.SOCIAL_NETWORK_CLOUD:
			return createSocialNetworkCloud();
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD:
			return createRealTimeBiddingCloud();
		case Cgm3Package.WEB_BROWSER:
			return createWebBrowser();
		case Cgm3Package.CLOUD_FOR_PHARMACY:
			return createCloudForPharmacy();
		case Cgm3Package.BUS:
			return createBus();
		case Cgm3Package.GPS_TRACKER:
			return createGPSTracker();
		case Cgm3Package.VIDEO_ANALYTICS:
			return createVideoAnalytics();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS:
			return createVideoWithoutAnalytics();
		case Cgm3Package.DRIVER:
			return createDriver();
		case Cgm3Package.CUSTOMER:
			return createCustomer();
		case Cgm3Package.ANALYTICS:
			return createAnalytics();
		case Cgm3Package.BLURRING:
			return createBlurring();
		case Cgm3Package.VIDEO_PROCESSING_CLOUD:
			return createVideoProcessingCloud();
		case Cgm3Package.CLIENT:
			return createClient();
		case Cgm3Package.CLOUD_SERVICE:
			return createCloudService();
		case Cgm3Package.LIGHT_SENSOR:
			return createLightSensor();
		case Cgm3Package.PHONE:
			return createPhone();
		case Cgm3Package.DOOR_LOCK:
			return createDoorLock();
		case Cgm3Package.THERMOSTAT:
			return createThermostat();
		case Cgm3Package.CAMERA:
			return createCamera();
		case Cgm3Package.COOKIES:
			return createCookies();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case Cgm3Package.DATA_RETENTION_ENUM:
			return createDataRetentionEnumFromString(eDataType, initialValue);
		case Cgm3Package.PATIENT_HEALTH_STATUS:
			return createPatientHealthStatusFromString(eDataType, initialValue);
		case Cgm3Package.COMMUNICATION_PROTOCOLS:
			return createCommunicationProtocolsFromString(eDataType, initialValue);
		case Cgm3Package.CHECKED_CONSENT:
			return createChecked_ConsentFromString(eDataType, initialValue);
		case Cgm3Package.CLOUD_STORAGE_LOCATION:
			return createCloudStorageLocationFromString(eDataType, initialValue);
		case Cgm3Package.LOCATION_GRANULARITY:
			return createLocationGranularityFromString(eDataType, initialValue);
		case Cgm3Package.CHECKED:
			return createCheckedFromString(eDataType, initialValue);
		case Cgm3Package.CLOUD_PROVIDER_SERVER:
			return createCloudProviderServerFromString(eDataType, initialValue);
		case Cgm3Package.TEST_ON_DUMMY_DATA:
			return createTestOnDummyDataFromString(eDataType, initialValue);
		case Cgm3Package.ANSWER:
			return createAnswerFromString(eDataType, initialValue);
		case Cgm3Package.CONSENT_DATA_TYPE:
			return createConsentDataTypeFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case Cgm3Package.DATA_RETENTION_ENUM:
			return convertDataRetentionEnumToString(eDataType, instanceValue);
		case Cgm3Package.PATIENT_HEALTH_STATUS:
			return convertPatientHealthStatusToString(eDataType, instanceValue);
		case Cgm3Package.COMMUNICATION_PROTOCOLS:
			return convertCommunicationProtocolsToString(eDataType, instanceValue);
		case Cgm3Package.CHECKED_CONSENT:
			return convertChecked_ConsentToString(eDataType, instanceValue);
		case Cgm3Package.CLOUD_STORAGE_LOCATION:
			return convertCloudStorageLocationToString(eDataType, instanceValue);
		case Cgm3Package.LOCATION_GRANULARITY:
			return convertLocationGranularityToString(eDataType, instanceValue);
		case Cgm3Package.CHECKED:
			return convertCheckedToString(eDataType, instanceValue);
		case Cgm3Package.CLOUD_PROVIDER_SERVER:
			return convertCloudProviderServerToString(eDataType, instanceValue);
		case Cgm3Package.TEST_ON_DUMMY_DATA:
			return convertTestOnDummyDataToString(eDataType, instanceValue);
		case Cgm3Package.ANSWER:
			return convertAnswerToString(eDataType, instanceValue);
		case Cgm3Package.CONSENT_DATA_TYPE:
			return convertConsentDataTypeToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CGMsensor createCGMsensor() {
		CGMsensorImpl cgMsensor = new CGMsensorImpl();
		return cgMsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartPhone createSmartPhone() {
		SmartPhoneImpl smartPhone = new SmartPhoneImpl();
		return smartPhone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Patient createPatient() {
		PatientImpl patient = new PatientImpl();
		return patient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Nurse createNurse() {
		NurseImpl nurse = new NurseImpl();
		return nurse;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Doctor createDoctor() {
		DoctorImpl doctor = new DoctorImpl();
		return doctor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NewEClass7 createNewEClass7() {
		NewEClass7Impl newEClass7 = new NewEClass7Impl();
		return newEClass7;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cloud createCloud() {
		CloudImpl cloud = new CloudImpl();
		return cloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Website createWebsite() {
		WebsiteImpl website = new WebsiteImpl();
		return website;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Hospital createHospital() {
		HospitalImpl hospital = new HospitalImpl();
		return hospital;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Researcher createResearcher() {
		ResearcherImpl researcher = new ResearcherImpl();
		return researcher;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MedicalRecord createMedicalRecord() {
		MedicalRecordImpl medicalRecord = new MedicalRecordImpl();
		return medicalRecord;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Consent_CheckedList createConsent_CheckedList() {
		Consent_CheckedListImpl consent_CheckedList = new Consent_CheckedListImpl();
		return consent_CheckedList;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StorageLocation createStorageLocation() {
		StorageLocationImpl storageLocation = new StorageLocationImpl();
		return storageLocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserLocation createUserLocation() {
		UserLocationImpl userLocation = new UserLocationImpl();
		return userLocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RiskCode createRiskCode() {
		RiskCodeImpl riskCode = new RiskCodeImpl();
		return riskCode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Authentication createAuthentication() {
		AuthenticationImpl authentication = new AuthenticationImpl();
		return authentication;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Authorization createAuthorization() {
		AuthorizationImpl authorization = new AuthorizationImpl();
		return authorization;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Firewall createFirewall() {
		FirewallImpl firewall = new FirewallImpl();
		return firewall;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataSharing createDataSharing() {
		DataSharingImpl dataSharing = new DataSharingImpl();
		return dataSharing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Warning createWarning() {
		WarningImpl warning = new WarningImpl();
		return warning;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Test_on_dummy createTest_on_dummy() {
		Test_on_dummyImpl test_on_dummy = new Test_on_dummyImpl();
		return test_on_dummy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Containerisation createContainerisation() {
		ContainerisationImpl containerisation = new ContainerisationImpl();
		return containerisation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Aggregation createAggregation() {
		AggregationImpl aggregation = new AggregationImpl();
		return aggregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NewEClass26 createNewEClass26() {
		NewEClass26Impl newEClass26 = new NewEClass26Impl();
		return newEClass26;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ComputerBrowser createComputerBrowser() {
		ComputerBrowserImpl computerBrowser = new ComputerBrowserImpl();
		return computerBrowser;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NewEClass28 createNewEClass28() {
		NewEClass28Impl newEClass28 = new NewEClass28Impl();
		return newEClass28;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PharmacyCloudold createPharmacyCloudold() {
		PharmacyCloudoldImpl pharmacyCloudold = new PharmacyCloudoldImpl();
		return pharmacyCloudold;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ShippingCloud createShippingCloud() {
		ShippingCloudImpl shippingCloud = new ShippingCloudImpl();
		return shippingCloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebhostingCloud createWebhostingCloud() {
		WebhostingCloudImpl webhostingCloud = new WebhostingCloudImpl();
		return webhostingCloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaymentCloud createPaymentCloud() {
		PaymentCloudImpl paymentCloud = new PaymentCloudImpl();
		return paymentCloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SocialNetworkCloud createSocialNetworkCloud() {
		SocialNetworkCloudImpl socialNetworkCloud = new SocialNetworkCloudImpl();
		return socialNetworkCloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RealTimeBiddingCloud createRealTimeBiddingCloud() {
		RealTimeBiddingCloudImpl realTimeBiddingCloud = new RealTimeBiddingCloudImpl();
		return realTimeBiddingCloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebBrowser createWebBrowser() {
		WebBrowserImpl webBrowser = new WebBrowserImpl();
		return webBrowser;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudForPharmacy createCloudForPharmacy() {
		CloudForPharmacyImpl cloudForPharmacy = new CloudForPharmacyImpl();
		return cloudForPharmacy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Bus createBus() {
		BusImpl bus = new BusImpl();
		return bus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GPSTracker createGPSTracker() {
		GPSTrackerImpl gpsTracker = new GPSTrackerImpl();
		return gpsTracker;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoAnalytics createVideoAnalytics() {
		VideoAnalyticsImpl videoAnalytics = new VideoAnalyticsImpl();
		return videoAnalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoWithoutAnalytics createVideoWithoutAnalytics() {
		VideoWithoutAnalyticsImpl videoWithoutAnalytics = new VideoWithoutAnalyticsImpl();
		return videoWithoutAnalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Driver createDriver() {
		DriverImpl driver = new DriverImpl();
		return driver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Customer createCustomer() {
		CustomerImpl customer = new CustomerImpl();
		return customer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Analytics createAnalytics() {
		AnalyticsImpl analytics = new AnalyticsImpl();
		return analytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Blurring createBlurring() {
		BlurringImpl blurring = new BlurringImpl();
		return blurring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoProcessingCloud createVideoProcessingCloud() {
		VideoProcessingCloudImpl videoProcessingCloud = new VideoProcessingCloudImpl();
		return videoProcessingCloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Client createClient() {
		ClientImpl client = new ClientImpl();
		return client;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudService createCloudService() {
		CloudServiceImpl cloudService = new CloudServiceImpl();
		return cloudService;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LightSensor createLightSensor() {
		LightSensorImpl lightSensor = new LightSensorImpl();
		return lightSensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Phone createPhone() {
		PhoneImpl phone = new PhoneImpl();
		return phone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DoorLock createDoorLock() {
		DoorLockImpl doorLock = new DoorLockImpl();
		return doorLock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Thermostat createThermostat() {
		ThermostatImpl thermostat = new ThermostatImpl();
		return thermostat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Camera createCamera() {
		CameraImpl camera = new CameraImpl();
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cookies createCookies() {
		CookiesImpl cookies = new CookiesImpl();
		return cookies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataRetentionEnum createDataRetentionEnumFromString(EDataType eDataType, String initialValue) {
		DataRetentionEnum result = DataRetentionEnum.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertDataRetentionEnumToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PatientHealthStatus createPatientHealthStatusFromString(EDataType eDataType, String initialValue) {
		PatientHealthStatus result = PatientHealthStatus.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPatientHealthStatusToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CommunicationProtocols createCommunicationProtocolsFromString(EDataType eDataType, String initialValue) {
		CommunicationProtocols result = CommunicationProtocols.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertCommunicationProtocolsToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked_Consent createChecked_ConsentFromString(EDataType eDataType, String initialValue) {
		Checked_Consent result = Checked_Consent.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertChecked_ConsentToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudStorageLocation createCloudStorageLocationFromString(EDataType eDataType, String initialValue) {
		CloudStorageLocation result = CloudStorageLocation.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertCloudStorageLocationToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LocationGranularity createLocationGranularityFromString(EDataType eDataType, String initialValue) {
		LocationGranularity result = LocationGranularity.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertLocationGranularityToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked createCheckedFromString(EDataType eDataType, String initialValue) {
		Checked result = Checked.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertCheckedToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudProviderServer createCloudProviderServerFromString(EDataType eDataType, String initialValue) {
		CloudProviderServer result = CloudProviderServer.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertCloudProviderServerToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TestOnDummyData createTestOnDummyDataFromString(EDataType eDataType, String initialValue) {
		TestOnDummyData result = TestOnDummyData.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTestOnDummyDataToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer createAnswerFromString(EDataType eDataType, String initialValue) {
		Answer result = Answer.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertAnswerToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object createConsentDataTypeFromString(EDataType eDataType, String initialValue) {
		return super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertConsentDataTypeToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cgm3Package getCgm3Package() {
		return (Cgm3Package) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static Cgm3Package getPackage() {
		return Cgm3Package.eINSTANCE;
	}

} //Cgm3FactoryImpl
