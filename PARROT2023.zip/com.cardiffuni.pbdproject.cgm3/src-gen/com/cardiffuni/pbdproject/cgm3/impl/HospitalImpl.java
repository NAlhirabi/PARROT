/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Aggregation;
import com.cardiffuni.pbdproject.cgm3.Analytics;
import com.cardiffuni.pbdproject.cgm3.Blurring;
import com.cardiffuni.pbdproject.cgm3.Bus;
import com.cardiffuni.pbdproject.cgm3.CGMsensor;
import com.cardiffuni.pbdproject.cgm3.Camera;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Client;
import com.cardiffuni.pbdproject.cgm3.Cloud;
import com.cardiffuni.pbdproject.cgm3.CloudForPharmacy;
import com.cardiffuni.pbdproject.cgm3.CloudService;
import com.cardiffuni.pbdproject.cgm3.ComputerBrowser;
import com.cardiffuni.pbdproject.cgm3.Consent_CheckedList;
import com.cardiffuni.pbdproject.cgm3.Containerisation;
import com.cardiffuni.pbdproject.cgm3.Cookies;
import com.cardiffuni.pbdproject.cgm3.Customer;
import com.cardiffuni.pbdproject.cgm3.DataSharing;
import com.cardiffuni.pbdproject.cgm3.Doctor;
import com.cardiffuni.pbdproject.cgm3.DoorLock;
import com.cardiffuni.pbdproject.cgm3.Driver;
import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.GPSTracker;
import com.cardiffuni.pbdproject.cgm3.Hospital;
import com.cardiffuni.pbdproject.cgm3.LightSensor;
import com.cardiffuni.pbdproject.cgm3.MedicalRecord;
import com.cardiffuni.pbdproject.cgm3.Nurse;
import com.cardiffuni.pbdproject.cgm3.Patient;
import com.cardiffuni.pbdproject.cgm3.PaymentCloud;
import com.cardiffuni.pbdproject.cgm3.PharmacyCloudold;
import com.cardiffuni.pbdproject.cgm3.Phone;
import com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud;
import com.cardiffuni.pbdproject.cgm3.Researcher;
import com.cardiffuni.pbdproject.cgm3.RiskCode;
import com.cardiffuni.pbdproject.cgm3.ShippingCloud;
import com.cardiffuni.pbdproject.cgm3.SmartPhone;
import com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud;
import com.cardiffuni.pbdproject.cgm3.StorageLocation;
import com.cardiffuni.pbdproject.cgm3.Test_on_dummy;
import com.cardiffuni.pbdproject.cgm3.Thermostat;
import com.cardiffuni.pbdproject.cgm3.UserLocation;
import com.cardiffuni.pbdproject.cgm3.VideoAnalytics;
import com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud;
import com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics;
import com.cardiffuni.pbdproject.cgm3.Warning;
import com.cardiffuni.pbdproject.cgm3.WebBrowser;
import com.cardiffuni.pbdproject.cgm3.WebhostingCloud;
import com.cardiffuni.pbdproject.cgm3.Website;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Hospital</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getPatient <em>Patient</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getDoctor <em>Doctor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getResearcher <em>Researcher</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getNurse <em>Nurse</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getCloud <em>Cloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getWebsite <em>Website</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getSmartphone <em>Smartphone</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getCgmsensor <em>Cgmsensor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getMedicalrecord <em>Medicalrecord</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getConsent_checkedlist <em>Consent checkedlist</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getStoragelocation <em>Storagelocation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getUserlocation <em>Userlocation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getRiskcode <em>Riskcode</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getEncryption <em>Encryption</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getDatasharing <em>Datasharing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getWarning <em>Warning</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getTest_on_dummy <em>Test on dummy</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getContainerisation <em>Containerisation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getAggregation <em>Aggregation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getComputerbrowser <em>Computerbrowser</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getPharmacycloud <em>Pharmacycloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getShippingcloud <em>Shippingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getWebhostingcloud <em>Webhostingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getPaymentcloud <em>Paymentcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getSocialnetworkcloud <em>Socialnetworkcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getWebbrowser <em>Webbrowser</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getCloudforpharmacy <em>Cloudforpharmacy</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getRealtimebiddingcloud <em>Realtimebiddingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getGpstracker <em>Gpstracker</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getBus <em>Bus</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getDriver <em>Driver</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getCustomer <em>Customer</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getVideoanalytics <em>Videoanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getAnalytics <em>Analytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getBlurring <em>Blurring</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getVideoprocessingcloud <em>Videoprocessingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getVideowithoutanalytics <em>Videowithoutanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getClient <em>Client</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getCloudservice <em>Cloudservice</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getLightsensor <em>Lightsensor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getPhone <em>Phone</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getThermostat <em>Thermostat</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getDoorlock <em>Doorlock</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getCamera <em>Camera</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl#getCookies <em>Cookies</em>}</li>
 * </ul>
 *
 * @generated
 */
public class HospitalImpl extends GeneralEntityImpl implements Hospital {
	/**
	 * The cached value of the '{@link #getPatient() <em>Patient</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatient()
	 * @generated
	 * @ordered
	 */
	protected EList<Patient> patient;

	/**
	 * The cached value of the '{@link #getDoctor() <em>Doctor</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoctor()
	 * @generated
	 * @ordered
	 */
	protected EList<Doctor> doctor;

	/**
	 * The cached value of the '{@link #getResearcher() <em>Researcher</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getResearcher()
	 * @generated
	 * @ordered
	 */
	protected EList<Researcher> researcher;

	/**
	 * The cached value of the '{@link #getNurse() <em>Nurse</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNurse()
	 * @generated
	 * @ordered
	 */
	protected EList<Nurse> nurse;

	/**
	 * The cached value of the '{@link #getCloud() <em>Cloud</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCloud()
	 * @generated
	 * @ordered
	 */
	protected EList<Cloud> cloud;

	/**
	 * The cached value of the '{@link #getWebsite() <em>Website</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWebsite()
	 * @generated
	 * @ordered
	 */
	protected EList<Website> website;

	/**
	 * The cached value of the '{@link #getSmartphone() <em>Smartphone</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSmartphone()
	 * @generated
	 * @ordered
	 */
	protected EList<SmartPhone> smartphone;

	/**
	 * The cached value of the '{@link #getCgmsensor() <em>Cgmsensor</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCgmsensor()
	 * @generated
	 * @ordered
	 */
	protected EList<CGMsensor> cgmsensor;

	/**
	 * The cached value of the '{@link #getMedicalrecord() <em>Medicalrecord</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMedicalrecord()
	 * @generated
	 * @ordered
	 */
	protected EList<MedicalRecord> medicalrecord;

	/**
	 * The cached value of the '{@link #getConsent_checkedlist() <em>Consent checkedlist</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConsent_checkedlist()
	 * @generated
	 * @ordered
	 */
	protected EList<Consent_CheckedList> consent_checkedlist;

	/**
	 * The cached value of the '{@link #getStoragelocation() <em>Storagelocation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStoragelocation()
	 * @generated
	 * @ordered
	 */
	protected EList<StorageLocation> storagelocation;

	/**
	 * The cached value of the '{@link #getUserlocation() <em>Userlocation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserlocation()
	 * @generated
	 * @ordered
	 */
	protected EList<UserLocation> userlocation;

	/**
	 * The cached value of the '{@link #getRiskcode() <em>Riskcode</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRiskcode()
	 * @generated
	 * @ordered
	 */
	protected EList<RiskCode> riskcode;

	/**
	 * The cached value of the '{@link #getEncryption() <em>Encryption</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryption()
	 * @generated
	 * @ordered
	 */
	protected EList<Encryption> encryption;

	/**
	 * The cached value of the '{@link #getDatasharing() <em>Datasharing</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDatasharing()
	 * @generated
	 * @ordered
	 */
	protected EList<DataSharing> datasharing;

	/**
	 * The cached value of the '{@link #getWarning() <em>Warning</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWarning()
	 * @generated
	 * @ordered
	 */
	protected EList<Warning> warning;

	/**
	 * The cached value of the '{@link #getTest_on_dummy() <em>Test on dummy</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTest_on_dummy()
	 * @generated
	 * @ordered
	 */
	protected EList<Test_on_dummy> test_on_dummy;

	/**
	 * The cached value of the '{@link #getContainerisation() <em>Containerisation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContainerisation()
	 * @generated
	 * @ordered
	 */
	protected EList<Containerisation> containerisation;

	/**
	 * The cached value of the '{@link #getAggregation() <em>Aggregation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAggregation()
	 * @generated
	 * @ordered
	 */
	protected EList<Aggregation> aggregation;

	/**
	 * The cached value of the '{@link #getComputerbrowser() <em>Computerbrowser</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComputerbrowser()
	 * @generated
	 * @ordered
	 */
	protected EList<ComputerBrowser> computerbrowser;

	/**
	 * The cached value of the '{@link #getPharmacycloud() <em>Pharmacycloud</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPharmacycloud()
	 * @generated
	 * @ordered
	 */
	protected EList<PharmacyCloudold> pharmacycloud;

	/**
	 * The cached value of the '{@link #getShippingcloud() <em>Shippingcloud</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getShippingcloud()
	 * @generated
	 * @ordered
	 */
	protected EList<ShippingCloud> shippingcloud;

	/**
	 * The cached value of the '{@link #getWebhostingcloud() <em>Webhostingcloud</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWebhostingcloud()
	 * @generated
	 * @ordered
	 */
	protected EList<WebhostingCloud> webhostingcloud;

	/**
	 * The cached value of the '{@link #getPaymentcloud() <em>Paymentcloud</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPaymentcloud()
	 * @generated
	 * @ordered
	 */
	protected EList<PaymentCloud> paymentcloud;

	/**
	 * The cached value of the '{@link #getSocialnetworkcloud() <em>Socialnetworkcloud</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSocialnetworkcloud()
	 * @generated
	 * @ordered
	 */
	protected EList<SocialNetworkCloud> socialnetworkcloud;

	/**
	 * The cached value of the '{@link #getWebbrowser() <em>Webbrowser</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWebbrowser()
	 * @generated
	 * @ordered
	 */
	protected EList<WebBrowser> webbrowser;

	/**
	 * The cached value of the '{@link #getCloudforpharmacy() <em>Cloudforpharmacy</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCloudforpharmacy()
	 * @generated
	 * @ordered
	 */
	protected EList<CloudForPharmacy> cloudforpharmacy;

	/**
	 * The cached value of the '{@link #getRealtimebiddingcloud() <em>Realtimebiddingcloud</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRealtimebiddingcloud()
	 * @generated
	 * @ordered
	 */
	protected EList<RealTimeBiddingCloud> realtimebiddingcloud;

	/**
	 * The cached value of the '{@link #getGpstracker() <em>Gpstracker</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGpstracker()
	 * @generated
	 * @ordered
	 */
	protected EList<GPSTracker> gpstracker;

	/**
	 * The cached value of the '{@link #getBus() <em>Bus</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBus()
	 * @generated
	 * @ordered
	 */
	protected EList<Bus> bus;

	/**
	 * The cached value of the '{@link #getDriver() <em>Driver</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDriver()
	 * @generated
	 * @ordered
	 */
	protected EList<Driver> driver;

	/**
	 * The cached value of the '{@link #getCustomer() <em>Customer</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustomer()
	 * @generated
	 * @ordered
	 */
	protected EList<Customer> customer;

	/**
	 * The cached value of the '{@link #getVideoanalytics() <em>Videoanalytics</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVideoanalytics()
	 * @generated
	 * @ordered
	 */
	protected EList<VideoAnalytics> videoanalytics;

	/**
	 * The cached value of the '{@link #getAnalytics() <em>Analytics</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnalytics()
	 * @generated
	 * @ordered
	 */
	protected EList<Analytics> analytics;

	/**
	 * The cached value of the '{@link #getBlurring() <em>Blurring</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBlurring()
	 * @generated
	 * @ordered
	 */
	protected EList<Blurring> blurring;

	/**
	 * The cached value of the '{@link #getVideoprocessingcloud() <em>Videoprocessingcloud</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVideoprocessingcloud()
	 * @generated
	 * @ordered
	 */
	protected EList<VideoProcessingCloud> videoprocessingcloud;

	/**
	 * The cached value of the '{@link #getVideowithoutanalytics() <em>Videowithoutanalytics</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVideowithoutanalytics()
	 * @generated
	 * @ordered
	 */
	protected EList<VideoWithoutAnalytics> videowithoutanalytics;

	/**
	 * The cached value of the '{@link #getClient() <em>Client</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getClient()
	 * @generated
	 * @ordered
	 */
	protected EList<Client> client;

	/**
	 * The cached value of the '{@link #getCloudservice() <em>Cloudservice</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCloudservice()
	 * @generated
	 * @ordered
	 */
	protected EList<CloudService> cloudservice;

	/**
	 * The cached value of the '{@link #getLightsensor() <em>Lightsensor</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLightsensor()
	 * @generated
	 * @ordered
	 */
	protected EList<LightSensor> lightsensor;

	/**
	 * The cached value of the '{@link #getPhone() <em>Phone</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhone()
	 * @generated
	 * @ordered
	 */
	protected EList<Phone> phone;

	/**
	 * The cached value of the '{@link #getThermostat() <em>Thermostat</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThermostat()
	 * @generated
	 * @ordered
	 */
	protected EList<Thermostat> thermostat;

	/**
	 * The cached value of the '{@link #getDoorlock() <em>Doorlock</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoorlock()
	 * @generated
	 * @ordered
	 */
	protected EList<DoorLock> doorlock;

	/**
	 * The cached value of the '{@link #getCamera() <em>Camera</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCamera()
	 * @generated
	 * @ordered
	 */
	protected EList<Camera> camera;

	/**
	 * The cached value of the '{@link #getCookies() <em>Cookies</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCookies()
	 * @generated
	 * @ordered
	 */
	protected EList<Cookies> cookies;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HospitalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.HOSPITAL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Patient> getPatient() {
		if (patient == null) {
			patient = new EObjectContainmentEList<Patient>(Patient.class, this, Cgm3Package.HOSPITAL__PATIENT);
		}
		return patient;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Doctor> getDoctor() {
		if (doctor == null) {
			doctor = new EObjectContainmentEList<Doctor>(Doctor.class, this, Cgm3Package.HOSPITAL__DOCTOR);
		}
		return doctor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Researcher> getResearcher() {
		if (researcher == null) {
			researcher = new EObjectContainmentEList<Researcher>(Researcher.class, this,
					Cgm3Package.HOSPITAL__RESEARCHER);
		}
		return researcher;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Nurse> getNurse() {
		if (nurse == null) {
			nurse = new EObjectContainmentEList<Nurse>(Nurse.class, this, Cgm3Package.HOSPITAL__NURSE);
		}
		return nurse;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Cloud> getCloud() {
		if (cloud == null) {
			cloud = new EObjectContainmentEList<Cloud>(Cloud.class, this, Cgm3Package.HOSPITAL__CLOUD);
		}
		return cloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Website> getWebsite() {
		if (website == null) {
			website = new EObjectContainmentEList<Website>(Website.class, this, Cgm3Package.HOSPITAL__WEBSITE);
		}
		return website;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SmartPhone> getSmartphone() {
		if (smartphone == null) {
			smartphone = new EObjectContainmentEList<SmartPhone>(SmartPhone.class, this,
					Cgm3Package.HOSPITAL__SMARTPHONE);
		}
		return smartphone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CGMsensor> getCgmsensor() {
		if (cgmsensor == null) {
			cgmsensor = new EObjectContainmentEList<CGMsensor>(CGMsensor.class, this, Cgm3Package.HOSPITAL__CGMSENSOR);
		}
		return cgmsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<MedicalRecord> getMedicalrecord() {
		if (medicalrecord == null) {
			medicalrecord = new EObjectContainmentEList<MedicalRecord>(MedicalRecord.class, this,
					Cgm3Package.HOSPITAL__MEDICALRECORD);
		}
		return medicalrecord;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Consent_CheckedList> getConsent_checkedlist() {
		if (consent_checkedlist == null) {
			consent_checkedlist = new EObjectContainmentEList<Consent_CheckedList>(Consent_CheckedList.class, this,
					Cgm3Package.HOSPITAL__CONSENT_CHECKEDLIST);
		}
		return consent_checkedlist;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<StorageLocation> getStoragelocation() {
		if (storagelocation == null) {
			storagelocation = new EObjectContainmentEList<StorageLocation>(StorageLocation.class, this,
					Cgm3Package.HOSPITAL__STORAGELOCATION);
		}
		return storagelocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<UserLocation> getUserlocation() {
		if (userlocation == null) {
			userlocation = new EObjectContainmentEList<UserLocation>(UserLocation.class, this,
					Cgm3Package.HOSPITAL__USERLOCATION);
		}
		return userlocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RiskCode> getRiskcode() {
		if (riskcode == null) {
			riskcode = new EObjectContainmentEList<RiskCode>(RiskCode.class, this, Cgm3Package.HOSPITAL__RISKCODE);
		}
		return riskcode;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Encryption> getEncryption() {
		if (encryption == null) {
			encryption = new EObjectContainmentEList<Encryption>(Encryption.class, this,
					Cgm3Package.HOSPITAL__ENCRYPTION);
		}
		return encryption;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DataSharing> getDatasharing() {
		if (datasharing == null) {
			datasharing = new EObjectContainmentEList<DataSharing>(DataSharing.class, this,
					Cgm3Package.HOSPITAL__DATASHARING);
		}
		return datasharing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Warning> getWarning() {
		if (warning == null) {
			warning = new EObjectContainmentEList<Warning>(Warning.class, this, Cgm3Package.HOSPITAL__WARNING);
		}
		return warning;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Test_on_dummy> getTest_on_dummy() {
		if (test_on_dummy == null) {
			test_on_dummy = new EObjectContainmentEList<Test_on_dummy>(Test_on_dummy.class, this,
					Cgm3Package.HOSPITAL__TEST_ON_DUMMY);
		}
		return test_on_dummy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Containerisation> getContainerisation() {
		if (containerisation == null) {
			containerisation = new EObjectContainmentEList<Containerisation>(Containerisation.class, this,
					Cgm3Package.HOSPITAL__CONTAINERISATION);
		}
		return containerisation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Aggregation> getAggregation() {
		if (aggregation == null) {
			aggregation = new EObjectContainmentEList<Aggregation>(Aggregation.class, this,
					Cgm3Package.HOSPITAL__AGGREGATION);
		}
		return aggregation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ComputerBrowser> getComputerbrowser() {
		if (computerbrowser == null) {
			computerbrowser = new EObjectContainmentEList<ComputerBrowser>(ComputerBrowser.class, this,
					Cgm3Package.HOSPITAL__COMPUTERBROWSER);
		}
		return computerbrowser;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PharmacyCloudold> getPharmacycloud() {
		if (pharmacycloud == null) {
			pharmacycloud = new EObjectContainmentEList<PharmacyCloudold>(PharmacyCloudold.class, this,
					Cgm3Package.HOSPITAL__PHARMACYCLOUD);
		}
		return pharmacycloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ShippingCloud> getShippingcloud() {
		if (shippingcloud == null) {
			shippingcloud = new EObjectContainmentEList<ShippingCloud>(ShippingCloud.class, this,
					Cgm3Package.HOSPITAL__SHIPPINGCLOUD);
		}
		return shippingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<WebhostingCloud> getWebhostingcloud() {
		if (webhostingcloud == null) {
			webhostingcloud = new EObjectContainmentEList<WebhostingCloud>(WebhostingCloud.class, this,
					Cgm3Package.HOSPITAL__WEBHOSTINGCLOUD);
		}
		return webhostingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PaymentCloud> getPaymentcloud() {
		if (paymentcloud == null) {
			paymentcloud = new EObjectContainmentEList<PaymentCloud>(PaymentCloud.class, this,
					Cgm3Package.HOSPITAL__PAYMENTCLOUD);
		}
		return paymentcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SocialNetworkCloud> getSocialnetworkcloud() {
		if (socialnetworkcloud == null) {
			socialnetworkcloud = new EObjectContainmentEList<SocialNetworkCloud>(SocialNetworkCloud.class, this,
					Cgm3Package.HOSPITAL__SOCIALNETWORKCLOUD);
		}
		return socialnetworkcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<WebBrowser> getWebbrowser() {
		if (webbrowser == null) {
			webbrowser = new EObjectContainmentEList<WebBrowser>(WebBrowser.class, this,
					Cgm3Package.HOSPITAL__WEBBROWSER);
		}
		return webbrowser;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CloudForPharmacy> getCloudforpharmacy() {
		if (cloudforpharmacy == null) {
			cloudforpharmacy = new EObjectContainmentEList<CloudForPharmacy>(CloudForPharmacy.class, this,
					Cgm3Package.HOSPITAL__CLOUDFORPHARMACY);
		}
		return cloudforpharmacy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RealTimeBiddingCloud> getRealtimebiddingcloud() {
		if (realtimebiddingcloud == null) {
			realtimebiddingcloud = new EObjectContainmentEList<RealTimeBiddingCloud>(RealTimeBiddingCloud.class, this,
					Cgm3Package.HOSPITAL__REALTIMEBIDDINGCLOUD);
		}
		return realtimebiddingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<GPSTracker> getGpstracker() {
		if (gpstracker == null) {
			gpstracker = new EObjectContainmentEList<GPSTracker>(GPSTracker.class, this,
					Cgm3Package.HOSPITAL__GPSTRACKER);
		}
		return gpstracker;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Bus> getBus() {
		if (bus == null) {
			bus = new EObjectContainmentEList<Bus>(Bus.class, this, Cgm3Package.HOSPITAL__BUS);
		}
		return bus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Driver> getDriver() {
		if (driver == null) {
			driver = new EObjectContainmentEList<Driver>(Driver.class, this, Cgm3Package.HOSPITAL__DRIVER);
		}
		return driver;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Customer> getCustomer() {
		if (customer == null) {
			customer = new EObjectContainmentEList<Customer>(Customer.class, this, Cgm3Package.HOSPITAL__CUSTOMER);
		}
		return customer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<VideoAnalytics> getVideoanalytics() {
		if (videoanalytics == null) {
			videoanalytics = new EObjectContainmentEList<VideoAnalytics>(VideoAnalytics.class, this,
					Cgm3Package.HOSPITAL__VIDEOANALYTICS);
		}
		return videoanalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Analytics> getAnalytics() {
		if (analytics == null) {
			analytics = new EObjectContainmentEList<Analytics>(Analytics.class, this, Cgm3Package.HOSPITAL__ANALYTICS);
		}
		return analytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Blurring> getBlurring() {
		if (blurring == null) {
			blurring = new EObjectContainmentEList<Blurring>(Blurring.class, this, Cgm3Package.HOSPITAL__BLURRING);
		}
		return blurring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<VideoProcessingCloud> getVideoprocessingcloud() {
		if (videoprocessingcloud == null) {
			videoprocessingcloud = new EObjectContainmentEList<VideoProcessingCloud>(VideoProcessingCloud.class, this,
					Cgm3Package.HOSPITAL__VIDEOPROCESSINGCLOUD);
		}
		return videoprocessingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<VideoWithoutAnalytics> getVideowithoutanalytics() {
		if (videowithoutanalytics == null) {
			videowithoutanalytics = new EObjectContainmentEList<VideoWithoutAnalytics>(VideoWithoutAnalytics.class,
					this, Cgm3Package.HOSPITAL__VIDEOWITHOUTANALYTICS);
		}
		return videowithoutanalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Client> getClient() {
		if (client == null) {
			client = new EObjectContainmentEList<Client>(Client.class, this, Cgm3Package.HOSPITAL__CLIENT);
		}
		return client;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CloudService> getCloudservice() {
		if (cloudservice == null) {
			cloudservice = new EObjectContainmentEList<CloudService>(CloudService.class, this,
					Cgm3Package.HOSPITAL__CLOUDSERVICE);
		}
		return cloudservice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<LightSensor> getLightsensor() {
		if (lightsensor == null) {
			lightsensor = new EObjectContainmentEList<LightSensor>(LightSensor.class, this,
					Cgm3Package.HOSPITAL__LIGHTSENSOR);
		}
		return lightsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Phone> getPhone() {
		if (phone == null) {
			phone = new EObjectContainmentEList<Phone>(Phone.class, this, Cgm3Package.HOSPITAL__PHONE);
		}
		return phone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Thermostat> getThermostat() {
		if (thermostat == null) {
			thermostat = new EObjectContainmentEList<Thermostat>(Thermostat.class, this,
					Cgm3Package.HOSPITAL__THERMOSTAT);
		}
		return thermostat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DoorLock> getDoorlock() {
		if (doorlock == null) {
			doorlock = new EObjectContainmentEList<DoorLock>(DoorLock.class, this, Cgm3Package.HOSPITAL__DOORLOCK);
		}
		return doorlock;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Camera> getCamera() {
		if (camera == null) {
			camera = new EObjectContainmentEList<Camera>(Camera.class, this, Cgm3Package.HOSPITAL__CAMERA);
		}
		return camera;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Cookies> getCookies() {
		if (cookies == null) {
			cookies = new EObjectContainmentEList<Cookies>(Cookies.class, this, Cgm3Package.HOSPITAL__COOKIES);
		}
		return cookies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.HOSPITAL__PATIENT:
			return ((InternalEList<?>) getPatient()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__DOCTOR:
			return ((InternalEList<?>) getDoctor()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__RESEARCHER:
			return ((InternalEList<?>) getResearcher()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__NURSE:
			return ((InternalEList<?>) getNurse()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__CLOUD:
			return ((InternalEList<?>) getCloud()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__WEBSITE:
			return ((InternalEList<?>) getWebsite()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__SMARTPHONE:
			return ((InternalEList<?>) getSmartphone()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__CGMSENSOR:
			return ((InternalEList<?>) getCgmsensor()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__MEDICALRECORD:
			return ((InternalEList<?>) getMedicalrecord()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__CONSENT_CHECKEDLIST:
			return ((InternalEList<?>) getConsent_checkedlist()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__STORAGELOCATION:
			return ((InternalEList<?>) getStoragelocation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__USERLOCATION:
			return ((InternalEList<?>) getUserlocation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__RISKCODE:
			return ((InternalEList<?>) getRiskcode()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__ENCRYPTION:
			return ((InternalEList<?>) getEncryption()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__DATASHARING:
			return ((InternalEList<?>) getDatasharing()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__WARNING:
			return ((InternalEList<?>) getWarning()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__TEST_ON_DUMMY:
			return ((InternalEList<?>) getTest_on_dummy()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__CONTAINERISATION:
			return ((InternalEList<?>) getContainerisation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__AGGREGATION:
			return ((InternalEList<?>) getAggregation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__COMPUTERBROWSER:
			return ((InternalEList<?>) getComputerbrowser()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__PHARMACYCLOUD:
			return ((InternalEList<?>) getPharmacycloud()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__SHIPPINGCLOUD:
			return ((InternalEList<?>) getShippingcloud()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__WEBHOSTINGCLOUD:
			return ((InternalEList<?>) getWebhostingcloud()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__PAYMENTCLOUD:
			return ((InternalEList<?>) getPaymentcloud()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__SOCIALNETWORKCLOUD:
			return ((InternalEList<?>) getSocialnetworkcloud()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__WEBBROWSER:
			return ((InternalEList<?>) getWebbrowser()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__CLOUDFORPHARMACY:
			return ((InternalEList<?>) getCloudforpharmacy()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__REALTIMEBIDDINGCLOUD:
			return ((InternalEList<?>) getRealtimebiddingcloud()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__GPSTRACKER:
			return ((InternalEList<?>) getGpstracker()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__BUS:
			return ((InternalEList<?>) getBus()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__DRIVER:
			return ((InternalEList<?>) getDriver()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__CUSTOMER:
			return ((InternalEList<?>) getCustomer()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__VIDEOANALYTICS:
			return ((InternalEList<?>) getVideoanalytics()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__ANALYTICS:
			return ((InternalEList<?>) getAnalytics()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__BLURRING:
			return ((InternalEList<?>) getBlurring()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__VIDEOPROCESSINGCLOUD:
			return ((InternalEList<?>) getVideoprocessingcloud()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__VIDEOWITHOUTANALYTICS:
			return ((InternalEList<?>) getVideowithoutanalytics()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__CLIENT:
			return ((InternalEList<?>) getClient()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__CLOUDSERVICE:
			return ((InternalEList<?>) getCloudservice()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__LIGHTSENSOR:
			return ((InternalEList<?>) getLightsensor()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__PHONE:
			return ((InternalEList<?>) getPhone()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__THERMOSTAT:
			return ((InternalEList<?>) getThermostat()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__DOORLOCK:
			return ((InternalEList<?>) getDoorlock()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__CAMERA:
			return ((InternalEList<?>) getCamera()).basicRemove(otherEnd, msgs);
		case Cgm3Package.HOSPITAL__COOKIES:
			return ((InternalEList<?>) getCookies()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.HOSPITAL__PATIENT:
			return getPatient();
		case Cgm3Package.HOSPITAL__DOCTOR:
			return getDoctor();
		case Cgm3Package.HOSPITAL__RESEARCHER:
			return getResearcher();
		case Cgm3Package.HOSPITAL__NURSE:
			return getNurse();
		case Cgm3Package.HOSPITAL__CLOUD:
			return getCloud();
		case Cgm3Package.HOSPITAL__WEBSITE:
			return getWebsite();
		case Cgm3Package.HOSPITAL__SMARTPHONE:
			return getSmartphone();
		case Cgm3Package.HOSPITAL__CGMSENSOR:
			return getCgmsensor();
		case Cgm3Package.HOSPITAL__MEDICALRECORD:
			return getMedicalrecord();
		case Cgm3Package.HOSPITAL__CONSENT_CHECKEDLIST:
			return getConsent_checkedlist();
		case Cgm3Package.HOSPITAL__STORAGELOCATION:
			return getStoragelocation();
		case Cgm3Package.HOSPITAL__USERLOCATION:
			return getUserlocation();
		case Cgm3Package.HOSPITAL__RISKCODE:
			return getRiskcode();
		case Cgm3Package.HOSPITAL__ENCRYPTION:
			return getEncryption();
		case Cgm3Package.HOSPITAL__DATASHARING:
			return getDatasharing();
		case Cgm3Package.HOSPITAL__WARNING:
			return getWarning();
		case Cgm3Package.HOSPITAL__TEST_ON_DUMMY:
			return getTest_on_dummy();
		case Cgm3Package.HOSPITAL__CONTAINERISATION:
			return getContainerisation();
		case Cgm3Package.HOSPITAL__AGGREGATION:
			return getAggregation();
		case Cgm3Package.HOSPITAL__COMPUTERBROWSER:
			return getComputerbrowser();
		case Cgm3Package.HOSPITAL__PHARMACYCLOUD:
			return getPharmacycloud();
		case Cgm3Package.HOSPITAL__SHIPPINGCLOUD:
			return getShippingcloud();
		case Cgm3Package.HOSPITAL__WEBHOSTINGCLOUD:
			return getWebhostingcloud();
		case Cgm3Package.HOSPITAL__PAYMENTCLOUD:
			return getPaymentcloud();
		case Cgm3Package.HOSPITAL__SOCIALNETWORKCLOUD:
			return getSocialnetworkcloud();
		case Cgm3Package.HOSPITAL__WEBBROWSER:
			return getWebbrowser();
		case Cgm3Package.HOSPITAL__CLOUDFORPHARMACY:
			return getCloudforpharmacy();
		case Cgm3Package.HOSPITAL__REALTIMEBIDDINGCLOUD:
			return getRealtimebiddingcloud();
		case Cgm3Package.HOSPITAL__GPSTRACKER:
			return getGpstracker();
		case Cgm3Package.HOSPITAL__BUS:
			return getBus();
		case Cgm3Package.HOSPITAL__DRIVER:
			return getDriver();
		case Cgm3Package.HOSPITAL__CUSTOMER:
			return getCustomer();
		case Cgm3Package.HOSPITAL__VIDEOANALYTICS:
			return getVideoanalytics();
		case Cgm3Package.HOSPITAL__ANALYTICS:
			return getAnalytics();
		case Cgm3Package.HOSPITAL__BLURRING:
			return getBlurring();
		case Cgm3Package.HOSPITAL__VIDEOPROCESSINGCLOUD:
			return getVideoprocessingcloud();
		case Cgm3Package.HOSPITAL__VIDEOWITHOUTANALYTICS:
			return getVideowithoutanalytics();
		case Cgm3Package.HOSPITAL__CLIENT:
			return getClient();
		case Cgm3Package.HOSPITAL__CLOUDSERVICE:
			return getCloudservice();
		case Cgm3Package.HOSPITAL__LIGHTSENSOR:
			return getLightsensor();
		case Cgm3Package.HOSPITAL__PHONE:
			return getPhone();
		case Cgm3Package.HOSPITAL__THERMOSTAT:
			return getThermostat();
		case Cgm3Package.HOSPITAL__DOORLOCK:
			return getDoorlock();
		case Cgm3Package.HOSPITAL__CAMERA:
			return getCamera();
		case Cgm3Package.HOSPITAL__COOKIES:
			return getCookies();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.HOSPITAL__PATIENT:
			getPatient().clear();
			getPatient().addAll((Collection<? extends Patient>) newValue);
			return;
		case Cgm3Package.HOSPITAL__DOCTOR:
			getDoctor().clear();
			getDoctor().addAll((Collection<? extends Doctor>) newValue);
			return;
		case Cgm3Package.HOSPITAL__RESEARCHER:
			getResearcher().clear();
			getResearcher().addAll((Collection<? extends Researcher>) newValue);
			return;
		case Cgm3Package.HOSPITAL__NURSE:
			getNurse().clear();
			getNurse().addAll((Collection<? extends Nurse>) newValue);
			return;
		case Cgm3Package.HOSPITAL__CLOUD:
			getCloud().clear();
			getCloud().addAll((Collection<? extends Cloud>) newValue);
			return;
		case Cgm3Package.HOSPITAL__WEBSITE:
			getWebsite().clear();
			getWebsite().addAll((Collection<? extends Website>) newValue);
			return;
		case Cgm3Package.HOSPITAL__SMARTPHONE:
			getSmartphone().clear();
			getSmartphone().addAll((Collection<? extends SmartPhone>) newValue);
			return;
		case Cgm3Package.HOSPITAL__CGMSENSOR:
			getCgmsensor().clear();
			getCgmsensor().addAll((Collection<? extends CGMsensor>) newValue);
			return;
		case Cgm3Package.HOSPITAL__MEDICALRECORD:
			getMedicalrecord().clear();
			getMedicalrecord().addAll((Collection<? extends MedicalRecord>) newValue);
			return;
		case Cgm3Package.HOSPITAL__CONSENT_CHECKEDLIST:
			getConsent_checkedlist().clear();
			getConsent_checkedlist().addAll((Collection<? extends Consent_CheckedList>) newValue);
			return;
		case Cgm3Package.HOSPITAL__STORAGELOCATION:
			getStoragelocation().clear();
			getStoragelocation().addAll((Collection<? extends StorageLocation>) newValue);
			return;
		case Cgm3Package.HOSPITAL__USERLOCATION:
			getUserlocation().clear();
			getUserlocation().addAll((Collection<? extends UserLocation>) newValue);
			return;
		case Cgm3Package.HOSPITAL__RISKCODE:
			getRiskcode().clear();
			getRiskcode().addAll((Collection<? extends RiskCode>) newValue);
			return;
		case Cgm3Package.HOSPITAL__ENCRYPTION:
			getEncryption().clear();
			getEncryption().addAll((Collection<? extends Encryption>) newValue);
			return;
		case Cgm3Package.HOSPITAL__DATASHARING:
			getDatasharing().clear();
			getDatasharing().addAll((Collection<? extends DataSharing>) newValue);
			return;
		case Cgm3Package.HOSPITAL__WARNING:
			getWarning().clear();
			getWarning().addAll((Collection<? extends Warning>) newValue);
			return;
		case Cgm3Package.HOSPITAL__TEST_ON_DUMMY:
			getTest_on_dummy().clear();
			getTest_on_dummy().addAll((Collection<? extends Test_on_dummy>) newValue);
			return;
		case Cgm3Package.HOSPITAL__CONTAINERISATION:
			getContainerisation().clear();
			getContainerisation().addAll((Collection<? extends Containerisation>) newValue);
			return;
		case Cgm3Package.HOSPITAL__AGGREGATION:
			getAggregation().clear();
			getAggregation().addAll((Collection<? extends Aggregation>) newValue);
			return;
		case Cgm3Package.HOSPITAL__COMPUTERBROWSER:
			getComputerbrowser().clear();
			getComputerbrowser().addAll((Collection<? extends ComputerBrowser>) newValue);
			return;
		case Cgm3Package.HOSPITAL__PHARMACYCLOUD:
			getPharmacycloud().clear();
			getPharmacycloud().addAll((Collection<? extends PharmacyCloudold>) newValue);
			return;
		case Cgm3Package.HOSPITAL__SHIPPINGCLOUD:
			getShippingcloud().clear();
			getShippingcloud().addAll((Collection<? extends ShippingCloud>) newValue);
			return;
		case Cgm3Package.HOSPITAL__WEBHOSTINGCLOUD:
			getWebhostingcloud().clear();
			getWebhostingcloud().addAll((Collection<? extends WebhostingCloud>) newValue);
			return;
		case Cgm3Package.HOSPITAL__PAYMENTCLOUD:
			getPaymentcloud().clear();
			getPaymentcloud().addAll((Collection<? extends PaymentCloud>) newValue);
			return;
		case Cgm3Package.HOSPITAL__SOCIALNETWORKCLOUD:
			getSocialnetworkcloud().clear();
			getSocialnetworkcloud().addAll((Collection<? extends SocialNetworkCloud>) newValue);
			return;
		case Cgm3Package.HOSPITAL__WEBBROWSER:
			getWebbrowser().clear();
			getWebbrowser().addAll((Collection<? extends WebBrowser>) newValue);
			return;
		case Cgm3Package.HOSPITAL__CLOUDFORPHARMACY:
			getCloudforpharmacy().clear();
			getCloudforpharmacy().addAll((Collection<? extends CloudForPharmacy>) newValue);
			return;
		case Cgm3Package.HOSPITAL__REALTIMEBIDDINGCLOUD:
			getRealtimebiddingcloud().clear();
			getRealtimebiddingcloud().addAll((Collection<? extends RealTimeBiddingCloud>) newValue);
			return;
		case Cgm3Package.HOSPITAL__GPSTRACKER:
			getGpstracker().clear();
			getGpstracker().addAll((Collection<? extends GPSTracker>) newValue);
			return;
		case Cgm3Package.HOSPITAL__BUS:
			getBus().clear();
			getBus().addAll((Collection<? extends Bus>) newValue);
			return;
		case Cgm3Package.HOSPITAL__DRIVER:
			getDriver().clear();
			getDriver().addAll((Collection<? extends Driver>) newValue);
			return;
		case Cgm3Package.HOSPITAL__CUSTOMER:
			getCustomer().clear();
			getCustomer().addAll((Collection<? extends Customer>) newValue);
			return;
		case Cgm3Package.HOSPITAL__VIDEOANALYTICS:
			getVideoanalytics().clear();
			getVideoanalytics().addAll((Collection<? extends VideoAnalytics>) newValue);
			return;
		case Cgm3Package.HOSPITAL__ANALYTICS:
			getAnalytics().clear();
			getAnalytics().addAll((Collection<? extends Analytics>) newValue);
			return;
		case Cgm3Package.HOSPITAL__BLURRING:
			getBlurring().clear();
			getBlurring().addAll((Collection<? extends Blurring>) newValue);
			return;
		case Cgm3Package.HOSPITAL__VIDEOPROCESSINGCLOUD:
			getVideoprocessingcloud().clear();
			getVideoprocessingcloud().addAll((Collection<? extends VideoProcessingCloud>) newValue);
			return;
		case Cgm3Package.HOSPITAL__VIDEOWITHOUTANALYTICS:
			getVideowithoutanalytics().clear();
			getVideowithoutanalytics().addAll((Collection<? extends VideoWithoutAnalytics>) newValue);
			return;
		case Cgm3Package.HOSPITAL__CLIENT:
			getClient().clear();
			getClient().addAll((Collection<? extends Client>) newValue);
			return;
		case Cgm3Package.HOSPITAL__CLOUDSERVICE:
			getCloudservice().clear();
			getCloudservice().addAll((Collection<? extends CloudService>) newValue);
			return;
		case Cgm3Package.HOSPITAL__LIGHTSENSOR:
			getLightsensor().clear();
			getLightsensor().addAll((Collection<? extends LightSensor>) newValue);
			return;
		case Cgm3Package.HOSPITAL__PHONE:
			getPhone().clear();
			getPhone().addAll((Collection<? extends Phone>) newValue);
			return;
		case Cgm3Package.HOSPITAL__THERMOSTAT:
			getThermostat().clear();
			getThermostat().addAll((Collection<? extends Thermostat>) newValue);
			return;
		case Cgm3Package.HOSPITAL__DOORLOCK:
			getDoorlock().clear();
			getDoorlock().addAll((Collection<? extends DoorLock>) newValue);
			return;
		case Cgm3Package.HOSPITAL__CAMERA:
			getCamera().clear();
			getCamera().addAll((Collection<? extends Camera>) newValue);
			return;
		case Cgm3Package.HOSPITAL__COOKIES:
			getCookies().clear();
			getCookies().addAll((Collection<? extends Cookies>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.HOSPITAL__PATIENT:
			getPatient().clear();
			return;
		case Cgm3Package.HOSPITAL__DOCTOR:
			getDoctor().clear();
			return;
		case Cgm3Package.HOSPITAL__RESEARCHER:
			getResearcher().clear();
			return;
		case Cgm3Package.HOSPITAL__NURSE:
			getNurse().clear();
			return;
		case Cgm3Package.HOSPITAL__CLOUD:
			getCloud().clear();
			return;
		case Cgm3Package.HOSPITAL__WEBSITE:
			getWebsite().clear();
			return;
		case Cgm3Package.HOSPITAL__SMARTPHONE:
			getSmartphone().clear();
			return;
		case Cgm3Package.HOSPITAL__CGMSENSOR:
			getCgmsensor().clear();
			return;
		case Cgm3Package.HOSPITAL__MEDICALRECORD:
			getMedicalrecord().clear();
			return;
		case Cgm3Package.HOSPITAL__CONSENT_CHECKEDLIST:
			getConsent_checkedlist().clear();
			return;
		case Cgm3Package.HOSPITAL__STORAGELOCATION:
			getStoragelocation().clear();
			return;
		case Cgm3Package.HOSPITAL__USERLOCATION:
			getUserlocation().clear();
			return;
		case Cgm3Package.HOSPITAL__RISKCODE:
			getRiskcode().clear();
			return;
		case Cgm3Package.HOSPITAL__ENCRYPTION:
			getEncryption().clear();
			return;
		case Cgm3Package.HOSPITAL__DATASHARING:
			getDatasharing().clear();
			return;
		case Cgm3Package.HOSPITAL__WARNING:
			getWarning().clear();
			return;
		case Cgm3Package.HOSPITAL__TEST_ON_DUMMY:
			getTest_on_dummy().clear();
			return;
		case Cgm3Package.HOSPITAL__CONTAINERISATION:
			getContainerisation().clear();
			return;
		case Cgm3Package.HOSPITAL__AGGREGATION:
			getAggregation().clear();
			return;
		case Cgm3Package.HOSPITAL__COMPUTERBROWSER:
			getComputerbrowser().clear();
			return;
		case Cgm3Package.HOSPITAL__PHARMACYCLOUD:
			getPharmacycloud().clear();
			return;
		case Cgm3Package.HOSPITAL__SHIPPINGCLOUD:
			getShippingcloud().clear();
			return;
		case Cgm3Package.HOSPITAL__WEBHOSTINGCLOUD:
			getWebhostingcloud().clear();
			return;
		case Cgm3Package.HOSPITAL__PAYMENTCLOUD:
			getPaymentcloud().clear();
			return;
		case Cgm3Package.HOSPITAL__SOCIALNETWORKCLOUD:
			getSocialnetworkcloud().clear();
			return;
		case Cgm3Package.HOSPITAL__WEBBROWSER:
			getWebbrowser().clear();
			return;
		case Cgm3Package.HOSPITAL__CLOUDFORPHARMACY:
			getCloudforpharmacy().clear();
			return;
		case Cgm3Package.HOSPITAL__REALTIMEBIDDINGCLOUD:
			getRealtimebiddingcloud().clear();
			return;
		case Cgm3Package.HOSPITAL__GPSTRACKER:
			getGpstracker().clear();
			return;
		case Cgm3Package.HOSPITAL__BUS:
			getBus().clear();
			return;
		case Cgm3Package.HOSPITAL__DRIVER:
			getDriver().clear();
			return;
		case Cgm3Package.HOSPITAL__CUSTOMER:
			getCustomer().clear();
			return;
		case Cgm3Package.HOSPITAL__VIDEOANALYTICS:
			getVideoanalytics().clear();
			return;
		case Cgm3Package.HOSPITAL__ANALYTICS:
			getAnalytics().clear();
			return;
		case Cgm3Package.HOSPITAL__BLURRING:
			getBlurring().clear();
			return;
		case Cgm3Package.HOSPITAL__VIDEOPROCESSINGCLOUD:
			getVideoprocessingcloud().clear();
			return;
		case Cgm3Package.HOSPITAL__VIDEOWITHOUTANALYTICS:
			getVideowithoutanalytics().clear();
			return;
		case Cgm3Package.HOSPITAL__CLIENT:
			getClient().clear();
			return;
		case Cgm3Package.HOSPITAL__CLOUDSERVICE:
			getCloudservice().clear();
			return;
		case Cgm3Package.HOSPITAL__LIGHTSENSOR:
			getLightsensor().clear();
			return;
		case Cgm3Package.HOSPITAL__PHONE:
			getPhone().clear();
			return;
		case Cgm3Package.HOSPITAL__THERMOSTAT:
			getThermostat().clear();
			return;
		case Cgm3Package.HOSPITAL__DOORLOCK:
			getDoorlock().clear();
			return;
		case Cgm3Package.HOSPITAL__CAMERA:
			getCamera().clear();
			return;
		case Cgm3Package.HOSPITAL__COOKIES:
			getCookies().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.HOSPITAL__PATIENT:
			return patient != null && !patient.isEmpty();
		case Cgm3Package.HOSPITAL__DOCTOR:
			return doctor != null && !doctor.isEmpty();
		case Cgm3Package.HOSPITAL__RESEARCHER:
			return researcher != null && !researcher.isEmpty();
		case Cgm3Package.HOSPITAL__NURSE:
			return nurse != null && !nurse.isEmpty();
		case Cgm3Package.HOSPITAL__CLOUD:
			return cloud != null && !cloud.isEmpty();
		case Cgm3Package.HOSPITAL__WEBSITE:
			return website != null && !website.isEmpty();
		case Cgm3Package.HOSPITAL__SMARTPHONE:
			return smartphone != null && !smartphone.isEmpty();
		case Cgm3Package.HOSPITAL__CGMSENSOR:
			return cgmsensor != null && !cgmsensor.isEmpty();
		case Cgm3Package.HOSPITAL__MEDICALRECORD:
			return medicalrecord != null && !medicalrecord.isEmpty();
		case Cgm3Package.HOSPITAL__CONSENT_CHECKEDLIST:
			return consent_checkedlist != null && !consent_checkedlist.isEmpty();
		case Cgm3Package.HOSPITAL__STORAGELOCATION:
			return storagelocation != null && !storagelocation.isEmpty();
		case Cgm3Package.HOSPITAL__USERLOCATION:
			return userlocation != null && !userlocation.isEmpty();
		case Cgm3Package.HOSPITAL__RISKCODE:
			return riskcode != null && !riskcode.isEmpty();
		case Cgm3Package.HOSPITAL__ENCRYPTION:
			return encryption != null && !encryption.isEmpty();
		case Cgm3Package.HOSPITAL__DATASHARING:
			return datasharing != null && !datasharing.isEmpty();
		case Cgm3Package.HOSPITAL__WARNING:
			return warning != null && !warning.isEmpty();
		case Cgm3Package.HOSPITAL__TEST_ON_DUMMY:
			return test_on_dummy != null && !test_on_dummy.isEmpty();
		case Cgm3Package.HOSPITAL__CONTAINERISATION:
			return containerisation != null && !containerisation.isEmpty();
		case Cgm3Package.HOSPITAL__AGGREGATION:
			return aggregation != null && !aggregation.isEmpty();
		case Cgm3Package.HOSPITAL__COMPUTERBROWSER:
			return computerbrowser != null && !computerbrowser.isEmpty();
		case Cgm3Package.HOSPITAL__PHARMACYCLOUD:
			return pharmacycloud != null && !pharmacycloud.isEmpty();
		case Cgm3Package.HOSPITAL__SHIPPINGCLOUD:
			return shippingcloud != null && !shippingcloud.isEmpty();
		case Cgm3Package.HOSPITAL__WEBHOSTINGCLOUD:
			return webhostingcloud != null && !webhostingcloud.isEmpty();
		case Cgm3Package.HOSPITAL__PAYMENTCLOUD:
			return paymentcloud != null && !paymentcloud.isEmpty();
		case Cgm3Package.HOSPITAL__SOCIALNETWORKCLOUD:
			return socialnetworkcloud != null && !socialnetworkcloud.isEmpty();
		case Cgm3Package.HOSPITAL__WEBBROWSER:
			return webbrowser != null && !webbrowser.isEmpty();
		case Cgm3Package.HOSPITAL__CLOUDFORPHARMACY:
			return cloudforpharmacy != null && !cloudforpharmacy.isEmpty();
		case Cgm3Package.HOSPITAL__REALTIMEBIDDINGCLOUD:
			return realtimebiddingcloud != null && !realtimebiddingcloud.isEmpty();
		case Cgm3Package.HOSPITAL__GPSTRACKER:
			return gpstracker != null && !gpstracker.isEmpty();
		case Cgm3Package.HOSPITAL__BUS:
			return bus != null && !bus.isEmpty();
		case Cgm3Package.HOSPITAL__DRIVER:
			return driver != null && !driver.isEmpty();
		case Cgm3Package.HOSPITAL__CUSTOMER:
			return customer != null && !customer.isEmpty();
		case Cgm3Package.HOSPITAL__VIDEOANALYTICS:
			return videoanalytics != null && !videoanalytics.isEmpty();
		case Cgm3Package.HOSPITAL__ANALYTICS:
			return analytics != null && !analytics.isEmpty();
		case Cgm3Package.HOSPITAL__BLURRING:
			return blurring != null && !blurring.isEmpty();
		case Cgm3Package.HOSPITAL__VIDEOPROCESSINGCLOUD:
			return videoprocessingcloud != null && !videoprocessingcloud.isEmpty();
		case Cgm3Package.HOSPITAL__VIDEOWITHOUTANALYTICS:
			return videowithoutanalytics != null && !videowithoutanalytics.isEmpty();
		case Cgm3Package.HOSPITAL__CLIENT:
			return client != null && !client.isEmpty();
		case Cgm3Package.HOSPITAL__CLOUDSERVICE:
			return cloudservice != null && !cloudservice.isEmpty();
		case Cgm3Package.HOSPITAL__LIGHTSENSOR:
			return lightsensor != null && !lightsensor.isEmpty();
		case Cgm3Package.HOSPITAL__PHONE:
			return phone != null && !phone.isEmpty();
		case Cgm3Package.HOSPITAL__THERMOSTAT:
			return thermostat != null && !thermostat.isEmpty();
		case Cgm3Package.HOSPITAL__DOORLOCK:
			return doorlock != null && !doorlock.isEmpty();
		case Cgm3Package.HOSPITAL__CAMERA:
			return camera != null && !camera.isEmpty();
		case Cgm3Package.HOSPITAL__COOKIES:
			return cookies != null && !cookies.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //HospitalImpl
