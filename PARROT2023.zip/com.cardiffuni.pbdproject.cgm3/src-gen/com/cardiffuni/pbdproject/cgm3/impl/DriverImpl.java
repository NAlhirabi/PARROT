/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Authentication;
import com.cardiffuni.pbdproject.cgm3.Authorization;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Consent_CheckedList;
import com.cardiffuni.pbdproject.cgm3.Driver;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Driver</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DriverImpl#getAuthentication <em>Authentication</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DriverImpl#getAuthorization <em>Authorization</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DriverImpl#getAge <em>Age</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DriverImpl#getConsent_checkedlist <em>Consent checkedlist</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DriverImpl#getDo_drivers_aware_of_being_recorded <em>Do drivers aware of being recorded</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DriverImpl extends GeneralEntityImpl implements Driver {
	/**
	 * The cached value of the '{@link #getAuthentication() <em>Authentication</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAuthentication()
	 * @generated
	 * @ordered
	 */
	protected EList<Authentication> authentication;

	/**
	 * The cached value of the '{@link #getAuthorization() <em>Authorization</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAuthorization()
	 * @generated
	 * @ordered
	 */
	protected EList<Authorization> authorization;

	/**
	 * The default value of the '{@link #getAge() <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAge()
	 * @generated
	 * @ordered
	 */
	protected static final String AGE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAge() <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAge()
	 * @generated
	 * @ordered
	 */
	protected String age = AGE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getConsent_checkedlist() <em>Consent checkedlist</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConsent_checkedlist()
	 * @generated
	 * @ordered
	 */
	protected EList<Consent_CheckedList> consent_checkedlist;

	/**
	 * The default value of the '{@link #getDo_drivers_aware_of_being_recorded() <em>Do drivers aware of being recorded</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_drivers_aware_of_being_recorded()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DO_DRIVERS_AWARE_OF_BEING_RECORDED_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDo_drivers_aware_of_being_recorded() <em>Do drivers aware of being recorded</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_drivers_aware_of_being_recorded()
	 * @generated
	 * @ordered
	 */
	protected Answer do_drivers_aware_of_being_recorded = DO_DRIVERS_AWARE_OF_BEING_RECORDED_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DriverImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.DRIVER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Authentication> getAuthentication() {
		if (authentication == null) {
			authentication = new EObjectContainmentEList<Authentication>(Authentication.class, this,
					Cgm3Package.DRIVER__AUTHENTICATION);
		}
		return authentication;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Authorization> getAuthorization() {
		if (authorization == null) {
			authorization = new EObjectContainmentEList<Authorization>(Authorization.class, this,
					Cgm3Package.DRIVER__AUTHORIZATION);
		}
		return authorization;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAge() {
		return age;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAge(String newAge) {
		String oldAge = age;
		age = newAge;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.DRIVER__AGE, oldAge, age));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Consent_CheckedList> getConsent_checkedlist() {
		if (consent_checkedlist == null) {
			consent_checkedlist = new EObjectContainmentEList<Consent_CheckedList>(Consent_CheckedList.class, this,
					Cgm3Package.DRIVER__CONSENT_CHECKEDLIST);
		}
		return consent_checkedlist;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDo_drivers_aware_of_being_recorded() {
		return do_drivers_aware_of_being_recorded;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDo_drivers_aware_of_being_recorded(Answer newDo_drivers_aware_of_being_recorded) {
		Answer oldDo_drivers_aware_of_being_recorded = do_drivers_aware_of_being_recorded;
		do_drivers_aware_of_being_recorded = newDo_drivers_aware_of_being_recorded == null
				? DO_DRIVERS_AWARE_OF_BEING_RECORDED_EDEFAULT
				: newDo_drivers_aware_of_being_recorded;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.DRIVER__DO_DRIVERS_AWARE_OF_BEING_RECORDED, oldDo_drivers_aware_of_being_recorded,
					do_drivers_aware_of_being_recorded));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.DRIVER__AUTHENTICATION:
			return ((InternalEList<?>) getAuthentication()).basicRemove(otherEnd, msgs);
		case Cgm3Package.DRIVER__AUTHORIZATION:
			return ((InternalEList<?>) getAuthorization()).basicRemove(otherEnd, msgs);
		case Cgm3Package.DRIVER__CONSENT_CHECKEDLIST:
			return ((InternalEList<?>) getConsent_checkedlist()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.DRIVER__AUTHENTICATION:
			return getAuthentication();
		case Cgm3Package.DRIVER__AUTHORIZATION:
			return getAuthorization();
		case Cgm3Package.DRIVER__AGE:
			return getAge();
		case Cgm3Package.DRIVER__CONSENT_CHECKEDLIST:
			return getConsent_checkedlist();
		case Cgm3Package.DRIVER__DO_DRIVERS_AWARE_OF_BEING_RECORDED:
			return getDo_drivers_aware_of_being_recorded();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.DRIVER__AUTHENTICATION:
			getAuthentication().clear();
			getAuthentication().addAll((Collection<? extends Authentication>) newValue);
			return;
		case Cgm3Package.DRIVER__AUTHORIZATION:
			getAuthorization().clear();
			getAuthorization().addAll((Collection<? extends Authorization>) newValue);
			return;
		case Cgm3Package.DRIVER__AGE:
			setAge((String) newValue);
			return;
		case Cgm3Package.DRIVER__CONSENT_CHECKEDLIST:
			getConsent_checkedlist().clear();
			getConsent_checkedlist().addAll((Collection<? extends Consent_CheckedList>) newValue);
			return;
		case Cgm3Package.DRIVER__DO_DRIVERS_AWARE_OF_BEING_RECORDED:
			setDo_drivers_aware_of_being_recorded((Answer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.DRIVER__AUTHENTICATION:
			getAuthentication().clear();
			return;
		case Cgm3Package.DRIVER__AUTHORIZATION:
			getAuthorization().clear();
			return;
		case Cgm3Package.DRIVER__AGE:
			setAge(AGE_EDEFAULT);
			return;
		case Cgm3Package.DRIVER__CONSENT_CHECKEDLIST:
			getConsent_checkedlist().clear();
			return;
		case Cgm3Package.DRIVER__DO_DRIVERS_AWARE_OF_BEING_RECORDED:
			setDo_drivers_aware_of_being_recorded(DO_DRIVERS_AWARE_OF_BEING_RECORDED_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.DRIVER__AUTHENTICATION:
			return authentication != null && !authentication.isEmpty();
		case Cgm3Package.DRIVER__AUTHORIZATION:
			return authorization != null && !authorization.isEmpty();
		case Cgm3Package.DRIVER__AGE:
			return AGE_EDEFAULT == null ? age != null : !AGE_EDEFAULT.equals(age);
		case Cgm3Package.DRIVER__CONSENT_CHECKEDLIST:
			return consent_checkedlist != null && !consent_checkedlist.isEmpty();
		case Cgm3Package.DRIVER__DO_DRIVERS_AWARE_OF_BEING_RECORDED:
			return do_drivers_aware_of_being_recorded != DO_DRIVERS_AWARE_OF_BEING_RECORDED_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Age: ");
		result.append(age);
		result.append(", Do_drivers_aware_of_being_recorded: ");
		result.append(do_drivers_aware_of_being_recorded);
		result.append(')');
		return result.toString();
	}

} //DriverImpl
