/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Authentication;
import com.cardiffuni.pbdproject.cgm3.Authorization;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.Client;
import com.cardiffuni.pbdproject.cgm3.Consent_CheckedList;
import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.Phone;
import com.cardiffuni.pbdproject.cgm3.Privacy_patterns;
import com.cardiffuni.pbdproject.cgm3.SmartPhone;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Client</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ClientImpl#getEncryptedData <em>Encrypted Data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ClientImpl#getPrivacy_patterns <em>Privacy patterns</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ClientImpl#getSmartphone <em>Smartphone</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ClientImpl#getConsent_checkedlist <em>Consent checkedlist</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ClientImpl#getPhoneNumber <em>Phone Number</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ClientImpl#getAuthentication <em>Authentication</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ClientImpl#getAuthorization <em>Authorization</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ClientImpl#getPhone <em>Phone</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ClientImpl extends GeneralEntityImpl implements Client {
	/**
	 * The default value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENCRYPTED_DATA_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected Checked encryptedData = ENCRYPTED_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected static final String PRIVACY_PATTERNS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected String privacy_patterns = PRIVACY_PATTERNS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSmartphone() <em>Smartphone</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSmartphone()
	 * @generated
	 * @ordered
	 */
	protected EList<SmartPhone> smartphone;

	/**
	 * The cached value of the '{@link #getConsent_checkedlist() <em>Consent checkedlist</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConsent_checkedlist()
	 * @generated
	 * @ordered
	 */
	protected EList<Consent_CheckedList> consent_checkedlist;

	/**
	 * The default value of the '{@link #getPhoneNumber() <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhoneNumber()
	 * @generated
	 * @ordered
	 */
	protected static final String PHONE_NUMBER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPhoneNumber() <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhoneNumber()
	 * @generated
	 * @ordered
	 */
	protected String phoneNumber = PHONE_NUMBER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAuthentication() <em>Authentication</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAuthentication()
	 * @generated
	 * @ordered
	 */
	protected EList<Authentication> authentication;

	/**
	 * The cached value of the '{@link #getAuthorization() <em>Authorization</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAuthorization()
	 * @generated
	 * @ordered
	 */
	protected EList<Authorization> authorization;

	/**
	 * The cached value of the '{@link #getPhone() <em>Phone</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPhone()
	 * @generated
	 * @ordered
	 */
	protected EList<Phone> phone;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClientImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.CLIENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEncryptedData() {
		return encryptedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncryptedData(Checked newEncryptedData) {
		Checked oldEncryptedData = encryptedData;
		encryptedData = newEncryptedData == null ? ENCRYPTED_DATA_EDEFAULT : newEncryptedData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLIENT__ENCRYPTED_DATA, oldEncryptedData,
					encryptedData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPrivacy_patterns() {
		return privacy_patterns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrivacy_patterns(String newPrivacy_patterns) {
		String oldPrivacy_patterns = privacy_patterns;
		privacy_patterns = newPrivacy_patterns;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLIENT__PRIVACY_PATTERNS,
					oldPrivacy_patterns, privacy_patterns));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SmartPhone> getSmartphone() {
		if (smartphone == null) {
			smartphone = new EObjectContainmentEList<SmartPhone>(SmartPhone.class, this,
					Cgm3Package.CLIENT__SMARTPHONE);
		}
		return smartphone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Consent_CheckedList> getConsent_checkedlist() {
		if (consent_checkedlist == null) {
			consent_checkedlist = new EObjectContainmentEList<Consent_CheckedList>(Consent_CheckedList.class, this,
					Cgm3Package.CLIENT__CONSENT_CHECKEDLIST);
		}
		return consent_checkedlist;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPhoneNumber(String newPhoneNumber) {
		String oldPhoneNumber = phoneNumber;
		phoneNumber = newPhoneNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CLIENT__PHONE_NUMBER, oldPhoneNumber,
					phoneNumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Authentication> getAuthentication() {
		if (authentication == null) {
			authentication = new EObjectContainmentEList<Authentication>(Authentication.class, this,
					Cgm3Package.CLIENT__AUTHENTICATION);
		}
		return authentication;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Authorization> getAuthorization() {
		if (authorization == null) {
			authorization = new EObjectContainmentEList<Authorization>(Authorization.class, this,
					Cgm3Package.CLIENT__AUTHORIZATION);
		}
		return authorization;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Phone> getPhone() {
		if (phone == null) {
			phone = new EObjectContainmentEList<Phone>(Phone.class, this, Cgm3Package.CLIENT__PHONE);
		}
		return phone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.CLIENT__SMARTPHONE:
			return ((InternalEList<?>) getSmartphone()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLIENT__CONSENT_CHECKEDLIST:
			return ((InternalEList<?>) getConsent_checkedlist()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLIENT__AUTHENTICATION:
			return ((InternalEList<?>) getAuthentication()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLIENT__AUTHORIZATION:
			return ((InternalEList<?>) getAuthorization()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CLIENT__PHONE:
			return ((InternalEList<?>) getPhone()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.CLIENT__ENCRYPTED_DATA:
			return getEncryptedData();
		case Cgm3Package.CLIENT__PRIVACY_PATTERNS:
			return getPrivacy_patterns();
		case Cgm3Package.CLIENT__SMARTPHONE:
			return getSmartphone();
		case Cgm3Package.CLIENT__CONSENT_CHECKEDLIST:
			return getConsent_checkedlist();
		case Cgm3Package.CLIENT__PHONE_NUMBER:
			return getPhoneNumber();
		case Cgm3Package.CLIENT__AUTHENTICATION:
			return getAuthentication();
		case Cgm3Package.CLIENT__AUTHORIZATION:
			return getAuthorization();
		case Cgm3Package.CLIENT__PHONE:
			return getPhone();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.CLIENT__ENCRYPTED_DATA:
			setEncryptedData((Checked) newValue);
			return;
		case Cgm3Package.CLIENT__PRIVACY_PATTERNS:
			setPrivacy_patterns((String) newValue);
			return;
		case Cgm3Package.CLIENT__SMARTPHONE:
			getSmartphone().clear();
			getSmartphone().addAll((Collection<? extends SmartPhone>) newValue);
			return;
		case Cgm3Package.CLIENT__CONSENT_CHECKEDLIST:
			getConsent_checkedlist().clear();
			getConsent_checkedlist().addAll((Collection<? extends Consent_CheckedList>) newValue);
			return;
		case Cgm3Package.CLIENT__PHONE_NUMBER:
			setPhoneNumber((String) newValue);
			return;
		case Cgm3Package.CLIENT__AUTHENTICATION:
			getAuthentication().clear();
			getAuthentication().addAll((Collection<? extends Authentication>) newValue);
			return;
		case Cgm3Package.CLIENT__AUTHORIZATION:
			getAuthorization().clear();
			getAuthorization().addAll((Collection<? extends Authorization>) newValue);
			return;
		case Cgm3Package.CLIENT__PHONE:
			getPhone().clear();
			getPhone().addAll((Collection<? extends Phone>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.CLIENT__ENCRYPTED_DATA:
			setEncryptedData(ENCRYPTED_DATA_EDEFAULT);
			return;
		case Cgm3Package.CLIENT__PRIVACY_PATTERNS:
			setPrivacy_patterns(PRIVACY_PATTERNS_EDEFAULT);
			return;
		case Cgm3Package.CLIENT__SMARTPHONE:
			getSmartphone().clear();
			return;
		case Cgm3Package.CLIENT__CONSENT_CHECKEDLIST:
			getConsent_checkedlist().clear();
			return;
		case Cgm3Package.CLIENT__PHONE_NUMBER:
			setPhoneNumber(PHONE_NUMBER_EDEFAULT);
			return;
		case Cgm3Package.CLIENT__AUTHENTICATION:
			getAuthentication().clear();
			return;
		case Cgm3Package.CLIENT__AUTHORIZATION:
			getAuthorization().clear();
			return;
		case Cgm3Package.CLIENT__PHONE:
			getPhone().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.CLIENT__ENCRYPTED_DATA:
			return encryptedData != ENCRYPTED_DATA_EDEFAULT;
		case Cgm3Package.CLIENT__PRIVACY_PATTERNS:
			return PRIVACY_PATTERNS_EDEFAULT == null ? privacy_patterns != null
					: !PRIVACY_PATTERNS_EDEFAULT.equals(privacy_patterns);
		case Cgm3Package.CLIENT__SMARTPHONE:
			return smartphone != null && !smartphone.isEmpty();
		case Cgm3Package.CLIENT__CONSENT_CHECKEDLIST:
			return consent_checkedlist != null && !consent_checkedlist.isEmpty();
		case Cgm3Package.CLIENT__PHONE_NUMBER:
			return PHONE_NUMBER_EDEFAULT == null ? phoneNumber != null : !PHONE_NUMBER_EDEFAULT.equals(phoneNumber);
		case Cgm3Package.CLIENT__AUTHENTICATION:
			return authentication != null && !authentication.isEmpty();
		case Cgm3Package.CLIENT__AUTHORIZATION:
			return authorization != null && !authorization.isEmpty();
		case Cgm3Package.CLIENT__PHONE:
			return phone != null && !phone.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.CLIENT__ENCRYPTED_DATA:
				return Cgm3Package.ENCRYPTION__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.CLIENT__PRIVACY_PATTERNS:
				return Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (baseFeatureID) {
			case Cgm3Package.ENCRYPTION__ENCRYPTED_DATA:
				return Cgm3Package.CLIENT__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (baseFeatureID) {
			case Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS:
				return Cgm3Package.CLIENT__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (EncryptedData: ");
		result.append(encryptedData);
		result.append(", Privacy_patterns: ");
		result.append(privacy_patterns);
		result.append(", PhoneNumber: ");
		result.append(phoneNumber);
		result.append(')');
		return result.toString();
	}

} //ClientImpl
