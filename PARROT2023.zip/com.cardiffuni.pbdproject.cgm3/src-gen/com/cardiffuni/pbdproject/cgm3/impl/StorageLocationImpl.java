/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.CloudProviderServer;
import com.cardiffuni.pbdproject.cgm3.StorageLocation;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Storage Location</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.StorageLocationImpl#getCloud_provider_and_server_location <em>Cloud provider and server location</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StorageLocationImpl extends GeneralEntityImpl implements StorageLocation {
	/**
	 * The default value of the '{@link #getCloud_provider_and_server_location() <em>Cloud provider and server location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCloud_provider_and_server_location()
	 * @generated
	 * @ordered
	 */
	protected static final CloudProviderServer CLOUD_PROVIDER_AND_SERVER_LOCATION_EDEFAULT = CloudProviderServer.US_PROVIDER_AND_US_SERVER_FOR_GERMAN_PATIENT;
	/**
	 * The cached value of the '{@link #getCloud_provider_and_server_location() <em>Cloud provider and server location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCloud_provider_and_server_location()
	 * @generated
	 * @ordered
	 */
	protected CloudProviderServer cloud_provider_and_server_location = CLOUD_PROVIDER_AND_SERVER_LOCATION_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StorageLocationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.STORAGE_LOCATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudProviderServer getCloud_provider_and_server_location() {
		return cloud_provider_and_server_location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCloud_provider_and_server_location(CloudProviderServer newCloud_provider_and_server_location) {
		CloudProviderServer oldCloud_provider_and_server_location = cloud_provider_and_server_location;
		cloud_provider_and_server_location = newCloud_provider_and_server_location == null
				? CLOUD_PROVIDER_AND_SERVER_LOCATION_EDEFAULT
				: newCloud_provider_and_server_location;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.STORAGE_LOCATION__CLOUD_PROVIDER_AND_SERVER_LOCATION,
					oldCloud_provider_and_server_location, cloud_provider_and_server_location));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.STORAGE_LOCATION__CLOUD_PROVIDER_AND_SERVER_LOCATION:
			return getCloud_provider_and_server_location();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.STORAGE_LOCATION__CLOUD_PROVIDER_AND_SERVER_LOCATION:
			setCloud_provider_and_server_location((CloudProviderServer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.STORAGE_LOCATION__CLOUD_PROVIDER_AND_SERVER_LOCATION:
			setCloud_provider_and_server_location(CLOUD_PROVIDER_AND_SERVER_LOCATION_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.STORAGE_LOCATION__CLOUD_PROVIDER_AND_SERVER_LOCATION:
			return cloud_provider_and_server_location != CLOUD_PROVIDER_AND_SERVER_LOCATION_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Cloud_provider_and_server_location: ");
		result.append(cloud_provider_and_server_location);
		result.append(')');
		return result.toString();
	}

} //StorageLocationImpl
