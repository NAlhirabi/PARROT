/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.LocationGranularity;
import com.cardiffuni.pbdproject.cgm3.UserLocation;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>User Location</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.UserLocationImpl#getLocation <em>Location</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.UserLocationImpl#getAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed <em>Are you planning to collect the exact location of the data subject when the location is not needed</em>}</li>
 * </ul>
 *
 * @generated
 */
public class UserLocationImpl extends GeneralEntityImpl implements UserLocation {
	/**
	 * The default value of the '{@link #getLocation() <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected static final LocationGranularity LOCATION_EDEFAULT = LocationGranularity.EXACT_LOCATION;
	/**
	 * The cached value of the '{@link #getLocation() <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLocation()
	 * @generated
	 * @ordered
	 */
	protected LocationGranularity location = LOCATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed() <em>Are you planning to collect the exact location of the data subject when the location is not needed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED_EDEFAULT = Answer.NOT_ANSWERED;
	/**
	 * The cached value of the '{@link #getAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed() <em>Are you planning to collect the exact location of the data subject when the location is not needed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed = ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UserLocationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.USER_LOCATION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LocationGranularity getLocation() {
		return location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLocation(LocationGranularity newLocation) {
		LocationGranularity oldLocation = location;
		location = newLocation == null ? LOCATION_EDEFAULT : newLocation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.USER_LOCATION__LOCATION, oldLocation,
					location));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed() {
		return are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed(
			Answer newAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed) {
		Answer oldAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed = are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed;
		are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed = newAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed == null
				? ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED_EDEFAULT
				: newAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.USER_LOCATION__ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED,
					oldAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed,
					are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.USER_LOCATION__LOCATION:
			return getLocation();
		case Cgm3Package.USER_LOCATION__ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED:
			return getAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.USER_LOCATION__LOCATION:
			setLocation((LocationGranularity) newValue);
			return;
		case Cgm3Package.USER_LOCATION__ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED:
			setAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed(
					(Answer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.USER_LOCATION__LOCATION:
			setLocation(LOCATION_EDEFAULT);
			return;
		case Cgm3Package.USER_LOCATION__ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED:
			setAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed(
					ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.USER_LOCATION__LOCATION:
			return location != LOCATION_EDEFAULT;
		case Cgm3Package.USER_LOCATION__ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED:
			return are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed != ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Location: ");
		result.append(location);
		result.append(
				", Are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed: ");
		result.append(
				are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed);
		result.append(')');
		return result.toString();
	}

} //UserLocationImpl
