/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Analytics;
import com.cardiffuni.pbdproject.cgm3.Blurring;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.Customer;
import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.VideoAnalytics;

import com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud;
import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Video Analytics</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoAnalyticsImpl#getEncryptedData <em>Encrypted Data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoAnalyticsImpl#getSerial_number <em>Serial number</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoAnalyticsImpl#getBlurring <em>Blurring</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoAnalyticsImpl#getAnalytics <em>Analytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoAnalyticsImpl#getCustomer <em>Customer</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoAnalyticsImpl#getVideoprocessingcloud <em>Videoprocessingcloud</em>}</li>
 * </ul>
 *
 * @generated
 */
public class VideoAnalyticsImpl extends GeneralEntityImpl implements VideoAnalytics {
	/**
	 * The default value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENCRYPTED_DATA_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected Checked encryptedData = ENCRYPTED_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #getSerial_number() <em>Serial number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSerial_number()
	 * @generated
	 * @ordered
	 */
	protected static final String SERIAL_NUMBER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSerial_number() <em>Serial number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSerial_number()
	 * @generated
	 * @ordered
	 */
	protected String serial_number = SERIAL_NUMBER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getBlurring() <em>Blurring</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBlurring()
	 * @generated
	 * @ordered
	 */
	protected EList<Blurring> blurring;

	/**
	 * The cached value of the '{@link #getAnalytics() <em>Analytics</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnalytics()
	 * @generated
	 * @ordered
	 */
	protected EList<Analytics> analytics;

	/**
	 * The cached value of the '{@link #getCustomer() <em>Customer</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustomer()
	 * @generated
	 * @ordered
	 */
	protected Customer customer;

	/**
	 * The cached value of the '{@link #getVideoprocessingcloud() <em>Videoprocessingcloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVideoprocessingcloud()
	 * @generated
	 * @ordered
	 */
	protected VideoProcessingCloud videoprocessingcloud;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VideoAnalyticsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.VIDEO_ANALYTICS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEncryptedData() {
		return encryptedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncryptedData(Checked newEncryptedData) {
		Checked oldEncryptedData = encryptedData;
		encryptedData = newEncryptedData == null ? ENCRYPTED_DATA_EDEFAULT : newEncryptedData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.VIDEO_ANALYTICS__ENCRYPTED_DATA,
					oldEncryptedData, encryptedData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSerial_number() {
		return serial_number;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSerial_number(String newSerial_number) {
		String oldSerial_number = serial_number;
		serial_number = newSerial_number;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.VIDEO_ANALYTICS__SERIAL_NUMBER,
					oldSerial_number, serial_number));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Blurring> getBlurring() {
		if (blurring == null) {
			blurring = new EObjectContainmentEList<Blurring>(Blurring.class, this,
					Cgm3Package.VIDEO_ANALYTICS__BLURRING);
		}
		return blurring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Analytics> getAnalytics() {
		if (analytics == null) {
			analytics = new EObjectContainmentEList<Analytics>(Analytics.class, this,
					Cgm3Package.VIDEO_ANALYTICS__ANALYTICS);
		}
		return analytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Customer getCustomer() {
		if (customer != null && customer.eIsProxy()) {
			InternalEObject oldCustomer = (InternalEObject) customer;
			customer = (Customer) eResolveProxy(oldCustomer);
			if (customer != oldCustomer) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.VIDEO_ANALYTICS__CUSTOMER,
							oldCustomer, customer));
			}
		}
		return customer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Customer basicGetCustomer() {
		return customer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCustomer(Customer newCustomer, NotificationChain msgs) {
		Customer oldCustomer = customer;
		customer = newCustomer;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_ANALYTICS__CUSTOMER, oldCustomer, newCustomer);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCustomer(Customer newCustomer) {
		if (newCustomer != customer) {
			NotificationChain msgs = null;
			if (customer != null)
				msgs = ((InternalEObject) customer).eInverseRemove(this, Cgm3Package.CUSTOMER__VIDEOANALYTICS,
						Customer.class, msgs);
			if (newCustomer != null)
				msgs = ((InternalEObject) newCustomer).eInverseAdd(this, Cgm3Package.CUSTOMER__VIDEOANALYTICS,
						Customer.class, msgs);
			msgs = basicSetCustomer(newCustomer, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.VIDEO_ANALYTICS__CUSTOMER, newCustomer,
					newCustomer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoProcessingCloud getVideoprocessingcloud() {
		if (videoprocessingcloud != null && videoprocessingcloud.eIsProxy()) {
			InternalEObject oldVideoprocessingcloud = (InternalEObject) videoprocessingcloud;
			videoprocessingcloud = (VideoProcessingCloud) eResolveProxy(oldVideoprocessingcloud);
			if (videoprocessingcloud != oldVideoprocessingcloud) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Cgm3Package.VIDEO_ANALYTICS__VIDEOPROCESSINGCLOUD, oldVideoprocessingcloud,
							videoprocessingcloud));
			}
		}
		return videoprocessingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoProcessingCloud basicGetVideoprocessingcloud() {
		return videoprocessingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetVideoprocessingcloud(VideoProcessingCloud newVideoprocessingcloud,
			NotificationChain msgs) {
		VideoProcessingCloud oldVideoprocessingcloud = videoprocessingcloud;
		videoprocessingcloud = newVideoprocessingcloud;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_ANALYTICS__VIDEOPROCESSINGCLOUD, oldVideoprocessingcloud,
					newVideoprocessingcloud);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVideoprocessingcloud(VideoProcessingCloud newVideoprocessingcloud) {
		if (newVideoprocessingcloud != videoprocessingcloud) {
			NotificationChain msgs = null;
			if (videoprocessingcloud != null)
				msgs = ((InternalEObject) videoprocessingcloud).eInverseRemove(this,
						Cgm3Package.VIDEO_PROCESSING_CLOUD__VIDEOANALYTICS, VideoProcessingCloud.class, msgs);
			if (newVideoprocessingcloud != null)
				msgs = ((InternalEObject) newVideoprocessingcloud).eInverseAdd(this,
						Cgm3Package.VIDEO_PROCESSING_CLOUD__VIDEOANALYTICS, VideoProcessingCloud.class, msgs);
			msgs = basicSetVideoprocessingcloud(newVideoprocessingcloud, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.VIDEO_ANALYTICS__VIDEOPROCESSINGCLOUD,
					newVideoprocessingcloud, newVideoprocessingcloud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.VIDEO_ANALYTICS__CUSTOMER:
			if (customer != null)
				msgs = ((InternalEObject) customer).eInverseRemove(this, Cgm3Package.CUSTOMER__VIDEOANALYTICS,
						Customer.class, msgs);
			return basicSetCustomer((Customer) otherEnd, msgs);
		case Cgm3Package.VIDEO_ANALYTICS__VIDEOPROCESSINGCLOUD:
			if (videoprocessingcloud != null)
				msgs = ((InternalEObject) videoprocessingcloud).eInverseRemove(this,
						Cgm3Package.VIDEO_PROCESSING_CLOUD__VIDEOANALYTICS, VideoProcessingCloud.class, msgs);
			return basicSetVideoprocessingcloud((VideoProcessingCloud) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.VIDEO_ANALYTICS__BLURRING:
			return ((InternalEList<?>) getBlurring()).basicRemove(otherEnd, msgs);
		case Cgm3Package.VIDEO_ANALYTICS__ANALYTICS:
			return ((InternalEList<?>) getAnalytics()).basicRemove(otherEnd, msgs);
		case Cgm3Package.VIDEO_ANALYTICS__CUSTOMER:
			return basicSetCustomer(null, msgs);
		case Cgm3Package.VIDEO_ANALYTICS__VIDEOPROCESSINGCLOUD:
			return basicSetVideoprocessingcloud(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.VIDEO_ANALYTICS__ENCRYPTED_DATA:
			return getEncryptedData();
		case Cgm3Package.VIDEO_ANALYTICS__SERIAL_NUMBER:
			return getSerial_number();
		case Cgm3Package.VIDEO_ANALYTICS__BLURRING:
			return getBlurring();
		case Cgm3Package.VIDEO_ANALYTICS__ANALYTICS:
			return getAnalytics();
		case Cgm3Package.VIDEO_ANALYTICS__CUSTOMER:
			if (resolve)
				return getCustomer();
			return basicGetCustomer();
		case Cgm3Package.VIDEO_ANALYTICS__VIDEOPROCESSINGCLOUD:
			if (resolve)
				return getVideoprocessingcloud();
			return basicGetVideoprocessingcloud();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.VIDEO_ANALYTICS__ENCRYPTED_DATA:
			setEncryptedData((Checked) newValue);
			return;
		case Cgm3Package.VIDEO_ANALYTICS__SERIAL_NUMBER:
			setSerial_number((String) newValue);
			return;
		case Cgm3Package.VIDEO_ANALYTICS__BLURRING:
			getBlurring().clear();
			getBlurring().addAll((Collection<? extends Blurring>) newValue);
			return;
		case Cgm3Package.VIDEO_ANALYTICS__ANALYTICS:
			getAnalytics().clear();
			getAnalytics().addAll((Collection<? extends Analytics>) newValue);
			return;
		case Cgm3Package.VIDEO_ANALYTICS__CUSTOMER:
			setCustomer((Customer) newValue);
			return;
		case Cgm3Package.VIDEO_ANALYTICS__VIDEOPROCESSINGCLOUD:
			setVideoprocessingcloud((VideoProcessingCloud) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.VIDEO_ANALYTICS__ENCRYPTED_DATA:
			setEncryptedData(ENCRYPTED_DATA_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_ANALYTICS__SERIAL_NUMBER:
			setSerial_number(SERIAL_NUMBER_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_ANALYTICS__BLURRING:
			getBlurring().clear();
			return;
		case Cgm3Package.VIDEO_ANALYTICS__ANALYTICS:
			getAnalytics().clear();
			return;
		case Cgm3Package.VIDEO_ANALYTICS__CUSTOMER:
			setCustomer((Customer) null);
			return;
		case Cgm3Package.VIDEO_ANALYTICS__VIDEOPROCESSINGCLOUD:
			setVideoprocessingcloud((VideoProcessingCloud) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.VIDEO_ANALYTICS__ENCRYPTED_DATA:
			return encryptedData != ENCRYPTED_DATA_EDEFAULT;
		case Cgm3Package.VIDEO_ANALYTICS__SERIAL_NUMBER:
			return SERIAL_NUMBER_EDEFAULT == null ? serial_number != null
					: !SERIAL_NUMBER_EDEFAULT.equals(serial_number);
		case Cgm3Package.VIDEO_ANALYTICS__BLURRING:
			return blurring != null && !blurring.isEmpty();
		case Cgm3Package.VIDEO_ANALYTICS__ANALYTICS:
			return analytics != null && !analytics.isEmpty();
		case Cgm3Package.VIDEO_ANALYTICS__CUSTOMER:
			return customer != null;
		case Cgm3Package.VIDEO_ANALYTICS__VIDEOPROCESSINGCLOUD:
			return videoprocessingcloud != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.VIDEO_ANALYTICS__ENCRYPTED_DATA:
				return Cgm3Package.ENCRYPTION__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (baseFeatureID) {
			case Cgm3Package.ENCRYPTION__ENCRYPTED_DATA:
				return Cgm3Package.VIDEO_ANALYTICS__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (EncryptedData: ");
		result.append(encryptedData);
		result.append(", Serial_number: ");
		result.append(serial_number);
		result.append(')');
		return result.toString();
	}

} //VideoAnalyticsImpl
