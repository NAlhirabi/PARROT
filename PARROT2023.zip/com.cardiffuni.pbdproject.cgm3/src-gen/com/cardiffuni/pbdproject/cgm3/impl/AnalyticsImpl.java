/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Analytics;
import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;

import com.cardiffuni.pbdproject.cgm3.DataRetentionEnum;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Analytics</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl#getRecord_retention_period <em>Record retention period</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl#getDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation <em>Does data processing applied on the camera to increase data minimisation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl#getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles <em>Does consent have been gathered from the staff who used these vehicles</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl#getDoes_the_system_record_information_other_than_the_purpose <em>Does the system record information other than the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl#getDoes_The_dynamic_masking_feature_is_enabled <em>Does The dynamic masking feature is enabled</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl#getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl#getDo_you_use_signs_that_say_CCTV_is_in_operation <em>Do you use signs that say CCTV is in operation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl#getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV <em>Does the sign has abrief explanation about the purpose of CCTV</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AnalyticsImpl extends GeneralEntityImpl implements Analytics {
	/**
	 * The default value of the '{@link #getRecord_retention_period() <em>Record retention period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecord_retention_period()
	 * @generated
	 * @ordered
	 */
	protected static final DataRetentionEnum RECORD_RETENTION_PERIOD_EDEFAULT = DataRetentionEnum.NOT_ACCEPTED;

	/**
	 * The cached value of the '{@link #getRecord_retention_period() <em>Record retention period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecord_retention_period()
	 * @generated
	 * @ordered
	 */
	protected DataRetentionEnum record_retention_period = RECORD_RETENTION_PERIOD_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation() <em>Does data processing applied on the camera to increase data minimisation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_DATA_PROCESSING_APPLIED_ON_THE_CAMERA_TO_INCREASE_DATA_MINIMISATION_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation() <em>Does data processing applied on the camera to increase data minimisation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation()
	 * @generated
	 * @ordered
	 */
	protected Answer does_data_processing_applied_on_the_camera_to_increase_data_minimisation = DOES_DATA_PROCESSING_APPLIED_ON_THE_CAMERA_TO_INCREASE_DATA_MINIMISATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles() <em>Does consent have been gathered from the staff who used these vehicles</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles() <em>Does consent have been gathered from the staff who used these vehicles</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles()
	 * @generated
	 * @ordered
	 */
	protected Answer does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles = DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_the_system_record_information_other_than_the_purpose() <em>Does the system record information other than the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_system_record_information_other_than_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_the_system_record_information_other_than_the_purpose() <em>Does the system record information other than the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_system_record_information_other_than_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected Answer does_the_system_record_information_other_than_the_purpose = DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_The_dynamic_masking_feature_is_enabled() <em>Does The dynamic masking feature is enabled</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_The_dynamic_masking_feature_is_enabled()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_The_dynamic_masking_feature_is_enabled() <em>Does The dynamic masking feature is enabled</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_The_dynamic_masking_feature_is_enabled()
	 * @generated
	 * @ordered
	 */
	protected Answer does_The_dynamic_masking_feature_is_enabled = DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring() <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring() <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring = ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT;

	/**
	 * The default value of the '{@link #getDo_you_use_signs_that_say_CCTV_is_in_operation() <em>Do you use signs that say CCTV is in operation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_you_use_signs_that_say_CCTV_is_in_operation()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDo_you_use_signs_that_say_CCTV_is_in_operation() <em>Do you use signs that say CCTV is in operation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_you_use_signs_that_say_CCTV_is_in_operation()
	 * @generated
	 * @ordered
	 */
	protected Answer do_you_use_signs_that_say_CCTV_is_in_operation = DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV() <em>Does the sign has abrief explanation about the purpose of CCTV</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV() <em>Does the sign has abrief explanation about the purpose of CCTV</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV()
	 * @generated
	 * @ordered
	 */
	protected Answer does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV = DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;

	/**
	 * The default value of the '{@link #getIs_data_against_accidental_loss_or_destruction_or_damage() <em>Is data against accidental loss or destruction or damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @generated
	 * @ordered
	 */
	protected static final Answer IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getIs_data_against_accidental_loss_or_destruction_or_damage() <em>Is data against accidental loss or destruction or damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @generated
	 * @ordered
	 */
	protected Answer is_data_against_accidental_loss_or_destruction_or_damage = IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() <em>Are you using appropriate technical or organisational measures to protect the data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() <em>Are you using appropriate technical or organisational measures to protect the data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AnalyticsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.ANALYTICS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataRetentionEnum getRecord_retention_period() {
		return record_retention_period;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRecord_retention_period(DataRetentionEnum newRecord_retention_period) {
		DataRetentionEnum oldRecord_retention_period = record_retention_period;
		record_retention_period = newRecord_retention_period == null ? RECORD_RETENTION_PERIOD_EDEFAULT
				: newRecord_retention_period;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.ANALYTICS__RECORD_RETENTION_PERIOD,
					oldRecord_retention_period, record_retention_period));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation() {
		return does_data_processing_applied_on_the_camera_to_increase_data_minimisation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation(
			Answer newDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation) {
		Answer oldDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation = does_data_processing_applied_on_the_camera_to_increase_data_minimisation;
		does_data_processing_applied_on_the_camera_to_increase_data_minimisation = newDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation == null
				? DOES_DATA_PROCESSING_APPLIED_ON_THE_CAMERA_TO_INCREASE_DATA_MINIMISATION_EDEFAULT
				: newDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.ANALYTICS__DOES_DATA_PROCESSING_APPLIED_ON_THE_CAMERA_TO_INCREASE_DATA_MINIMISATION,
					oldDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation,
					does_data_processing_applied_on_the_camera_to_increase_data_minimisation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles() {
		return does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles(
			Answer newDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles) {
		Answer oldDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles = does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles;
		does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles = newDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles == null
				? DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT
				: newDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES,
					oldDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles,
					does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_the_system_record_information_other_than_the_purpose() {
		return does_the_system_record_information_other_than_the_purpose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_the_system_record_information_other_than_the_purpose(
			Answer newDoes_the_system_record_information_other_than_the_purpose) {
		Answer oldDoes_the_system_record_information_other_than_the_purpose = does_the_system_record_information_other_than_the_purpose;
		does_the_system_record_information_other_than_the_purpose = newDoes_the_system_record_information_other_than_the_purpose == null
				? DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT
				: newDoes_the_system_record_information_other_than_the_purpose;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE,
					oldDoes_the_system_record_information_other_than_the_purpose,
					does_the_system_record_information_other_than_the_purpose));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_The_dynamic_masking_feature_is_enabled() {
		return does_The_dynamic_masking_feature_is_enabled;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_The_dynamic_masking_feature_is_enabled(Answer newDoes_The_dynamic_masking_feature_is_enabled) {
		Answer oldDoes_The_dynamic_masking_feature_is_enabled = does_The_dynamic_masking_feature_is_enabled;
		does_The_dynamic_masking_feature_is_enabled = newDoes_The_dynamic_masking_feature_is_enabled == null
				? DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED_EDEFAULT
				: newDoes_The_dynamic_masking_feature_is_enabled;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED,
					oldDoes_The_dynamic_masking_feature_is_enabled, does_The_dynamic_masking_feature_is_enabled));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring() {
		return are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring(
			Answer newAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring) {
		Answer oldAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring = are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring;
		are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring = newAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring == null
				? ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT
				: newAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING,
					oldAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring,
					are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDo_you_use_signs_that_say_CCTV_is_in_operation() {
		return do_you_use_signs_that_say_CCTV_is_in_operation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDo_you_use_signs_that_say_CCTV_is_in_operation(
			Answer newDo_you_use_signs_that_say_CCTV_is_in_operation) {
		Answer oldDo_you_use_signs_that_say_CCTV_is_in_operation = do_you_use_signs_that_say_CCTV_is_in_operation;
		do_you_use_signs_that_say_CCTV_is_in_operation = newDo_you_use_signs_that_say_CCTV_is_in_operation == null
				? DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT
				: newDo_you_use_signs_that_say_CCTV_is_in_operation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION,
					oldDo_you_use_signs_that_say_CCTV_is_in_operation, do_you_use_signs_that_say_CCTV_is_in_operation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV() {
		return does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV(
			Answer newDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV) {
		Answer oldDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV = does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV;
		does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV = newDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV == null
				? DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT
				: newDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV,
					oldDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV,
					does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
			Answer newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes) {
		Answer oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes = are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes == null
				? ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT
				: newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
					oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes,
					are_you_storing_the_data_longer_than_is_necessary_for_the_purposes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getIs_data_against_accidental_loss_or_destruction_or_damage() {
		return is_data_against_accidental_loss_or_destruction_or_damage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIs_data_against_accidental_loss_or_destruction_or_damage(
			Answer newIs_data_against_accidental_loss_or_destruction_or_damage) {
		Answer oldIs_data_against_accidental_loss_or_destruction_or_damage = is_data_against_accidental_loss_or_destruction_or_damage;
		is_data_against_accidental_loss_or_destruction_or_damage = newIs_data_against_accidental_loss_or_destruction_or_damage == null
				? IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT
				: newIs_data_against_accidental_loss_or_destruction_or_damage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE,
					oldIs_data_against_accidental_loss_or_destruction_or_damage,
					is_data_against_accidental_loss_or_destruction_or_damage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() {
		return are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(
			Answer newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data) {
		Answer oldAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
		are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data == null
				? ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT
				: newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA,
					oldAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data,
					are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.ANALYTICS__RECORD_RETENTION_PERIOD:
			return getRecord_retention_period();
		case Cgm3Package.ANALYTICS__DOES_DATA_PROCESSING_APPLIED_ON_THE_CAMERA_TO_INCREASE_DATA_MINIMISATION:
			return getDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation();
		case Cgm3Package.ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES:
			return getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles();
		case Cgm3Package.ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			return getDoes_the_system_record_information_other_than_the_purpose();
		case Cgm3Package.ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED:
			return getDoes_The_dynamic_masking_feature_is_enabled();
		case Cgm3Package.ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING:
			return getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring();
		case Cgm3Package.ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION:
			return getDo_you_use_signs_that_say_CCTV_is_in_operation();
		case Cgm3Package.ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV:
			return getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV();
		case Cgm3Package.ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();
		case Cgm3Package.ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			return getIs_data_against_accidental_loss_or_destruction_or_damage();
		case Cgm3Package.ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			return getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.ANALYTICS__RECORD_RETENTION_PERIOD:
			setRecord_retention_period((DataRetentionEnum) newValue);
			return;
		case Cgm3Package.ANALYTICS__DOES_DATA_PROCESSING_APPLIED_ON_THE_CAMERA_TO_INCREASE_DATA_MINIMISATION:
			setDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation((Answer) newValue);
			return;
		case Cgm3Package.ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES:
			setDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles((Answer) newValue);
			return;
		case Cgm3Package.ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			setDoes_the_system_record_information_other_than_the_purpose((Answer) newValue);
			return;
		case Cgm3Package.ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED:
			setDoes_The_dynamic_masking_feature_is_enabled((Answer) newValue);
			return;
		case Cgm3Package.ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING:
			setAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring((Answer) newValue);
			return;
		case Cgm3Package.ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION:
			setDo_you_use_signs_that_say_CCTV_is_in_operation((Answer) newValue);
			return;
		case Cgm3Package.ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV:
			setDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV((Answer) newValue);
			return;
		case Cgm3Package.ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes((Answer) newValue);
			return;
		case Cgm3Package.ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			setIs_data_against_accidental_loss_or_destruction_or_damage((Answer) newValue);
			return;
		case Cgm3Package.ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data((Answer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.ANALYTICS__RECORD_RETENTION_PERIOD:
			setRecord_retention_period(RECORD_RETENTION_PERIOD_EDEFAULT);
			return;
		case Cgm3Package.ANALYTICS__DOES_DATA_PROCESSING_APPLIED_ON_THE_CAMERA_TO_INCREASE_DATA_MINIMISATION:
			setDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation(
					DOES_DATA_PROCESSING_APPLIED_ON_THE_CAMERA_TO_INCREASE_DATA_MINIMISATION_EDEFAULT);
			return;
		case Cgm3Package.ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES:
			setDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles(
					DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT);
			return;
		case Cgm3Package.ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			setDoes_the_system_record_information_other_than_the_purpose(
					DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT);
			return;
		case Cgm3Package.ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED:
			setDoes_The_dynamic_masking_feature_is_enabled(DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED_EDEFAULT);
			return;
		case Cgm3Package.ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING:
			setAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring(
					ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT);
			return;
		case Cgm3Package.ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION:
			setDo_you_use_signs_that_say_CCTV_is_in_operation(DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT);
			return;
		case Cgm3Package.ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV:
			setDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV(
					DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT);
			return;
		case Cgm3Package.ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
					ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT);
			return;
		case Cgm3Package.ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			setIs_data_against_accidental_loss_or_destruction_or_damage(
					IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT);
			return;
		case Cgm3Package.ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(
					ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.ANALYTICS__RECORD_RETENTION_PERIOD:
			return record_retention_period != RECORD_RETENTION_PERIOD_EDEFAULT;
		case Cgm3Package.ANALYTICS__DOES_DATA_PROCESSING_APPLIED_ON_THE_CAMERA_TO_INCREASE_DATA_MINIMISATION:
			return does_data_processing_applied_on_the_camera_to_increase_data_minimisation != DOES_DATA_PROCESSING_APPLIED_ON_THE_CAMERA_TO_INCREASE_DATA_MINIMISATION_EDEFAULT;
		case Cgm3Package.ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES:
			return does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles != DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT;
		case Cgm3Package.ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			return does_the_system_record_information_other_than_the_purpose != DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT;
		case Cgm3Package.ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED:
			return does_The_dynamic_masking_feature_is_enabled != DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED_EDEFAULT;
		case Cgm3Package.ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING:
			return are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring != ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT;
		case Cgm3Package.ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION:
			return do_you_use_signs_that_say_CCTV_is_in_operation != DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT;
		case Cgm3Package.ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV:
			return does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV != DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT;
		case Cgm3Package.ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes != ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;
		case Cgm3Package.ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			return is_data_against_accidental_loss_or_destruction_or_damage != IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT;
		case Cgm3Package.ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			return are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data != ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Record_retention_period: ");
		result.append(record_retention_period);
		result.append(", Does_data_processing_applied_on_the_camera_to_increase_data_minimisation: ");
		result.append(does_data_processing_applied_on_the_camera_to_increase_data_minimisation);
		result.append(", Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles: ");
		result.append(does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles);
		result.append(", Does_the_system_record_information_other_than_the_purpose: ");
		result.append(does_the_system_record_information_other_than_the_purpose);
		result.append(", Does_The_dynamic_masking_feature_is_enabled: ");
		result.append(does_The_dynamic_masking_feature_is_enabled);
		result.append(", Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring: ");
		result.append(are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring);
		result.append(", Do_you_use_signs_that_say_CCTV_is_in_operation: ");
		result.append(do_you_use_signs_that_say_CCTV_is_in_operation);
		result.append(", Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV: ");
		result.append(does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV);
		result.append(", Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes: ");
		result.append(are_you_storing_the_data_longer_than_is_necessary_for_the_purposes);
		result.append(", Is_data_against_accidental_loss_or_destruction_or_damage: ");
		result.append(is_data_against_accidental_loss_or_destruction_or_damage);
		result.append(", Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data: ");
		result.append(are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data);
		result.append(')');
		return result.toString();
	}

} //AnalyticsImpl
