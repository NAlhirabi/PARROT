/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.Cloud;
import com.cardiffuni.pbdproject.cgm3.Cookies;
import com.cardiffuni.pbdproject.cgm3.Doctor;
import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.Researcher;
import com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud;
import com.cardiffuni.pbdproject.cgm3.Website;
import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Website</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.WebsiteImpl#getEncryptedData <em>Encrypted Data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.WebsiteImpl#getCloud <em>Cloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.WebsiteImpl#getDoctor <em>Doctor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.WebsiteImpl#getResearcher <em>Researcher</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.WebsiteImpl#getURL <em>URL</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.WebsiteImpl#getVideoprocessingcloud <em>Videoprocessingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.WebsiteImpl#getCookies <em>Cookies</em>}</li>
 * </ul>
 *
 * @generated
 */
public class WebsiteImpl extends GeneralEntityImpl implements Website {
	/**
	 * The default value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENCRYPTED_DATA_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected Checked encryptedData = ENCRYPTED_DATA_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCloud() <em>Cloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCloud()
	 * @generated
	 * @ordered
	 */
	protected Cloud cloud;

	/**
	 * The cached value of the '{@link #getDoctor() <em>Doctor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoctor()
	 * @generated
	 * @ordered
	 */
	protected Doctor doctor;
	/**
	 * The cached value of the '{@link #getResearcher() <em>Researcher</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getResearcher()
	 * @generated
	 * @ordered
	 */
	protected Researcher researcher;
	/**
	 * The default value of the '{@link #getURL() <em>URL</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getURL()
	 * @generated
	 * @ordered
	 */
	protected static final String URL_EDEFAULT = null;
	/**
	 * The cached value of the '{@link #getURL() <em>URL</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getURL()
	 * @generated
	 * @ordered
	 */
	protected String url = URL_EDEFAULT;

	/**
	 * The cached value of the '{@link #getVideoprocessingcloud() <em>Videoprocessingcloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVideoprocessingcloud()
	 * @generated
	 * @ordered
	 */
	protected VideoProcessingCloud videoprocessingcloud;

	/**
	 * The cached value of the '{@link #getCookies() <em>Cookies</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCookies()
	 * @generated
	 * @ordered
	 */
	protected EList<Cookies> cookies;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WebsiteImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.WEBSITE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEncryptedData() {
		return encryptedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncryptedData(Checked newEncryptedData) {
		Checked oldEncryptedData = encryptedData;
		encryptedData = newEncryptedData == null ? ENCRYPTED_DATA_EDEFAULT : newEncryptedData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.WEBSITE__ENCRYPTED_DATA, oldEncryptedData,
					encryptedData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cloud getCloud() {
		if (cloud != null && cloud.eIsProxy()) {
			InternalEObject oldCloud = (InternalEObject) cloud;
			cloud = (Cloud) eResolveProxy(oldCloud);
			if (cloud != oldCloud) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.WEBSITE__CLOUD, oldCloud,
							cloud));
			}
		}
		return cloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cloud basicGetCloud() {
		return cloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCloud(Cloud newCloud, NotificationChain msgs) {
		Cloud oldCloud = cloud;
		cloud = newCloud;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Cgm3Package.WEBSITE__CLOUD,
					oldCloud, newCloud);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCloud(Cloud newCloud) {
		if (newCloud != cloud) {
			NotificationChain msgs = null;
			if (cloud != null)
				msgs = ((InternalEObject) cloud).eInverseRemove(this, Cgm3Package.CLOUD__WEBSITE, Cloud.class, msgs);
			if (newCloud != null)
				msgs = ((InternalEObject) newCloud).eInverseAdd(this, Cgm3Package.CLOUD__WEBSITE, Cloud.class, msgs);
			msgs = basicSetCloud(newCloud, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.WEBSITE__CLOUD, newCloud, newCloud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Doctor getDoctor() {
		if (doctor != null && doctor.eIsProxy()) {
			InternalEObject oldDoctor = (InternalEObject) doctor;
			doctor = (Doctor) eResolveProxy(oldDoctor);
			if (doctor != oldDoctor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.WEBSITE__DOCTOR, oldDoctor,
							doctor));
			}
		}
		return doctor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Doctor basicGetDoctor() {
		return doctor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDoctor(Doctor newDoctor, NotificationChain msgs) {
		Doctor oldDoctor = doctor;
		doctor = newDoctor;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, Cgm3Package.WEBSITE__DOCTOR,
					oldDoctor, newDoctor);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoctor(Doctor newDoctor) {
		if (newDoctor != doctor) {
			NotificationChain msgs = null;
			if (doctor != null)
				msgs = ((InternalEObject) doctor).eInverseRemove(this, Cgm3Package.DOCTOR__WEBSITE, Doctor.class, msgs);
			if (newDoctor != null)
				msgs = ((InternalEObject) newDoctor).eInverseAdd(this, Cgm3Package.DOCTOR__WEBSITE, Doctor.class, msgs);
			msgs = basicSetDoctor(newDoctor, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.WEBSITE__DOCTOR, newDoctor, newDoctor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Researcher getResearcher() {
		if (researcher != null && researcher.eIsProxy()) {
			InternalEObject oldResearcher = (InternalEObject) researcher;
			researcher = (Researcher) eResolveProxy(oldResearcher);
			if (researcher != oldResearcher) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.WEBSITE__RESEARCHER,
							oldResearcher, researcher));
			}
		}
		return researcher;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Researcher basicGetResearcher() {
		return researcher;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetResearcher(Researcher newResearcher, NotificationChain msgs) {
		Researcher oldResearcher = researcher;
		researcher = newResearcher;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.WEBSITE__RESEARCHER, oldResearcher, newResearcher);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setResearcher(Researcher newResearcher) {
		if (newResearcher != researcher) {
			NotificationChain msgs = null;
			if (researcher != null)
				msgs = ((InternalEObject) researcher).eInverseRemove(this, Cgm3Package.RESEARCHER__WEBSITE,
						Researcher.class, msgs);
			if (newResearcher != null)
				msgs = ((InternalEObject) newResearcher).eInverseAdd(this, Cgm3Package.RESEARCHER__WEBSITE,
						Researcher.class, msgs);
			msgs = basicSetResearcher(newResearcher, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.WEBSITE__RESEARCHER, newResearcher,
					newResearcher));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getURL() {
		return url;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setURL(String newURL) {
		String oldURL = url;
		url = newURL;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.WEBSITE__URL, oldURL, url));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoProcessingCloud getVideoprocessingcloud() {
		if (videoprocessingcloud != null && videoprocessingcloud.eIsProxy()) {
			InternalEObject oldVideoprocessingcloud = (InternalEObject) videoprocessingcloud;
			videoprocessingcloud = (VideoProcessingCloud) eResolveProxy(oldVideoprocessingcloud);
			if (videoprocessingcloud != oldVideoprocessingcloud) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.WEBSITE__VIDEOPROCESSINGCLOUD,
							oldVideoprocessingcloud, videoprocessingcloud));
			}
		}
		return videoprocessingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoProcessingCloud basicGetVideoprocessingcloud() {
		return videoprocessingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetVideoprocessingcloud(VideoProcessingCloud newVideoprocessingcloud,
			NotificationChain msgs) {
		VideoProcessingCloud oldVideoprocessingcloud = videoprocessingcloud;
		videoprocessingcloud = newVideoprocessingcloud;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.WEBSITE__VIDEOPROCESSINGCLOUD, oldVideoprocessingcloud, newVideoprocessingcloud);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVideoprocessingcloud(VideoProcessingCloud newVideoprocessingcloud) {
		if (newVideoprocessingcloud != videoprocessingcloud) {
			NotificationChain msgs = null;
			if (videoprocessingcloud != null)
				msgs = ((InternalEObject) videoprocessingcloud).eInverseRemove(this,
						Cgm3Package.VIDEO_PROCESSING_CLOUD__WEBSITE, VideoProcessingCloud.class, msgs);
			if (newVideoprocessingcloud != null)
				msgs = ((InternalEObject) newVideoprocessingcloud).eInverseAdd(this,
						Cgm3Package.VIDEO_PROCESSING_CLOUD__WEBSITE, VideoProcessingCloud.class, msgs);
			msgs = basicSetVideoprocessingcloud(newVideoprocessingcloud, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.WEBSITE__VIDEOPROCESSINGCLOUD,
					newVideoprocessingcloud, newVideoprocessingcloud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Cookies> getCookies() {
		if (cookies == null) {
			cookies = new EObjectContainmentEList<Cookies>(Cookies.class, this, Cgm3Package.WEBSITE__COOKIES);
		}
		return cookies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.WEBSITE__CLOUD:
			if (cloud != null)
				msgs = ((InternalEObject) cloud).eInverseRemove(this, Cgm3Package.CLOUD__WEBSITE, Cloud.class, msgs);
			return basicSetCloud((Cloud) otherEnd, msgs);
		case Cgm3Package.WEBSITE__DOCTOR:
			if (doctor != null)
				msgs = ((InternalEObject) doctor).eInverseRemove(this, Cgm3Package.DOCTOR__WEBSITE, Doctor.class, msgs);
			return basicSetDoctor((Doctor) otherEnd, msgs);
		case Cgm3Package.WEBSITE__RESEARCHER:
			if (researcher != null)
				msgs = ((InternalEObject) researcher).eInverseRemove(this, Cgm3Package.RESEARCHER__WEBSITE,
						Researcher.class, msgs);
			return basicSetResearcher((Researcher) otherEnd, msgs);
		case Cgm3Package.WEBSITE__VIDEOPROCESSINGCLOUD:
			if (videoprocessingcloud != null)
				msgs = ((InternalEObject) videoprocessingcloud).eInverseRemove(this,
						Cgm3Package.VIDEO_PROCESSING_CLOUD__WEBSITE, VideoProcessingCloud.class, msgs);
			return basicSetVideoprocessingcloud((VideoProcessingCloud) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.WEBSITE__CLOUD:
			return basicSetCloud(null, msgs);
		case Cgm3Package.WEBSITE__DOCTOR:
			return basicSetDoctor(null, msgs);
		case Cgm3Package.WEBSITE__RESEARCHER:
			return basicSetResearcher(null, msgs);
		case Cgm3Package.WEBSITE__VIDEOPROCESSINGCLOUD:
			return basicSetVideoprocessingcloud(null, msgs);
		case Cgm3Package.WEBSITE__COOKIES:
			return ((InternalEList<?>) getCookies()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.WEBSITE__ENCRYPTED_DATA:
			return getEncryptedData();
		case Cgm3Package.WEBSITE__CLOUD:
			if (resolve)
				return getCloud();
			return basicGetCloud();
		case Cgm3Package.WEBSITE__DOCTOR:
			if (resolve)
				return getDoctor();
			return basicGetDoctor();
		case Cgm3Package.WEBSITE__RESEARCHER:
			if (resolve)
				return getResearcher();
			return basicGetResearcher();
		case Cgm3Package.WEBSITE__URL:
			return getURL();
		case Cgm3Package.WEBSITE__VIDEOPROCESSINGCLOUD:
			if (resolve)
				return getVideoprocessingcloud();
			return basicGetVideoprocessingcloud();
		case Cgm3Package.WEBSITE__COOKIES:
			return getCookies();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.WEBSITE__ENCRYPTED_DATA:
			setEncryptedData((Checked) newValue);
			return;
		case Cgm3Package.WEBSITE__CLOUD:
			setCloud((Cloud) newValue);
			return;
		case Cgm3Package.WEBSITE__DOCTOR:
			setDoctor((Doctor) newValue);
			return;
		case Cgm3Package.WEBSITE__RESEARCHER:
			setResearcher((Researcher) newValue);
			return;
		case Cgm3Package.WEBSITE__URL:
			setURL((String) newValue);
			return;
		case Cgm3Package.WEBSITE__VIDEOPROCESSINGCLOUD:
			setVideoprocessingcloud((VideoProcessingCloud) newValue);
			return;
		case Cgm3Package.WEBSITE__COOKIES:
			getCookies().clear();
			getCookies().addAll((Collection<? extends Cookies>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.WEBSITE__ENCRYPTED_DATA:
			setEncryptedData(ENCRYPTED_DATA_EDEFAULT);
			return;
		case Cgm3Package.WEBSITE__CLOUD:
			setCloud((Cloud) null);
			return;
		case Cgm3Package.WEBSITE__DOCTOR:
			setDoctor((Doctor) null);
			return;
		case Cgm3Package.WEBSITE__RESEARCHER:
			setResearcher((Researcher) null);
			return;
		case Cgm3Package.WEBSITE__URL:
			setURL(URL_EDEFAULT);
			return;
		case Cgm3Package.WEBSITE__VIDEOPROCESSINGCLOUD:
			setVideoprocessingcloud((VideoProcessingCloud) null);
			return;
		case Cgm3Package.WEBSITE__COOKIES:
			getCookies().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.WEBSITE__ENCRYPTED_DATA:
			return encryptedData != ENCRYPTED_DATA_EDEFAULT;
		case Cgm3Package.WEBSITE__CLOUD:
			return cloud != null;
		case Cgm3Package.WEBSITE__DOCTOR:
			return doctor != null;
		case Cgm3Package.WEBSITE__RESEARCHER:
			return researcher != null;
		case Cgm3Package.WEBSITE__URL:
			return URL_EDEFAULT == null ? url != null : !URL_EDEFAULT.equals(url);
		case Cgm3Package.WEBSITE__VIDEOPROCESSINGCLOUD:
			return videoprocessingcloud != null;
		case Cgm3Package.WEBSITE__COOKIES:
			return cookies != null && !cookies.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.WEBSITE__ENCRYPTED_DATA:
				return Cgm3Package.ENCRYPTION__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (baseFeatureID) {
			case Cgm3Package.ENCRYPTION__ENCRYPTED_DATA:
				return Cgm3Package.WEBSITE__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (EncryptedData: ");
		result.append(encryptedData);
		result.append(", URL: ");
		result.append(url);
		result.append(')');
		return result.toString();
	}

} //WebsiteImpl
