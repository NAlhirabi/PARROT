/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.CloudService;
import com.cardiffuni.pbdproject.cgm3.CommunicationProtocols;
import com.cardiffuni.pbdproject.cgm3.DataRetentionEnum;
import com.cardiffuni.pbdproject.cgm3.DoorLock;

import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.Privacy_patterns;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Door Lock</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoorLockImpl#getEncryptedData <em>Encrypted Data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoorLockImpl#getPrivacy_patterns <em>Privacy patterns</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoorLockImpl#getCloudservice <em>Cloudservice</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoorLockImpl#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoorLockImpl#getConnection <em>Connection</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoorLockImpl#getDataRetention <em>Data Retention</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoorLockImpl#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DoorLockImpl#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DoorLockImpl extends GeneralEntityImpl implements DoorLock {
	/**
	 * The default value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENCRYPTED_DATA_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected Checked encryptedData = ENCRYPTED_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected static final String PRIVACY_PATTERNS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected String privacy_patterns = PRIVACY_PATTERNS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCloudservice() <em>Cloudservice</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCloudservice()
	 * @generated
	 * @ordered
	 */
	protected CloudService cloudservice;

	/**
	 * The default value of the '{@link #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() <em>Are you using appropriate technical or organisational measures to protect the data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT = Answer.NOT_ANSWERED;
	/**
	 * The cached value of the '{@link #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() <em>Are you using appropriate technical or organisational measures to protect the data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT;
	/**
	 * The default value of the '{@link #getConnection() <em>Connection</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnection()
	 * @generated
	 * @ordered
	 */
	protected static final CommunicationProtocols CONNECTION_EDEFAULT = CommunicationProtocols.BLUTOOTH;
	/**
	 * The cached value of the '{@link #getConnection() <em>Connection</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnection()
	 * @generated
	 * @ordered
	 */
	protected CommunicationProtocols connection = CONNECTION_EDEFAULT;
	/**
	 * The default value of the '{@link #getDataRetention() <em>Data Retention</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataRetention()
	 * @generated
	 * @ordered
	 */
	protected static final DataRetentionEnum DATA_RETENTION_EDEFAULT = DataRetentionEnum.NOT_ACCEPTED;
	/**
	 * The cached value of the '{@link #getDataRetention() <em>Data Retention</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataRetention()
	 * @generated
	 * @ordered
	 */
	protected DataRetentionEnum dataRetention = DATA_RETENTION_EDEFAULT;
	/**
	 * The default value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT = Answer.NOT_ANSWERED;
	/**
	 * The cached value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;
	/**
	 * The default value of the '{@link #getIs_data_against_accidental_loss_or_destruction_or_damage() <em>Is data against accidental loss or destruction or damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @generated
	 * @ordered
	 */
	protected static final Answer IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT = Answer.NOT_ANSWERED;
	/**
	 * The cached value of the '{@link #getIs_data_against_accidental_loss_or_destruction_or_damage() <em>Is data against accidental loss or destruction or damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @generated
	 * @ordered
	 */
	protected Answer is_data_against_accidental_loss_or_destruction_or_damage = IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DoorLockImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.DOOR_LOCK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEncryptedData() {
		return encryptedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncryptedData(Checked newEncryptedData) {
		Checked oldEncryptedData = encryptedData;
		encryptedData = newEncryptedData == null ? ENCRYPTED_DATA_EDEFAULT : newEncryptedData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.DOOR_LOCK__ENCRYPTED_DATA,
					oldEncryptedData, encryptedData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPrivacy_patterns() {
		return privacy_patterns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrivacy_patterns(String newPrivacy_patterns) {
		String oldPrivacy_patterns = privacy_patterns;
		privacy_patterns = newPrivacy_patterns;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.DOOR_LOCK__PRIVACY_PATTERNS,
					oldPrivacy_patterns, privacy_patterns));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudService getCloudservice() {
		if (cloudservice != null && cloudservice.eIsProxy()) {
			InternalEObject oldCloudservice = (InternalEObject) cloudservice;
			cloudservice = (CloudService) eResolveProxy(oldCloudservice);
			if (cloudservice != oldCloudservice) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.DOOR_LOCK__CLOUDSERVICE,
							oldCloudservice, cloudservice));
			}
		}
		return cloudservice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudService basicGetCloudservice() {
		return cloudservice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCloudservice(CloudService newCloudservice, NotificationChain msgs) {
		CloudService oldCloudservice = cloudservice;
		cloudservice = newCloudservice;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.DOOR_LOCK__CLOUDSERVICE, oldCloudservice, newCloudservice);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCloudservice(CloudService newCloudservice) {
		if (newCloudservice != cloudservice) {
			NotificationChain msgs = null;
			if (cloudservice != null)
				msgs = ((InternalEObject) cloudservice).eInverseRemove(this, Cgm3Package.CLOUD_SERVICE__DOORLOCK,
						CloudService.class, msgs);
			if (newCloudservice != null)
				msgs = ((InternalEObject) newCloudservice).eInverseAdd(this, Cgm3Package.CLOUD_SERVICE__DOORLOCK,
						CloudService.class, msgs);
			msgs = basicSetCloudservice(newCloudservice, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.DOOR_LOCK__CLOUDSERVICE, newCloudservice,
					newCloudservice));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() {
		return are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(
			Answer newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data) {
		Answer oldAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
		are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data == null
				? ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT
				: newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.DOOR_LOCK__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA,
					oldAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data,
					are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CommunicationProtocols getConnection() {
		return connection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConnection(CommunicationProtocols newConnection) {
		CommunicationProtocols oldConnection = connection;
		connection = newConnection == null ? CONNECTION_EDEFAULT : newConnection;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.DOOR_LOCK__CONNECTION, oldConnection,
					connection));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataRetentionEnum getDataRetention() {
		return dataRetention;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDataRetention(DataRetentionEnum newDataRetention) {
		DataRetentionEnum oldDataRetention = dataRetention;
		dataRetention = newDataRetention == null ? DATA_RETENTION_EDEFAULT : newDataRetention;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.DOOR_LOCK__DATA_RETENTION,
					oldDataRetention, dataRetention));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
			Answer newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes) {
		Answer oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes = are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes == null
				? ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT
				: newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.DOOR_LOCK__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
					oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes,
					are_you_storing_the_data_longer_than_is_necessary_for_the_purposes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getIs_data_against_accidental_loss_or_destruction_or_damage() {
		return is_data_against_accidental_loss_or_destruction_or_damage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIs_data_against_accidental_loss_or_destruction_or_damage(
			Answer newIs_data_against_accidental_loss_or_destruction_or_damage) {
		Answer oldIs_data_against_accidental_loss_or_destruction_or_damage = is_data_against_accidental_loss_or_destruction_or_damage;
		is_data_against_accidental_loss_or_destruction_or_damage = newIs_data_against_accidental_loss_or_destruction_or_damage == null
				? IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT
				: newIs_data_against_accidental_loss_or_destruction_or_damage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.DOOR_LOCK__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE,
					oldIs_data_against_accidental_loss_or_destruction_or_damage,
					is_data_against_accidental_loss_or_destruction_or_damage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.DOOR_LOCK__CLOUDSERVICE:
			if (cloudservice != null)
				msgs = ((InternalEObject) cloudservice).eInverseRemove(this, Cgm3Package.CLOUD_SERVICE__DOORLOCK,
						CloudService.class, msgs);
			return basicSetCloudservice((CloudService) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.DOOR_LOCK__CLOUDSERVICE:
			return basicSetCloudservice(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.DOOR_LOCK__ENCRYPTED_DATA:
			return getEncryptedData();
		case Cgm3Package.DOOR_LOCK__PRIVACY_PATTERNS:
			return getPrivacy_patterns();
		case Cgm3Package.DOOR_LOCK__CLOUDSERVICE:
			if (resolve)
				return getCloudservice();
			return basicGetCloudservice();
		case Cgm3Package.DOOR_LOCK__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			return getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();
		case Cgm3Package.DOOR_LOCK__CONNECTION:
			return getConnection();
		case Cgm3Package.DOOR_LOCK__DATA_RETENTION:
			return getDataRetention();
		case Cgm3Package.DOOR_LOCK__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();
		case Cgm3Package.DOOR_LOCK__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			return getIs_data_against_accidental_loss_or_destruction_or_damage();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.DOOR_LOCK__ENCRYPTED_DATA:
			setEncryptedData((Checked) newValue);
			return;
		case Cgm3Package.DOOR_LOCK__PRIVACY_PATTERNS:
			setPrivacy_patterns((String) newValue);
			return;
		case Cgm3Package.DOOR_LOCK__CLOUDSERVICE:
			setCloudservice((CloudService) newValue);
			return;
		case Cgm3Package.DOOR_LOCK__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data((Answer) newValue);
			return;
		case Cgm3Package.DOOR_LOCK__CONNECTION:
			setConnection((CommunicationProtocols) newValue);
			return;
		case Cgm3Package.DOOR_LOCK__DATA_RETENTION:
			setDataRetention((DataRetentionEnum) newValue);
			return;
		case Cgm3Package.DOOR_LOCK__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes((Answer) newValue);
			return;
		case Cgm3Package.DOOR_LOCK__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			setIs_data_against_accidental_loss_or_destruction_or_damage((Answer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.DOOR_LOCK__ENCRYPTED_DATA:
			setEncryptedData(ENCRYPTED_DATA_EDEFAULT);
			return;
		case Cgm3Package.DOOR_LOCK__PRIVACY_PATTERNS:
			setPrivacy_patterns(PRIVACY_PATTERNS_EDEFAULT);
			return;
		case Cgm3Package.DOOR_LOCK__CLOUDSERVICE:
			setCloudservice((CloudService) null);
			return;
		case Cgm3Package.DOOR_LOCK__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(
					ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT);
			return;
		case Cgm3Package.DOOR_LOCK__CONNECTION:
			setConnection(CONNECTION_EDEFAULT);
			return;
		case Cgm3Package.DOOR_LOCK__DATA_RETENTION:
			setDataRetention(DATA_RETENTION_EDEFAULT);
			return;
		case Cgm3Package.DOOR_LOCK__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
					ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT);
			return;
		case Cgm3Package.DOOR_LOCK__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			setIs_data_against_accidental_loss_or_destruction_or_damage(
					IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.DOOR_LOCK__ENCRYPTED_DATA:
			return encryptedData != ENCRYPTED_DATA_EDEFAULT;
		case Cgm3Package.DOOR_LOCK__PRIVACY_PATTERNS:
			return PRIVACY_PATTERNS_EDEFAULT == null ? privacy_patterns != null
					: !PRIVACY_PATTERNS_EDEFAULT.equals(privacy_patterns);
		case Cgm3Package.DOOR_LOCK__CLOUDSERVICE:
			return cloudservice != null;
		case Cgm3Package.DOOR_LOCK__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			return are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data != ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT;
		case Cgm3Package.DOOR_LOCK__CONNECTION:
			return connection != CONNECTION_EDEFAULT;
		case Cgm3Package.DOOR_LOCK__DATA_RETENTION:
			return dataRetention != DATA_RETENTION_EDEFAULT;
		case Cgm3Package.DOOR_LOCK__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes != ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;
		case Cgm3Package.DOOR_LOCK__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			return is_data_against_accidental_loss_or_destruction_or_damage != IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.DOOR_LOCK__ENCRYPTED_DATA:
				return Cgm3Package.ENCRYPTION__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.DOOR_LOCK__PRIVACY_PATTERNS:
				return Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (baseFeatureID) {
			case Cgm3Package.ENCRYPTION__ENCRYPTED_DATA:
				return Cgm3Package.DOOR_LOCK__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (baseFeatureID) {
			case Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS:
				return Cgm3Package.DOOR_LOCK__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (EncryptedData: ");
		result.append(encryptedData);
		result.append(", Privacy_patterns: ");
		result.append(privacy_patterns);
		result.append(", Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data: ");
		result.append(are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data);
		result.append(", Connection: ");
		result.append(connection);
		result.append(", DataRetention: ");
		result.append(dataRetention);
		result.append(", Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes: ");
		result.append(are_you_storing_the_data_longer_than_is_necessary_for_the_purposes);
		result.append(", Is_data_against_accidental_loss_or_destruction_or_damage: ");
		result.append(is_data_against_accidental_loss_or_destruction_or_damage);
		result.append(')');
		return result.toString();
	}

} //DoorLockImpl
