/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.DataSharing;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Data Sharing</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DataSharingImpl#getApply_anonymisation_for_researcher <em>Apply anonymisation for researcher</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.DataSharingImpl#getEnsure_accessControl <em>Ensure access Control</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DataSharingImpl extends GeneralEntityImpl implements DataSharing {
	/**
	 * The default value of the '{@link #getApply_anonymisation_for_researcher() <em>Apply anonymisation for researcher</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getApply_anonymisation_for_researcher()
	 * @generated
	 * @ordered
	 */
	protected static final Checked APPLY_ANONYMISATION_FOR_RESEARCHER_EDEFAULT = Checked.NO;
	/**
	 * The cached value of the '{@link #getApply_anonymisation_for_researcher() <em>Apply anonymisation for researcher</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getApply_anonymisation_for_researcher()
	 * @generated
	 * @ordered
	 */
	protected Checked apply_anonymisation_for_researcher = APPLY_ANONYMISATION_FOR_RESEARCHER_EDEFAULT;
	/**
	 * The default value of the '{@link #getEnsure_accessControl() <em>Ensure access Control</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnsure_accessControl()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENSURE_ACCESS_CONTROL_EDEFAULT = Checked.NO;
	/**
	 * The cached value of the '{@link #getEnsure_accessControl() <em>Ensure access Control</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnsure_accessControl()
	 * @generated
	 * @ordered
	 */
	protected Checked ensure_accessControl = ENSURE_ACCESS_CONTROL_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DataSharingImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.DATA_SHARING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getApply_anonymisation_for_researcher() {
		return apply_anonymisation_for_researcher;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setApply_anonymisation_for_researcher(Checked newApply_anonymisation_for_researcher) {
		Checked oldApply_anonymisation_for_researcher = apply_anonymisation_for_researcher;
		apply_anonymisation_for_researcher = newApply_anonymisation_for_researcher == null
				? APPLY_ANONYMISATION_FOR_RESEARCHER_EDEFAULT
				: newApply_anonymisation_for_researcher;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.DATA_SHARING__APPLY_ANONYMISATION_FOR_RESEARCHER, oldApply_anonymisation_for_researcher,
					apply_anonymisation_for_researcher));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEnsure_accessControl() {
		return ensure_accessControl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEnsure_accessControl(Checked newEnsure_accessControl) {
		Checked oldEnsure_accessControl = ensure_accessControl;
		ensure_accessControl = newEnsure_accessControl == null ? ENSURE_ACCESS_CONTROL_EDEFAULT
				: newEnsure_accessControl;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.DATA_SHARING__ENSURE_ACCESS_CONTROL,
					oldEnsure_accessControl, ensure_accessControl));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.DATA_SHARING__APPLY_ANONYMISATION_FOR_RESEARCHER:
			return getApply_anonymisation_for_researcher();
		case Cgm3Package.DATA_SHARING__ENSURE_ACCESS_CONTROL:
			return getEnsure_accessControl();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.DATA_SHARING__APPLY_ANONYMISATION_FOR_RESEARCHER:
			setApply_anonymisation_for_researcher((Checked) newValue);
			return;
		case Cgm3Package.DATA_SHARING__ENSURE_ACCESS_CONTROL:
			setEnsure_accessControl((Checked) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.DATA_SHARING__APPLY_ANONYMISATION_FOR_RESEARCHER:
			setApply_anonymisation_for_researcher(APPLY_ANONYMISATION_FOR_RESEARCHER_EDEFAULT);
			return;
		case Cgm3Package.DATA_SHARING__ENSURE_ACCESS_CONTROL:
			setEnsure_accessControl(ENSURE_ACCESS_CONTROL_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.DATA_SHARING__APPLY_ANONYMISATION_FOR_RESEARCHER:
			return apply_anonymisation_for_researcher != APPLY_ANONYMISATION_FOR_RESEARCHER_EDEFAULT;
		case Cgm3Package.DATA_SHARING__ENSURE_ACCESS_CONTROL:
			return ensure_accessControl != ENSURE_ACCESS_CONTROL_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Apply_anonymisation_for_researcher: ");
		result.append(apply_anonymisation_for_researcher);
		result.append(", Ensure_accessControl: ");
		result.append(ensure_accessControl);
		result.append(')');
		return result.toString();
	}

} //DataSharingImpl
