/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.CGMsensor;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.Cloud;
import com.cardiffuni.pbdproject.cgm3.ComputerBrowser;
import com.cardiffuni.pbdproject.cgm3.DataRetentionEnum;
import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.PharmacyCloudold;
import com.cardiffuni.pbdproject.cgm3.UserLocation;
import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Computer Browser</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl#getEncryptedData <em>Encrypted Data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl#getCgmsensor <em>Cgmsensor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl#getCloud <em>Cloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl#getPatient_info_Retention_Period <em>Patient info Retention Period</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl#getUserlocation <em>Userlocation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl#getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate <em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl#getAre_you_planning_to_send_all_the_data_to_the_cloud <em>Are you planning to send all the data to the cloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl#getPharmacycloud <em>Pharmacycloud</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ComputerBrowserImpl extends GeneralEntityImpl implements ComputerBrowser {
	/**
	 * The default value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENCRYPTED_DATA_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected Checked encryptedData = ENCRYPTED_DATA_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCgmsensor() <em>Cgmsensor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCgmsensor()
	 * @generated
	 * @ordered
	 */
	protected CGMsensor cgmsensor;

	/**
	 * The cached value of the '{@link #getCloud() <em>Cloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCloud()
	 * @generated
	 * @ordered
	 */
	protected Cloud cloud;

	/**
	 * The default value of the '{@link #getPatient_info_Retention_Period() <em>Patient info Retention Period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatient_info_Retention_Period()
	 * @generated
	 * @ordered
	 */
	protected static final DataRetentionEnum PATIENT_INFO_RETENTION_PERIOD_EDEFAULT = DataRetentionEnum.NOT_ACCEPTED;

	/**
	 * The cached value of the '{@link #getPatient_info_Retention_Period() <em>Patient info Retention Period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPatient_info_Retention_Period()
	 * @generated
	 * @ordered
	 */
	protected DataRetentionEnum patient_info_Retention_Period = PATIENT_INFO_RETENTION_PERIOD_EDEFAULT;

	/**
	 * The cached value of the '{@link #getUserlocation() <em>Userlocation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserlocation()
	 * @generated
	 * @ordered
	 */
	protected EList<UserLocation> userlocation;

	/**
	 * The default value of the '{@link #getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate() <em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate() <em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate = ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_planning_to_send_all_the_data_to_the_cloud() <em>Are you planning to send all the data to the cloud</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_planning_to_send_all_the_data_to_the_cloud()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_planning_to_send_all_the_data_to_the_cloud() <em>Are you planning to send all the data to the cloud</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_planning_to_send_all_the_data_to_the_cloud()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_planning_to_send_all_the_data_to_the_cloud = ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() <em>Are you processing data in an incompatible way with the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() <em>Are you processing data in an incompatible way with the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_processing_data_in_an_incompatible_way_with_the_purpose = ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;

	/**
	 * The default value of the '{@link #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 * @ordered
	 */
	protected static final Answer IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 * @ordered
	 */
	protected Answer is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPharmacycloud() <em>Pharmacycloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPharmacycloud()
	 * @generated
	 * @ordered
	 */
	protected PharmacyCloudold pharmacycloud;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ComputerBrowserImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.COMPUTER_BROWSER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEncryptedData() {
		return encryptedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncryptedData(Checked newEncryptedData) {
		Checked oldEncryptedData = encryptedData;
		encryptedData = newEncryptedData == null ? ENCRYPTED_DATA_EDEFAULT : newEncryptedData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.COMPUTER_BROWSER__ENCRYPTED_DATA,
					oldEncryptedData, encryptedData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CGMsensor getCgmsensor() {
		if (cgmsensor != null && cgmsensor.eIsProxy()) {
			InternalEObject oldCgmsensor = (InternalEObject) cgmsensor;
			cgmsensor = (CGMsensor) eResolveProxy(oldCgmsensor);
			if (cgmsensor != oldCgmsensor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.COMPUTER_BROWSER__CGMSENSOR,
							oldCgmsensor, cgmsensor));
			}
		}
		return cgmsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CGMsensor basicGetCgmsensor() {
		return cgmsensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCgmsensor(CGMsensor newCgmsensor) {
		CGMsensor oldCgmsensor = cgmsensor;
		cgmsensor = newCgmsensor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.COMPUTER_BROWSER__CGMSENSOR, oldCgmsensor,
					cgmsensor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cloud getCloud() {
		if (cloud != null && cloud.eIsProxy()) {
			InternalEObject oldCloud = (InternalEObject) cloud;
			cloud = (Cloud) eResolveProxy(oldCloud);
			if (cloud != oldCloud) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.COMPUTER_BROWSER__CLOUD,
							oldCloud, cloud));
			}
		}
		return cloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cloud basicGetCloud() {
		return cloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCloud(Cloud newCloud) {
		Cloud oldCloud = cloud;
		cloud = newCloud;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.COMPUTER_BROWSER__CLOUD, oldCloud,
					cloud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataRetentionEnum getPatient_info_Retention_Period() {
		return patient_info_Retention_Period;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPatient_info_Retention_Period(DataRetentionEnum newPatient_info_Retention_Period) {
		DataRetentionEnum oldPatient_info_Retention_Period = patient_info_Retention_Period;
		patient_info_Retention_Period = newPatient_info_Retention_Period == null
				? PATIENT_INFO_RETENTION_PERIOD_EDEFAULT
				: newPatient_info_Retention_Period;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.COMPUTER_BROWSER__PATIENT_INFO_RETENTION_PERIOD, oldPatient_info_Retention_Period,
					patient_info_Retention_Period));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<UserLocation> getUserlocation() {
		if (userlocation == null) {
			userlocation = new EObjectContainmentEList<UserLocation>(UserLocation.class, this,
					Cgm3Package.COMPUTER_BROWSER__USERLOCATION);
		}
		return userlocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate() {
		return are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate(
			Answer newAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate) {
		Answer oldAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate = are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate;
		are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate = newAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate == null
				? ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE_EDEFAULT
				: newAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE,
					oldAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate,
					are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_planning_to_send_all_the_data_to_the_cloud() {
		return are_you_planning_to_send_all_the_data_to_the_cloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_planning_to_send_all_the_data_to_the_cloud(
			Answer newAre_you_planning_to_send_all_the_data_to_the_cloud) {
		Answer oldAre_you_planning_to_send_all_the_data_to_the_cloud = are_you_planning_to_send_all_the_data_to_the_cloud;
		are_you_planning_to_send_all_the_data_to_the_cloud = newAre_you_planning_to_send_all_the_data_to_the_cloud == null
				? ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD_EDEFAULT
				: newAre_you_planning_to_send_all_the_data_to_the_cloud;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD,
					oldAre_you_planning_to_send_all_the_data_to_the_cloud,
					are_you_planning_to_send_all_the_data_to_the_cloud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return are_you_processing_data_in_an_incompatible_way_with_the_purpose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(
			Answer newAre_you_processing_data_in_an_incompatible_way_with_the_purpose) {
		Answer oldAre_you_processing_data_in_an_incompatible_way_with_the_purpose = are_you_processing_data_in_an_incompatible_way_with_the_purpose;
		are_you_processing_data_in_an_incompatible_way_with_the_purpose = newAre_you_processing_data_in_an_incompatible_way_with_the_purpose == null
				? ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT
				: newAre_you_processing_data_in_an_incompatible_way_with_the_purpose;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE,
					oldAre_you_processing_data_in_an_incompatible_way_with_the_purpose,
					are_you_processing_data_in_an_incompatible_way_with_the_purpose));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
			Answer newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes) {
		Answer oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes = are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes == null
				? ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT
				: newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.COMPUTER_BROWSER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
					oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes,
					are_you_storing_the_data_longer_than_is_necessary_for_the_purposes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
			Answer newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures) {
		Answer oldIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
		is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures == null
				? IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT
				: newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.COMPUTER_BROWSER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES,
					oldIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures,
					is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PharmacyCloudold getPharmacycloud() {
		if (pharmacycloud != null && pharmacycloud.eIsProxy()) {
			InternalEObject oldPharmacycloud = (InternalEObject) pharmacycloud;
			pharmacycloud = (PharmacyCloudold) eResolveProxy(oldPharmacycloud);
			if (pharmacycloud != oldPharmacycloud) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Cgm3Package.COMPUTER_BROWSER__PHARMACYCLOUD, oldPharmacycloud, pharmacycloud));
			}
		}
		return pharmacycloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PharmacyCloudold basicGetPharmacycloud() {
		return pharmacycloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPharmacycloud(PharmacyCloudold newPharmacycloud, NotificationChain msgs) {
		PharmacyCloudold oldPharmacycloud = pharmacycloud;
		pharmacycloud = newPharmacycloud;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.COMPUTER_BROWSER__PHARMACYCLOUD, oldPharmacycloud, newPharmacycloud);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPharmacycloud(PharmacyCloudold newPharmacycloud) {
		if (newPharmacycloud != pharmacycloud) {
			NotificationChain msgs = null;
			if (pharmacycloud != null)
				msgs = ((InternalEObject) pharmacycloud).eInverseRemove(this,
						Cgm3Package.PHARMACY_CLOUDOLD__COMPUTERBROWSER, PharmacyCloudold.class, msgs);
			if (newPharmacycloud != null)
				msgs = ((InternalEObject) newPharmacycloud).eInverseAdd(this,
						Cgm3Package.PHARMACY_CLOUDOLD__COMPUTERBROWSER, PharmacyCloudold.class, msgs);
			msgs = basicSetPharmacycloud(newPharmacycloud, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.COMPUTER_BROWSER__PHARMACYCLOUD,
					newPharmacycloud, newPharmacycloud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.COMPUTER_BROWSER__PHARMACYCLOUD:
			if (pharmacycloud != null)
				msgs = ((InternalEObject) pharmacycloud).eInverseRemove(this,
						Cgm3Package.PHARMACY_CLOUDOLD__COMPUTERBROWSER, PharmacyCloudold.class, msgs);
			return basicSetPharmacycloud((PharmacyCloudold) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.COMPUTER_BROWSER__USERLOCATION:
			return ((InternalEList<?>) getUserlocation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.COMPUTER_BROWSER__PHARMACYCLOUD:
			return basicSetPharmacycloud(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.COMPUTER_BROWSER__ENCRYPTED_DATA:
			return getEncryptedData();
		case Cgm3Package.COMPUTER_BROWSER__CGMSENSOR:
			if (resolve)
				return getCgmsensor();
			return basicGetCgmsensor();
		case Cgm3Package.COMPUTER_BROWSER__CLOUD:
			if (resolve)
				return getCloud();
			return basicGetCloud();
		case Cgm3Package.COMPUTER_BROWSER__PATIENT_INFO_RETENTION_PERIOD:
			return getPatient_info_Retention_Period();
		case Cgm3Package.COMPUTER_BROWSER__USERLOCATION:
			return getUserlocation();
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE:
			return getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate();
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD:
			return getAre_you_planning_to_send_all_the_data_to_the_cloud();
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			return getAre_you_processing_data_in_an_incompatible_way_with_the_purpose();
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();
		case Cgm3Package.COMPUTER_BROWSER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			return getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();
		case Cgm3Package.COMPUTER_BROWSER__PHARMACYCLOUD:
			if (resolve)
				return getPharmacycloud();
			return basicGetPharmacycloud();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.COMPUTER_BROWSER__ENCRYPTED_DATA:
			setEncryptedData((Checked) newValue);
			return;
		case Cgm3Package.COMPUTER_BROWSER__CGMSENSOR:
			setCgmsensor((CGMsensor) newValue);
			return;
		case Cgm3Package.COMPUTER_BROWSER__CLOUD:
			setCloud((Cloud) newValue);
			return;
		case Cgm3Package.COMPUTER_BROWSER__PATIENT_INFO_RETENTION_PERIOD:
			setPatient_info_Retention_Period((DataRetentionEnum) newValue);
			return;
		case Cgm3Package.COMPUTER_BROWSER__USERLOCATION:
			getUserlocation().clear();
			getUserlocation().addAll((Collection<? extends UserLocation>) newValue);
			return;
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE:
			setAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate(
					(Answer) newValue);
			return;
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD:
			setAre_you_planning_to_send_all_the_data_to_the_cloud((Answer) newValue);
			return;
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			setAre_you_processing_data_in_an_incompatible_way_with_the_purpose((Answer) newValue);
			return;
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes((Answer) newValue);
			return;
		case Cgm3Package.COMPUTER_BROWSER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
					(Answer) newValue);
			return;
		case Cgm3Package.COMPUTER_BROWSER__PHARMACYCLOUD:
			setPharmacycloud((PharmacyCloudold) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.COMPUTER_BROWSER__ENCRYPTED_DATA:
			setEncryptedData(ENCRYPTED_DATA_EDEFAULT);
			return;
		case Cgm3Package.COMPUTER_BROWSER__CGMSENSOR:
			setCgmsensor((CGMsensor) null);
			return;
		case Cgm3Package.COMPUTER_BROWSER__CLOUD:
			setCloud((Cloud) null);
			return;
		case Cgm3Package.COMPUTER_BROWSER__PATIENT_INFO_RETENTION_PERIOD:
			setPatient_info_Retention_Period(PATIENT_INFO_RETENTION_PERIOD_EDEFAULT);
			return;
		case Cgm3Package.COMPUTER_BROWSER__USERLOCATION:
			getUserlocation().clear();
			return;
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE:
			setAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate(
					ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE_EDEFAULT);
			return;
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD:
			setAre_you_planning_to_send_all_the_data_to_the_cloud(
					ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD_EDEFAULT);
			return;
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(
					ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT);
			return;
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
					ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT);
			return;
		case Cgm3Package.COMPUTER_BROWSER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
					IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT);
			return;
		case Cgm3Package.COMPUTER_BROWSER__PHARMACYCLOUD:
			setPharmacycloud((PharmacyCloudold) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.COMPUTER_BROWSER__ENCRYPTED_DATA:
			return encryptedData != ENCRYPTED_DATA_EDEFAULT;
		case Cgm3Package.COMPUTER_BROWSER__CGMSENSOR:
			return cgmsensor != null;
		case Cgm3Package.COMPUTER_BROWSER__CLOUD:
			return cloud != null;
		case Cgm3Package.COMPUTER_BROWSER__PATIENT_INFO_RETENTION_PERIOD:
			return patient_info_Retention_Period != PATIENT_INFO_RETENTION_PERIOD_EDEFAULT;
		case Cgm3Package.COMPUTER_BROWSER__USERLOCATION:
			return userlocation != null && !userlocation.isEmpty();
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE:
			return are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate != ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE_EDEFAULT;
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD:
			return are_you_planning_to_send_all_the_data_to_the_cloud != ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD_EDEFAULT;
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			return are_you_processing_data_in_an_incompatible_way_with_the_purpose != ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT;
		case Cgm3Package.COMPUTER_BROWSER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes != ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;
		case Cgm3Package.COMPUTER_BROWSER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			return is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures != IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT;
		case Cgm3Package.COMPUTER_BROWSER__PHARMACYCLOUD:
			return pharmacycloud != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.COMPUTER_BROWSER__ENCRYPTED_DATA:
				return Cgm3Package.ENCRYPTION__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (baseFeatureID) {
			case Cgm3Package.ENCRYPTION__ENCRYPTED_DATA:
				return Cgm3Package.COMPUTER_BROWSER__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (EncryptedData: ");
		result.append(encryptedData);
		result.append(", Patient_info_Retention_Period: ");
		result.append(patient_info_Retention_Period);
		result.append(
				", Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate: ");
		result.append(
				are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate);
		result.append(", Are_you_planning_to_send_all_the_data_to_the_cloud: ");
		result.append(are_you_planning_to_send_all_the_data_to_the_cloud);
		result.append(", Are_you_processing_data_in_an_incompatible_way_with_the_purpose: ");
		result.append(are_you_processing_data_in_an_incompatible_way_with_the_purpose);
		result.append(", Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes: ");
		result.append(are_you_storing_the_data_longer_than_is_necessary_for_the_purposes);
		result.append(
				", Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures: ");
		result.append(
				is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures);
		result.append(')');
		return result.toString();
	}

} //ComputerBrowserImpl
