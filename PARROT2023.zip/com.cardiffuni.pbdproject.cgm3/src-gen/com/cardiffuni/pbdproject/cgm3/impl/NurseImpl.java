/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Nurse;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Nurse</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class NurseImpl extends GeneralEntityImpl implements Nurse {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NurseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.NURSE;
	}

} //NurseImpl
