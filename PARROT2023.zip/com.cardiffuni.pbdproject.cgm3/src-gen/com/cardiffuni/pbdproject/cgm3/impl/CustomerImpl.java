/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Consent_CheckedList;
import com.cardiffuni.pbdproject.cgm3.Customer;

import com.cardiffuni.pbdproject.cgm3.VideoAnalytics;
import com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics;
import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Customer</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CustomerImpl#getGeneral_features <em>General features</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CustomerImpl#getConsent_checkedlist <em>Consent checkedlist</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CustomerImpl#getDo_people_aware_of_being_recorded <em>Do people aware of being recorded</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CustomerImpl#getVideoanalytics <em>Videoanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.CustomerImpl#getVideowithoutanalytics <em>Videowithoutanalytics</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CustomerImpl extends GeneralEntityImpl implements Customer {
	/**
	 * The default value of the '{@link #getGeneral_features() <em>General features</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGeneral_features()
	 * @generated
	 * @ordered
	 */
	protected static final String GENERAL_FEATURES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getGeneral_features() <em>General features</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGeneral_features()
	 * @generated
	 * @ordered
	 */
	protected String general_features = GENERAL_FEATURES_EDEFAULT;

	/**
	 * The cached value of the '{@link #getConsent_checkedlist() <em>Consent checkedlist</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConsent_checkedlist()
	 * @generated
	 * @ordered
	 */
	protected EList<Consent_CheckedList> consent_checkedlist;

	/**
	 * The default value of the '{@link #getDo_people_aware_of_being_recorded() <em>Do people aware of being recorded</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_people_aware_of_being_recorded()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDo_people_aware_of_being_recorded() <em>Do people aware of being recorded</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_people_aware_of_being_recorded()
	 * @generated
	 * @ordered
	 */
	protected Answer do_people_aware_of_being_recorded = DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT;

	/**
	 * The cached value of the '{@link #getVideoanalytics() <em>Videoanalytics</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVideoanalytics()
	 * @generated
	 * @ordered
	 */
	protected VideoAnalytics videoanalytics;

	/**
	 * The cached value of the '{@link #getVideowithoutanalytics() <em>Videowithoutanalytics</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVideowithoutanalytics()
	 * @generated
	 * @ordered
	 */
	protected VideoWithoutAnalytics videowithoutanalytics;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CustomerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.CUSTOMER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getGeneral_features() {
		return general_features;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGeneral_features(String newGeneral_features) {
		String oldGeneral_features = general_features;
		general_features = newGeneral_features;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CUSTOMER__GENERAL_FEATURES,
					oldGeneral_features, general_features));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Consent_CheckedList> getConsent_checkedlist() {
		if (consent_checkedlist == null) {
			consent_checkedlist = new EObjectContainmentEList<Consent_CheckedList>(Consent_CheckedList.class, this,
					Cgm3Package.CUSTOMER__CONSENT_CHECKEDLIST);
		}
		return consent_checkedlist;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDo_people_aware_of_being_recorded() {
		return do_people_aware_of_being_recorded;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDo_people_aware_of_being_recorded(Answer newDo_people_aware_of_being_recorded) {
		Answer oldDo_people_aware_of_being_recorded = do_people_aware_of_being_recorded;
		do_people_aware_of_being_recorded = newDo_people_aware_of_being_recorded == null
				? DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT
				: newDo_people_aware_of_being_recorded;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CUSTOMER__DO_PEOPLE_AWARE_OF_BEING_RECORDED, oldDo_people_aware_of_being_recorded,
					do_people_aware_of_being_recorded));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoAnalytics getVideoanalytics() {
		if (videoanalytics != null && videoanalytics.eIsProxy()) {
			InternalEObject oldVideoanalytics = (InternalEObject) videoanalytics;
			videoanalytics = (VideoAnalytics) eResolveProxy(oldVideoanalytics);
			if (videoanalytics != oldVideoanalytics) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.CUSTOMER__VIDEOANALYTICS,
							oldVideoanalytics, videoanalytics));
			}
		}
		return videoanalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoAnalytics basicGetVideoanalytics() {
		return videoanalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetVideoanalytics(VideoAnalytics newVideoanalytics, NotificationChain msgs) {
		VideoAnalytics oldVideoanalytics = videoanalytics;
		videoanalytics = newVideoanalytics;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CUSTOMER__VIDEOANALYTICS, oldVideoanalytics, newVideoanalytics);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVideoanalytics(VideoAnalytics newVideoanalytics) {
		if (newVideoanalytics != videoanalytics) {
			NotificationChain msgs = null;
			if (videoanalytics != null)
				msgs = ((InternalEObject) videoanalytics).eInverseRemove(this, Cgm3Package.VIDEO_ANALYTICS__CUSTOMER,
						VideoAnalytics.class, msgs);
			if (newVideoanalytics != null)
				msgs = ((InternalEObject) newVideoanalytics).eInverseAdd(this, Cgm3Package.VIDEO_ANALYTICS__CUSTOMER,
						VideoAnalytics.class, msgs);
			msgs = basicSetVideoanalytics(newVideoanalytics, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CUSTOMER__VIDEOANALYTICS,
					newVideoanalytics, newVideoanalytics));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoWithoutAnalytics getVideowithoutanalytics() {
		if (videowithoutanalytics != null && videowithoutanalytics.eIsProxy()) {
			InternalEObject oldVideowithoutanalytics = (InternalEObject) videowithoutanalytics;
			videowithoutanalytics = (VideoWithoutAnalytics) eResolveProxy(oldVideowithoutanalytics);
			if (videowithoutanalytics != oldVideowithoutanalytics) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Cgm3Package.CUSTOMER__VIDEOWITHOUTANALYTICS, oldVideowithoutanalytics,
							videowithoutanalytics));
			}
		}
		return videowithoutanalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoWithoutAnalytics basicGetVideowithoutanalytics() {
		return videowithoutanalytics;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetVideowithoutanalytics(VideoWithoutAnalytics newVideowithoutanalytics,
			NotificationChain msgs) {
		VideoWithoutAnalytics oldVideowithoutanalytics = videowithoutanalytics;
		videowithoutanalytics = newVideowithoutanalytics;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.CUSTOMER__VIDEOWITHOUTANALYTICS, oldVideowithoutanalytics, newVideowithoutanalytics);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVideowithoutanalytics(VideoWithoutAnalytics newVideowithoutanalytics) {
		if (newVideowithoutanalytics != videowithoutanalytics) {
			NotificationChain msgs = null;
			if (videowithoutanalytics != null)
				msgs = ((InternalEObject) videowithoutanalytics).eInverseRemove(this,
						Cgm3Package.VIDEO_WITHOUT_ANALYTICS__CUSTOMER, VideoWithoutAnalytics.class, msgs);
			if (newVideowithoutanalytics != null)
				msgs = ((InternalEObject) newVideowithoutanalytics).eInverseAdd(this,
						Cgm3Package.VIDEO_WITHOUT_ANALYTICS__CUSTOMER, VideoWithoutAnalytics.class, msgs);
			msgs = basicSetVideowithoutanalytics(newVideowithoutanalytics, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.CUSTOMER__VIDEOWITHOUTANALYTICS,
					newVideowithoutanalytics, newVideowithoutanalytics));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.CUSTOMER__VIDEOANALYTICS:
			if (videoanalytics != null)
				msgs = ((InternalEObject) videoanalytics).eInverseRemove(this, Cgm3Package.VIDEO_ANALYTICS__CUSTOMER,
						VideoAnalytics.class, msgs);
			return basicSetVideoanalytics((VideoAnalytics) otherEnd, msgs);
		case Cgm3Package.CUSTOMER__VIDEOWITHOUTANALYTICS:
			if (videowithoutanalytics != null)
				msgs = ((InternalEObject) videowithoutanalytics).eInverseRemove(this,
						Cgm3Package.VIDEO_WITHOUT_ANALYTICS__CUSTOMER, VideoWithoutAnalytics.class, msgs);
			return basicSetVideowithoutanalytics((VideoWithoutAnalytics) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.CUSTOMER__CONSENT_CHECKEDLIST:
			return ((InternalEList<?>) getConsent_checkedlist()).basicRemove(otherEnd, msgs);
		case Cgm3Package.CUSTOMER__VIDEOANALYTICS:
			return basicSetVideoanalytics(null, msgs);
		case Cgm3Package.CUSTOMER__VIDEOWITHOUTANALYTICS:
			return basicSetVideowithoutanalytics(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.CUSTOMER__GENERAL_FEATURES:
			return getGeneral_features();
		case Cgm3Package.CUSTOMER__CONSENT_CHECKEDLIST:
			return getConsent_checkedlist();
		case Cgm3Package.CUSTOMER__DO_PEOPLE_AWARE_OF_BEING_RECORDED:
			return getDo_people_aware_of_being_recorded();
		case Cgm3Package.CUSTOMER__VIDEOANALYTICS:
			if (resolve)
				return getVideoanalytics();
			return basicGetVideoanalytics();
		case Cgm3Package.CUSTOMER__VIDEOWITHOUTANALYTICS:
			if (resolve)
				return getVideowithoutanalytics();
			return basicGetVideowithoutanalytics();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.CUSTOMER__GENERAL_FEATURES:
			setGeneral_features((String) newValue);
			return;
		case Cgm3Package.CUSTOMER__CONSENT_CHECKEDLIST:
			getConsent_checkedlist().clear();
			getConsent_checkedlist().addAll((Collection<? extends Consent_CheckedList>) newValue);
			return;
		case Cgm3Package.CUSTOMER__DO_PEOPLE_AWARE_OF_BEING_RECORDED:
			setDo_people_aware_of_being_recorded((Answer) newValue);
			return;
		case Cgm3Package.CUSTOMER__VIDEOANALYTICS:
			setVideoanalytics((VideoAnalytics) newValue);
			return;
		case Cgm3Package.CUSTOMER__VIDEOWITHOUTANALYTICS:
			setVideowithoutanalytics((VideoWithoutAnalytics) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.CUSTOMER__GENERAL_FEATURES:
			setGeneral_features(GENERAL_FEATURES_EDEFAULT);
			return;
		case Cgm3Package.CUSTOMER__CONSENT_CHECKEDLIST:
			getConsent_checkedlist().clear();
			return;
		case Cgm3Package.CUSTOMER__DO_PEOPLE_AWARE_OF_BEING_RECORDED:
			setDo_people_aware_of_being_recorded(DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT);
			return;
		case Cgm3Package.CUSTOMER__VIDEOANALYTICS:
			setVideoanalytics((VideoAnalytics) null);
			return;
		case Cgm3Package.CUSTOMER__VIDEOWITHOUTANALYTICS:
			setVideowithoutanalytics((VideoWithoutAnalytics) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.CUSTOMER__GENERAL_FEATURES:
			return GENERAL_FEATURES_EDEFAULT == null ? general_features != null
					: !GENERAL_FEATURES_EDEFAULT.equals(general_features);
		case Cgm3Package.CUSTOMER__CONSENT_CHECKEDLIST:
			return consent_checkedlist != null && !consent_checkedlist.isEmpty();
		case Cgm3Package.CUSTOMER__DO_PEOPLE_AWARE_OF_BEING_RECORDED:
			return do_people_aware_of_being_recorded != DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT;
		case Cgm3Package.CUSTOMER__VIDEOANALYTICS:
			return videoanalytics != null;
		case Cgm3Package.CUSTOMER__VIDEOWITHOUTANALYTICS:
			return videowithoutanalytics != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (General_features: ");
		result.append(general_features);
		result.append(", Do_people_aware_of_being_recorded: ");
		result.append(do_people_aware_of_being_recorded);
		result.append(')');
		return result.toString();
	}

} //CustomerImpl
