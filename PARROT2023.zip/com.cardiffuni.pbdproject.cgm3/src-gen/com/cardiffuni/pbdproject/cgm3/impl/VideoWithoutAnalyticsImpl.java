/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.Customer;
import com.cardiffuni.pbdproject.cgm3.DataRetentionEnum;
import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud;
import com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Video Without Analytics</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getEncryptedData <em>Encrypted Data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getSerial_number <em>Serial number</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getRecord_retention_period <em>Record retention period</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getDo_people_aware_of_being_recorded <em>Do people aware of being recorded</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getEnsure_data_minimisation_is_aplied <em>Ensure data minimisation is aplied</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles <em>Does consent have been gathered from the staff who used these vehicles</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV <em>Does the sign has abrief explanation about the purpose of CCTV</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getDoes_the_system_record_information_other_than_the_purpose <em>Does the system record information other than the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getDo_you_use_signs_that_say_CCTV_is_in_operation <em>Do you use signs that say CCTV is in operation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getDoes_The_dynamic_masking_feature_is_enabled <em>Does The dynamic masking feature is enabled</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getAre_you_sending_data_without_anonymisation <em>Are you sending data without anonymisation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getAre_you_allowing_data_unauthorised_access <em>Are you allowing data unauthorised access</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getAre_you_storing_the_footage_in_a_secure_location <em>Are you storing the footage in asecure location</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getCustomer <em>Customer</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl#getVideoprocessingcloud <em>Videoprocessingcloud</em>}</li>
 * </ul>
 *
 * @generated
 */
public class VideoWithoutAnalyticsImpl extends GeneralEntityImpl implements VideoWithoutAnalytics {
	/**
	 * The default value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENCRYPTED_DATA_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected Checked encryptedData = ENCRYPTED_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #getSerial_number() <em>Serial number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSerial_number()
	 * @generated
	 * @ordered
	 */
	protected static final String SERIAL_NUMBER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSerial_number() <em>Serial number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSerial_number()
	 * @generated
	 * @ordered
	 */
	protected String serial_number = SERIAL_NUMBER_EDEFAULT;

	/**
	 * The default value of the '{@link #getRecord_retention_period() <em>Record retention period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecord_retention_period()
	 * @generated
	 * @ordered
	 */
	protected static final DataRetentionEnum RECORD_RETENTION_PERIOD_EDEFAULT = DataRetentionEnum.NOT_ACCEPTED;

	/**
	 * The cached value of the '{@link #getRecord_retention_period() <em>Record retention period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRecord_retention_period()
	 * @generated
	 * @ordered
	 */
	protected DataRetentionEnum record_retention_period = RECORD_RETENTION_PERIOD_EDEFAULT;

	/**
	 * The default value of the '{@link #getDo_people_aware_of_being_recorded() <em>Do people aware of being recorded</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_people_aware_of_being_recorded()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDo_people_aware_of_being_recorded() <em>Do people aware of being recorded</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_people_aware_of_being_recorded()
	 * @generated
	 * @ordered
	 */
	protected Answer do_people_aware_of_being_recorded = DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT;

	/**
	 * The default value of the '{@link #getEnsure_data_minimisation_is_aplied() <em>Ensure data minimisation is aplied</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnsure_data_minimisation_is_aplied()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ENSURE_DATA_MINIMISATION_IS_APLIED_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getEnsure_data_minimisation_is_aplied() <em>Ensure data minimisation is aplied</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnsure_data_minimisation_is_aplied()
	 * @generated
	 * @ordered
	 */
	protected Answer ensure_data_minimisation_is_aplied = ENSURE_DATA_MINIMISATION_IS_APLIED_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles() <em>Does consent have been gathered from the staff who used these vehicles</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles() <em>Does consent have been gathered from the staff who used these vehicles</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles()
	 * @generated
	 * @ordered
	 */
	protected Answer does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles = DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV() <em>Does the sign has abrief explanation about the purpose of CCTV</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV() <em>Does the sign has abrief explanation about the purpose of CCTV</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV()
	 * @generated
	 * @ordered
	 */
	protected Answer does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV = DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_the_system_record_information_other_than_the_purpose() <em>Does the system record information other than the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_system_record_information_other_than_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_the_system_record_information_other_than_the_purpose() <em>Does the system record information other than the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_the_system_record_information_other_than_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected Answer does_the_system_record_information_other_than_the_purpose = DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() <em>Are you using appropriate technical or organisational measures to protect the data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() <em>Are you using appropriate technical or organisational measures to protect the data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring() <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring() <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring = ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT;

	/**
	 * The default value of the '{@link #getDo_you_use_signs_that_say_CCTV_is_in_operation() <em>Do you use signs that say CCTV is in operation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_you_use_signs_that_say_CCTV_is_in_operation()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDo_you_use_signs_that_say_CCTV_is_in_operation() <em>Do you use signs that say CCTV is in operation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDo_you_use_signs_that_say_CCTV_is_in_operation()
	 * @generated
	 * @ordered
	 */
	protected Answer do_you_use_signs_that_say_CCTV_is_in_operation = DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getIs_data_against_accidental_loss_or_destruction_or_damage() <em>Is data against accidental loss or destruction or damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @generated
	 * @ordered
	 */
	protected static final Answer IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getIs_data_against_accidental_loss_or_destruction_or_damage() <em>Is data against accidental loss or destruction or damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @generated
	 * @ordered
	 */
	protected Answer is_data_against_accidental_loss_or_destruction_or_damage = IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDoes_The_dynamic_masking_feature_is_enabled() <em>Does The dynamic masking feature is enabled</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_The_dynamic_masking_feature_is_enabled()
	 * @generated
	 * @ordered
	 */
	protected static final Answer DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getDoes_The_dynamic_masking_feature_is_enabled() <em>Does The dynamic masking feature is enabled</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDoes_The_dynamic_masking_feature_is_enabled()
	 * @generated
	 * @ordered
	 */
	protected Answer does_The_dynamic_masking_feature_is_enabled = DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_sending_data_without_anonymisation() <em>Are you sending data without anonymisation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_sending_data_without_anonymisation()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_sending_data_without_anonymisation() <em>Are you sending data without anonymisation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_sending_data_without_anonymisation()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_sending_data_without_anonymisation = ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_allowing_data_unauthorised_access() <em>Are you allowing data unauthorised access</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_allowing_data_unauthorised_access()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_allowing_data_unauthorised_access() <em>Are you allowing data unauthorised access</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_allowing_data_unauthorised_access()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_allowing_data_unauthorised_access = ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_storing_the_footage_in_a_secure_location() <em>Are you storing the footage in asecure location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_footage_in_a_secure_location()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_storing_the_footage_in_a_secure_location() <em>Are you storing the footage in asecure location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_footage_in_a_secure_location()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_storing_the_footage_in_a_secure_location = ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCustomer() <em>Customer</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustomer()
	 * @generated
	 * @ordered
	 */
	protected Customer customer;

	/**
	 * The cached value of the '{@link #getVideoprocessingcloud() <em>Videoprocessingcloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVideoprocessingcloud()
	 * @generated
	 * @ordered
	 */
	protected VideoProcessingCloud videoprocessingcloud;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VideoWithoutAnalyticsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.VIDEO_WITHOUT_ANALYTICS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEncryptedData() {
		return encryptedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncryptedData(Checked newEncryptedData) {
		Checked oldEncryptedData = encryptedData;
		encryptedData = newEncryptedData == null ? ENCRYPTED_DATA_EDEFAULT : newEncryptedData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ENCRYPTED_DATA,
					oldEncryptedData, encryptedData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSerial_number() {
		return serial_number;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSerial_number(String newSerial_number) {
		String oldSerial_number = serial_number;
		serial_number = newSerial_number;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.VIDEO_WITHOUT_ANALYTICS__SERIAL_NUMBER,
					oldSerial_number, serial_number));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDo_people_aware_of_being_recorded() {
		return do_people_aware_of_being_recorded;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDo_people_aware_of_being_recorded(Answer newDo_people_aware_of_being_recorded) {
		Answer oldDo_people_aware_of_being_recorded = do_people_aware_of_being_recorded;
		do_people_aware_of_being_recorded = newDo_people_aware_of_being_recorded == null
				? DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT
				: newDo_people_aware_of_being_recorded;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DO_PEOPLE_AWARE_OF_BEING_RECORDED,
					oldDo_people_aware_of_being_recorded, do_people_aware_of_being_recorded));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataRetentionEnum getRecord_retention_period() {
		return record_retention_period;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRecord_retention_period(DataRetentionEnum newRecord_retention_period) {
		DataRetentionEnum oldRecord_retention_period = record_retention_period;
		record_retention_period = newRecord_retention_period == null ? RECORD_RETENTION_PERIOD_EDEFAULT
				: newRecord_retention_period;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__RECORD_RETENTION_PERIOD, oldRecord_retention_period,
					record_retention_period));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getEnsure_data_minimisation_is_aplied() {
		return ensure_data_minimisation_is_aplied;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEnsure_data_minimisation_is_aplied(Answer newEnsure_data_minimisation_is_aplied) {
		Answer oldEnsure_data_minimisation_is_aplied = ensure_data_minimisation_is_aplied;
		ensure_data_minimisation_is_aplied = newEnsure_data_minimisation_is_aplied == null
				? ENSURE_DATA_MINIMISATION_IS_APLIED_EDEFAULT
				: newEnsure_data_minimisation_is_aplied;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ENSURE_DATA_MINIMISATION_IS_APLIED,
					oldEnsure_data_minimisation_is_aplied, ensure_data_minimisation_is_aplied));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
			Answer newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes) {
		Answer oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes = are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes == null
				? ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT
				: newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
					oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes,
					are_you_storing_the_data_longer_than_is_necessary_for_the_purposes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles() {
		return does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles(
			Answer newDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles) {
		Answer oldDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles = does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles;
		does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles = newDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles == null
				? DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT
				: newDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES,
					oldDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles,
					does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV() {
		return does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV(
			Answer newDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV) {
		Answer oldDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV = does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV;
		does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV = newDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV == null
				? DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT
				: newDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV,
					oldDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV,
					does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_the_system_record_information_other_than_the_purpose() {
		return does_the_system_record_information_other_than_the_purpose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_the_system_record_information_other_than_the_purpose(
			Answer newDoes_the_system_record_information_other_than_the_purpose) {
		Answer oldDoes_the_system_record_information_other_than_the_purpose = does_the_system_record_information_other_than_the_purpose;
		does_the_system_record_information_other_than_the_purpose = newDoes_the_system_record_information_other_than_the_purpose == null
				? DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT
				: newDoes_the_system_record_information_other_than_the_purpose;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE,
					oldDoes_the_system_record_information_other_than_the_purpose,
					does_the_system_record_information_other_than_the_purpose));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() {
		return are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(
			Answer newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data) {
		Answer oldAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
		are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data = newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data == null
				? ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT
				: newAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA,
					oldAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data,
					are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring() {
		return are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring(
			Answer newAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring) {
		Answer oldAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring = are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring;
		are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring = newAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring == null
				? ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT
				: newAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING,
					oldAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring,
					are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDo_you_use_signs_that_say_CCTV_is_in_operation() {
		return do_you_use_signs_that_say_CCTV_is_in_operation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDo_you_use_signs_that_say_CCTV_is_in_operation(
			Answer newDo_you_use_signs_that_say_CCTV_is_in_operation) {
		Answer oldDo_you_use_signs_that_say_CCTV_is_in_operation = do_you_use_signs_that_say_CCTV_is_in_operation;
		do_you_use_signs_that_say_CCTV_is_in_operation = newDo_you_use_signs_that_say_CCTV_is_in_operation == null
				? DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT
				: newDo_you_use_signs_that_say_CCTV_is_in_operation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION,
					oldDo_you_use_signs_that_say_CCTV_is_in_operation, do_you_use_signs_that_say_CCTV_is_in_operation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getIs_data_against_accidental_loss_or_destruction_or_damage() {
		return is_data_against_accidental_loss_or_destruction_or_damage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIs_data_against_accidental_loss_or_destruction_or_damage(
			Answer newIs_data_against_accidental_loss_or_destruction_or_damage) {
		Answer oldIs_data_against_accidental_loss_or_destruction_or_damage = is_data_against_accidental_loss_or_destruction_or_damage;
		is_data_against_accidental_loss_or_destruction_or_damage = newIs_data_against_accidental_loss_or_destruction_or_damage == null
				? IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT
				: newIs_data_against_accidental_loss_or_destruction_or_damage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE,
					oldIs_data_against_accidental_loss_or_destruction_or_damage,
					is_data_against_accidental_loss_or_destruction_or_damage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getDoes_The_dynamic_masking_feature_is_enabled() {
		return does_The_dynamic_masking_feature_is_enabled;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDoes_The_dynamic_masking_feature_is_enabled(Answer newDoes_The_dynamic_masking_feature_is_enabled) {
		Answer oldDoes_The_dynamic_masking_feature_is_enabled = does_The_dynamic_masking_feature_is_enabled;
		does_The_dynamic_masking_feature_is_enabled = newDoes_The_dynamic_masking_feature_is_enabled == null
				? DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED_EDEFAULT
				: newDoes_The_dynamic_masking_feature_is_enabled;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED,
					oldDoes_The_dynamic_masking_feature_is_enabled, does_The_dynamic_masking_feature_is_enabled));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_sending_data_without_anonymisation() {
		return are_you_sending_data_without_anonymisation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_sending_data_without_anonymisation(Answer newAre_you_sending_data_without_anonymisation) {
		Answer oldAre_you_sending_data_without_anonymisation = are_you_sending_data_without_anonymisation;
		are_you_sending_data_without_anonymisation = newAre_you_sending_data_without_anonymisation == null
				? ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION_EDEFAULT
				: newAre_you_sending_data_without_anonymisation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION,
					oldAre_you_sending_data_without_anonymisation, are_you_sending_data_without_anonymisation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_allowing_data_unauthorised_access() {
		return are_you_allowing_data_unauthorised_access;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_allowing_data_unauthorised_access(Answer newAre_you_allowing_data_unauthorised_access) {
		Answer oldAre_you_allowing_data_unauthorised_access = are_you_allowing_data_unauthorised_access;
		are_you_allowing_data_unauthorised_access = newAre_you_allowing_data_unauthorised_access == null
				? ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS_EDEFAULT
				: newAre_you_allowing_data_unauthorised_access;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS,
					oldAre_you_allowing_data_unauthorised_access, are_you_allowing_data_unauthorised_access));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_storing_the_footage_in_a_secure_location() {
		return are_you_storing_the_footage_in_a_secure_location;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_storing_the_footage_in_a_secure_location(
			Answer newAre_you_storing_the_footage_in_a_secure_location) {
		Answer oldAre_you_storing_the_footage_in_a_secure_location = are_you_storing_the_footage_in_a_secure_location;
		are_you_storing_the_footage_in_a_secure_location = newAre_you_storing_the_footage_in_a_secure_location == null
				? ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION_EDEFAULT
				: newAre_you_storing_the_footage_in_a_secure_location;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION,
					oldAre_you_storing_the_footage_in_a_secure_location,
					are_you_storing_the_footage_in_a_secure_location));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Customer getCustomer() {
		if (customer != null && customer.eIsProxy()) {
			InternalEObject oldCustomer = (InternalEObject) customer;
			customer = (Customer) eResolveProxy(oldCustomer);
			if (customer != oldCustomer) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Cgm3Package.VIDEO_WITHOUT_ANALYTICS__CUSTOMER, oldCustomer, customer));
			}
		}
		return customer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Customer basicGetCustomer() {
		return customer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCustomer(Customer newCustomer, NotificationChain msgs) {
		Customer oldCustomer = customer;
		customer = newCustomer;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__CUSTOMER, oldCustomer, newCustomer);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCustomer(Customer newCustomer) {
		if (newCustomer != customer) {
			NotificationChain msgs = null;
			if (customer != null)
				msgs = ((InternalEObject) customer).eInverseRemove(this, Cgm3Package.CUSTOMER__VIDEOWITHOUTANALYTICS,
						Customer.class, msgs);
			if (newCustomer != null)
				msgs = ((InternalEObject) newCustomer).eInverseAdd(this, Cgm3Package.CUSTOMER__VIDEOWITHOUTANALYTICS,
						Customer.class, msgs);
			msgs = basicSetCustomer(newCustomer, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.VIDEO_WITHOUT_ANALYTICS__CUSTOMER,
					newCustomer, newCustomer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoProcessingCloud getVideoprocessingcloud() {
		if (videoprocessingcloud != null && videoprocessingcloud.eIsProxy()) {
			InternalEObject oldVideoprocessingcloud = (InternalEObject) videoprocessingcloud;
			videoprocessingcloud = (VideoProcessingCloud) eResolveProxy(oldVideoprocessingcloud);
			if (videoprocessingcloud != oldVideoprocessingcloud) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							Cgm3Package.VIDEO_WITHOUT_ANALYTICS__VIDEOPROCESSINGCLOUD, oldVideoprocessingcloud,
							videoprocessingcloud));
			}
		}
		return videoprocessingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VideoProcessingCloud basicGetVideoprocessingcloud() {
		return videoprocessingcloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetVideoprocessingcloud(VideoProcessingCloud newVideoprocessingcloud,
			NotificationChain msgs) {
		VideoProcessingCloud oldVideoprocessingcloud = videoprocessingcloud;
		videoprocessingcloud = newVideoprocessingcloud;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__VIDEOPROCESSINGCLOUD, oldVideoprocessingcloud,
					newVideoprocessingcloud);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVideoprocessingcloud(VideoProcessingCloud newVideoprocessingcloud) {
		if (newVideoprocessingcloud != videoprocessingcloud) {
			NotificationChain msgs = null;
			if (videoprocessingcloud != null)
				msgs = ((InternalEObject) videoprocessingcloud).eInverseRemove(this,
						Cgm3Package.VIDEO_PROCESSING_CLOUD__VIDEOWITHOUTANALYTICS, VideoProcessingCloud.class, msgs);
			if (newVideoprocessingcloud != null)
				msgs = ((InternalEObject) newVideoprocessingcloud).eInverseAdd(this,
						Cgm3Package.VIDEO_PROCESSING_CLOUD__VIDEOWITHOUTANALYTICS, VideoProcessingCloud.class, msgs);
			msgs = basicSetVideoprocessingcloud(newVideoprocessingcloud, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.VIDEO_WITHOUT_ANALYTICS__VIDEOPROCESSINGCLOUD, newVideoprocessingcloud,
					newVideoprocessingcloud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__CUSTOMER:
			if (customer != null)
				msgs = ((InternalEObject) customer).eInverseRemove(this, Cgm3Package.CUSTOMER__VIDEOWITHOUTANALYTICS,
						Customer.class, msgs);
			return basicSetCustomer((Customer) otherEnd, msgs);
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__VIDEOPROCESSINGCLOUD:
			if (videoprocessingcloud != null)
				msgs = ((InternalEObject) videoprocessingcloud).eInverseRemove(this,
						Cgm3Package.VIDEO_PROCESSING_CLOUD__VIDEOWITHOUTANALYTICS, VideoProcessingCloud.class, msgs);
			return basicSetVideoprocessingcloud((VideoProcessingCloud) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__CUSTOMER:
			return basicSetCustomer(null, msgs);
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__VIDEOPROCESSINGCLOUD:
			return basicSetVideoprocessingcloud(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ENCRYPTED_DATA:
			return getEncryptedData();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__SERIAL_NUMBER:
			return getSerial_number();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__RECORD_RETENTION_PERIOD:
			return getRecord_retention_period();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DO_PEOPLE_AWARE_OF_BEING_RECORDED:
			return getDo_people_aware_of_being_recorded();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ENSURE_DATA_MINIMISATION_IS_APLIED:
			return getEnsure_data_minimisation_is_aplied();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES:
			return getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV:
			return getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			return getDoes_the_system_record_information_other_than_the_purpose();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			return getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING:
			return getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION:
			return getDo_you_use_signs_that_say_CCTV_is_in_operation();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			return getIs_data_against_accidental_loss_or_destruction_or_damage();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED:
			return getDoes_The_dynamic_masking_feature_is_enabled();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION:
			return getAre_you_sending_data_without_anonymisation();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS:
			return getAre_you_allowing_data_unauthorised_access();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION:
			return getAre_you_storing_the_footage_in_a_secure_location();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__CUSTOMER:
			if (resolve)
				return getCustomer();
			return basicGetCustomer();
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__VIDEOPROCESSINGCLOUD:
			if (resolve)
				return getVideoprocessingcloud();
			return basicGetVideoprocessingcloud();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ENCRYPTED_DATA:
			setEncryptedData((Checked) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__SERIAL_NUMBER:
			setSerial_number((String) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__RECORD_RETENTION_PERIOD:
			setRecord_retention_period((DataRetentionEnum) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DO_PEOPLE_AWARE_OF_BEING_RECORDED:
			setDo_people_aware_of_being_recorded((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ENSURE_DATA_MINIMISATION_IS_APLIED:
			setEnsure_data_minimisation_is_aplied((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES:
			setDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV:
			setDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			setDoes_the_system_record_information_other_than_the_purpose((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING:
			setAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION:
			setDo_you_use_signs_that_say_CCTV_is_in_operation((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			setIs_data_against_accidental_loss_or_destruction_or_damage((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED:
			setDoes_The_dynamic_masking_feature_is_enabled((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION:
			setAre_you_sending_data_without_anonymisation((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS:
			setAre_you_allowing_data_unauthorised_access((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION:
			setAre_you_storing_the_footage_in_a_secure_location((Answer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__CUSTOMER:
			setCustomer((Customer) newValue);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__VIDEOPROCESSINGCLOUD:
			setVideoprocessingcloud((VideoProcessingCloud) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ENCRYPTED_DATA:
			setEncryptedData(ENCRYPTED_DATA_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__SERIAL_NUMBER:
			setSerial_number(SERIAL_NUMBER_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__RECORD_RETENTION_PERIOD:
			setRecord_retention_period(RECORD_RETENTION_PERIOD_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DO_PEOPLE_AWARE_OF_BEING_RECORDED:
			setDo_people_aware_of_being_recorded(DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ENSURE_DATA_MINIMISATION_IS_APLIED:
			setEnsure_data_minimisation_is_aplied(ENSURE_DATA_MINIMISATION_IS_APLIED_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
					ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES:
			setDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles(
					DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV:
			setDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV(
					DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			setDoes_the_system_record_information_other_than_the_purpose(
					DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(
					ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING:
			setAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring(
					ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION:
			setDo_you_use_signs_that_say_CCTV_is_in_operation(DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			setIs_data_against_accidental_loss_or_destruction_or_damage(
					IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED:
			setDoes_The_dynamic_masking_feature_is_enabled(DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION:
			setAre_you_sending_data_without_anonymisation(ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS:
			setAre_you_allowing_data_unauthorised_access(ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION:
			setAre_you_storing_the_footage_in_a_secure_location(
					ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION_EDEFAULT);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__CUSTOMER:
			setCustomer((Customer) null);
			return;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__VIDEOPROCESSINGCLOUD:
			setVideoprocessingcloud((VideoProcessingCloud) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ENCRYPTED_DATA:
			return encryptedData != ENCRYPTED_DATA_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__SERIAL_NUMBER:
			return SERIAL_NUMBER_EDEFAULT == null ? serial_number != null
					: !SERIAL_NUMBER_EDEFAULT.equals(serial_number);
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__RECORD_RETENTION_PERIOD:
			return record_retention_period != RECORD_RETENTION_PERIOD_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DO_PEOPLE_AWARE_OF_BEING_RECORDED:
			return do_people_aware_of_being_recorded != DO_PEOPLE_AWARE_OF_BEING_RECORDED_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ENSURE_DATA_MINIMISATION_IS_APLIED:
			return ensure_data_minimisation_is_aplied != ENSURE_DATA_MINIMISATION_IS_APLIED_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes != ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES:
			return does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles != DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV:
			return does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV != DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			return does_the_system_record_information_other_than_the_purpose != DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
			return are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data != ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING:
			return are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring != ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION:
			return do_you_use_signs_that_say_CCTV_is_in_operation != DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			return is_data_against_accidental_loss_or_destruction_or_damage != IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED:
			return does_The_dynamic_masking_feature_is_enabled != DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION:
			return are_you_sending_data_without_anonymisation != ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS:
			return are_you_allowing_data_unauthorised_access != ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION:
			return are_you_storing_the_footage_in_a_secure_location != ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION_EDEFAULT;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__CUSTOMER:
			return customer != null;
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__VIDEOPROCESSINGCLOUD:
			return videoprocessingcloud != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ENCRYPTED_DATA:
				return Cgm3Package.ENCRYPTION__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (baseFeatureID) {
			case Cgm3Package.ENCRYPTION__ENCRYPTED_DATA:
				return Cgm3Package.VIDEO_WITHOUT_ANALYTICS__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (EncryptedData: ");
		result.append(encryptedData);
		result.append(", Serial_number: ");
		result.append(serial_number);
		result.append(", Record_retention_period: ");
		result.append(record_retention_period);
		result.append(", Do_people_aware_of_being_recorded: ");
		result.append(do_people_aware_of_being_recorded);
		result.append(", Ensure_data_minimisation_is_aplied: ");
		result.append(ensure_data_minimisation_is_aplied);
		result.append(", Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes: ");
		result.append(are_you_storing_the_data_longer_than_is_necessary_for_the_purposes);
		result.append(", Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles: ");
		result.append(does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles);
		result.append(", Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV: ");
		result.append(does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV);
		result.append(", Does_the_system_record_information_other_than_the_purpose: ");
		result.append(does_the_system_record_information_other_than_the_purpose);
		result.append(", Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data: ");
		result.append(are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data);
		result.append(", Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring: ");
		result.append(are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring);
		result.append(", Do_you_use_signs_that_say_CCTV_is_in_operation: ");
		result.append(do_you_use_signs_that_say_CCTV_is_in_operation);
		result.append(", Is_data_against_accidental_loss_or_destruction_or_damage: ");
		result.append(is_data_against_accidental_loss_or_destruction_or_damage);
		result.append(", Does_The_dynamic_masking_feature_is_enabled: ");
		result.append(does_The_dynamic_masking_feature_is_enabled);
		result.append(", Are_you_sending_data_without_anonymisation: ");
		result.append(are_you_sending_data_without_anonymisation);
		result.append(", Are_you_allowing_data_unauthorised_access: ");
		result.append(are_you_allowing_data_unauthorised_access);
		result.append(", Are_you_storing_the_footage_in_a_secure_location: ");
		result.append(are_you_storing_the_footage_in_a_secure_location);
		result.append(')');
		return result.toString();
	}

} //VideoWithoutAnalyticsImpl
