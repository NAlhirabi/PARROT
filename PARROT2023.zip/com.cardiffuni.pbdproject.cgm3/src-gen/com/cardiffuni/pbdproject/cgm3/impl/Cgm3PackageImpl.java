/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Aggregation;
import com.cardiffuni.pbdproject.cgm3.Analytics;
import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Authentication;
import com.cardiffuni.pbdproject.cgm3.Authorization;
import com.cardiffuni.pbdproject.cgm3.Blurring;
import com.cardiffuni.pbdproject.cgm3.Bus;
import com.cardiffuni.pbdproject.cgm3.CGMsensor;
import com.cardiffuni.pbdproject.cgm3.Camera;
import com.cardiffuni.pbdproject.cgm3.Cgm3Factory;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.Checked_Consent;
import com.cardiffuni.pbdproject.cgm3.Client;
import com.cardiffuni.pbdproject.cgm3.Cloud;
import com.cardiffuni.pbdproject.cgm3.CloudForPharmacy;
import com.cardiffuni.pbdproject.cgm3.CloudProviderServer;
import com.cardiffuni.pbdproject.cgm3.CloudService;
import com.cardiffuni.pbdproject.cgm3.CloudStorageLocation;
import com.cardiffuni.pbdproject.cgm3.CommunicationProtocols;
import com.cardiffuni.pbdproject.cgm3.ComputerBrowser;
import com.cardiffuni.pbdproject.cgm3.Consent_CheckedList;
import com.cardiffuni.pbdproject.cgm3.Containerisation;
import com.cardiffuni.pbdproject.cgm3.Cookies;
import com.cardiffuni.pbdproject.cgm3.Customer;
import com.cardiffuni.pbdproject.cgm3.DataRetentionEnum;
import com.cardiffuni.pbdproject.cgm3.DataSharing;
import com.cardiffuni.pbdproject.cgm3.Doctor;
import com.cardiffuni.pbdproject.cgm3.DoorLock;
import com.cardiffuni.pbdproject.cgm3.Driver;
import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.Firewall;
import com.cardiffuni.pbdproject.cgm3.GPSTracker;
import com.cardiffuni.pbdproject.cgm3.GeneralEntity;
import com.cardiffuni.pbdproject.cgm3.Hospital;
import com.cardiffuni.pbdproject.cgm3.LightSensor;
import com.cardiffuni.pbdproject.cgm3.LocationGranularity;
import com.cardiffuni.pbdproject.cgm3.MedicalRecord;
import com.cardiffuni.pbdproject.cgm3.NewEClass26;
import com.cardiffuni.pbdproject.cgm3.NewEClass28;
import com.cardiffuni.pbdproject.cgm3.NewEClass7;
import com.cardiffuni.pbdproject.cgm3.Nurse;
import com.cardiffuni.pbdproject.cgm3.Patient;
import com.cardiffuni.pbdproject.cgm3.PatientHealthStatus;
import com.cardiffuni.pbdproject.cgm3.PaymentCloud;
import com.cardiffuni.pbdproject.cgm3.PharmacyCloudold;
import com.cardiffuni.pbdproject.cgm3.Phone;
import com.cardiffuni.pbdproject.cgm3.Privacy_patterns;
import com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud;
import com.cardiffuni.pbdproject.cgm3.Researcher;
import com.cardiffuni.pbdproject.cgm3.RiskCode;
import com.cardiffuni.pbdproject.cgm3.ShippingCloud;
import com.cardiffuni.pbdproject.cgm3.SmartPhone;
import com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud;
import com.cardiffuni.pbdproject.cgm3.StorageLocation;
import com.cardiffuni.pbdproject.cgm3.TestOnDummyData;
import com.cardiffuni.pbdproject.cgm3.Test_on_dummy;
import com.cardiffuni.pbdproject.cgm3.Thermostat;
import com.cardiffuni.pbdproject.cgm3.UserLocation;
import com.cardiffuni.pbdproject.cgm3.VideoAnalytics;
import com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud;
import com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics;
import com.cardiffuni.pbdproject.cgm3.Warning;
import com.cardiffuni.pbdproject.cgm3.WebBrowser;
import com.cardiffuni.pbdproject.cgm3.WebhostingCloud;
import com.cardiffuni.pbdproject.cgm3.Website;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Cgm3PackageImpl extends EPackageImpl implements Cgm3Package {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass generalEntityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cgMsensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass smartPhoneEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass patientEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass nurseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass doctorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass newEClass7EClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cloudEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass websiteEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass hospitalEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass researcherEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass medicalRecordEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass consent_CheckedListEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass storageLocationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass userLocationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass riskCodeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass authenticationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass authorizationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass firewallEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass encryptionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dataSharingEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass warningEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass test_on_dummyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass containerisationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass aggregationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass newEClass26EClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass computerBrowserEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass newEClass28EClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pharmacyCloudoldEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass shippingCloudEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass webhostingCloudEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass paymentCloudEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass socialNetworkCloudEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass realTimeBiddingCloudEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass webBrowserEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cloudForPharmacyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass busEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass gpsTrackerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass videoAnalyticsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass videoWithoutAnalyticsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass driverEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass customerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass analyticsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass blurringEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass videoProcessingCloudEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass clientEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cloudServiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass lightSensorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass phoneEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass doorLockEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass thermostatEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cameraEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass privacy_patternsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cookiesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum dataRetentionEnumEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum patientHealthStatusEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum communicationProtocolsEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum checked_ConsentEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum cloudStorageLocationEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum locationGranularityEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum checkedEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum cloudProviderServerEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum testOnDummyDataEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum answerEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType consentDataTypeEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private Cgm3PackageImpl() {
		super(eNS_URI, Cgm3Factory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link Cgm3Package#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static Cgm3Package init() {
		if (isInited)
			return (Cgm3Package) EPackage.Registry.INSTANCE.getEPackage(Cgm3Package.eNS_URI);

		// Obtain or create and register package
		Object registeredCgm3Package = EPackage.Registry.INSTANCE.get(eNS_URI);
		Cgm3PackageImpl theCgm3Package = registeredCgm3Package instanceof Cgm3PackageImpl
				? (Cgm3PackageImpl) registeredCgm3Package
				: new Cgm3PackageImpl();

		isInited = true;

		// Initialize simple dependencies
		XMLTypePackage.eINSTANCE.eClass();

		// Create package meta-data objects
		theCgm3Package.createPackageContents();

		// Initialize created meta-data
		theCgm3Package.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theCgm3Package.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Cgm3Package.eNS_URI, theCgm3Package);
		return theCgm3Package;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGeneralEntity() {
		return generalEntityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGeneralEntity_Name() {
		return (EAttribute) generalEntityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCGMsensor() {
		return cgMsensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCGMsensor_Smartphone() {
		return (EReference) cgMsensorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCGMsensor_Glucose_amount() {
		return (EAttribute) cgMsensorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCGMsensor_Connection() {
		return (EAttribute) cgMsensorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCGMsensor_DataRetention() {
		return (EAttribute) cgMsensorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCGMsensor_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) cgMsensorEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCGMsensor_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) cgMsensorEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSmartPhone() {
		return smartPhoneEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSmartPhone_Cgmsensor() {
		return (EReference) smartPhoneEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSmartPhone_Cloud() {
		return (EReference) smartPhoneEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSmartPhone_Blood_Sugar_Level() {
		return (EAttribute) smartPhoneEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSmartPhone_Connection() {
		return (EAttribute) smartPhoneEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSmartPhone_Patient_info_Retention_Period() {
		return (EAttribute) smartPhoneEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSmartPhone_Userlocation() {
		return (EReference) smartPhoneEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSmartPhone_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate() {
		return (EAttribute) smartPhoneEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSmartPhone_Are_you_planning_to_send_all_the_data_to_the_cloud() {
		return (EAttribute) smartPhoneEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSmartPhone_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) smartPhoneEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSmartPhone_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) smartPhoneEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSmartPhone_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) smartPhoneEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSmartPhone_Smartphone() {
		return (EReference) smartPhoneEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSmartPhone_Pharmacycloud() {
		return (EReference) smartPhoneEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSmartPhone_Cloudforpharmacy() {
		return (EReference) smartPhoneEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSmartPhone_Cookies() {
		return (EReference) smartPhoneEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPatient() {
		return patientEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatient_Smartphone() {
		return (EReference) patientEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatient_Cgmsensor() {
		return (EReference) patientEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatient_Doctor() {
		return (EReference) patientEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatient_Medicalrecord() {
		return (EReference) patientEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPatient_Age() {
		return (EAttribute) patientEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatient_Consent_checkedlist() {
		return (EReference) patientEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPatient_PhoneNumber() {
		return (EAttribute) patientEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatient_Authentication() {
		return (EReference) patientEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatient_Authorization() {
		return (EReference) patientEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatient_Datasharing() {
		return (EReference) patientEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatient_Computerbrowser() {
		return (EReference) patientEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPatient_Webbrowser() {
		return (EReference) patientEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNurse() {
		return nurseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDoctor() {
		return doctorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDoctor_Patient() {
		return (EReference) doctorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDoctor_Website() {
		return (EReference) doctorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDoctor_Specialty() {
		return (EAttribute) doctorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDoctor_Authentication() {
		return (EReference) doctorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDoctor_Authorization() {
		return (EReference) doctorEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDoctor_Are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data() {
		return (EAttribute) doctorEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNewEClass7() {
		return newEClass7EClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCloud() {
		return cloudEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloud_Smartphone() {
		return (EReference) cloudEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloud_Website() {
		return (EReference) cloudEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloud_DataRetention() {
		return (EAttribute) cloudEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloud_Storagelocation() {
		return (EReference) cloudEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloud_Datasharing() {
		return (EReference) cloudEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloud_Test_on_dummy() {
		return (EReference) cloudEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloud_Containerisation() {
		return (EReference) cloudEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloud_Aggregation() {
		return (EReference) cloudEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose() {
		return (EAttribute) cloudEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) cloudEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent() {
		return (EAttribute) cloudEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) cloudEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() {
		return (EAttribute) cloudEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) cloudEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloud_Medicalrecord() {
		return (EReference) cloudEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getWebsite() {
		return websiteEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebsite_Cloud() {
		return (EReference) websiteEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebsite_Doctor() {
		return (EReference) websiteEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebsite_Researcher() {
		return (EReference) websiteEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebsite_URL() {
		return (EAttribute) websiteEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebsite_Videoprocessingcloud() {
		return (EReference) websiteEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebsite_Cookies() {
		return (EReference) websiteEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHospital() {
		return hospitalEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Patient() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Doctor() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Researcher() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Nurse() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Cloud() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Website() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Smartphone() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Cgmsensor() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Medicalrecord() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Consent_checkedlist() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Storagelocation() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Userlocation() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Riskcode() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Encryption() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Datasharing() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Warning() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Test_on_dummy() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Containerisation() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Aggregation() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Computerbrowser() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Pharmacycloud() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Shippingcloud() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Webhostingcloud() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Paymentcloud() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Socialnetworkcloud() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Webbrowser() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(25);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Cloudforpharmacy() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(26);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Realtimebiddingcloud() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(27);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Gpstracker() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(28);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Bus() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(29);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Driver() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(30);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Customer() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(31);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Videoanalytics() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(32);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Analytics() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(33);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Blurring() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(34);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Videoprocessingcloud() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(35);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Videowithoutanalytics() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(36);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Client() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(37);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Cloudservice() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(38);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Lightsensor() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(39);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Phone() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(40);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Thermostat() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(41);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Doorlock() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(42);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Camera() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(43);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHospital_Cookies() {
		return (EReference) hospitalEClass.getEStructuralFeatures().get(44);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getResearcher() {
		return researcherEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getResearcher_Website() {
		return (EReference) researcherEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getResearcher_Authentication() {
		return (EReference) researcherEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getResearcher_Authorization() {
		return (EReference) researcherEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getResearcher_Are_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data() {
		return (EAttribute) researcherEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getResearcher_Are_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name() {
		return (EAttribute) researcherEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMedicalRecord() {
		return medicalRecordEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMedicalRecord_RecordRetentionPeriod() {
		return (EAttribute) medicalRecordEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConsent_CheckedList() {
		return consent_CheckedListEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConsent_CheckedList_Capture_age_authorization_if_age_is_less_than_16() {
		return (EAttribute) consent_CheckedListEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConsent_CheckedList_Capture_withdrawal_log() {
		return (EAttribute) consent_CheckedListEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConsent_CheckedList_Capture_log_Terms_of_use_AND_consent_to_process() {
		return (EAttribute) consent_CheckedListEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConsent_CheckedList_Capture_consent_to_process_special_category_data() {
		return (EAttribute) consent_CheckedListEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConsent_CheckedList_Capture_consent_to_term_of_use() {
		return (EAttribute) consent_CheckedListEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConsent_CheckedList_Surface_privacy_notice() {
		return (EAttribute) consent_CheckedListEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConsent_CheckedList_Capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used() {
		return (EAttribute) consent_CheckedListEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStorageLocation() {
		return storageLocationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStorageLocation_Cloud_provider_and_server_location() {
		return (EAttribute) storageLocationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getUserLocation() {
		return userLocationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUserLocation_Location() {
		return (EAttribute) userLocationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUserLocation_Are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed() {
		return (EAttribute) userLocationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRiskCode() {
		return riskCodeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAuthentication() {
		return authenticationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAuthentication_Authenticated() {
		return (EAttribute) authenticationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAuthorization() {
		return authorizationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAuthorization_Authorized() {
		return (EAttribute) authorizationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFirewall() {
		return firewallEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEncryption() {
		return encryptionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEncryption_EncryptedData() {
		return (EAttribute) encryptionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDataSharing() {
		return dataSharingEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDataSharing_Apply_anonymisation_for_researcher() {
		return (EAttribute) dataSharingEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDataSharing_Ensure_accessControl() {
		return (EAttribute) dataSharingEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getWarning() {
		return warningEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTest_on_dummy() {
		return test_on_dummyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTest_on_dummy_Testing_on_dummy_data() {
		return (EAttribute) test_on_dummyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getContainerisation() {
		return containerisationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAggregation() {
		return aggregationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNewEClass26() {
		return newEClass26EClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getComputerBrowser() {
		return computerBrowserEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getComputerBrowser_Cgmsensor() {
		return (EReference) computerBrowserEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getComputerBrowser_Cloud() {
		return (EReference) computerBrowserEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getComputerBrowser_Patient_info_Retention_Period() {
		return (EAttribute) computerBrowserEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getComputerBrowser_Userlocation() {
		return (EReference) computerBrowserEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getComputerBrowser_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate() {
		return (EAttribute) computerBrowserEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getComputerBrowser_Are_you_planning_to_send_all_the_data_to_the_cloud() {
		return (EAttribute) computerBrowserEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getComputerBrowser_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) computerBrowserEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getComputerBrowser_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) computerBrowserEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getComputerBrowser_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) computerBrowserEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getComputerBrowser_Pharmacycloud() {
		return (EReference) computerBrowserEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNewEClass28() {
		return newEClass28EClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPharmacyCloudold() {
		return pharmacyCloudoldEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPharmacyCloudold_Smartphone() {
		return (EReference) pharmacyCloudoldEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPharmacyCloudold_Website() {
		return (EReference) pharmacyCloudoldEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPharmacyCloudold_DataRetention() {
		return (EAttribute) pharmacyCloudoldEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPharmacyCloudold_Storagelocation() {
		return (EReference) pharmacyCloudoldEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPharmacyCloudold_Datasharing() {
		return (EReference) pharmacyCloudoldEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPharmacyCloudold_Test_on_dummy() {
		return (EReference) pharmacyCloudoldEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPharmacyCloudold_Containerisation() {
		return (EReference) pharmacyCloudoldEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPharmacyCloudold_Aggregation() {
		return (EReference) pharmacyCloudoldEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPharmacyCloudold_Are_you_collecting_data_that_are_not_needed_for_the_purpose() {
		return (EAttribute) pharmacyCloudoldEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPharmacyCloudold_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) pharmacyCloudoldEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPharmacyCloudold_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent() {
		return (EAttribute) pharmacyCloudoldEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPharmacyCloudold_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) pharmacyCloudoldEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPharmacyCloudold_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() {
		return (EAttribute) pharmacyCloudoldEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPharmacyCloudold_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) pharmacyCloudoldEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPharmacyCloudold_Computerbrowser() {
		return (EReference) pharmacyCloudoldEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getShippingCloud() {
		return shippingCloudEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getShippingCloud_Smartphone() {
		return (EReference) shippingCloudEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getShippingCloud_Website() {
		return (EReference) shippingCloudEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getShippingCloud_DataRetention() {
		return (EAttribute) shippingCloudEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getShippingCloud_Storagelocation() {
		return (EReference) shippingCloudEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getShippingCloud_Datasharing() {
		return (EReference) shippingCloudEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getShippingCloud_Test_on_dummy() {
		return (EReference) shippingCloudEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getShippingCloud_Containerisation() {
		return (EReference) shippingCloudEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getShippingCloud_Aggregation() {
		return (EReference) shippingCloudEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getShippingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose() {
		return (EAttribute) shippingCloudEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getShippingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) shippingCloudEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getShippingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent() {
		return (EAttribute) shippingCloudEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getShippingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) shippingCloudEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getShippingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() {
		return (EAttribute) shippingCloudEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getShippingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) shippingCloudEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getShippingCloud_Cloudforpharmacy() {
		return (EReference) shippingCloudEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getWebhostingCloud() {
		return webhostingCloudEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebhostingCloud_Smartphone() {
		return (EReference) webhostingCloudEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebhostingCloud_Website() {
		return (EReference) webhostingCloudEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebhostingCloud_DataRetention() {
		return (EAttribute) webhostingCloudEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebhostingCloud_Storagelocation() {
		return (EReference) webhostingCloudEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebhostingCloud_Datasharing() {
		return (EReference) webhostingCloudEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebhostingCloud_Test_on_dummy() {
		return (EReference) webhostingCloudEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebhostingCloud_Containerisation() {
		return (EReference) webhostingCloudEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebhostingCloud_Aggregation() {
		return (EReference) webhostingCloudEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebhostingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose() {
		return (EAttribute) webhostingCloudEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebhostingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) webhostingCloudEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebhostingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent() {
		return (EAttribute) webhostingCloudEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebhostingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) webhostingCloudEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebhostingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() {
		return (EAttribute) webhostingCloudEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebhostingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) webhostingCloudEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebhostingCloud_Cloudforpharmacy() {
		return (EReference) webhostingCloudEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebhostingCloud_Socialnetworkcloud() {
		return (EReference) webhostingCloudEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebhostingCloud_Realtimebiddingcloud() {
		return (EReference) webhostingCloudEClass.getEStructuralFeatures().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPaymentCloud() {
		return paymentCloudEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaymentCloud_Smartphone() {
		return (EReference) paymentCloudEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaymentCloud_Website() {
		return (EReference) paymentCloudEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPaymentCloud_DataRetention() {
		return (EAttribute) paymentCloudEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaymentCloud_Storagelocation() {
		return (EReference) paymentCloudEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaymentCloud_Datasharing() {
		return (EReference) paymentCloudEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaymentCloud_Test_on_dummy() {
		return (EReference) paymentCloudEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaymentCloud_Containerisation() {
		return (EReference) paymentCloudEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaymentCloud_Aggregation() {
		return (EReference) paymentCloudEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPaymentCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose() {
		return (EAttribute) paymentCloudEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPaymentCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) paymentCloudEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPaymentCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent() {
		return (EAttribute) paymentCloudEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPaymentCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) paymentCloudEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPaymentCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() {
		return (EAttribute) paymentCloudEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPaymentCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) paymentCloudEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPaymentCloud_Cloudforpharmacy() {
		return (EReference) paymentCloudEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSocialNetworkCloud() {
		return socialNetworkCloudEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSocialNetworkCloud_Smartphone() {
		return (EReference) socialNetworkCloudEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSocialNetworkCloud_Website() {
		return (EReference) socialNetworkCloudEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSocialNetworkCloud_DataRetention() {
		return (EAttribute) socialNetworkCloudEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSocialNetworkCloud_Storagelocation() {
		return (EReference) socialNetworkCloudEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSocialNetworkCloud_Datasharing() {
		return (EReference) socialNetworkCloudEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSocialNetworkCloud_Test_on_dummy() {
		return (EReference) socialNetworkCloudEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSocialNetworkCloud_Containerisation() {
		return (EReference) socialNetworkCloudEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSocialNetworkCloud_Aggregation() {
		return (EReference) socialNetworkCloudEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSocialNetworkCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose() {
		return (EAttribute) socialNetworkCloudEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSocialNetworkCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) socialNetworkCloudEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSocialNetworkCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent() {
		return (EAttribute) socialNetworkCloudEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSocialNetworkCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) socialNetworkCloudEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSocialNetworkCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() {
		return (EAttribute) socialNetworkCloudEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSocialNetworkCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) socialNetworkCloudEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSocialNetworkCloud_Cloudforpharmacy() {
		return (EReference) socialNetworkCloudEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSocialNetworkCloud_Webhostingcloud() {
		return (EReference) socialNetworkCloudEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRealTimeBiddingCloud() {
		return realTimeBiddingCloudEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRealTimeBiddingCloud_Smartphone() {
		return (EReference) realTimeBiddingCloudEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRealTimeBiddingCloud_Website() {
		return (EReference) realTimeBiddingCloudEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRealTimeBiddingCloud_DataRetention() {
		return (EAttribute) realTimeBiddingCloudEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRealTimeBiddingCloud_Storagelocation() {
		return (EReference) realTimeBiddingCloudEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRealTimeBiddingCloud_Datasharing() {
		return (EReference) realTimeBiddingCloudEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRealTimeBiddingCloud_Test_on_dummy() {
		return (EReference) realTimeBiddingCloudEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRealTimeBiddingCloud_Containerisation() {
		return (EReference) realTimeBiddingCloudEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRealTimeBiddingCloud_Aggregation() {
		return (EReference) realTimeBiddingCloudEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRealTimeBiddingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose() {
		return (EAttribute) realTimeBiddingCloudEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRealTimeBiddingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) realTimeBiddingCloudEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRealTimeBiddingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent() {
		return (EAttribute) realTimeBiddingCloudEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRealTimeBiddingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) realTimeBiddingCloudEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRealTimeBiddingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() {
		return (EAttribute) realTimeBiddingCloudEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRealTimeBiddingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) realTimeBiddingCloudEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRealTimeBiddingCloud_Webhostingcloud() {
		return (EReference) realTimeBiddingCloudEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getWebBrowser() {
		return webBrowserEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebBrowser_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) webBrowserEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebBrowser_Are_you_planning_to_send_all_the_data_to_the_cloud() {
		return (EAttribute) webBrowserEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebBrowser_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) webBrowserEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebBrowser_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) webBrowserEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebBrowser_Patient_info_Retention_Period() {
		return (EAttribute) webBrowserEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWebBrowser_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate() {
		return (EAttribute) webBrowserEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebBrowser_Userlocation() {
		return (EReference) webBrowserEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebBrowser_Cloudforpharmacy() {
		return (EReference) webBrowserEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWebBrowser_Cookies() {
		return (EReference) webBrowserEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCloudForPharmacy() {
		return cloudForPharmacyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudForPharmacy_Smartphone() {
		return (EReference) cloudForPharmacyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudForPharmacy_Webbrowser() {
		return (EReference) cloudForPharmacyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudForPharmacy_Storagelocation() {
		return (EReference) cloudForPharmacyEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudForPharmacy_Test_on_dummy() {
		return (EReference) cloudForPharmacyEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudForPharmacy_Containerisation() {
		return (EReference) cloudForPharmacyEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudForPharmacy_Aggregation() {
		return (EReference) cloudForPharmacyEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudForPharmacy_Datasharing() {
		return (EReference) cloudForPharmacyEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudForPharmacy_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() {
		return (EAttribute) cloudForPharmacyEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudForPharmacy_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) cloudForPharmacyEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudForPharmacy_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) cloudForPharmacyEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudForPharmacy_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent() {
		return (EAttribute) cloudForPharmacyEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudForPharmacy_DataRetention() {
		return (EAttribute) cloudForPharmacyEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudForPharmacy_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) cloudForPharmacyEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudForPharmacy_Are_you_collecting_data_that_are_not_needed_for_the_purpose() {
		return (EAttribute) cloudForPharmacyEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudForPharmacy_Paymentcloud() {
		return (EReference) cloudForPharmacyEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudForPharmacy_Socialnetworkcloud() {
		return (EReference) cloudForPharmacyEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudForPharmacy_Shippingcloud() {
		return (EReference) cloudForPharmacyEClass.getEStructuralFeatures().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudForPharmacy_Webhostingcloud() {
		return (EReference) cloudForPharmacyEClass.getEStructuralFeatures().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBus() {
		return busEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBus_Gpstracker() {
		return (EReference) busEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBus_Plate_number() {
		return (EAttribute) busEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBus_Route_number() {
		return (EAttribute) busEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBus_Driver_name() {
		return (EAttribute) busEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBus_Driver() {
		return (EReference) busEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBus_Videoanalytics() {
		return (EReference) busEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBus_Videoprocessingcloud() {
		return (EReference) busEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBus_Customer() {
		return (EReference) busEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBus_Videowithoutanalytics() {
		return (EReference) busEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGPSTracker() {
		return gpsTrackerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGPSTracker_ID() {
		return (EAttribute) gpsTrackerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGPSTracker_Coordinates() {
		return (EAttribute) gpsTrackerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGPSTracker_Speed() {
		return (EAttribute) gpsTrackerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGPSTracker_Does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks() {
		return (EAttribute) gpsTrackerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGPSTracker_Record_retention_period() {
		return (EAttribute) gpsTrackerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGPSTracker_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles() {
		return (EAttribute) gpsTrackerEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGPSTracker_Is_data_against_accidental_loss_or_destruction_or_damage() {
		return (EAttribute) gpsTrackerEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGPSTracker_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() {
		return (EAttribute) gpsTrackerEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGPSTracker_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) gpsTrackerEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGPSTracker_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring() {
		return (EAttribute) gpsTrackerEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGPSTracker_Does_the_staff_aware_of_the_use_of_the_GPS_systems() {
		return (EAttribute) gpsTrackerEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getGPSTracker_Does_the_system_record_information_other_than_the_purpose() {
		return (EAttribute) gpsTrackerEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVideoAnalytics() {
		return videoAnalyticsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoAnalytics_Serial_number() {
		return (EAttribute) videoAnalyticsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoAnalytics_Blurring() {
		return (EReference) videoAnalyticsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoAnalytics_Analytics() {
		return (EReference) videoAnalyticsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoAnalytics_Customer() {
		return (EReference) videoAnalyticsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoAnalytics_Videoprocessingcloud() {
		return (EReference) videoAnalyticsEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVideoWithoutAnalytics() {
		return videoWithoutAnalyticsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Serial_number() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Do_people_aware_of_being_recorded() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Record_retention_period() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Ensure_data_minimisation_is_aplied() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Does_the_system_record_information_other_than_the_purpose() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Do_you_use_signs_that_say_CCTV_is_in_operation() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Is_data_against_accidental_loss_or_destruction_or_damage() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Does_The_dynamic_masking_feature_is_enabled() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Are_you_sending_data_without_anonymisation() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Are_you_allowing_data_unauthorised_access() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoWithoutAnalytics_Are_you_storing_the_footage_in_a_secure_location() {
		return (EAttribute) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoWithoutAnalytics_Customer() {
		return (EReference) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoWithoutAnalytics_Videoprocessingcloud() {
		return (EReference) videoWithoutAnalyticsEClass.getEStructuralFeatures().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDriver() {
		return driverEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDriver_Authentication() {
		return (EReference) driverEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDriver_Authorization() {
		return (EReference) driverEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDriver_Age() {
		return (EAttribute) driverEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDriver_Consent_checkedlist() {
		return (EReference) driverEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDriver_Do_drivers_aware_of_being_recorded() {
		return (EAttribute) driverEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCustomer() {
		return customerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCustomer_General_features() {
		return (EAttribute) customerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCustomer_Consent_checkedlist() {
		return (EReference) customerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCustomer_Do_people_aware_of_being_recorded() {
		return (EAttribute) customerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCustomer_Videoanalytics() {
		return (EReference) customerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCustomer_Videowithoutanalytics() {
		return (EReference) customerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAnalytics() {
		return analyticsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalytics_Record_retention_period() {
		return (EAttribute) analyticsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalytics_Does_data_processing_applied_on_the_camera_to_increase_data_minimisation() {
		return (EAttribute) analyticsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalytics_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles() {
		return (EAttribute) analyticsEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalytics_Does_the_system_record_information_other_than_the_purpose() {
		return (EAttribute) analyticsEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalytics_Does_The_dynamic_masking_feature_is_enabled() {
		return (EAttribute) analyticsEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalytics_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring() {
		return (EAttribute) analyticsEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalytics_Do_you_use_signs_that_say_CCTV_is_in_operation() {
		return (EAttribute) analyticsEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalytics_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV() {
		return (EAttribute) analyticsEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalytics_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) analyticsEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalytics_Is_data_against_accidental_loss_or_destruction_or_damage() {
		return (EAttribute) analyticsEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAnalytics_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() {
		return (EAttribute) analyticsEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBlurring() {
		return blurringEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getBlurring_Does_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation() {
		return (EAttribute) blurringEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVideoProcessingCloud() {
		return videoProcessingCloudEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoProcessingCloud_DataRetention() {
		return (EAttribute) videoProcessingCloudEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoProcessingCloud_Storagelocation() {
		return (EReference) videoProcessingCloudEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoProcessingCloud_Datasharing() {
		return (EReference) videoProcessingCloudEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoProcessingCloud_Test_on_dummy() {
		return (EReference) videoProcessingCloudEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoProcessingCloud_Containerisation() {
		return (EReference) videoProcessingCloudEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoProcessingCloud_Aggregation() {
		return (EReference) videoProcessingCloudEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoProcessingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose() {
		return (EAttribute) videoProcessingCloudEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoProcessingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) videoProcessingCloudEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoProcessingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent() {
		return (EAttribute) videoProcessingCloudEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoProcessingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) videoProcessingCloudEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoProcessingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() {
		return (EAttribute) videoProcessingCloudEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVideoProcessingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) videoProcessingCloudEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoProcessingCloud_Gpstracker() {
		return (EReference) videoProcessingCloudEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoProcessingCloud_Videoanalytics() {
		return (EReference) videoProcessingCloudEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoProcessingCloud_Videowithoutanalytics() {
		return (EReference) videoProcessingCloudEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVideoProcessingCloud_Website() {
		return (EReference) videoProcessingCloudEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClient() {
		return clientEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getClient_Smartphone() {
		return (EReference) clientEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getClient_Consent_checkedlist() {
		return (EReference) clientEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getClient_PhoneNumber() {
		return (EAttribute) clientEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getClient_Authentication() {
		return (EReference) clientEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getClient_Authorization() {
		return (EReference) clientEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getClient_Phone() {
		return (EReference) clientEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCloudService() {
		return cloudServiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudService_DataRetention() {
		return (EAttribute) cloudServiceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudService_Storagelocation() {
		return (EReference) cloudServiceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudService_Datasharing() {
		return (EReference) cloudServiceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudService_Test_on_dummy() {
		return (EReference) cloudServiceEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudService_Containerisation() {
		return (EReference) cloudServiceEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudService_Aggregation() {
		return (EReference) cloudServiceEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudService_Are_you_collecting_data_that_are_not_needed_for_the_purpose() {
		return (EAttribute) cloudServiceEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudService_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) cloudServiceEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudService_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent() {
		return (EAttribute) cloudServiceEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudService_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) cloudServiceEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudService_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing() {
		return (EAttribute) cloudServiceEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCloudService_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) cloudServiceEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudService_Gpstracker() {
		return (EReference) cloudServiceEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudService_Videoanalytics() {
		return (EReference) cloudServiceEClass.getEStructuralFeatures().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudService_Videowithoutanalytics() {
		return (EReference) cloudServiceEClass.getEStructuralFeatures().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudService_Lightsensor() {
		return (EReference) cloudServiceEClass.getEStructuralFeatures().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudService_Phone() {
		return (EReference) cloudServiceEClass.getEStructuralFeatures().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudService_Camera() {
		return (EReference) cloudServiceEClass.getEStructuralFeatures().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudService_Doorlock() {
		return (EReference) cloudServiceEClass.getEStructuralFeatures().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCloudService_Thermostat() {
		return (EReference) cloudServiceEClass.getEStructuralFeatures().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getLightSensor() {
		return lightSensorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLightSensor_Connection() {
		return (EAttribute) lightSensorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLightSensor_DataRetention() {
		return (EAttribute) lightSensorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLightSensor_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) lightSensorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getLightSensor_Cloudservice() {
		return (EReference) lightSensorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLightSensor_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() {
		return (EAttribute) lightSensorEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getLightSensor_Is_data_against_accidental_loss_or_destruction_or_damage() {
		return (EAttribute) lightSensorEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPhone() {
		return phoneEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPhone_User_info_Retention_Period() {
		return (EAttribute) phoneEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPhone_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return (EAttribute) phoneEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPhone_Are_you_planning_to_send_all_the_data_to_the_cloud() {
		return (EAttribute) phoneEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPhone_Are_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return (EAttribute) phoneEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPhone_Connection() {
		return (EAttribute) phoneEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPhone_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate() {
		return (EAttribute) phoneEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPhone_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) phoneEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPhone_Userlocation() {
		return (EReference) phoneEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPhone_Cloudservice() {
		return (EReference) phoneEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPhone_Cookies() {
		return (EReference) phoneEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDoorLock() {
		return doorLockEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDoorLock_Cloudservice() {
		return (EReference) doorLockEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDoorLock_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() {
		return (EAttribute) doorLockEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDoorLock_Connection() {
		return (EAttribute) doorLockEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDoorLock_DataRetention() {
		return (EAttribute) doorLockEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDoorLock_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) doorLockEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDoorLock_Is_data_against_accidental_loss_or_destruction_or_damage() {
		return (EAttribute) doorLockEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getThermostat() {
		return thermostatEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getThermostat_Cloudservice() {
		return (EReference) thermostatEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getThermostat_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() {
		return (EAttribute) thermostatEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getThermostat_Connection() {
		return (EAttribute) thermostatEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getThermostat_DataRetention() {
		return (EAttribute) thermostatEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getThermostat_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) thermostatEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getThermostat_Is_data_against_accidental_loss_or_destruction_or_damage() {
		return (EAttribute) thermostatEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCamera() {
		return cameraEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_Are_you_sending_data_without_anonymisation() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_Do_people_aware_of_being_recorded() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_Are_you_storing_the_footage_in_a_secure_location() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_Ensure_data_minimisation_is_aplied() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_Do_you_use_signs_that_say_CCTV_is_in_operation() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_Does_the_system_record_information_other_than_the_purpose() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_Record_retention_period() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_Are_you_allowing_data_unauthorised_access() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCamera_Is_data_against_accidental_loss_or_destruction_or_damage() {
		return (EAttribute) cameraEClass.getEStructuralFeatures().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCamera_Cloudservice() {
		return (EReference) cameraEClass.getEStructuralFeatures().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPrivacy_patterns() {
		return privacy_patternsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPrivacy_patterns_Privacy_patterns() {
		return (EAttribute) privacy_patternsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCookies() {
		return cookiesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCookies_Use_the_surface_cookies_banner_if_cookies_are_placed() {
		return (EAttribute) cookiesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCookies_The_cookie_banner_must_be_resurfaced_if_new_cookies_are_added() {
		return (EAttribute) cookiesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCookies_The_cookie_banner_must_be_resurfaced_if_browser_settings_change() {
		return (EAttribute) cookiesEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCookies_Capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used() {
		return (EAttribute) cookiesEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCookies_Place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used() {
		return (EAttribute) cookiesEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCookies_Consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc() {
		return (EAttribute) cookiesEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getDataRetentionEnum() {
		return dataRetentionEnumEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getPatientHealthStatus() {
		return patientHealthStatusEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getCommunicationProtocols() {
		return communicationProtocolsEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getChecked_Consent() {
		return checked_ConsentEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getCloudStorageLocation() {
		return cloudStorageLocationEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getLocationGranularity() {
		return locationGranularityEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getChecked() {
		return checkedEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getCloudProviderServer() {
		return cloudProviderServerEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTestOnDummyData() {
		return testOnDummyDataEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getAnswer() {
		return answerEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getConsentDataType() {
		return consentDataTypeEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cgm3Factory getCgm3Factory() {
		return (Cgm3Factory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		generalEntityEClass = createEClass(GENERAL_ENTITY);
		createEAttribute(generalEntityEClass, GENERAL_ENTITY__NAME);

		cgMsensorEClass = createEClass(CG_MSENSOR);
		createEReference(cgMsensorEClass, CG_MSENSOR__SMARTPHONE);
		createEAttribute(cgMsensorEClass, CG_MSENSOR__GLUCOSE_AMOUNT);
		createEAttribute(cgMsensorEClass, CG_MSENSOR__CONNECTION);
		createEAttribute(cgMsensorEClass, CG_MSENSOR__DATA_RETENTION);
		createEAttribute(cgMsensorEClass,
				CG_MSENSOR__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(cgMsensorEClass,
				CG_MSENSOR__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);

		smartPhoneEClass = createEClass(SMART_PHONE);
		createEReference(smartPhoneEClass, SMART_PHONE__CGMSENSOR);
		createEReference(smartPhoneEClass, SMART_PHONE__CLOUD);
		createEAttribute(smartPhoneEClass, SMART_PHONE__BLOOD_SUGAR_LEVEL);
		createEAttribute(smartPhoneEClass, SMART_PHONE__CONNECTION);
		createEAttribute(smartPhoneEClass, SMART_PHONE__PATIENT_INFO_RETENTION_PERIOD);
		createEReference(smartPhoneEClass, SMART_PHONE__USERLOCATION);
		createEAttribute(smartPhoneEClass,
				SMART_PHONE__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE);
		createEAttribute(smartPhoneEClass, SMART_PHONE__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD);
		createEAttribute(smartPhoneEClass,
				SMART_PHONE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(smartPhoneEClass,
				SMART_PHONE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(smartPhoneEClass,
				SMART_PHONE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEReference(smartPhoneEClass, SMART_PHONE__SMARTPHONE);
		createEReference(smartPhoneEClass, SMART_PHONE__PHARMACYCLOUD);
		createEReference(smartPhoneEClass, SMART_PHONE__CLOUDFORPHARMACY);
		createEReference(smartPhoneEClass, SMART_PHONE__COOKIES);

		patientEClass = createEClass(PATIENT);
		createEReference(patientEClass, PATIENT__SMARTPHONE);
		createEReference(patientEClass, PATIENT__CGMSENSOR);
		createEReference(patientEClass, PATIENT__DOCTOR);
		createEReference(patientEClass, PATIENT__MEDICALRECORD);
		createEAttribute(patientEClass, PATIENT__AGE);
		createEReference(patientEClass, PATIENT__CONSENT_CHECKEDLIST);
		createEAttribute(patientEClass, PATIENT__PHONE_NUMBER);
		createEReference(patientEClass, PATIENT__AUTHENTICATION);
		createEReference(patientEClass, PATIENT__AUTHORIZATION);
		createEReference(patientEClass, PATIENT__DATASHARING);
		createEReference(patientEClass, PATIENT__COMPUTERBROWSER);
		createEReference(patientEClass, PATIENT__WEBBROWSER);

		nurseEClass = createEClass(NURSE);

		doctorEClass = createEClass(DOCTOR);
		createEReference(doctorEClass, DOCTOR__PATIENT);
		createEReference(doctorEClass, DOCTOR__WEBSITE);
		createEAttribute(doctorEClass, DOCTOR__SPECIALTY);
		createEReference(doctorEClass, DOCTOR__AUTHENTICATION);
		createEReference(doctorEClass, DOCTOR__AUTHORIZATION);
		createEAttribute(doctorEClass,
				DOCTOR__ARE_YOU_ALLOWING_UNAUTHORISED_DOCTORS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_HEALTH_DATA);

		newEClass7EClass = createEClass(NEW_ECLASS7);

		cloudEClass = createEClass(CLOUD);
		createEReference(cloudEClass, CLOUD__SMARTPHONE);
		createEReference(cloudEClass, CLOUD__WEBSITE);
		createEAttribute(cloudEClass, CLOUD__DATA_RETENTION);
		createEReference(cloudEClass, CLOUD__STORAGELOCATION);
		createEReference(cloudEClass, CLOUD__DATASHARING);
		createEReference(cloudEClass, CLOUD__TEST_ON_DUMMY);
		createEReference(cloudEClass, CLOUD__CONTAINERISATION);
		createEReference(cloudEClass, CLOUD__AGGREGATION);
		createEAttribute(cloudEClass, CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE);
		createEAttribute(cloudEClass, CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(cloudEClass,
				CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT);
		createEAttribute(cloudEClass, CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(cloudEClass,
				CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING);
		createEAttribute(cloudEClass,
				CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEReference(cloudEClass, CLOUD__MEDICALRECORD);

		websiteEClass = createEClass(WEBSITE);
		createEReference(websiteEClass, WEBSITE__CLOUD);
		createEReference(websiteEClass, WEBSITE__DOCTOR);
		createEReference(websiteEClass, WEBSITE__RESEARCHER);
		createEAttribute(websiteEClass, WEBSITE__URL);
		createEReference(websiteEClass, WEBSITE__VIDEOPROCESSINGCLOUD);
		createEReference(websiteEClass, WEBSITE__COOKIES);

		hospitalEClass = createEClass(HOSPITAL);
		createEReference(hospitalEClass, HOSPITAL__PATIENT);
		createEReference(hospitalEClass, HOSPITAL__DOCTOR);
		createEReference(hospitalEClass, HOSPITAL__RESEARCHER);
		createEReference(hospitalEClass, HOSPITAL__NURSE);
		createEReference(hospitalEClass, HOSPITAL__CLOUD);
		createEReference(hospitalEClass, HOSPITAL__WEBSITE);
		createEReference(hospitalEClass, HOSPITAL__SMARTPHONE);
		createEReference(hospitalEClass, HOSPITAL__CGMSENSOR);
		createEReference(hospitalEClass, HOSPITAL__MEDICALRECORD);
		createEReference(hospitalEClass, HOSPITAL__CONSENT_CHECKEDLIST);
		createEReference(hospitalEClass, HOSPITAL__STORAGELOCATION);
		createEReference(hospitalEClass, HOSPITAL__USERLOCATION);
		createEReference(hospitalEClass, HOSPITAL__RISKCODE);
		createEReference(hospitalEClass, HOSPITAL__ENCRYPTION);
		createEReference(hospitalEClass, HOSPITAL__DATASHARING);
		createEReference(hospitalEClass, HOSPITAL__WARNING);
		createEReference(hospitalEClass, HOSPITAL__TEST_ON_DUMMY);
		createEReference(hospitalEClass, HOSPITAL__CONTAINERISATION);
		createEReference(hospitalEClass, HOSPITAL__AGGREGATION);
		createEReference(hospitalEClass, HOSPITAL__COMPUTERBROWSER);
		createEReference(hospitalEClass, HOSPITAL__PHARMACYCLOUD);
		createEReference(hospitalEClass, HOSPITAL__SHIPPINGCLOUD);
		createEReference(hospitalEClass, HOSPITAL__WEBHOSTINGCLOUD);
		createEReference(hospitalEClass, HOSPITAL__PAYMENTCLOUD);
		createEReference(hospitalEClass, HOSPITAL__SOCIALNETWORKCLOUD);
		createEReference(hospitalEClass, HOSPITAL__WEBBROWSER);
		createEReference(hospitalEClass, HOSPITAL__CLOUDFORPHARMACY);
		createEReference(hospitalEClass, HOSPITAL__REALTIMEBIDDINGCLOUD);
		createEReference(hospitalEClass, HOSPITAL__GPSTRACKER);
		createEReference(hospitalEClass, HOSPITAL__BUS);
		createEReference(hospitalEClass, HOSPITAL__DRIVER);
		createEReference(hospitalEClass, HOSPITAL__CUSTOMER);
		createEReference(hospitalEClass, HOSPITAL__VIDEOANALYTICS);
		createEReference(hospitalEClass, HOSPITAL__ANALYTICS);
		createEReference(hospitalEClass, HOSPITAL__BLURRING);
		createEReference(hospitalEClass, HOSPITAL__VIDEOPROCESSINGCLOUD);
		createEReference(hospitalEClass, HOSPITAL__VIDEOWITHOUTANALYTICS);
		createEReference(hospitalEClass, HOSPITAL__CLIENT);
		createEReference(hospitalEClass, HOSPITAL__CLOUDSERVICE);
		createEReference(hospitalEClass, HOSPITAL__LIGHTSENSOR);
		createEReference(hospitalEClass, HOSPITAL__PHONE);
		createEReference(hospitalEClass, HOSPITAL__THERMOSTAT);
		createEReference(hospitalEClass, HOSPITAL__DOORLOCK);
		createEReference(hospitalEClass, HOSPITAL__CAMERA);
		createEReference(hospitalEClass, HOSPITAL__COOKIES);

		researcherEClass = createEClass(RESEARCHER);
		createEReference(researcherEClass, RESEARCHER__WEBSITE);
		createEReference(researcherEClass, RESEARCHER__AUTHENTICATION);
		createEReference(researcherEClass, RESEARCHER__AUTHORIZATION);
		createEAttribute(researcherEClass,
				RESEARCHER__ARE_YOU_ALLOWING_RESEARCHERS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_MEDICAL_DATA);
		createEAttribute(researcherEClass,
				RESEARCHER__ARE_YOU_ALLOWING_UNAUTHORISED_RESEARCHERS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_PERSONAL_DATA_SUCH_AS_NAME);

		medicalRecordEClass = createEClass(MEDICAL_RECORD);
		createEAttribute(medicalRecordEClass, MEDICAL_RECORD__RECORD_RETENTION_PERIOD);

		consent_CheckedListEClass = createEClass(CONSENT_CHECKED_LIST);
		createEAttribute(consent_CheckedListEClass,
				CONSENT_CHECKED_LIST__CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16);
		createEAttribute(consent_CheckedListEClass, CONSENT_CHECKED_LIST__CAPTURE_WITHDRAWAL_LOG);
		createEAttribute(consent_CheckedListEClass,
				CONSENT_CHECKED_LIST__CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS);
		createEAttribute(consent_CheckedListEClass,
				CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA);
		createEAttribute(consent_CheckedListEClass, CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_TERM_OF_USE);
		createEAttribute(consent_CheckedListEClass, CONSENT_CHECKED_LIST__SURFACE_PRIVACY_NOTICE);
		createEAttribute(consent_CheckedListEClass,
				CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED);

		storageLocationEClass = createEClass(STORAGE_LOCATION);
		createEAttribute(storageLocationEClass, STORAGE_LOCATION__CLOUD_PROVIDER_AND_SERVER_LOCATION);

		userLocationEClass = createEClass(USER_LOCATION);
		createEAttribute(userLocationEClass, USER_LOCATION__LOCATION);
		createEAttribute(userLocationEClass,
				USER_LOCATION__ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED);

		riskCodeEClass = createEClass(RISK_CODE);

		authenticationEClass = createEClass(AUTHENTICATION);
		createEAttribute(authenticationEClass, AUTHENTICATION__AUTHENTICATED);

		authorizationEClass = createEClass(AUTHORIZATION);
		createEAttribute(authorizationEClass, AUTHORIZATION__AUTHORIZED);

		firewallEClass = createEClass(FIREWALL);

		encryptionEClass = createEClass(ENCRYPTION);
		createEAttribute(encryptionEClass, ENCRYPTION__ENCRYPTED_DATA);

		dataSharingEClass = createEClass(DATA_SHARING);
		createEAttribute(dataSharingEClass, DATA_SHARING__APPLY_ANONYMISATION_FOR_RESEARCHER);
		createEAttribute(dataSharingEClass, DATA_SHARING__ENSURE_ACCESS_CONTROL);

		warningEClass = createEClass(WARNING);

		test_on_dummyEClass = createEClass(TEST_ON_DUMMY);
		createEAttribute(test_on_dummyEClass, TEST_ON_DUMMY__TESTING_ON_DUMMY_DATA);

		containerisationEClass = createEClass(CONTAINERISATION);

		aggregationEClass = createEClass(AGGREGATION);

		newEClass26EClass = createEClass(NEW_ECLASS26);

		computerBrowserEClass = createEClass(COMPUTER_BROWSER);
		createEReference(computerBrowserEClass, COMPUTER_BROWSER__CGMSENSOR);
		createEReference(computerBrowserEClass, COMPUTER_BROWSER__CLOUD);
		createEAttribute(computerBrowserEClass, COMPUTER_BROWSER__PATIENT_INFO_RETENTION_PERIOD);
		createEReference(computerBrowserEClass, COMPUTER_BROWSER__USERLOCATION);
		createEAttribute(computerBrowserEClass,
				COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE);
		createEAttribute(computerBrowserEClass, COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD);
		createEAttribute(computerBrowserEClass,
				COMPUTER_BROWSER__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(computerBrowserEClass,
				COMPUTER_BROWSER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(computerBrowserEClass,
				COMPUTER_BROWSER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEReference(computerBrowserEClass, COMPUTER_BROWSER__PHARMACYCLOUD);

		newEClass28EClass = createEClass(NEW_ECLASS28);

		pharmacyCloudoldEClass = createEClass(PHARMACY_CLOUDOLD);
		createEReference(pharmacyCloudoldEClass, PHARMACY_CLOUDOLD__SMARTPHONE);
		createEReference(pharmacyCloudoldEClass, PHARMACY_CLOUDOLD__WEBSITE);
		createEAttribute(pharmacyCloudoldEClass, PHARMACY_CLOUDOLD__DATA_RETENTION);
		createEReference(pharmacyCloudoldEClass, PHARMACY_CLOUDOLD__STORAGELOCATION);
		createEReference(pharmacyCloudoldEClass, PHARMACY_CLOUDOLD__DATASHARING);
		createEReference(pharmacyCloudoldEClass, PHARMACY_CLOUDOLD__TEST_ON_DUMMY);
		createEReference(pharmacyCloudoldEClass, PHARMACY_CLOUDOLD__CONTAINERISATION);
		createEReference(pharmacyCloudoldEClass, PHARMACY_CLOUDOLD__AGGREGATION);
		createEAttribute(pharmacyCloudoldEClass,
				PHARMACY_CLOUDOLD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE);
		createEAttribute(pharmacyCloudoldEClass,
				PHARMACY_CLOUDOLD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(pharmacyCloudoldEClass,
				PHARMACY_CLOUDOLD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT);
		createEAttribute(pharmacyCloudoldEClass,
				PHARMACY_CLOUDOLD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(pharmacyCloudoldEClass,
				PHARMACY_CLOUDOLD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING);
		createEAttribute(pharmacyCloudoldEClass,
				PHARMACY_CLOUDOLD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEReference(pharmacyCloudoldEClass, PHARMACY_CLOUDOLD__COMPUTERBROWSER);

		shippingCloudEClass = createEClass(SHIPPING_CLOUD);
		createEReference(shippingCloudEClass, SHIPPING_CLOUD__SMARTPHONE);
		createEReference(shippingCloudEClass, SHIPPING_CLOUD__WEBSITE);
		createEAttribute(shippingCloudEClass, SHIPPING_CLOUD__DATA_RETENTION);
		createEReference(shippingCloudEClass, SHIPPING_CLOUD__STORAGELOCATION);
		createEReference(shippingCloudEClass, SHIPPING_CLOUD__DATASHARING);
		createEReference(shippingCloudEClass, SHIPPING_CLOUD__TEST_ON_DUMMY);
		createEReference(shippingCloudEClass, SHIPPING_CLOUD__CONTAINERISATION);
		createEReference(shippingCloudEClass, SHIPPING_CLOUD__AGGREGATION);
		createEAttribute(shippingCloudEClass,
				SHIPPING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE);
		createEAttribute(shippingCloudEClass,
				SHIPPING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(shippingCloudEClass,
				SHIPPING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT);
		createEAttribute(shippingCloudEClass,
				SHIPPING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(shippingCloudEClass,
				SHIPPING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING);
		createEAttribute(shippingCloudEClass,
				SHIPPING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEReference(shippingCloudEClass, SHIPPING_CLOUD__CLOUDFORPHARMACY);

		webhostingCloudEClass = createEClass(WEBHOSTING_CLOUD);
		createEReference(webhostingCloudEClass, WEBHOSTING_CLOUD__SMARTPHONE);
		createEReference(webhostingCloudEClass, WEBHOSTING_CLOUD__WEBSITE);
		createEAttribute(webhostingCloudEClass, WEBHOSTING_CLOUD__DATA_RETENTION);
		createEReference(webhostingCloudEClass, WEBHOSTING_CLOUD__STORAGELOCATION);
		createEReference(webhostingCloudEClass, WEBHOSTING_CLOUD__DATASHARING);
		createEReference(webhostingCloudEClass, WEBHOSTING_CLOUD__TEST_ON_DUMMY);
		createEReference(webhostingCloudEClass, WEBHOSTING_CLOUD__CONTAINERISATION);
		createEReference(webhostingCloudEClass, WEBHOSTING_CLOUD__AGGREGATION);
		createEAttribute(webhostingCloudEClass,
				WEBHOSTING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE);
		createEAttribute(webhostingCloudEClass,
				WEBHOSTING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(webhostingCloudEClass,
				WEBHOSTING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT);
		createEAttribute(webhostingCloudEClass,
				WEBHOSTING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(webhostingCloudEClass,
				WEBHOSTING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING);
		createEAttribute(webhostingCloudEClass,
				WEBHOSTING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEReference(webhostingCloudEClass, WEBHOSTING_CLOUD__CLOUDFORPHARMACY);
		createEReference(webhostingCloudEClass, WEBHOSTING_CLOUD__SOCIALNETWORKCLOUD);
		createEReference(webhostingCloudEClass, WEBHOSTING_CLOUD__REALTIMEBIDDINGCLOUD);

		paymentCloudEClass = createEClass(PAYMENT_CLOUD);
		createEReference(paymentCloudEClass, PAYMENT_CLOUD__SMARTPHONE);
		createEReference(paymentCloudEClass, PAYMENT_CLOUD__WEBSITE);
		createEAttribute(paymentCloudEClass, PAYMENT_CLOUD__DATA_RETENTION);
		createEReference(paymentCloudEClass, PAYMENT_CLOUD__STORAGELOCATION);
		createEReference(paymentCloudEClass, PAYMENT_CLOUD__DATASHARING);
		createEReference(paymentCloudEClass, PAYMENT_CLOUD__TEST_ON_DUMMY);
		createEReference(paymentCloudEClass, PAYMENT_CLOUD__CONTAINERISATION);
		createEReference(paymentCloudEClass, PAYMENT_CLOUD__AGGREGATION);
		createEAttribute(paymentCloudEClass,
				PAYMENT_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE);
		createEAttribute(paymentCloudEClass,
				PAYMENT_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(paymentCloudEClass,
				PAYMENT_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT);
		createEAttribute(paymentCloudEClass,
				PAYMENT_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(paymentCloudEClass,
				PAYMENT_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING);
		createEAttribute(paymentCloudEClass,
				PAYMENT_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEReference(paymentCloudEClass, PAYMENT_CLOUD__CLOUDFORPHARMACY);

		socialNetworkCloudEClass = createEClass(SOCIAL_NETWORK_CLOUD);
		createEReference(socialNetworkCloudEClass, SOCIAL_NETWORK_CLOUD__SMARTPHONE);
		createEReference(socialNetworkCloudEClass, SOCIAL_NETWORK_CLOUD__WEBSITE);
		createEAttribute(socialNetworkCloudEClass, SOCIAL_NETWORK_CLOUD__DATA_RETENTION);
		createEReference(socialNetworkCloudEClass, SOCIAL_NETWORK_CLOUD__STORAGELOCATION);
		createEReference(socialNetworkCloudEClass, SOCIAL_NETWORK_CLOUD__DATASHARING);
		createEReference(socialNetworkCloudEClass, SOCIAL_NETWORK_CLOUD__TEST_ON_DUMMY);
		createEReference(socialNetworkCloudEClass, SOCIAL_NETWORK_CLOUD__CONTAINERISATION);
		createEReference(socialNetworkCloudEClass, SOCIAL_NETWORK_CLOUD__AGGREGATION);
		createEAttribute(socialNetworkCloudEClass,
				SOCIAL_NETWORK_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE);
		createEAttribute(socialNetworkCloudEClass,
				SOCIAL_NETWORK_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(socialNetworkCloudEClass,
				SOCIAL_NETWORK_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT);
		createEAttribute(socialNetworkCloudEClass,
				SOCIAL_NETWORK_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(socialNetworkCloudEClass,
				SOCIAL_NETWORK_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING);
		createEAttribute(socialNetworkCloudEClass,
				SOCIAL_NETWORK_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEReference(socialNetworkCloudEClass, SOCIAL_NETWORK_CLOUD__CLOUDFORPHARMACY);
		createEReference(socialNetworkCloudEClass, SOCIAL_NETWORK_CLOUD__WEBHOSTINGCLOUD);

		realTimeBiddingCloudEClass = createEClass(REAL_TIME_BIDDING_CLOUD);
		createEReference(realTimeBiddingCloudEClass, REAL_TIME_BIDDING_CLOUD__SMARTPHONE);
		createEReference(realTimeBiddingCloudEClass, REAL_TIME_BIDDING_CLOUD__WEBSITE);
		createEAttribute(realTimeBiddingCloudEClass, REAL_TIME_BIDDING_CLOUD__DATA_RETENTION);
		createEReference(realTimeBiddingCloudEClass, REAL_TIME_BIDDING_CLOUD__STORAGELOCATION);
		createEReference(realTimeBiddingCloudEClass, REAL_TIME_BIDDING_CLOUD__DATASHARING);
		createEReference(realTimeBiddingCloudEClass, REAL_TIME_BIDDING_CLOUD__TEST_ON_DUMMY);
		createEReference(realTimeBiddingCloudEClass, REAL_TIME_BIDDING_CLOUD__CONTAINERISATION);
		createEReference(realTimeBiddingCloudEClass, REAL_TIME_BIDDING_CLOUD__AGGREGATION);
		createEAttribute(realTimeBiddingCloudEClass,
				REAL_TIME_BIDDING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE);
		createEAttribute(realTimeBiddingCloudEClass,
				REAL_TIME_BIDDING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(realTimeBiddingCloudEClass,
				REAL_TIME_BIDDING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT);
		createEAttribute(realTimeBiddingCloudEClass,
				REAL_TIME_BIDDING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(realTimeBiddingCloudEClass,
				REAL_TIME_BIDDING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING);
		createEAttribute(realTimeBiddingCloudEClass,
				REAL_TIME_BIDDING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEReference(realTimeBiddingCloudEClass, REAL_TIME_BIDDING_CLOUD__WEBHOSTINGCLOUD);

		webBrowserEClass = createEClass(WEB_BROWSER);
		createEAttribute(webBrowserEClass,
				WEB_BROWSER__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(webBrowserEClass, WEB_BROWSER__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD);
		createEAttribute(webBrowserEClass,
				WEB_BROWSER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(webBrowserEClass,
				WEB_BROWSER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEAttribute(webBrowserEClass, WEB_BROWSER__PATIENT_INFO_RETENTION_PERIOD);
		createEAttribute(webBrowserEClass,
				WEB_BROWSER__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE);
		createEReference(webBrowserEClass, WEB_BROWSER__USERLOCATION);
		createEReference(webBrowserEClass, WEB_BROWSER__CLOUDFORPHARMACY);
		createEReference(webBrowserEClass, WEB_BROWSER__COOKIES);

		cloudForPharmacyEClass = createEClass(CLOUD_FOR_PHARMACY);
		createEReference(cloudForPharmacyEClass, CLOUD_FOR_PHARMACY__SMARTPHONE);
		createEReference(cloudForPharmacyEClass, CLOUD_FOR_PHARMACY__WEBBROWSER);
		createEReference(cloudForPharmacyEClass, CLOUD_FOR_PHARMACY__STORAGELOCATION);
		createEReference(cloudForPharmacyEClass, CLOUD_FOR_PHARMACY__TEST_ON_DUMMY);
		createEReference(cloudForPharmacyEClass, CLOUD_FOR_PHARMACY__CONTAINERISATION);
		createEReference(cloudForPharmacyEClass, CLOUD_FOR_PHARMACY__AGGREGATION);
		createEReference(cloudForPharmacyEClass, CLOUD_FOR_PHARMACY__DATASHARING);
		createEAttribute(cloudForPharmacyEClass,
				CLOUD_FOR_PHARMACY__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING);
		createEAttribute(cloudForPharmacyEClass,
				CLOUD_FOR_PHARMACY__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(cloudForPharmacyEClass,
				CLOUD_FOR_PHARMACY__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(cloudForPharmacyEClass,
				CLOUD_FOR_PHARMACY__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT);
		createEAttribute(cloudForPharmacyEClass, CLOUD_FOR_PHARMACY__DATA_RETENTION);
		createEAttribute(cloudForPharmacyEClass,
				CLOUD_FOR_PHARMACY__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEAttribute(cloudForPharmacyEClass,
				CLOUD_FOR_PHARMACY__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE);
		createEReference(cloudForPharmacyEClass, CLOUD_FOR_PHARMACY__PAYMENTCLOUD);
		createEReference(cloudForPharmacyEClass, CLOUD_FOR_PHARMACY__SOCIALNETWORKCLOUD);
		createEReference(cloudForPharmacyEClass, CLOUD_FOR_PHARMACY__SHIPPINGCLOUD);
		createEReference(cloudForPharmacyEClass, CLOUD_FOR_PHARMACY__WEBHOSTINGCLOUD);

		busEClass = createEClass(BUS);
		createEReference(busEClass, BUS__GPSTRACKER);
		createEAttribute(busEClass, BUS__PLATE_NUMBER);
		createEAttribute(busEClass, BUS__ROUTE_NUMBER);
		createEAttribute(busEClass, BUS__DRIVER_NAME);
		createEReference(busEClass, BUS__VIDEOWITHOUTANALYTICS);
		createEReference(busEClass, BUS__DRIVER);
		createEReference(busEClass, BUS__VIDEOANALYTICS);
		createEReference(busEClass, BUS__VIDEOPROCESSINGCLOUD);
		createEReference(busEClass, BUS__CUSTOMER);

		gpsTrackerEClass = createEClass(GPS_TRACKER);
		createEAttribute(gpsTrackerEClass, GPS_TRACKER__ID);
		createEAttribute(gpsTrackerEClass, GPS_TRACKER__COORDINATES);
		createEAttribute(gpsTrackerEClass, GPS_TRACKER__SPEED);
		createEAttribute(gpsTrackerEClass,
				GPS_TRACKER__DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS);
		createEAttribute(gpsTrackerEClass, GPS_TRACKER__RECORD_RETENTION_PERIOD);
		createEAttribute(gpsTrackerEClass,
				GPS_TRACKER__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES);
		createEAttribute(gpsTrackerEClass, GPS_TRACKER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE);
		createEAttribute(gpsTrackerEClass,
				GPS_TRACKER__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA);
		createEAttribute(gpsTrackerEClass,
				GPS_TRACKER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(gpsTrackerEClass,
				GPS_TRACKER__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING);
		createEAttribute(gpsTrackerEClass, GPS_TRACKER__DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS);
		createEAttribute(gpsTrackerEClass, GPS_TRACKER__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE);

		videoAnalyticsEClass = createEClass(VIDEO_ANALYTICS);
		createEAttribute(videoAnalyticsEClass, VIDEO_ANALYTICS__SERIAL_NUMBER);
		createEReference(videoAnalyticsEClass, VIDEO_ANALYTICS__BLURRING);
		createEReference(videoAnalyticsEClass, VIDEO_ANALYTICS__ANALYTICS);
		createEReference(videoAnalyticsEClass, VIDEO_ANALYTICS__CUSTOMER);
		createEReference(videoAnalyticsEClass, VIDEO_ANALYTICS__VIDEOPROCESSINGCLOUD);

		videoWithoutAnalyticsEClass = createEClass(VIDEO_WITHOUT_ANALYTICS);
		createEAttribute(videoWithoutAnalyticsEClass, VIDEO_WITHOUT_ANALYTICS__SERIAL_NUMBER);
		createEAttribute(videoWithoutAnalyticsEClass, VIDEO_WITHOUT_ANALYTICS__RECORD_RETENTION_PERIOD);
		createEAttribute(videoWithoutAnalyticsEClass, VIDEO_WITHOUT_ANALYTICS__DO_PEOPLE_AWARE_OF_BEING_RECORDED);
		createEAttribute(videoWithoutAnalyticsEClass, VIDEO_WITHOUT_ANALYTICS__ENSURE_DATA_MINIMISATION_IS_APLIED);
		createEAttribute(videoWithoutAnalyticsEClass,
				VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(videoWithoutAnalyticsEClass,
				VIDEO_WITHOUT_ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES);
		createEAttribute(videoWithoutAnalyticsEClass,
				VIDEO_WITHOUT_ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV);
		createEAttribute(videoWithoutAnalyticsEClass,
				VIDEO_WITHOUT_ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE);
		createEAttribute(videoWithoutAnalyticsEClass,
				VIDEO_WITHOUT_ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA);
		createEAttribute(videoWithoutAnalyticsEClass,
				VIDEO_WITHOUT_ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING);
		createEAttribute(videoWithoutAnalyticsEClass,
				VIDEO_WITHOUT_ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION);
		createEAttribute(videoWithoutAnalyticsEClass,
				VIDEO_WITHOUT_ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE);
		createEAttribute(videoWithoutAnalyticsEClass,
				VIDEO_WITHOUT_ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED);
		createEAttribute(videoWithoutAnalyticsEClass,
				VIDEO_WITHOUT_ANALYTICS__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION);
		createEAttribute(videoWithoutAnalyticsEClass,
				VIDEO_WITHOUT_ANALYTICS__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS);
		createEAttribute(videoWithoutAnalyticsEClass,
				VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION);
		createEReference(videoWithoutAnalyticsEClass, VIDEO_WITHOUT_ANALYTICS__CUSTOMER);
		createEReference(videoWithoutAnalyticsEClass, VIDEO_WITHOUT_ANALYTICS__VIDEOPROCESSINGCLOUD);

		driverEClass = createEClass(DRIVER);
		createEReference(driverEClass, DRIVER__AUTHENTICATION);
		createEReference(driverEClass, DRIVER__AUTHORIZATION);
		createEAttribute(driverEClass, DRIVER__AGE);
		createEReference(driverEClass, DRIVER__CONSENT_CHECKEDLIST);
		createEAttribute(driverEClass, DRIVER__DO_DRIVERS_AWARE_OF_BEING_RECORDED);

		customerEClass = createEClass(CUSTOMER);
		createEAttribute(customerEClass, CUSTOMER__GENERAL_FEATURES);
		createEReference(customerEClass, CUSTOMER__CONSENT_CHECKEDLIST);
		createEAttribute(customerEClass, CUSTOMER__DO_PEOPLE_AWARE_OF_BEING_RECORDED);
		createEReference(customerEClass, CUSTOMER__VIDEOANALYTICS);
		createEReference(customerEClass, CUSTOMER__VIDEOWITHOUTANALYTICS);

		analyticsEClass = createEClass(ANALYTICS);
		createEAttribute(analyticsEClass, ANALYTICS__RECORD_RETENTION_PERIOD);
		createEAttribute(analyticsEClass,
				ANALYTICS__DOES_DATA_PROCESSING_APPLIED_ON_THE_CAMERA_TO_INCREASE_DATA_MINIMISATION);
		createEAttribute(analyticsEClass,
				ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES);
		createEAttribute(analyticsEClass, ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE);
		createEAttribute(analyticsEClass, ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED);
		createEAttribute(analyticsEClass,
				ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING);
		createEAttribute(analyticsEClass, ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION);
		createEAttribute(analyticsEClass, ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV);
		createEAttribute(analyticsEClass,
				ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(analyticsEClass, ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE);
		createEAttribute(analyticsEClass,
				ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA);

		blurringEClass = createEClass(BLURRING);
		createEAttribute(blurringEClass,
				BLURRING__DOES_THE_FACE_BLUR_FEATURE_ENABLED_FOR_INDIVIDUALS_TO_SUPPORT_INDIVIDUAL_ANONYMISATION);

		videoProcessingCloudEClass = createEClass(VIDEO_PROCESSING_CLOUD);
		createEAttribute(videoProcessingCloudEClass, VIDEO_PROCESSING_CLOUD__DATA_RETENTION);
		createEReference(videoProcessingCloudEClass, VIDEO_PROCESSING_CLOUD__STORAGELOCATION);
		createEReference(videoProcessingCloudEClass, VIDEO_PROCESSING_CLOUD__DATASHARING);
		createEReference(videoProcessingCloudEClass, VIDEO_PROCESSING_CLOUD__TEST_ON_DUMMY);
		createEReference(videoProcessingCloudEClass, VIDEO_PROCESSING_CLOUD__CONTAINERISATION);
		createEReference(videoProcessingCloudEClass, VIDEO_PROCESSING_CLOUD__AGGREGATION);
		createEAttribute(videoProcessingCloudEClass,
				VIDEO_PROCESSING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE);
		createEAttribute(videoProcessingCloudEClass,
				VIDEO_PROCESSING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(videoProcessingCloudEClass,
				VIDEO_PROCESSING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT);
		createEAttribute(videoProcessingCloudEClass,
				VIDEO_PROCESSING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(videoProcessingCloudEClass,
				VIDEO_PROCESSING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING);
		createEAttribute(videoProcessingCloudEClass,
				VIDEO_PROCESSING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEReference(videoProcessingCloudEClass, VIDEO_PROCESSING_CLOUD__GPSTRACKER);
		createEReference(videoProcessingCloudEClass, VIDEO_PROCESSING_CLOUD__VIDEOANALYTICS);
		createEReference(videoProcessingCloudEClass, VIDEO_PROCESSING_CLOUD__VIDEOWITHOUTANALYTICS);
		createEReference(videoProcessingCloudEClass, VIDEO_PROCESSING_CLOUD__WEBSITE);

		clientEClass = createEClass(CLIENT);
		createEReference(clientEClass, CLIENT__SMARTPHONE);
		createEReference(clientEClass, CLIENT__CONSENT_CHECKEDLIST);
		createEAttribute(clientEClass, CLIENT__PHONE_NUMBER);
		createEReference(clientEClass, CLIENT__AUTHENTICATION);
		createEReference(clientEClass, CLIENT__AUTHORIZATION);
		createEReference(clientEClass, CLIENT__PHONE);

		cloudServiceEClass = createEClass(CLOUD_SERVICE);
		createEAttribute(cloudServiceEClass, CLOUD_SERVICE__DATA_RETENTION);
		createEReference(cloudServiceEClass, CLOUD_SERVICE__STORAGELOCATION);
		createEReference(cloudServiceEClass, CLOUD_SERVICE__DATASHARING);
		createEReference(cloudServiceEClass, CLOUD_SERVICE__TEST_ON_DUMMY);
		createEReference(cloudServiceEClass, CLOUD_SERVICE__CONTAINERISATION);
		createEReference(cloudServiceEClass, CLOUD_SERVICE__AGGREGATION);
		createEAttribute(cloudServiceEClass,
				CLOUD_SERVICE__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE);
		createEAttribute(cloudServiceEClass,
				CLOUD_SERVICE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(cloudServiceEClass,
				CLOUD_SERVICE__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT);
		createEAttribute(cloudServiceEClass,
				CLOUD_SERVICE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(cloudServiceEClass,
				CLOUD_SERVICE__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING);
		createEAttribute(cloudServiceEClass,
				CLOUD_SERVICE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEReference(cloudServiceEClass, CLOUD_SERVICE__GPSTRACKER);
		createEReference(cloudServiceEClass, CLOUD_SERVICE__VIDEOANALYTICS);
		createEReference(cloudServiceEClass, CLOUD_SERVICE__VIDEOWITHOUTANALYTICS);
		createEReference(cloudServiceEClass, CLOUD_SERVICE__LIGHTSENSOR);
		createEReference(cloudServiceEClass, CLOUD_SERVICE__PHONE);
		createEReference(cloudServiceEClass, CLOUD_SERVICE__CAMERA);
		createEReference(cloudServiceEClass, CLOUD_SERVICE__DOORLOCK);
		createEReference(cloudServiceEClass, CLOUD_SERVICE__THERMOSTAT);

		lightSensorEClass = createEClass(LIGHT_SENSOR);
		createEAttribute(lightSensorEClass, LIGHT_SENSOR__CONNECTION);
		createEAttribute(lightSensorEClass, LIGHT_SENSOR__DATA_RETENTION);
		createEAttribute(lightSensorEClass,
				LIGHT_SENSOR__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEReference(lightSensorEClass, LIGHT_SENSOR__CLOUDSERVICE);
		createEAttribute(lightSensorEClass,
				LIGHT_SENSOR__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA);
		createEAttribute(lightSensorEClass, LIGHT_SENSOR__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE);

		phoneEClass = createEClass(PHONE);
		createEAttribute(phoneEClass, PHONE__USER_INFO_RETENTION_PERIOD);
		createEAttribute(phoneEClass,
				PHONE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES);
		createEAttribute(phoneEClass, PHONE__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD);
		createEAttribute(phoneEClass, PHONE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE);
		createEAttribute(phoneEClass, PHONE__CONNECTION);
		createEAttribute(phoneEClass,
				PHONE__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE);
		createEAttribute(phoneEClass, PHONE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEReference(phoneEClass, PHONE__USERLOCATION);
		createEReference(phoneEClass, PHONE__CLOUDSERVICE);
		createEReference(phoneEClass, PHONE__COOKIES);

		doorLockEClass = createEClass(DOOR_LOCK);
		createEReference(doorLockEClass, DOOR_LOCK__CLOUDSERVICE);
		createEAttribute(doorLockEClass,
				DOOR_LOCK__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA);
		createEAttribute(doorLockEClass, DOOR_LOCK__CONNECTION);
		createEAttribute(doorLockEClass, DOOR_LOCK__DATA_RETENTION);
		createEAttribute(doorLockEClass, DOOR_LOCK__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(doorLockEClass, DOOR_LOCK__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE);

		thermostatEClass = createEClass(THERMOSTAT);
		createEReference(thermostatEClass, THERMOSTAT__CLOUDSERVICE);
		createEAttribute(thermostatEClass,
				THERMOSTAT__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA);
		createEAttribute(thermostatEClass, THERMOSTAT__CONNECTION);
		createEAttribute(thermostatEClass, THERMOSTAT__DATA_RETENTION);
		createEAttribute(thermostatEClass,
				THERMOSTAT__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(thermostatEClass, THERMOSTAT__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE);

		cameraEClass = createEClass(CAMERA);
		createEAttribute(cameraEClass, CAMERA__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION);
		createEAttribute(cameraEClass, CAMERA__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV);
		createEAttribute(cameraEClass, CAMERA__DO_PEOPLE_AWARE_OF_BEING_RECORDED);
		createEAttribute(cameraEClass,
				CAMERA__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA);
		createEAttribute(cameraEClass, CAMERA__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION);
		createEAttribute(cameraEClass, CAMERA__ENSURE_DATA_MINIMISATION_IS_APLIED);
		createEAttribute(cameraEClass, CAMERA__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION);
		createEAttribute(cameraEClass, CAMERA__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE);
		createEAttribute(cameraEClass, CAMERA__RECORD_RETENTION_PERIOD);
		createEAttribute(cameraEClass, CAMERA__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS);
		createEAttribute(cameraEClass, CAMERA__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES);
		createEAttribute(cameraEClass, CAMERA__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE);
		createEReference(cameraEClass, CAMERA__CLOUDSERVICE);

		privacy_patternsEClass = createEClass(PRIVACY_PATTERNS);
		createEAttribute(privacy_patternsEClass, PRIVACY_PATTERNS__PRIVACY_PATTERNS);

		cookiesEClass = createEClass(COOKIES);
		createEAttribute(cookiesEClass, COOKIES__USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED);
		createEAttribute(cookiesEClass, COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED);
		createEAttribute(cookiesEClass, COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE);
		createEAttribute(cookiesEClass,
				COOKIES__CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED);
		createEAttribute(cookiesEClass,
				COOKIES__PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED);
		createEAttribute(cookiesEClass,
				COOKIES__CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC);

		// Create enums
		dataRetentionEnumEEnum = createEEnum(DATA_RETENTION_ENUM);
		patientHealthStatusEEnum = createEEnum(PATIENT_HEALTH_STATUS);
		communicationProtocolsEEnum = createEEnum(COMMUNICATION_PROTOCOLS);
		checked_ConsentEEnum = createEEnum(CHECKED_CONSENT);
		cloudStorageLocationEEnum = createEEnum(CLOUD_STORAGE_LOCATION);
		locationGranularityEEnum = createEEnum(LOCATION_GRANULARITY);
		checkedEEnum = createEEnum(CHECKED);
		cloudProviderServerEEnum = createEEnum(CLOUD_PROVIDER_SERVER);
		testOnDummyDataEEnum = createEEnum(TEST_ON_DUMMY_DATA);
		answerEEnum = createEEnum(ANSWER);

		// Create data types
		consentDataTypeEDataType = createEDataType(CONSENT_DATA_TYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		XMLTypePackage theXMLTypePackage = (XMLTypePackage) EPackage.Registry.INSTANCE
				.getEPackage(XMLTypePackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		cgMsensorEClass.getESuperTypes().add(this.getGeneralEntity());
		cgMsensorEClass.getESuperTypes().add(this.getEncryption());
		smartPhoneEClass.getESuperTypes().add(this.getGeneralEntity());
		smartPhoneEClass.getESuperTypes().add(this.getEncryption());
		smartPhoneEClass.getESuperTypes().add(this.getPrivacy_patterns());
		patientEClass.getESuperTypes().add(this.getGeneralEntity());
		patientEClass.getESuperTypes().add(this.getEncryption());
		patientEClass.getESuperTypes().add(this.getPrivacy_patterns());
		nurseEClass.getESuperTypes().add(this.getGeneralEntity());
		doctorEClass.getESuperTypes().add(this.getGeneralEntity());
		doctorEClass.getESuperTypes().add(this.getEncryption());
		newEClass7EClass.getESuperTypes().add(this.getGeneralEntity());
		cloudEClass.getESuperTypes().add(this.getGeneralEntity());
		cloudEClass.getESuperTypes().add(this.getEncryption());
		websiteEClass.getESuperTypes().add(this.getGeneralEntity());
		websiteEClass.getESuperTypes().add(this.getEncryption());
		hospitalEClass.getESuperTypes().add(this.getGeneralEntity());
		researcherEClass.getESuperTypes().add(this.getGeneralEntity());
		researcherEClass.getESuperTypes().add(this.getEncryption());
		medicalRecordEClass.getESuperTypes().add(this.getGeneralEntity());
		consent_CheckedListEClass.getESuperTypes().add(this.getGeneralEntity());
		storageLocationEClass.getESuperTypes().add(this.getGeneralEntity());
		userLocationEClass.getESuperTypes().add(this.getGeneralEntity());
		riskCodeEClass.getESuperTypes().add(this.getGeneralEntity());
		authenticationEClass.getESuperTypes().add(this.getGeneralEntity());
		authorizationEClass.getESuperTypes().add(this.getGeneralEntity());
		firewallEClass.getESuperTypes().add(this.getGeneralEntity());
		encryptionEClass.getESuperTypes().add(this.getGeneralEntity());
		dataSharingEClass.getESuperTypes().add(this.getGeneralEntity());
		warningEClass.getESuperTypes().add(this.getGeneralEntity());
		test_on_dummyEClass.getESuperTypes().add(this.getGeneralEntity());
		containerisationEClass.getESuperTypes().add(this.getGeneralEntity());
		aggregationEClass.getESuperTypes().add(this.getGeneralEntity());
		computerBrowserEClass.getESuperTypes().add(this.getGeneralEntity());
		computerBrowserEClass.getESuperTypes().add(this.getEncryption());
		pharmacyCloudoldEClass.getESuperTypes().add(this.getGeneralEntity());
		pharmacyCloudoldEClass.getESuperTypes().add(this.getEncryption());
		shippingCloudEClass.getESuperTypes().add(this.getGeneralEntity());
		shippingCloudEClass.getESuperTypes().add(this.getEncryption());
		shippingCloudEClass.getESuperTypes().add(this.getPrivacy_patterns());
		webhostingCloudEClass.getESuperTypes().add(this.getGeneralEntity());
		webhostingCloudEClass.getESuperTypes().add(this.getEncryption());
		webhostingCloudEClass.getESuperTypes().add(this.getPrivacy_patterns());
		paymentCloudEClass.getESuperTypes().add(this.getGeneralEntity());
		paymentCloudEClass.getESuperTypes().add(this.getEncryption());
		paymentCloudEClass.getESuperTypes().add(this.getPrivacy_patterns());
		socialNetworkCloudEClass.getESuperTypes().add(this.getGeneralEntity());
		socialNetworkCloudEClass.getESuperTypes().add(this.getEncryption());
		socialNetworkCloudEClass.getESuperTypes().add(this.getPrivacy_patterns());
		realTimeBiddingCloudEClass.getESuperTypes().add(this.getGeneralEntity());
		realTimeBiddingCloudEClass.getESuperTypes().add(this.getEncryption());
		realTimeBiddingCloudEClass.getESuperTypes().add(this.getPrivacy_patterns());
		webBrowserEClass.getESuperTypes().add(this.getGeneralEntity());
		webBrowserEClass.getESuperTypes().add(this.getPrivacy_patterns());
		webBrowserEClass.getESuperTypes().add(this.getEncryption());
		cloudForPharmacyEClass.getESuperTypes().add(this.getGeneralEntity());
		cloudForPharmacyEClass.getESuperTypes().add(this.getPrivacy_patterns());
		cloudForPharmacyEClass.getESuperTypes().add(this.getEncryption());
		busEClass.getESuperTypes().add(this.getGeneralEntity());
		gpsTrackerEClass.getESuperTypes().add(this.getGeneralEntity());
		videoAnalyticsEClass.getESuperTypes().add(this.getGeneralEntity());
		videoAnalyticsEClass.getESuperTypes().add(this.getEncryption());
		videoWithoutAnalyticsEClass.getESuperTypes().add(this.getGeneralEntity());
		videoWithoutAnalyticsEClass.getESuperTypes().add(this.getEncryption());
		driverEClass.getESuperTypes().add(this.getGeneralEntity());
		customerEClass.getESuperTypes().add(this.getGeneralEntity());
		analyticsEClass.getESuperTypes().add(this.getGeneralEntity());
		blurringEClass.getESuperTypes().add(this.getGeneralEntity());
		videoProcessingCloudEClass.getESuperTypes().add(this.getGeneralEntity());
		videoProcessingCloudEClass.getESuperTypes().add(this.getEncryption());
		clientEClass.getESuperTypes().add(this.getGeneralEntity());
		clientEClass.getESuperTypes().add(this.getEncryption());
		clientEClass.getESuperTypes().add(this.getPrivacy_patterns());
		cloudServiceEClass.getESuperTypes().add(this.getGeneralEntity());
		cloudServiceEClass.getESuperTypes().add(this.getEncryption());
		cloudServiceEClass.getESuperTypes().add(this.getPrivacy_patterns());
		lightSensorEClass.getESuperTypes().add(this.getGeneralEntity());
		lightSensorEClass.getESuperTypes().add(this.getEncryption());
		lightSensorEClass.getESuperTypes().add(this.getPrivacy_patterns());
		phoneEClass.getESuperTypes().add(this.getGeneralEntity());
		phoneEClass.getESuperTypes().add(this.getEncryption());
		phoneEClass.getESuperTypes().add(this.getPrivacy_patterns());
		doorLockEClass.getESuperTypes().add(this.getGeneralEntity());
		doorLockEClass.getESuperTypes().add(this.getEncryption());
		doorLockEClass.getESuperTypes().add(this.getPrivacy_patterns());
		thermostatEClass.getESuperTypes().add(this.getGeneralEntity());
		thermostatEClass.getESuperTypes().add(this.getEncryption());
		thermostatEClass.getESuperTypes().add(this.getPrivacy_patterns());
		cameraEClass.getESuperTypes().add(this.getGeneralEntity());
		cameraEClass.getESuperTypes().add(this.getEncryption());
		cameraEClass.getESuperTypes().add(this.getPrivacy_patterns());
		cookiesEClass.getESuperTypes().add(this.getGeneralEntity());

		// Initialize classes, features, and operations; add parameters
		initEClass(generalEntityEClass, GeneralEntity.class, "GeneralEntity", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getGeneralEntity_Name(), ecorePackage.getEString(), "name", null, 0, 1, GeneralEntity.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cgMsensorEClass, CGMsensor.class, "CGMsensor", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCGMsensor_Smartphone(), this.getSmartPhone(), this.getSmartPhone_Cgmsensor(), "smartphone",
				null, 0, 1, CGMsensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCGMsensor_Glucose_amount(), theXMLTypePackage.getInt(), "Glucose_amount", null, 0, 1,
				CGMsensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCGMsensor_Connection(), this.getCommunicationProtocols(), "Connection", null, 0, 1,
				CGMsensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCGMsensor_DataRetention(), this.getDataRetentionEnum(), "DataRetention", null, 0, 1,
				CGMsensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCGMsensor_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", null, 0, 1,
				CGMsensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getCGMsensor_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				null, 0, 1, CGMsensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(smartPhoneEClass, SmartPhone.class, "SmartPhone", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSmartPhone_Cgmsensor(), this.getCGMsensor(), this.getCGMsensor_Smartphone(), "cgmsensor",
				null, 0, 1, SmartPhone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSmartPhone_Cloud(), this.getCloud(), this.getCloud_Smartphone(), "cloud", null, 0, 1,
				SmartPhone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSmartPhone_Blood_Sugar_Level(), this.getPatientHealthStatus(), "Blood_Sugar_Level", null, 0,
				1, SmartPhone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getSmartPhone_Connection(), this.getCommunicationProtocols(), "Connection", "Blutooth_and_WiFi",
				0, 1, SmartPhone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getSmartPhone_Patient_info_Retention_Period(), this.getDataRetentionEnum(),
				"Patient_info_Retention_Period", null, 0, 1, SmartPhone.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSmartPhone_Userlocation(), this.getUserLocation(), null, "userlocation", null, 0, -1,
				SmartPhone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getSmartPhone_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate(),
				this.getAnswer(),
				"Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate",
				"Not_Answered", 0, 1, SmartPhone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSmartPhone_Are_you_planning_to_send_all_the_data_to_the_cloud(), this.getAnswer(),
				"Are_you_planning_to_send_all_the_data_to_the_cloud", "Not_Answered", 0, 1, SmartPhone.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSmartPhone_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(),
				this.getAnswer(), "Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0,
				1, SmartPhone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getSmartPhone_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered",
				0, 1, SmartPhone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getSmartPhone_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				null, 0, 1, SmartPhone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSmartPhone_Smartphone(), this.getSmartPhone(), null, "smartphone", null, 0, -1,
				SmartPhone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSmartPhone_Pharmacycloud(), this.getPharmacyCloudold(), null, "pharmacycloud", null, 0, -1,
				SmartPhone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSmartPhone_Cloudforpharmacy(), this.getCloudForPharmacy(),
				this.getCloudForPharmacy_Smartphone(), "cloudforpharmacy", null, 0, 1, SmartPhone.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getSmartPhone_Cookies(), this.getCookies(), null, "cookies", null, 0, -1, SmartPhone.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(patientEClass, Patient.class, "Patient", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPatient_Smartphone(), this.getSmartPhone(), null, "smartphone", null, 0, -1, Patient.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatient_Cgmsensor(), this.getCGMsensor(), null, "cgmsensor", null, 0, -1, Patient.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatient_Doctor(), this.getDoctor(), this.getDoctor_Patient(), "doctor", null, 0, 1,
				Patient.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatient_Medicalrecord(), this.getMedicalRecord(), null, "medicalrecord", null, 0, -1,
				Patient.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPatient_Age(), theXMLTypePackage.getInt(), "Age", null, 0, 1, Patient.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatient_Consent_checkedlist(), this.getConsent_CheckedList(), null, "consent_checkedlist",
				null, 0, -1, Patient.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPatient_PhoneNumber(), ecorePackage.getEString(), "PhoneNumber", null, 0, 1, Patient.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatient_Authentication(), this.getAuthentication(), null, "authentication", null, 0, -1,
				Patient.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatient_Authorization(), this.getAuthorization(), null, "authorization", null, 0, -1,
				Patient.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatient_Datasharing(), this.getDataSharing(), null, "datasharing", null, 0, -1, Patient.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatient_Computerbrowser(), this.getComputerBrowser(), null, "computerbrowser", null, 0, -1,
				Patient.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPatient_Webbrowser(), this.getWebBrowser(), null, "webbrowser", null, 0, -1, Patient.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(nurseEClass, Nurse.class, "Nurse", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(doctorEClass, Doctor.class, "Doctor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDoctor_Patient(), this.getPatient(), this.getPatient_Doctor(), "patient", null, 0, 1,
				Doctor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDoctor_Website(), this.getWebsite(), this.getWebsite_Doctor(), "website", null, 0, 1,
				Doctor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDoctor_Specialty(), ecorePackage.getEString(), "Specialty", null, 0, 1, Doctor.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDoctor_Authentication(), this.getAuthentication(), null, "authentication", null, 0, -1,
				Doctor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDoctor_Authorization(), this.getAuthorization(), null, "authorization", null, 0, -1,
				Doctor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getDoctor_Are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data(),
				this.getAnswer(),
				"Are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data", null, 0, 1,
				Doctor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(newEClass7EClass, NewEClass7.class, "NewEClass7", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(cloudEClass, Cloud.class, "Cloud", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCloud_Smartphone(), this.getSmartPhone(), this.getSmartPhone_Cloud(), "smartphone", null, 0,
				1, Cloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloud_Website(), this.getWebsite(), this.getWebsite_Cloud(), "website", null, 0, -1,
				Cloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCloud_DataRetention(), this.getDataRetentionEnum(), "DataRetention", "NotAccepted", 0, 1,
				Cloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getCloud_Storagelocation(), this.getStorageLocation(), null, "storagelocation", null, 0, -1,
				Cloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloud_Datasharing(), this.getDataSharing(), null, "datasharing", null, 0, -1, Cloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloud_Test_on_dummy(), this.getTest_on_dummy(), null, "test_on_dummy", null, 0, -1,
				Cloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloud_Containerisation(), this.getContainerisation(), null, "containerisation", null, 0, -1,
				Cloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloud_Aggregation(), this.getAggregation(), null, "aggregation", null, 0, -1, Cloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose(), this.getAnswer(),
				"Are_you_collecting_data_that_are_not_needed_for_the_purpose", "Not_Answered", 0, 1, Cloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(), this.getAnswer(),
				"Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0, 1, Cloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent(),
				this.getAnswer(), "Are_you_sharing_data_with_other_parties_without_having_data_subject_consent",
				"Not_Answered", 0, 1, Cloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(), this.getAnswer(),
				"Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered", 0, 1, Cloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(),
				this.getAnswer(),
				"Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing",
				"Not_Answered", 0, 1, Cloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				"Not_Answered", 0, 1, Cloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloud_Medicalrecord(), this.getMedicalRecord(), null, "medicalrecord", null, 0, -1,
				Cloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(websiteEClass, Website.class, "Website", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getWebsite_Cloud(), this.getCloud(), this.getCloud_Website(), "cloud", null, 0, 1, Website.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebsite_Doctor(), this.getDoctor(), this.getDoctor_Website(), "doctor", null, 0, 1,
				Website.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebsite_Researcher(), this.getResearcher(), this.getResearcher_Website(), "researcher", null,
				0, 1, Website.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWebsite_URL(), ecorePackage.getEString(), "URL", null, 0, 1, Website.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebsite_Videoprocessingcloud(), this.getVideoProcessingCloud(),
				this.getVideoProcessingCloud_Website(), "videoprocessingcloud", null, 0, 1, Website.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebsite_Cookies(), this.getCookies(), null, "cookies", null, 0, -1, Website.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(hospitalEClass, Hospital.class, "Hospital", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getHospital_Patient(), this.getPatient(), null, "patient", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Doctor(), this.getDoctor(), null, "doctor", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Researcher(), this.getResearcher(), null, "researcher", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Nurse(), this.getNurse(), null, "nurse", null, 0, -1, Hospital.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getHospital_Cloud(), this.getCloud(), null, "cloud", null, 0, -1, Hospital.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getHospital_Website(), this.getWebsite(), null, "website", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Smartphone(), this.getSmartPhone(), null, "smartphone", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Cgmsensor(), this.getCGMsensor(), null, "cgmsensor", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Medicalrecord(), this.getMedicalRecord(), null, "medicalrecord", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Consent_checkedlist(), this.getConsent_CheckedList(), null, "consent_checkedlist",
				null, 0, -1, Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Storagelocation(), this.getStorageLocation(), null, "storagelocation", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Userlocation(), this.getUserLocation(), null, "userlocation", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Riskcode(), this.getRiskCode(), null, "riskcode", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Encryption(), this.getEncryption(), null, "encryption", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Datasharing(), this.getDataSharing(), null, "datasharing", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Warning(), this.getWarning(), null, "warning", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Test_on_dummy(), this.getTest_on_dummy(), null, "test_on_dummy", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Containerisation(), this.getContainerisation(), null, "containerisation", null, 0,
				-1, Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Aggregation(), this.getAggregation(), null, "aggregation", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Computerbrowser(), this.getComputerBrowser(), null, "computerbrowser", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Pharmacycloud(), this.getPharmacyCloudold(), null, "pharmacycloud", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Shippingcloud(), this.getShippingCloud(), null, "shippingcloud", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Webhostingcloud(), this.getWebhostingCloud(), null, "webhostingcloud", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Paymentcloud(), this.getPaymentCloud(), null, "paymentcloud", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Socialnetworkcloud(), this.getSocialNetworkCloud(), null, "socialnetworkcloud", null,
				0, -1, Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Webbrowser(), this.getWebBrowser(), null, "webbrowser", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Cloudforpharmacy(), this.getCloudForPharmacy(), null, "cloudforpharmacy", null, 0,
				-1, Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Realtimebiddingcloud(), this.getRealTimeBiddingCloud(), null, "realtimebiddingcloud",
				null, 0, -1, Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Gpstracker(), this.getGPSTracker(), null, "gpstracker", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Bus(), this.getBus(), null, "bus", null, 0, -1, Hospital.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getHospital_Driver(), this.getDriver(), null, "driver", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Customer(), this.getCustomer(), null, "customer", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Videoanalytics(), this.getVideoAnalytics(), null, "videoanalytics", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Analytics(), this.getAnalytics(), null, "analytics", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Blurring(), this.getBlurring(), null, "blurring", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Videoprocessingcloud(), this.getVideoProcessingCloud(), null, "videoprocessingcloud",
				null, 0, -1, Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Videowithoutanalytics(), this.getVideoWithoutAnalytics(), null,
				"videowithoutanalytics", null, 0, -1, Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Client(), this.getClient(), null, "client", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Cloudservice(), this.getCloudService(), null, "cloudservice", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Lightsensor(), this.getLightSensor(), null, "lightsensor", null, 0, -1,
				Hospital.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Phone(), this.getPhone(), null, "phone", null, 0, -1, Hospital.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getHospital_Thermostat(), this.getThermostat(), null, "thermostat", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Doorlock(), this.getDoorLock(), null, "doorlock", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Camera(), this.getCamera(), null, "camera", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHospital_Cookies(), this.getCookies(), null, "cookies", null, 0, -1, Hospital.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(researcherEClass, Researcher.class, "Researcher", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getResearcher_Website(), this.getWebsite(), this.getWebsite_Researcher(), "website", null, 0, 1,
				Researcher.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getResearcher_Authentication(), this.getAuthentication(), null, "authentication", null, 0, -1,
				Researcher.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getResearcher_Authorization(), this.getAuthorization(), null, "authorization", null, 0, -1,
				Researcher.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getResearcher_Are_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data(),
				this.getAnswer(), "Are_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data",
				null, 0, 1, Researcher.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getResearcher_Are_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name(),
				this.getAnswer(),
				"Are_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name",
				null, 0, 1, Researcher.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(medicalRecordEClass, MedicalRecord.class, "MedicalRecord", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMedicalRecord_RecordRetentionPeriod(), this.getDataRetentionEnum(), "RecordRetentionPeriod",
				"NotAccepted", 0, 1, MedicalRecord.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(consent_CheckedListEClass, Consent_CheckedList.class, "Consent_CheckedList", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getConsent_CheckedList_Capture_age_authorization_if_age_is_less_than_16(),
				this.getChecked_Consent(), "Capture_age_authorization_if_age_is_less_than_16", "No", 0, 1,
				Consent_CheckedList.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getConsent_CheckedList_Capture_withdrawal_log(), this.getChecked_Consent(),
				"Capture_withdrawal_log", null, 0, 1, Consent_CheckedList.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getConsent_CheckedList_Capture_log_Terms_of_use_AND_consent_to_process(),
				this.getChecked_Consent(), "Capture_log_Terms_of_use_AND_consent_to_process", null, 0, 1,
				Consent_CheckedList.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getConsent_CheckedList_Capture_consent_to_process_special_category_data(),
				this.getChecked_Consent(), "Capture_consent_to_process_special_category_data", null, 0, 1,
				Consent_CheckedList.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getConsent_CheckedList_Capture_consent_to_term_of_use(), this.getChecked_Consent(),
				"Capture_consent_to_term_of_use", null, 0, 1, Consent_CheckedList.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getConsent_CheckedList_Surface_privacy_notice(), this.getChecked_Consent(),
				"Surface_privacy_notice", null, 0, 1, Consent_CheckedList.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getConsent_CheckedList_Capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used(),
				this.getChecked_Consent(), "Capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used",
				null, 0, 1, Consent_CheckedList.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(storageLocationEClass, StorageLocation.class, "StorageLocation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getStorageLocation_Cloud_provider_and_server_location(), this.getCloudProviderServer(),
				"Cloud_provider_and_server_location", null, 0, 1, StorageLocation.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(userLocationEClass, UserLocation.class, "UserLocation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getUserLocation_Location(), this.getLocationGranularity(), "Location", null, 0, 1,
				UserLocation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getUserLocation_Are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed(),
				this.getAnswer(),
				"Are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed",
				null, 0, 1, UserLocation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(riskCodeEClass, RiskCode.class, "RiskCode", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(authenticationEClass, Authentication.class, "Authentication", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAuthentication_Authenticated(), this.getChecked(), "Authenticated", null, 0, 1,
				Authentication.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(authorizationEClass, Authorization.class, "Authorization", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAuthorization_Authorized(), this.getChecked(), "Authorized", null, 0, 1, Authorization.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(firewallEClass, Firewall.class, "Firewall", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(encryptionEClass, Encryption.class, "Encryption", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEncryption_EncryptedData(), this.getChecked(), "EncryptedData", null, 0, 1, Encryption.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(dataSharingEClass, DataSharing.class, "DataSharing", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDataSharing_Apply_anonymisation_for_researcher(), this.getChecked(),
				"Apply_anonymisation_for_researcher", "No", 0, 1, DataSharing.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDataSharing_Ensure_accessControl(), this.getChecked(), "Ensure_accessControl", null, 0, 1,
				DataSharing.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(warningEClass, Warning.class, "Warning", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(test_on_dummyEClass, Test_on_dummy.class, "Test_on_dummy", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTest_on_dummy_Testing_on_dummy_data(), this.getTestOnDummyData(), "Testing_on_dummy_data",
				" Testing_phase_and_dummy_data", 0, 1, Test_on_dummy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(containerisationEClass, Containerisation.class, "Containerisation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(aggregationEClass, Aggregation.class, "Aggregation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(newEClass26EClass, NewEClass26.class, "NewEClass26", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(computerBrowserEClass, ComputerBrowser.class, "ComputerBrowser", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getComputerBrowser_Cgmsensor(), this.getCGMsensor(), null, "cgmsensor", null, 0, 1,
				ComputerBrowser.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getComputerBrowser_Cloud(), this.getCloud(), null, "cloud", null, 0, 1, ComputerBrowser.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getComputerBrowser_Patient_info_Retention_Period(), this.getDataRetentionEnum(),
				"Patient_info_Retention_Period", null, 0, 1, ComputerBrowser.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getComputerBrowser_Userlocation(), this.getUserLocation(), null, "userlocation", null, 0, -1,
				ComputerBrowser.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getComputerBrowser_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate(),
				this.getAnswer(),
				"Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate",
				"Not_Answered", 0, 1, ComputerBrowser.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getComputerBrowser_Are_you_planning_to_send_all_the_data_to_the_cloud(), this.getAnswer(),
				"Are_you_planning_to_send_all_the_data_to_the_cloud", "Not_Answered", 0, 1, ComputerBrowser.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getComputerBrowser_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(),
				this.getAnswer(), "Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0,
				1, ComputerBrowser.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getComputerBrowser_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered",
				0, 1, ComputerBrowser.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getComputerBrowser_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				null, 0, 1, ComputerBrowser.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getComputerBrowser_Pharmacycloud(), this.getPharmacyCloudold(),
				this.getPharmacyCloudold_Computerbrowser(), "pharmacycloud", null, 0, 1, ComputerBrowser.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(newEClass28EClass, NewEClass28.class, "NewEClass28", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(pharmacyCloudoldEClass, PharmacyCloudold.class, "PharmacyCloudold", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPharmacyCloudold_Smartphone(), this.getSmartPhone(), null, "smartphone", null, 0, 1,
				PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPharmacyCloudold_Website(), this.getWebsite(), null, "website", null, 0, -1,
				PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPharmacyCloudold_DataRetention(), this.getDataRetentionEnum(), "DataRetention", "NotAccepted",
				0, 1, PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPharmacyCloudold_Storagelocation(), this.getStorageLocation(), null, "storagelocation", null,
				0, -1, PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPharmacyCloudold_Datasharing(), this.getDataSharing(), null, "datasharing", null, 0, -1,
				PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPharmacyCloudold_Test_on_dummy(), this.getTest_on_dummy(), null, "test_on_dummy", null, 0, -1,
				PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPharmacyCloudold_Containerisation(), this.getContainerisation(), null, "containerisation",
				null, 0, -1, PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPharmacyCloudold_Aggregation(), this.getAggregation(), null, "aggregation", null, 0, -1,
				PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPharmacyCloudold_Are_you_collecting_data_that_are_not_needed_for_the_purpose(),
				this.getAnswer(), "Are_you_collecting_data_that_are_not_needed_for_the_purpose", "Not_Answered", 0, 1,
				PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPharmacyCloudold_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(),
				this.getAnswer(), "Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0,
				1, PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getPharmacyCloudold_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent(),
				this.getAnswer(), "Are_you_sharing_data_with_other_parties_without_having_data_subject_consent",
				"Not_Answered", 0, 1, PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPharmacyCloudold_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered",
				0, 1, PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getPharmacyCloudold_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(),
				this.getAnswer(),
				"Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing",
				"Not_Answered", 0, 1, PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getPharmacyCloudold_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				"Not_Answered", 0, 1, PharmacyCloudold.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPharmacyCloudold_Computerbrowser(), this.getComputerBrowser(),
				this.getComputerBrowser_Pharmacycloud(), "computerbrowser", null, 0, 1, PharmacyCloudold.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(shippingCloudEClass, ShippingCloud.class, "ShippingCloud", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getShippingCloud_Smartphone(), this.getSmartPhone(), null, "smartphone", null, 0, 1,
				ShippingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getShippingCloud_Website(), this.getWebsite(), null, "website", null, 0, -1, ShippingCloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getShippingCloud_DataRetention(), this.getDataRetentionEnum(), "DataRetention", "NotAccepted", 0,
				1, ShippingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getShippingCloud_Storagelocation(), this.getStorageLocation(), null, "storagelocation", null, 0,
				-1, ShippingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getShippingCloud_Datasharing(), this.getDataSharing(), null, "datasharing", null, 0, -1,
				ShippingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getShippingCloud_Test_on_dummy(), this.getTest_on_dummy(), null, "test_on_dummy", null, 0, -1,
				ShippingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getShippingCloud_Containerisation(), this.getContainerisation(), null, "containerisation", null,
				0, -1, ShippingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getShippingCloud_Aggregation(), this.getAggregation(), null, "aggregation", null, 0, -1,
				ShippingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getShippingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose(), this.getAnswer(),
				"Are_you_collecting_data_that_are_not_needed_for_the_purpose", "Not_Answered", 0, 1,
				ShippingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getShippingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(),
				this.getAnswer(), "Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0,
				1, ShippingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getShippingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent(),
				this.getAnswer(), "Are_you_sharing_data_with_other_parties_without_having_data_subject_consent",
				"Not_Answered", 0, 1, ShippingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getShippingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered",
				0, 1, ShippingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getShippingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(),
				this.getAnswer(),
				"Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing",
				"Not_Answered", 0, 1, ShippingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getShippingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				"Not_Answered", 0, 1, ShippingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getShippingCloud_Cloudforpharmacy(), this.getCloudForPharmacy(),
				this.getCloudForPharmacy_Shippingcloud(), "cloudforpharmacy", null, 0, 1, ShippingCloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(webhostingCloudEClass, WebhostingCloud.class, "WebhostingCloud", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getWebhostingCloud_Smartphone(), this.getSmartPhone(), null, "smartphone", null, 0, 1,
				WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebhostingCloud_Website(), this.getWebsite(), null, "website", null, 0, -1,
				WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWebhostingCloud_DataRetention(), this.getDataRetentionEnum(), "DataRetention", "NotAccepted",
				0, 1, WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebhostingCloud_Storagelocation(), this.getStorageLocation(), null, "storagelocation", null,
				0, -1, WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebhostingCloud_Datasharing(), this.getDataSharing(), null, "datasharing", null, 0, -1,
				WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebhostingCloud_Test_on_dummy(), this.getTest_on_dummy(), null, "test_on_dummy", null, 0, -1,
				WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebhostingCloud_Containerisation(), this.getContainerisation(), null, "containerisation",
				null, 0, -1, WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebhostingCloud_Aggregation(), this.getAggregation(), null, "aggregation", null, 0, -1,
				WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWebhostingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose(),
				this.getAnswer(), "Are_you_collecting_data_that_are_not_needed_for_the_purpose", "Not_Answered", 0, 1,
				WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getWebhostingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(),
				this.getAnswer(), "Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0,
				1, WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getWebhostingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent(),
				this.getAnswer(), "Are_you_sharing_data_with_other_parties_without_having_data_subject_consent",
				"Not_Answered", 0, 1, WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWebhostingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered",
				0, 1, WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getWebhostingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(),
				this.getAnswer(),
				"Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing",
				"Not_Answered", 0, 1, WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getWebhostingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				"Not_Answered", 0, 1, WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebhostingCloud_Cloudforpharmacy(), this.getCloudForPharmacy(),
				this.getCloudForPharmacy_Webhostingcloud(), "cloudforpharmacy", null, 0, 1, WebhostingCloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebhostingCloud_Socialnetworkcloud(), this.getSocialNetworkCloud(),
				this.getSocialNetworkCloud_Webhostingcloud(), "socialnetworkcloud", null, 0, 1, WebhostingCloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebhostingCloud_Realtimebiddingcloud(), this.getRealTimeBiddingCloud(),
				this.getRealTimeBiddingCloud_Webhostingcloud(), "realtimebiddingcloud", null, 0, 1,
				WebhostingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(paymentCloudEClass, PaymentCloud.class, "PaymentCloud", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPaymentCloud_Smartphone(), this.getSmartPhone(), null, "smartphone", null, 0, 1,
				PaymentCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPaymentCloud_Website(), this.getWebsite(), null, "website", null, 0, -1, PaymentCloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPaymentCloud_DataRetention(), this.getDataRetentionEnum(), "DataRetention", "NotAccepted", 0,
				1, PaymentCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getPaymentCloud_Storagelocation(), this.getStorageLocation(), null, "storagelocation", null, 0,
				-1, PaymentCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPaymentCloud_Datasharing(), this.getDataSharing(), null, "datasharing", null, 0, -1,
				PaymentCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPaymentCloud_Test_on_dummy(), this.getTest_on_dummy(), null, "test_on_dummy", null, 0, -1,
				PaymentCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPaymentCloud_Containerisation(), this.getContainerisation(), null, "containerisation", null,
				0, -1, PaymentCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPaymentCloud_Aggregation(), this.getAggregation(), null, "aggregation", null, 0, -1,
				PaymentCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPaymentCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose(), this.getAnswer(),
				"Are_you_collecting_data_that_are_not_needed_for_the_purpose", "Not_Answered", 0, 1, PaymentCloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPaymentCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(),
				this.getAnswer(), "Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0,
				1, PaymentCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPaymentCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent(),
				this.getAnswer(), "Are_you_sharing_data_with_other_parties_without_having_data_subject_consent",
				"Not_Answered", 0, 1, PaymentCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPaymentCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered",
				0, 1, PaymentCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getPaymentCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(),
				this.getAnswer(),
				"Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing",
				"Not_Answered", 0, 1, PaymentCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getPaymentCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				"Not_Answered", 0, 1, PaymentCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPaymentCloud_Cloudforpharmacy(), this.getCloudForPharmacy(),
				this.getCloudForPharmacy_Paymentcloud(), "cloudforpharmacy", null, 0, 1, PaymentCloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(socialNetworkCloudEClass, SocialNetworkCloud.class, "SocialNetworkCloud", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSocialNetworkCloud_Smartphone(), this.getSmartPhone(), null, "smartphone", null, 0, 1,
				SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSocialNetworkCloud_Website(), this.getWebsite(), null, "website", null, 0, -1,
				SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSocialNetworkCloud_DataRetention(), this.getDataRetentionEnum(), "DataRetention",
				"NotAccepted", 0, 1, SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSocialNetworkCloud_Storagelocation(), this.getStorageLocation(), null, "storagelocation",
				null, 0, -1, SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSocialNetworkCloud_Datasharing(), this.getDataSharing(), null, "datasharing", null, 0, -1,
				SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSocialNetworkCloud_Test_on_dummy(), this.getTest_on_dummy(), null, "test_on_dummy", null, 0,
				-1, SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSocialNetworkCloud_Containerisation(), this.getContainerisation(), null, "containerisation",
				null, 0, -1, SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSocialNetworkCloud_Aggregation(), this.getAggregation(), null, "aggregation", null, 0, -1,
				SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSocialNetworkCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose(),
				this.getAnswer(), "Are_you_collecting_data_that_are_not_needed_for_the_purpose", "Not_Answered", 0, 1,
				SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getSocialNetworkCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(),
				this.getAnswer(), "Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0,
				1, SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getSocialNetworkCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent(),
				this.getAnswer(), "Are_you_sharing_data_with_other_parties_without_having_data_subject_consent",
				"Not_Answered", 0, 1, SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSocialNetworkCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered",
				0, 1, SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getSocialNetworkCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(),
				this.getAnswer(),
				"Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing",
				"Not_Answered", 0, 1, SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getSocialNetworkCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				"Not_Answered", 0, 1, SocialNetworkCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSocialNetworkCloud_Cloudforpharmacy(), this.getCloudForPharmacy(),
				this.getCloudForPharmacy_Socialnetworkcloud(), "cloudforpharmacy", null, 0, 1, SocialNetworkCloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSocialNetworkCloud_Webhostingcloud(), this.getWebhostingCloud(),
				this.getWebhostingCloud_Socialnetworkcloud(), "webhostingcloud", null, 0, 1, SocialNetworkCloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(realTimeBiddingCloudEClass, RealTimeBiddingCloud.class, "RealTimeBiddingCloud", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRealTimeBiddingCloud_Smartphone(), this.getSmartPhone(), null, "smartphone", null, 0, 1,
				RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRealTimeBiddingCloud_Website(), this.getWebsite(), null, "website", null, 0, -1,
				RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRealTimeBiddingCloud_DataRetention(), this.getDataRetentionEnum(), "DataRetention",
				"NotAccepted", 0, 1, RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRealTimeBiddingCloud_Storagelocation(), this.getStorageLocation(), null, "storagelocation",
				null, 0, -1, RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRealTimeBiddingCloud_Datasharing(), this.getDataSharing(), null, "datasharing", null, 0, -1,
				RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRealTimeBiddingCloud_Test_on_dummy(), this.getTest_on_dummy(), null, "test_on_dummy", null, 0,
				-1, RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRealTimeBiddingCloud_Containerisation(), this.getContainerisation(), null, "containerisation",
				null, 0, -1, RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRealTimeBiddingCloud_Aggregation(), this.getAggregation(), null, "aggregation", null, 0, -1,
				RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRealTimeBiddingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose(),
				this.getAnswer(), "Are_you_collecting_data_that_are_not_needed_for_the_purpose", "Not_Answered", 0, 1,
				RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRealTimeBiddingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(),
				this.getAnswer(), "Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0,
				1, RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getRealTimeBiddingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent(),
				this.getAnswer(), "Are_you_sharing_data_with_other_parties_without_having_data_subject_consent",
				"Not_Answered", 0, 1, RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRealTimeBiddingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered",
				0, 1, RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getRealTimeBiddingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(),
				this.getAnswer(),
				"Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing",
				"Not_Answered", 0, 1, RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getRealTimeBiddingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				"Not_Answered", 0, 1, RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRealTimeBiddingCloud_Webhostingcloud(), this.getWebhostingCloud(),
				this.getWebhostingCloud_Realtimebiddingcloud(), "webhostingcloud", null, 0, 1,
				RealTimeBiddingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(webBrowserEClass, WebBrowser.class, "WebBrowser", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getWebBrowser_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(),
				this.getAnswer(), "Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0,
				1, WebBrowser.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getWebBrowser_Are_you_planning_to_send_all_the_data_to_the_cloud(), this.getAnswer(),
				"Are_you_planning_to_send_all_the_data_to_the_cloud", "Not_Answered", 0, 1, WebBrowser.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWebBrowser_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered",
				0, 1, WebBrowser.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getWebBrowser_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				null, 0, 1, WebBrowser.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWebBrowser_Patient_info_Retention_Period(), this.getDataRetentionEnum(),
				"Patient_info_Retention_Period", null, 0, 1, WebBrowser.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getWebBrowser_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate(),
				this.getAnswer(),
				"Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate",
				"Not_Answered", 0, 1, WebBrowser.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebBrowser_Userlocation(), this.getUserLocation(), null, "userlocation", null, 0, -1,
				WebBrowser.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWebBrowser_Cloudforpharmacy(), this.getCloudForPharmacy(),
				this.getCloudForPharmacy_Webbrowser(), "cloudforpharmacy", null, 0, 1, WebBrowser.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getWebBrowser_Cookies(), this.getCookies(), null, "cookies", null, 0, -1, WebBrowser.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cloudForPharmacyEClass, CloudForPharmacy.class, "CloudForPharmacy", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCloudForPharmacy_Smartphone(), this.getSmartPhone(), this.getSmartPhone_Cloudforpharmacy(),
				"smartphone", null, 0, 1, CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudForPharmacy_Webbrowser(), this.getWebBrowser(), this.getWebBrowser_Cloudforpharmacy(),
				"webbrowser", null, 0, 1, CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudForPharmacy_Storagelocation(), this.getStorageLocation(), null, "storagelocation", null,
				0, -1, CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudForPharmacy_Test_on_dummy(), this.getTest_on_dummy(), null, "test_on_dummy", null, 0, -1,
				CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudForPharmacy_Containerisation(), this.getContainerisation(), null, "containerisation",
				null, 0, -1, CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudForPharmacy_Aggregation(), this.getAggregation(), null, "aggregation", null, 0, -1,
				CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudForPharmacy_Datasharing(), this.getDataSharing(), null, "datasharing", null, 0, -1,
				CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getCloudForPharmacy_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(),
				this.getAnswer(),
				"Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing",
				"Not_Answered", 0, 1, CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCloudForPharmacy_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(),
				this.getAnswer(), "Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0,
				1, CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCloudForPharmacy_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered",
				0, 1, CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getCloudForPharmacy_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent(),
				this.getAnswer(), "Are_you_sharing_data_with_other_parties_without_having_data_subject_consent",
				"Not_Answered", 0, 1, CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCloudForPharmacy_DataRetention(), this.getDataRetentionEnum(), "DataRetention", "NotAccepted",
				0, 1, CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getCloudForPharmacy_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				"Not_Answered", 0, 1, CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCloudForPharmacy_Are_you_collecting_data_that_are_not_needed_for_the_purpose(),
				this.getAnswer(), "Are_you_collecting_data_that_are_not_needed_for_the_purpose", "Not_Answered", 0, 1,
				CloudForPharmacy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getCloudForPharmacy_Paymentcloud(), this.getPaymentCloud(),
				this.getPaymentCloud_Cloudforpharmacy(), "paymentcloud", null, 0, 1, CloudForPharmacy.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudForPharmacy_Socialnetworkcloud(), this.getSocialNetworkCloud(),
				this.getSocialNetworkCloud_Cloudforpharmacy(), "socialnetworkcloud", null, 0, 1, CloudForPharmacy.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudForPharmacy_Shippingcloud(), this.getShippingCloud(),
				this.getShippingCloud_Cloudforpharmacy(), "shippingcloud", null, 0, 1, CloudForPharmacy.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudForPharmacy_Webhostingcloud(), this.getWebhostingCloud(),
				this.getWebhostingCloud_Cloudforpharmacy(), "webhostingcloud", null, 0, 1, CloudForPharmacy.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(busEClass, Bus.class, "Bus", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBus_Gpstracker(), this.getGPSTracker(), null, "gpstracker", null, 0, -1, Bus.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getBus_Plate_number(), theXMLTypePackage.getString(), "Plate_number", null, 0, 1, Bus.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getBus_Route_number(), theXMLTypePackage.getString(), "Route_number", null, 0, 1, Bus.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getBus_Driver_name(), theXMLTypePackage.getString(), "Driver_name", null, 0, 1, Bus.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getBus_Videowithoutanalytics(), this.getVideoWithoutAnalytics(), null, "videowithoutanalytics",
				null, 0, -1, Bus.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getBus_Driver(), this.getDriver(), null, "driver", null, 0, -1, Bus.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getBus_Videoanalytics(), this.getVideoAnalytics(), null, "videoanalytics", null, 0, -1,
				Bus.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getBus_Videoprocessingcloud(), this.getVideoProcessingCloud(), null, "videoprocessingcloud",
				null, 0, -1, Bus.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getBus_Customer(), this.getCustomer(), null, "customer", null, 0, -1, Bus.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(gpsTrackerEClass, GPSTracker.class, "GPSTracker", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getGPSTracker_ID(), theXMLTypePackage.getString(), "ID", null, 0, 1, GPSTracker.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGPSTracker_Coordinates(), theXMLTypePackage.getString(), "Coordinates", null, 0, 1,
				GPSTracker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getGPSTracker_Speed(), theXMLTypePackage.getString(), "Speed", null, 0, 1, GPSTracker.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGPSTracker_Does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks(),
				this.getAnswer(), "Does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks",
				null, 0, 1, GPSTracker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGPSTracker_Record_retention_period(), this.getDataRetentionEnum(), "Record_retention_period",
				null, 0, 1, GPSTracker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGPSTracker_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles(),
				this.getAnswer(), "Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles", null, 0, 1,
				GPSTracker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getGPSTracker_Is_data_against_accidental_loss_or_destruction_or_damage(), this.getAnswer(),
				"Is_data_against_accidental_loss_or_destruction_or_damage", null, 0, 1, GPSTracker.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getGPSTracker_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(),
				this.getAnswer(), "Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data",
				null, 0, 1, GPSTracker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGPSTracker_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", null, 0, 1,
				GPSTracker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getGPSTracker_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring(),
				this.getAnswer(),
				"Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring", null, 0, 1,
				GPSTracker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getGPSTracker_Does_the_staff_aware_of_the_use_of_the_GPS_systems(), this.getAnswer(),
				"Does_the_staff_aware_of_the_use_of_the_GPS_systems", null, 0, 1, GPSTracker.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getGPSTracker_Does_the_system_record_information_other_than_the_purpose(), this.getAnswer(),
				"Does_the_system_record_information_other_than_the_purpose", null, 0, 1, GPSTracker.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(videoAnalyticsEClass, VideoAnalytics.class, "VideoAnalytics", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVideoAnalytics_Serial_number(), theXMLTypePackage.getString(), "Serial_number", null, 0, 1,
				VideoAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getVideoAnalytics_Blurring(), this.getBlurring(), null, "blurring", null, 0, -1,
				VideoAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoAnalytics_Analytics(), this.getAnalytics(), null, "analytics", null, 0, -1,
				VideoAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoAnalytics_Customer(), this.getCustomer(), this.getCustomer_Videoanalytics(), "customer",
				null, 0, 1, VideoAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoAnalytics_Videoprocessingcloud(), this.getVideoProcessingCloud(),
				this.getVideoProcessingCloud_Videoanalytics(), "videoprocessingcloud", null, 0, 1, VideoAnalytics.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(videoWithoutAnalyticsEClass, VideoWithoutAnalytics.class, "VideoWithoutAnalytics", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVideoWithoutAnalytics_Serial_number(), theXMLTypePackage.getString(), "Serial_number", null,
				0, 1, VideoWithoutAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoWithoutAnalytics_Record_retention_period(), this.getDataRetentionEnum(),
				"Record_retention_period", null, 0, 1, VideoWithoutAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoWithoutAnalytics_Do_people_aware_of_being_recorded(), this.getAnswer(),
				"Do_people_aware_of_being_recorded", null, 0, 1, VideoWithoutAnalytics.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoWithoutAnalytics_Ensure_data_minimisation_is_aplied(), this.getAnswer(),
				"Ensure_data_minimisation_is_aplied", null, 0, 1, VideoWithoutAnalytics.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoWithoutAnalytics_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", null, 0, 1,
				VideoWithoutAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getVideoWithoutAnalytics_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles(),
				this.getAnswer(), "Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles", null, 0, 1,
				VideoWithoutAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoWithoutAnalytics_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV(),
				this.getAnswer(), "Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV", "Not_Answered", 0,
				1, VideoWithoutAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoWithoutAnalytics_Does_the_system_record_information_other_than_the_purpose(),
				this.getAnswer(), "Does_the_system_record_information_other_than_the_purpose", null, 0, 1,
				VideoWithoutAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getVideoWithoutAnalytics_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(),
				this.getAnswer(), "Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data",
				null, 0, 1, VideoWithoutAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getVideoWithoutAnalytics_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring(),
				this.getAnswer(),
				"Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring", null, 0, 1,
				VideoWithoutAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoWithoutAnalytics_Do_you_use_signs_that_say_CCTV_is_in_operation(), this.getAnswer(),
				"Do_you_use_signs_that_say_CCTV_is_in_operation", null, 0, 1, VideoWithoutAnalytics.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoWithoutAnalytics_Is_data_against_accidental_loss_or_destruction_or_damage(),
				this.getAnswer(), "Is_data_against_accidental_loss_or_destruction_or_damage", null, 0, 1,
				VideoWithoutAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoWithoutAnalytics_Does_The_dynamic_masking_feature_is_enabled(), this.getAnswer(),
				"Does_The_dynamic_masking_feature_is_enabled", null, 0, 1, VideoWithoutAnalytics.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoWithoutAnalytics_Are_you_sending_data_without_anonymisation(), this.getAnswer(),
				"Are_you_sending_data_without_anonymisation", null, 0, 1, VideoWithoutAnalytics.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoWithoutAnalytics_Are_you_allowing_data_unauthorised_access(), this.getAnswer(),
				"Are_you_allowing_data_unauthorised_access", null, 0, 1, VideoWithoutAnalytics.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoWithoutAnalytics_Are_you_storing_the_footage_in_a_secure_location(), this.getAnswer(),
				"Are_you_storing_the_footage_in_a_secure_location", null, 0, 1, VideoWithoutAnalytics.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoWithoutAnalytics_Customer(), this.getCustomer(),
				this.getCustomer_Videowithoutanalytics(), "customer", null, 0, 1, VideoWithoutAnalytics.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoWithoutAnalytics_Videoprocessingcloud(), this.getVideoProcessingCloud(),
				this.getVideoProcessingCloud_Videowithoutanalytics(), "videoprocessingcloud", null, 0, 1,
				VideoWithoutAnalytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(driverEClass, Driver.class, "Driver", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDriver_Authentication(), this.getAuthentication(), null, "authentication", null, 0, -1,
				Driver.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDriver_Authorization(), this.getAuthorization(), null, "authorization", null, 0, -1,
				Driver.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDriver_Age(), theXMLTypePackage.getString(), "Age", null, 0, 1, Driver.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDriver_Consent_checkedlist(), this.getConsent_CheckedList(), null, "consent_checkedlist",
				null, 0, -1, Driver.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDriver_Do_drivers_aware_of_being_recorded(), this.getAnswer(),
				"Do_drivers_aware_of_being_recorded", null, 0, 1, Driver.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(customerEClass, Customer.class, "Customer", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCustomer_General_features(), theXMLTypePackage.getString(), "General_features", null, 0, 1,
				Customer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getCustomer_Consent_checkedlist(), this.getConsent_CheckedList(), null, "consent_checkedlist",
				null, 0, -1, Customer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCustomer_Do_people_aware_of_being_recorded(), this.getAnswer(),
				"Do_people_aware_of_being_recorded", null, 0, 1, Customer.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCustomer_Videoanalytics(), this.getVideoAnalytics(), this.getVideoAnalytics_Customer(),
				"videoanalytics", null, 0, 1, Customer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCustomer_Videowithoutanalytics(), this.getVideoWithoutAnalytics(),
				this.getVideoWithoutAnalytics_Customer(), "videowithoutanalytics", null, 0, 1, Customer.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(analyticsEClass, Analytics.class, "Analytics", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAnalytics_Record_retention_period(), this.getDataRetentionEnum(), "Record_retention_period",
				null, 0, 1, Analytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAnalytics_Does_data_processing_applied_on_the_camera_to_increase_data_minimisation(),
				this.getAnswer(), "Does_data_processing_applied_on_the_camera_to_increase_data_minimisation", null, 0,
				1, Analytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAnalytics_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles(),
				this.getAnswer(), "Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles", null, 0, 1,
				Analytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAnalytics_Does_the_system_record_information_other_than_the_purpose(), this.getAnswer(),
				"Does_the_system_record_information_other_than_the_purpose", null, 0, 1, Analytics.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAnalytics_Does_The_dynamic_masking_feature_is_enabled(), this.getAnswer(),
				"Does_The_dynamic_masking_feature_is_enabled", null, 0, 1, Analytics.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getAnalytics_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring(),
				this.getAnswer(),
				"Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring", null, 0, 1,
				Analytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAnalytics_Do_you_use_signs_that_say_CCTV_is_in_operation(), this.getAnswer(),
				"Do_you_use_signs_that_say_CCTV_is_in_operation", null, 0, 1, Analytics.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAnalytics_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV(), this.getAnswer(),
				"Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV", "Not_Answered", 0, 1,
				Analytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAnalytics_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", null, 0, 1,
				Analytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getAnalytics_Is_data_against_accidental_loss_or_destruction_or_damage(), this.getAnswer(),
				"Is_data_against_accidental_loss_or_destruction_or_damage", null, 0, 1, Analytics.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getAnalytics_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(),
				this.getAnswer(), "Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data",
				null, 0, 1, Analytics.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(blurringEClass, Blurring.class, "Blurring", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(
				getBlurring_Does_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation(),
				this.getAnswer(),
				"Does_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation", null, 0, 1,
				Blurring.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(videoProcessingCloudEClass, VideoProcessingCloud.class, "VideoProcessingCloud", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVideoProcessingCloud_DataRetention(), this.getDataRetentionEnum(), "DataRetention",
				"NotAccepted", 0, 1, VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoProcessingCloud_Storagelocation(), this.getStorageLocation(), null, "storagelocation",
				null, 0, -1, VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoProcessingCloud_Datasharing(), this.getDataSharing(), null, "datasharing", null, 0, -1,
				VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoProcessingCloud_Test_on_dummy(), this.getTest_on_dummy(), null, "test_on_dummy", null, 0,
				-1, VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoProcessingCloud_Containerisation(), this.getContainerisation(), null, "containerisation",
				null, 0, -1, VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoProcessingCloud_Aggregation(), this.getAggregation(), null, "aggregation", null, 0, -1,
				VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoProcessingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose(),
				this.getAnswer(), "Are_you_collecting_data_that_are_not_needed_for_the_purpose", "Not_Answered", 0, 1,
				VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoProcessingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(),
				this.getAnswer(), "Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0,
				1, VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getVideoProcessingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent(),
				this.getAnswer(), "Are_you_sharing_data_with_other_parties_without_having_data_subject_consent",
				"Not_Answered", 0, 1, VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVideoProcessingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered",
				0, 1, VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getVideoProcessingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(),
				this.getAnswer(),
				"Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing",
				"Not_Answered", 0, 1, VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getVideoProcessingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				"Not_Answered", 0, 1, VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoProcessingCloud_Gpstracker(), this.getGPSTracker(), null, "gpstracker", null, 0, -1,
				VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoProcessingCloud_Videoanalytics(), this.getVideoAnalytics(),
				this.getVideoAnalytics_Videoprocessingcloud(), "videoanalytics", null, 0, 1, VideoProcessingCloud.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoProcessingCloud_Videowithoutanalytics(), this.getVideoWithoutAnalytics(),
				this.getVideoWithoutAnalytics_Videoprocessingcloud(), "videowithoutanalytics", null, 0, 1,
				VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVideoProcessingCloud_Website(), this.getWebsite(), this.getWebsite_Videoprocessingcloud(),
				"website", null, 0, 1, VideoProcessingCloud.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(clientEClass, Client.class, "Client", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getClient_Smartphone(), this.getSmartPhone(), null, "smartphone", null, 0, -1, Client.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getClient_Consent_checkedlist(), this.getConsent_CheckedList(), null, "consent_checkedlist",
				null, 0, -1, Client.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getClient_PhoneNumber(), ecorePackage.getEString(), "PhoneNumber", null, 0, 1, Client.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getClient_Authentication(), this.getAuthentication(), null, "authentication", null, 0, -1,
				Client.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getClient_Authorization(), this.getAuthorization(), null, "authorization", null, 0, -1,
				Client.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getClient_Phone(), this.getPhone(), null, "phone", null, 0, -1, Client.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(cloudServiceEClass, CloudService.class, "CloudService", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCloudService_DataRetention(), this.getDataRetentionEnum(), "DataRetention", "NotAccepted", 0,
				1, CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getCloudService_Storagelocation(), this.getStorageLocation(), null, "storagelocation", null, 0,
				-1, CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudService_Datasharing(), this.getDataSharing(), null, "datasharing", null, 0, -1,
				CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudService_Test_on_dummy(), this.getTest_on_dummy(), null, "test_on_dummy", null, 0, -1,
				CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudService_Containerisation(), this.getContainerisation(), null, "containerisation", null,
				0, -1, CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudService_Aggregation(), this.getAggregation(), null, "aggregation", null, 0, -1,
				CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCloudService_Are_you_collecting_data_that_are_not_needed_for_the_purpose(), this.getAnswer(),
				"Are_you_collecting_data_that_are_not_needed_for_the_purpose", "Not_Answered", 0, 1, CloudService.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCloudService_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(),
				this.getAnswer(), "Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0,
				1, CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCloudService_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent(),
				this.getAnswer(), "Are_you_sharing_data_with_other_parties_without_having_data_subject_consent",
				"Not_Answered", 0, 1, CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCloudService_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered",
				0, 1, CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getCloudService_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(),
				this.getAnswer(),
				"Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing",
				"Not_Answered", 0, 1, CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getCloudService_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				"Not_Answered", 0, 1, CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE,
				!IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudService_Gpstracker(), this.getGPSTracker(), null, "gpstracker", null, 0, -1,
				CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudService_Videoanalytics(), this.getVideoAnalytics(), null, "videoanalytics", null, 0, 1,
				CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudService_Videowithoutanalytics(), this.getVideoWithoutAnalytics(), null,
				"videowithoutanalytics", null, 0, 1, CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudService_Lightsensor(), this.getLightSensor(), this.getLightSensor_Cloudservice(),
				"lightsensor", null, 0, 1, CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudService_Phone(), this.getPhone(), this.getPhone_Cloudservice(), "phone", null, 0, 1,
				CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudService_Camera(), this.getCamera(), this.getCamera_Cloudservice(), "camera", null, 0, 1,
				CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudService_Doorlock(), this.getDoorLock(), this.getDoorLock_Cloudservice(), "doorlock",
				null, 0, 1, CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCloudService_Thermostat(), this.getThermostat(), this.getThermostat_Cloudservice(),
				"thermostat", null, 0, 1, CloudService.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(lightSensorEClass, LightSensor.class, "LightSensor", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getLightSensor_Connection(), this.getCommunicationProtocols(), "Connection", null, 0, 1,
				LightSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getLightSensor_DataRetention(), this.getDataRetentionEnum(), "DataRetention", null, 0, 1,
				LightSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getLightSensor_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", null, 0, 1,
				LightSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getLightSensor_Cloudservice(), this.getCloudService(), this.getCloudService_Lightsensor(),
				"cloudservice", null, 0, 1, LightSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getLightSensor_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(),
				this.getAnswer(), "Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data",
				null, 0, 1, LightSensor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getLightSensor_Is_data_against_accidental_loss_or_destruction_or_damage(), this.getAnswer(),
				"Is_data_against_accidental_loss_or_destruction_or_damage", null, 0, 1, LightSensor.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(phoneEClass, Phone.class, "Phone", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPhone_User_info_Retention_Period(), this.getDataRetentionEnum(), "User_info_Retention_Period",
				null, 0, 1, Phone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getPhone_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(),
				this.getAnswer(),
				"Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures",
				null, 0, 1, Phone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPhone_Are_you_planning_to_send_all_the_data_to_the_cloud(), this.getAnswer(),
				"Are_you_planning_to_send_all_the_data_to_the_cloud", "Not_Answered", 0, 1, Phone.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPhone_Are_you_processing_data_in_an_incompatible_way_with_the_purpose(), this.getAnswer(),
				"Are_you_processing_data_in_an_incompatible_way_with_the_purpose", "Not_Answered", 0, 1, Phone.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPhone_Connection(), this.getCommunicationProtocols(), "Connection", "Blutooth_and_WiFi", 0, 1,
				Phone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEAttribute(
				getPhone_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate(),
				this.getAnswer(),
				"Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate",
				"Not_Answered", 0, 1, Phone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPhone_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(), this.getAnswer(),
				"Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", "Not_Answered", 0, 1, Phone.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPhone_Userlocation(), this.getUserLocation(), null, "userlocation", null, 0, -1, Phone.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPhone_Cloudservice(), this.getCloudService(), this.getCloudService_Phone(), "cloudservice",
				null, 0, 1, Phone.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPhone_Cookies(), this.getCookies(), null, "cookies", null, 0, -1, Phone.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(doorLockEClass, DoorLock.class, "DoorLock", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDoorLock_Cloudservice(), this.getCloudService(), this.getCloudService_Doorlock(),
				"cloudservice", null, 0, 1, DoorLock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDoorLock_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(),
				this.getAnswer(), "Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data",
				null, 0, 1, DoorLock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDoorLock_Connection(), this.getCommunicationProtocols(), "Connection", null, 0, 1,
				DoorLock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getDoorLock_DataRetention(), this.getDataRetentionEnum(), "DataRetention", null, 0, 1,
				DoorLock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getDoorLock_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", null, 0, 1,
				DoorLock.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getDoorLock_Is_data_against_accidental_loss_or_destruction_or_damage(), this.getAnswer(),
				"Is_data_against_accidental_loss_or_destruction_or_damage", null, 0, 1, DoorLock.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(thermostatEClass, Thermostat.class, "Thermostat", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getThermostat_Cloudservice(), this.getCloudService(), this.getCloudService_Thermostat(),
				"cloudservice", null, 0, 1, Thermostat.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getThermostat_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(),
				this.getAnswer(), "Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data",
				null, 0, 1, Thermostat.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getThermostat_Connection(), this.getCommunicationProtocols(), "Connection", null, 0, 1,
				Thermostat.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getThermostat_DataRetention(), this.getDataRetentionEnum(), "DataRetention", null, 0, 1,
				Thermostat.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getThermostat_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(),
				this.getAnswer(), "Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", null, 0, 1,
				Thermostat.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getThermostat_Is_data_against_accidental_loss_or_destruction_or_damage(), this.getAnswer(),
				"Is_data_against_accidental_loss_or_destruction_or_damage", null, 0, 1, Thermostat.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cameraEClass, Camera.class, "Camera", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCamera_Are_you_sending_data_without_anonymisation(), this.getAnswer(),
				"Are_you_sending_data_without_anonymisation", null, 0, 1, Camera.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCamera_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV(), this.getAnswer(),
				"Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV", "Not_Answered", 0, 1, Camera.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCamera_Do_people_aware_of_being_recorded(), this.getAnswer(),
				"Do_people_aware_of_being_recorded", null, 0, 1, Camera.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCamera_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(),
				this.getAnswer(), "Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data",
				null, 0, 1, Camera.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCamera_Are_you_storing_the_footage_in_a_secure_location(), this.getAnswer(),
				"Are_you_storing_the_footage_in_a_secure_location", null, 0, 1, Camera.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCamera_Ensure_data_minimisation_is_aplied(), this.getAnswer(),
				"Ensure_data_minimisation_is_aplied", null, 0, 1, Camera.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCamera_Do_you_use_signs_that_say_CCTV_is_in_operation(), this.getAnswer(),
				"Do_you_use_signs_that_say_CCTV_is_in_operation", null, 0, 1, Camera.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCamera_Does_the_system_record_information_other_than_the_purpose(), this.getAnswer(),
				"Does_the_system_record_information_other_than_the_purpose", null, 0, 1, Camera.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCamera_Record_retention_period(), this.getDataRetentionEnum(), "Record_retention_period",
				null, 0, 1, Camera.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCamera_Are_you_allowing_data_unauthorised_access(), this.getAnswer(),
				"Are_you_allowing_data_unauthorised_access", null, 0, 1, Camera.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCamera_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes(), this.getAnswer(),
				"Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes", null, 0, 1, Camera.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCamera_Is_data_against_accidental_loss_or_destruction_or_damage(), this.getAnswer(),
				"Is_data_against_accidental_loss_or_destruction_or_damage", null, 0, 1, Camera.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCamera_Cloudservice(), this.getCloudService(), this.getCloudService_Camera(), "cloudservice",
				null, 0, 1, Camera.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(privacy_patternsEClass, Privacy_patterns.class, "Privacy_patterns", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPrivacy_patterns_Privacy_patterns(), theXMLTypePackage.getString(), "Privacy_patterns", null,
				0, 1, Privacy_patterns.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cookiesEClass, Cookies.class, "Cookies", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCookies_Use_the_surface_cookies_banner_if_cookies_are_placed(), this.getChecked(),
				"Use_the_surface_cookies_banner_if_cookies_are_placed", "No", 0, 1, Cookies.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCookies_The_cookie_banner_must_be_resurfaced_if_new_cookies_are_added(), this.getChecked(),
				"The_cookie_banner_must_be_resurfaced_if_new_cookies_are_added", "No", 0, 1, Cookies.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCookies_The_cookie_banner_must_be_resurfaced_if_browser_settings_change(), this.getChecked(),
				"The_cookie_banner_must_be_resurfaced_if_browser_settings_change", "No", 0, 1, Cookies.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getCookies_Capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used(),
				this.getChecked(),
				"Capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used", "No", 0, 1,
				Cookies.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(
				getCookies_Place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used(),
				this.getChecked(),
				"Place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used", "No",
				0, 1, Cookies.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getCookies_Consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc(),
				theXMLTypePackage.getString(),
				"Consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc", "No", 0, 1,
				Cookies.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(dataRetentionEnumEEnum, DataRetentionEnum.class, "DataRetentionEnum");
		addEEnumLiteral(dataRetentionEnumEEnum, DataRetentionEnum.NOT_ACCEPTED);
		addEEnumLiteral(dataRetentionEnumEEnum, DataRetentionEnum.ACCEPTED);

		initEEnum(patientHealthStatusEEnum, PatientHealthStatus.class, "PatientHealthStatus");
		addEEnumLiteral(patientHealthStatusEEnum, PatientHealthStatus.SUSPECTED_SICK);
		addEEnumLiteral(patientHealthStatusEEnum, PatientHealthStatus.SICK);
		addEEnumLiteral(patientHealthStatusEEnum, PatientHealthStatus.HEALTHY);

		initEEnum(communicationProtocolsEEnum, CommunicationProtocols.class, "CommunicationProtocols");
		addEEnumLiteral(communicationProtocolsEEnum, CommunicationProtocols.BLUTOOTH);
		addEEnumLiteral(communicationProtocolsEEnum, CommunicationProtocols.WI_FI);
		addEEnumLiteral(communicationProtocolsEEnum, CommunicationProtocols.BLUTOOTH_AND_WI_FI);

		initEEnum(checked_ConsentEEnum, Checked_Consent.class, "Checked_Consent");
		addEEnumLiteral(checked_ConsentEEnum, Checked_Consent.NO);
		addEEnumLiteral(checked_ConsentEEnum, Checked_Consent.YES);

		initEEnum(cloudStorageLocationEEnum, CloudStorageLocation.class, "CloudStorageLocation");
		addEEnumLiteral(cloudStorageLocationEEnum, CloudStorageLocation.OUTSIDE_EU_IN_US);
		addEEnumLiteral(cloudStorageLocationEEnum, CloudStorageLocation.INSIDE_EU);

		initEEnum(locationGranularityEEnum, LocationGranularity.class, "LocationGranularity");
		addEEnumLiteral(locationGranularityEEnum, LocationGranularity.EXACT_LOCATION);
		addEEnumLiteral(locationGranularityEEnum, LocationGranularity.POSTAL_CODE);
		addEEnumLiteral(locationGranularityEEnum, LocationGranularity.TOWN);
		addEEnumLiteral(locationGranularityEEnum, LocationGranularity.COUNTRY);
		addEEnumLiteral(locationGranularityEEnum, LocationGranularity.NOT_NEEDED);

		initEEnum(checkedEEnum, Checked.class, "Checked");
		addEEnumLiteral(checkedEEnum, Checked.NO);
		addEEnumLiteral(checkedEEnum, Checked.YES);

		initEEnum(cloudProviderServerEEnum, CloudProviderServer.class, "CloudProviderServer");
		addEEnumLiteral(cloudProviderServerEEnum, CloudProviderServer.US_PROVIDER_AND_US_SERVER_FOR_GERMAN_PATIENT);
		addEEnumLiteral(cloudProviderServerEEnum, CloudProviderServer.US_PROVIDER_AND_EU_SERVER_FOR_UK_OR_NE_PATIENT);
		addEEnumLiteral(cloudProviderServerEEnum, CloudProviderServer.US_PROVIDER_AND_EU_SERVER_FOR_US_PATIENT);
		addEEnumLiteral(cloudProviderServerEEnum, CloudProviderServer.US_PROVIDER_AND_US_SERVER_FOR_US_PATIENT);
		addEEnumLiteral(cloudProviderServerEEnum, CloudProviderServer.EU_PROVIDER_AND_EU_SERVER_FOR_GERMAN_PATIENT);

		initEEnum(testOnDummyDataEEnum, TestOnDummyData.class, "TestOnDummyData");
		addEEnumLiteral(testOnDummyDataEEnum, TestOnDummyData.TESTING_PHASE_AND_DUMMY_DATA);
		addEEnumLiteral(testOnDummyDataEEnum, TestOnDummyData.TESTING_PHASE_AND_LIVE_DATA);
		addEEnumLiteral(testOnDummyDataEEnum, TestOnDummyData.LIVE_PHASE_AND_DUMMY_DATA);
		addEEnumLiteral(testOnDummyDataEEnum, TestOnDummyData.LIVE_PHASE_AND_LIVE_DATA);

		initEEnum(answerEEnum, Answer.class, "Answer");
		addEEnumLiteral(answerEEnum, Answer.NOT_ANSWERED);
		addEEnumLiteral(answerEEnum, Answer.YES);
		addEEnumLiteral(answerEEnum, Answer.NO);

		// Initialize data types
		initEDataType(consentDataTypeEDataType, Object.class, "ConsentDataType", IS_SERIALIZABLE,
				!IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);
	}

} //Cgm3PackageImpl
