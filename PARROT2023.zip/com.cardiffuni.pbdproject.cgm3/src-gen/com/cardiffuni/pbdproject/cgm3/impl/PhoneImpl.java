/**
 */
package com.cardiffuni.pbdproject.cgm3.impl;

import com.cardiffuni.pbdproject.cgm3.Answer;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Checked;
import com.cardiffuni.pbdproject.cgm3.CloudService;
import com.cardiffuni.pbdproject.cgm3.CommunicationProtocols;
import com.cardiffuni.pbdproject.cgm3.Cookies;
import com.cardiffuni.pbdproject.cgm3.DataRetentionEnum;
import com.cardiffuni.pbdproject.cgm3.Encryption;
import com.cardiffuni.pbdproject.cgm3.Phone;
import com.cardiffuni.pbdproject.cgm3.Privacy_patterns;
import com.cardiffuni.pbdproject.cgm3.UserLocation;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Phone</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl#getEncryptedData <em>Encrypted Data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl#getPrivacy_patterns <em>Privacy patterns</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl#getUser_info_Retention_Period <em>User info Retention Period</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl#getAre_you_planning_to_send_all_the_data_to_the_cloud <em>Are you planning to send all the data to the cloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl#getConnection <em>Connection</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl#getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate <em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl#getUserlocation <em>Userlocation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl#getCloudservice <em>Cloudservice</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl#getCookies <em>Cookies</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PhoneImpl extends GeneralEntityImpl implements Phone {
	/**
	 * The default value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected static final Checked ENCRYPTED_DATA_EDEFAULT = Checked.NO;

	/**
	 * The cached value of the '{@link #getEncryptedData() <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEncryptedData()
	 * @generated
	 * @ordered
	 */
	protected Checked encryptedData = ENCRYPTED_DATA_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected static final String PRIVACY_PATTERNS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPrivacy_patterns() <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrivacy_patterns()
	 * @generated
	 * @ordered
	 */
	protected String privacy_patterns = PRIVACY_PATTERNS_EDEFAULT;

	/**
	 * The default value of the '{@link #getUser_info_Retention_Period() <em>User info Retention Period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUser_info_Retention_Period()
	 * @generated
	 * @ordered
	 */
	protected static final DataRetentionEnum USER_INFO_RETENTION_PERIOD_EDEFAULT = DataRetentionEnum.NOT_ACCEPTED;

	/**
	 * The cached value of the '{@link #getUser_info_Retention_Period() <em>User info Retention Period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUser_info_Retention_Period()
	 * @generated
	 * @ordered
	 */
	protected DataRetentionEnum user_info_Retention_Period = USER_INFO_RETENTION_PERIOD_EDEFAULT;

	/**
	 * The default value of the '{@link #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 * @ordered
	 */
	protected static final Answer IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 * @ordered
	 */
	protected Answer is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_planning_to_send_all_the_data_to_the_cloud() <em>Are you planning to send all the data to the cloud</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_planning_to_send_all_the_data_to_the_cloud()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_planning_to_send_all_the_data_to_the_cloud() <em>Are you planning to send all the data to the cloud</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_planning_to_send_all_the_data_to_the_cloud()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_planning_to_send_all_the_data_to_the_cloud = ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() <em>Are you processing data in an incompatible way with the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() <em>Are you processing data in an incompatible way with the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_processing_data_in_an_incompatible_way_with_the_purpose = ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT;

	/**
	 * The default value of the '{@link #getConnection() <em>Connection</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnection()
	 * @generated
	 * @ordered
	 */
	protected static final CommunicationProtocols CONNECTION_EDEFAULT = CommunicationProtocols.BLUTOOTH_AND_WI_FI;

	/**
	 * The cached value of the '{@link #getConnection() <em>Connection</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnection()
	 * @generated
	 * @ordered
	 */
	protected CommunicationProtocols connection = CONNECTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate() <em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate() <em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate = ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected static final Answer ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT = Answer.NOT_ANSWERED;

	/**
	 * The cached value of the '{@link #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 * @ordered
	 */
	protected Answer are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;

	/**
	 * The cached value of the '{@link #getUserlocation() <em>Userlocation</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUserlocation()
	 * @generated
	 * @ordered
	 */
	protected EList<UserLocation> userlocation;

	/**
	 * The cached value of the '{@link #getCloudservice() <em>Cloudservice</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCloudservice()
	 * @generated
	 * @ordered
	 */
	protected CloudService cloudservice;

	/**
	 * The cached value of the '{@link #getCookies() <em>Cookies</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCookies()
	 * @generated
	 * @ordered
	 */
	protected EList<Cookies> cookies;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PhoneImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Cgm3Package.Literals.PHONE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Checked getEncryptedData() {
		return encryptedData;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEncryptedData(Checked newEncryptedData) {
		Checked oldEncryptedData = encryptedData;
		encryptedData = newEncryptedData == null ? ENCRYPTED_DATA_EDEFAULT : newEncryptedData;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.PHONE__ENCRYPTED_DATA, oldEncryptedData,
					encryptedData));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPrivacy_patterns() {
		return privacy_patterns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrivacy_patterns(String newPrivacy_patterns) {
		String oldPrivacy_patterns = privacy_patterns;
		privacy_patterns = newPrivacy_patterns;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.PHONE__PRIVACY_PATTERNS,
					oldPrivacy_patterns, privacy_patterns));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DataRetentionEnum getUser_info_Retention_Period() {
		return user_info_Retention_Period;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUser_info_Retention_Period(DataRetentionEnum newUser_info_Retention_Period) {
		DataRetentionEnum oldUser_info_Retention_Period = user_info_Retention_Period;
		user_info_Retention_Period = newUser_info_Retention_Period == null ? USER_INFO_RETENTION_PERIOD_EDEFAULT
				: newUser_info_Retention_Period;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.PHONE__USER_INFO_RETENTION_PERIOD,
					oldUser_info_Retention_Period, user_info_Retention_Period));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures() {
		return is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
			Answer newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures) {
		Answer oldIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
		is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures = newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures == null
				? IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT
				: newIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.PHONE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES,
					oldIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures,
					is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_planning_to_send_all_the_data_to_the_cloud() {
		return are_you_planning_to_send_all_the_data_to_the_cloud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_planning_to_send_all_the_data_to_the_cloud(
			Answer newAre_you_planning_to_send_all_the_data_to_the_cloud) {
		Answer oldAre_you_planning_to_send_all_the_data_to_the_cloud = are_you_planning_to_send_all_the_data_to_the_cloud;
		are_you_planning_to_send_all_the_data_to_the_cloud = newAre_you_planning_to_send_all_the_data_to_the_cloud == null
				? ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD_EDEFAULT
				: newAre_you_planning_to_send_all_the_data_to_the_cloud;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.PHONE__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD,
					oldAre_you_planning_to_send_all_the_data_to_the_cloud,
					are_you_planning_to_send_all_the_data_to_the_cloud));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_processing_data_in_an_incompatible_way_with_the_purpose() {
		return are_you_processing_data_in_an_incompatible_way_with_the_purpose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(
			Answer newAre_you_processing_data_in_an_incompatible_way_with_the_purpose) {
		Answer oldAre_you_processing_data_in_an_incompatible_way_with_the_purpose = are_you_processing_data_in_an_incompatible_way_with_the_purpose;
		are_you_processing_data_in_an_incompatible_way_with_the_purpose = newAre_you_processing_data_in_an_incompatible_way_with_the_purpose == null
				? ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT
				: newAre_you_processing_data_in_an_incompatible_way_with_the_purpose;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.PHONE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE,
					oldAre_you_processing_data_in_an_incompatible_way_with_the_purpose,
					are_you_processing_data_in_an_incompatible_way_with_the_purpose));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CommunicationProtocols getConnection() {
		return connection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConnection(CommunicationProtocols newConnection) {
		CommunicationProtocols oldConnection = connection;
		connection = newConnection == null ? CONNECTION_EDEFAULT : newConnection;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.PHONE__CONNECTION, oldConnection,
					connection));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate() {
		return are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate(
			Answer newAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate) {
		Answer oldAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate = are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate;
		are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate = newAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate == null
				? ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE_EDEFAULT
				: newAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.PHONE__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE,
					oldAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate,
					are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes() {
		return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
			Answer newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes) {
		Answer oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes = are_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		are_you_storing_the_data_longer_than_is_necessary_for_the_purposes = newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes == null
				? ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT
				: newAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					Cgm3Package.PHONE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
					oldAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes,
					are_you_storing_the_data_longer_than_is_necessary_for_the_purposes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<UserLocation> getUserlocation() {
		if (userlocation == null) {
			userlocation = new EObjectContainmentEList<UserLocation>(UserLocation.class, this,
					Cgm3Package.PHONE__USERLOCATION);
		}
		return userlocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudService getCloudservice() {
		if (cloudservice != null && cloudservice.eIsProxy()) {
			InternalEObject oldCloudservice = (InternalEObject) cloudservice;
			cloudservice = (CloudService) eResolveProxy(oldCloudservice);
			if (cloudservice != oldCloudservice) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Cgm3Package.PHONE__CLOUDSERVICE,
							oldCloudservice, cloudservice));
			}
		}
		return cloudservice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CloudService basicGetCloudservice() {
		return cloudservice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCloudservice(CloudService newCloudservice, NotificationChain msgs) {
		CloudService oldCloudservice = cloudservice;
		cloudservice = newCloudservice;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					Cgm3Package.PHONE__CLOUDSERVICE, oldCloudservice, newCloudservice);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCloudservice(CloudService newCloudservice) {
		if (newCloudservice != cloudservice) {
			NotificationChain msgs = null;
			if (cloudservice != null)
				msgs = ((InternalEObject) cloudservice).eInverseRemove(this, Cgm3Package.CLOUD_SERVICE__PHONE,
						CloudService.class, msgs);
			if (newCloudservice != null)
				msgs = ((InternalEObject) newCloudservice).eInverseAdd(this, Cgm3Package.CLOUD_SERVICE__PHONE,
						CloudService.class, msgs);
			msgs = basicSetCloudservice(newCloudservice, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Cgm3Package.PHONE__CLOUDSERVICE, newCloudservice,
					newCloudservice));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Cookies> getCookies() {
		if (cookies == null) {
			cookies = new EObjectContainmentEList<Cookies>(Cookies.class, this, Cgm3Package.PHONE__COOKIES);
		}
		return cookies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.PHONE__CLOUDSERVICE:
			if (cloudservice != null)
				msgs = ((InternalEObject) cloudservice).eInverseRemove(this, Cgm3Package.CLOUD_SERVICE__PHONE,
						CloudService.class, msgs);
			return basicSetCloudservice((CloudService) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case Cgm3Package.PHONE__USERLOCATION:
			return ((InternalEList<?>) getUserlocation()).basicRemove(otherEnd, msgs);
		case Cgm3Package.PHONE__CLOUDSERVICE:
			return basicSetCloudservice(null, msgs);
		case Cgm3Package.PHONE__COOKIES:
			return ((InternalEList<?>) getCookies()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case Cgm3Package.PHONE__ENCRYPTED_DATA:
			return getEncryptedData();
		case Cgm3Package.PHONE__PRIVACY_PATTERNS:
			return getPrivacy_patterns();
		case Cgm3Package.PHONE__USER_INFO_RETENTION_PERIOD:
			return getUser_info_Retention_Period();
		case Cgm3Package.PHONE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			return getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();
		case Cgm3Package.PHONE__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD:
			return getAre_you_planning_to_send_all_the_data_to_the_cloud();
		case Cgm3Package.PHONE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			return getAre_you_processing_data_in_an_incompatible_way_with_the_purpose();
		case Cgm3Package.PHONE__CONNECTION:
			return getConnection();
		case Cgm3Package.PHONE__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE:
			return getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate();
		case Cgm3Package.PHONE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();
		case Cgm3Package.PHONE__USERLOCATION:
			return getUserlocation();
		case Cgm3Package.PHONE__CLOUDSERVICE:
			if (resolve)
				return getCloudservice();
			return basicGetCloudservice();
		case Cgm3Package.PHONE__COOKIES:
			return getCookies();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case Cgm3Package.PHONE__ENCRYPTED_DATA:
			setEncryptedData((Checked) newValue);
			return;
		case Cgm3Package.PHONE__PRIVACY_PATTERNS:
			setPrivacy_patterns((String) newValue);
			return;
		case Cgm3Package.PHONE__USER_INFO_RETENTION_PERIOD:
			setUser_info_Retention_Period((DataRetentionEnum) newValue);
			return;
		case Cgm3Package.PHONE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
					(Answer) newValue);
			return;
		case Cgm3Package.PHONE__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD:
			setAre_you_planning_to_send_all_the_data_to_the_cloud((Answer) newValue);
			return;
		case Cgm3Package.PHONE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			setAre_you_processing_data_in_an_incompatible_way_with_the_purpose((Answer) newValue);
			return;
		case Cgm3Package.PHONE__CONNECTION:
			setConnection((CommunicationProtocols) newValue);
			return;
		case Cgm3Package.PHONE__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE:
			setAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate(
					(Answer) newValue);
			return;
		case Cgm3Package.PHONE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes((Answer) newValue);
			return;
		case Cgm3Package.PHONE__USERLOCATION:
			getUserlocation().clear();
			getUserlocation().addAll((Collection<? extends UserLocation>) newValue);
			return;
		case Cgm3Package.PHONE__CLOUDSERVICE:
			setCloudservice((CloudService) newValue);
			return;
		case Cgm3Package.PHONE__COOKIES:
			getCookies().clear();
			getCookies().addAll((Collection<? extends Cookies>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case Cgm3Package.PHONE__ENCRYPTED_DATA:
			setEncryptedData(ENCRYPTED_DATA_EDEFAULT);
			return;
		case Cgm3Package.PHONE__PRIVACY_PATTERNS:
			setPrivacy_patterns(PRIVACY_PATTERNS_EDEFAULT);
			return;
		case Cgm3Package.PHONE__USER_INFO_RETENTION_PERIOD:
			setUser_info_Retention_Period(USER_INFO_RETENTION_PERIOD_EDEFAULT);
			return;
		case Cgm3Package.PHONE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
					IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT);
			return;
		case Cgm3Package.PHONE__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD:
			setAre_you_planning_to_send_all_the_data_to_the_cloud(
					ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD_EDEFAULT);
			return;
		case Cgm3Package.PHONE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(
					ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT);
			return;
		case Cgm3Package.PHONE__CONNECTION:
			setConnection(CONNECTION_EDEFAULT);
			return;
		case Cgm3Package.PHONE__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE:
			setAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate(
					ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE_EDEFAULT);
			return;
		case Cgm3Package.PHONE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(
					ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT);
			return;
		case Cgm3Package.PHONE__USERLOCATION:
			getUserlocation().clear();
			return;
		case Cgm3Package.PHONE__CLOUDSERVICE:
			setCloudservice((CloudService) null);
			return;
		case Cgm3Package.PHONE__COOKIES:
			getCookies().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case Cgm3Package.PHONE__ENCRYPTED_DATA:
			return encryptedData != ENCRYPTED_DATA_EDEFAULT;
		case Cgm3Package.PHONE__PRIVACY_PATTERNS:
			return PRIVACY_PATTERNS_EDEFAULT == null ? privacy_patterns != null
					: !PRIVACY_PATTERNS_EDEFAULT.equals(privacy_patterns);
		case Cgm3Package.PHONE__USER_INFO_RETENTION_PERIOD:
			return user_info_Retention_Period != USER_INFO_RETENTION_PERIOD_EDEFAULT;
		case Cgm3Package.PHONE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			return is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures != IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_EDEFAULT;
		case Cgm3Package.PHONE__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD:
			return are_you_planning_to_send_all_the_data_to_the_cloud != ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD_EDEFAULT;
		case Cgm3Package.PHONE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
			return are_you_processing_data_in_an_incompatible_way_with_the_purpose != ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE_EDEFAULT;
		case Cgm3Package.PHONE__CONNECTION:
			return connection != CONNECTION_EDEFAULT;
		case Cgm3Package.PHONE__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE:
			return are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate != ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE_EDEFAULT;
		case Cgm3Package.PHONE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
			return are_you_storing_the_data_longer_than_is_necessary_for_the_purposes != ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES_EDEFAULT;
		case Cgm3Package.PHONE__USERLOCATION:
			return userlocation != null && !userlocation.isEmpty();
		case Cgm3Package.PHONE__CLOUDSERVICE:
			return cloudservice != null;
		case Cgm3Package.PHONE__COOKIES:
			return cookies != null && !cookies.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.PHONE__ENCRYPTED_DATA:
				return Cgm3Package.ENCRYPTION__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (derivedFeatureID) {
			case Cgm3Package.PHONE__PRIVACY_PATTERNS:
				return Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == Encryption.class) {
			switch (baseFeatureID) {
			case Cgm3Package.ENCRYPTION__ENCRYPTED_DATA:
				return Cgm3Package.PHONE__ENCRYPTED_DATA;
			default:
				return -1;
			}
		}
		if (baseClass == Privacy_patterns.class) {
			switch (baseFeatureID) {
			case Cgm3Package.PRIVACY_PATTERNS__PRIVACY_PATTERNS:
				return Cgm3Package.PHONE__PRIVACY_PATTERNS;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (EncryptedData: ");
		result.append(encryptedData);
		result.append(", Privacy_patterns: ");
		result.append(privacy_patterns);
		result.append(", User_info_Retention_Period: ");
		result.append(user_info_Retention_Period);
		result.append(
				", Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures: ");
		result.append(
				is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures);
		result.append(", Are_you_planning_to_send_all_the_data_to_the_cloud: ");
		result.append(are_you_planning_to_send_all_the_data_to_the_cloud);
		result.append(", Are_you_processing_data_in_an_incompatible_way_with_the_purpose: ");
		result.append(are_you_processing_data_in_an_incompatible_way_with_the_purpose);
		result.append(", Connection: ");
		result.append(connection);
		result.append(
				", Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate: ");
		result.append(
				are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate);
		result.append(", Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes: ");
		result.append(are_you_storing_the_data_longer_than_is_necessary_for_the_purposes);
		result.append(')');
		return result.toString();
	}

} //PhoneImpl
