/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package
 * @generated
 */
public interface Cgm3Factory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Cgm3Factory eINSTANCE = com.cardiffuni.pbdproject.cgm3.impl.Cgm3FactoryImpl.init();

	/**
	 * Returns a new object of class '<em>CG Msensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>CG Msensor</em>'.
	 * @generated
	 */
	CGMsensor createCGMsensor();

	/**
	 * Returns a new object of class '<em>Smart Phone</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Smart Phone</em>'.
	 * @generated
	 */
	SmartPhone createSmartPhone();

	/**
	 * Returns a new object of class '<em>Patient</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Patient</em>'.
	 * @generated
	 */
	Patient createPatient();

	/**
	 * Returns a new object of class '<em>Nurse</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Nurse</em>'.
	 * @generated
	 */
	Nurse createNurse();

	/**
	 * Returns a new object of class '<em>Doctor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Doctor</em>'.
	 * @generated
	 */
	Doctor createDoctor();

	/**
	 * Returns a new object of class '<em>New EClass7</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>New EClass7</em>'.
	 * @generated
	 */
	NewEClass7 createNewEClass7();

	/**
	 * Returns a new object of class '<em>Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Cloud</em>'.
	 * @generated
	 */
	Cloud createCloud();

	/**
	 * Returns a new object of class '<em>Website</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Website</em>'.
	 * @generated
	 */
	Website createWebsite();

	/**
	 * Returns a new object of class '<em>Hospital</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Hospital</em>'.
	 * @generated
	 */
	Hospital createHospital();

	/**
	 * Returns a new object of class '<em>Researcher</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Researcher</em>'.
	 * @generated
	 */
	Researcher createResearcher();

	/**
	 * Returns a new object of class '<em>Medical Record</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Medical Record</em>'.
	 * @generated
	 */
	MedicalRecord createMedicalRecord();

	/**
	 * Returns a new object of class '<em>Consent Checked List</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Consent Checked List</em>'.
	 * @generated
	 */
	Consent_CheckedList createConsent_CheckedList();

	/**
	 * Returns a new object of class '<em>Storage Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Storage Location</em>'.
	 * @generated
	 */
	StorageLocation createStorageLocation();

	/**
	 * Returns a new object of class '<em>User Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>User Location</em>'.
	 * @generated
	 */
	UserLocation createUserLocation();

	/**
	 * Returns a new object of class '<em>Risk Code</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Risk Code</em>'.
	 * @generated
	 */
	RiskCode createRiskCode();

	/**
	 * Returns a new object of class '<em>Authentication</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Authentication</em>'.
	 * @generated
	 */
	Authentication createAuthentication();

	/**
	 * Returns a new object of class '<em>Authorization</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Authorization</em>'.
	 * @generated
	 */
	Authorization createAuthorization();

	/**
	 * Returns a new object of class '<em>Firewall</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Firewall</em>'.
	 * @generated
	 */
	Firewall createFirewall();

	/**
	 * Returns a new object of class '<em>Data Sharing</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Data Sharing</em>'.
	 * @generated
	 */
	DataSharing createDataSharing();

	/**
	 * Returns a new object of class '<em>Warning</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Warning</em>'.
	 * @generated
	 */
	Warning createWarning();

	/**
	 * Returns a new object of class '<em>Test on dummy</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Test on dummy</em>'.
	 * @generated
	 */
	Test_on_dummy createTest_on_dummy();

	/**
	 * Returns a new object of class '<em>Containerisation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Containerisation</em>'.
	 * @generated
	 */
	Containerisation createContainerisation();

	/**
	 * Returns a new object of class '<em>Aggregation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Aggregation</em>'.
	 * @generated
	 */
	Aggregation createAggregation();

	/**
	 * Returns a new object of class '<em>New EClass26</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>New EClass26</em>'.
	 * @generated
	 */
	NewEClass26 createNewEClass26();

	/**
	 * Returns a new object of class '<em>Computer Browser</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Computer Browser</em>'.
	 * @generated
	 */
	ComputerBrowser createComputerBrowser();

	/**
	 * Returns a new object of class '<em>New EClass28</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>New EClass28</em>'.
	 * @generated
	 */
	NewEClass28 createNewEClass28();

	/**
	 * Returns a new object of class '<em>Pharmacy Cloudold</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pharmacy Cloudold</em>'.
	 * @generated
	 */
	PharmacyCloudold createPharmacyCloudold();

	/**
	 * Returns a new object of class '<em>Shipping Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Shipping Cloud</em>'.
	 * @generated
	 */
	ShippingCloud createShippingCloud();

	/**
	 * Returns a new object of class '<em>Webhosting Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Webhosting Cloud</em>'.
	 * @generated
	 */
	WebhostingCloud createWebhostingCloud();

	/**
	 * Returns a new object of class '<em>Payment Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Payment Cloud</em>'.
	 * @generated
	 */
	PaymentCloud createPaymentCloud();

	/**
	 * Returns a new object of class '<em>Social Network Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Social Network Cloud</em>'.
	 * @generated
	 */
	SocialNetworkCloud createSocialNetworkCloud();

	/**
	 * Returns a new object of class '<em>Real Time Bidding Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Real Time Bidding Cloud</em>'.
	 * @generated
	 */
	RealTimeBiddingCloud createRealTimeBiddingCloud();

	/**
	 * Returns a new object of class '<em>Web Browser</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Web Browser</em>'.
	 * @generated
	 */
	WebBrowser createWebBrowser();

	/**
	 * Returns a new object of class '<em>Cloud For Pharmacy</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Cloud For Pharmacy</em>'.
	 * @generated
	 */
	CloudForPharmacy createCloudForPharmacy();

	/**
	 * Returns a new object of class '<em>Bus</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Bus</em>'.
	 * @generated
	 */
	Bus createBus();

	/**
	 * Returns a new object of class '<em>GPS Tracker</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>GPS Tracker</em>'.
	 * @generated
	 */
	GPSTracker createGPSTracker();

	/**
	 * Returns a new object of class '<em>Video Analytics</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Video Analytics</em>'.
	 * @generated
	 */
	VideoAnalytics createVideoAnalytics();

	/**
	 * Returns a new object of class '<em>Video Without Analytics</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Video Without Analytics</em>'.
	 * @generated
	 */
	VideoWithoutAnalytics createVideoWithoutAnalytics();

	/**
	 * Returns a new object of class '<em>Driver</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Driver</em>'.
	 * @generated
	 */
	Driver createDriver();

	/**
	 * Returns a new object of class '<em>Customer</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Customer</em>'.
	 * @generated
	 */
	Customer createCustomer();

	/**
	 * Returns a new object of class '<em>Analytics</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Analytics</em>'.
	 * @generated
	 */
	Analytics createAnalytics();

	/**
	 * Returns a new object of class '<em>Blurring</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Blurring</em>'.
	 * @generated
	 */
	Blurring createBlurring();

	/**
	 * Returns a new object of class '<em>Video Processing Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Video Processing Cloud</em>'.
	 * @generated
	 */
	VideoProcessingCloud createVideoProcessingCloud();

	/**
	 * Returns a new object of class '<em>Client</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Client</em>'.
	 * @generated
	 */
	Client createClient();

	/**
	 * Returns a new object of class '<em>Cloud Service</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Cloud Service</em>'.
	 * @generated
	 */
	CloudService createCloudService();

	/**
	 * Returns a new object of class '<em>Light Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Light Sensor</em>'.
	 * @generated
	 */
	LightSensor createLightSensor();

	/**
	 * Returns a new object of class '<em>Phone</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Phone</em>'.
	 * @generated
	 */
	Phone createPhone();

	/**
	 * Returns a new object of class '<em>Door Lock</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Door Lock</em>'.
	 * @generated
	 */
	DoorLock createDoorLock();

	/**
	 * Returns a new object of class '<em>Thermostat</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Thermostat</em>'.
	 * @generated
	 */
	Thermostat createThermostat();

	/**
	 * Returns a new object of class '<em>Camera</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Camera</em>'.
	 * @generated
	 */
	Camera createCamera();

	/**
	 * Returns a new object of class '<em>Cookies</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Cookies</em>'.
	 * @generated
	 */
	Cookies createCookies();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	Cgm3Package getCgm3Package();

} //Cgm3Factory
