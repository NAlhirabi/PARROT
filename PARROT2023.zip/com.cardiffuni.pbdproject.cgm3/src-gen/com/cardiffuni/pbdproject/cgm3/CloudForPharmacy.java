/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cloud For Pharmacy</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getSmartphone <em>Smartphone</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getWebbrowser <em>Webbrowser</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getStoragelocation <em>Storagelocation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getTest_on_dummy <em>Test on dummy</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getContainerisation <em>Containerisation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAggregation <em>Aggregation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getDatasharing <em>Datasharing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getDataRetention <em>Data Retention</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getPaymentcloud <em>Paymentcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getSocialnetworkcloud <em>Socialnetworkcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getShippingcloud <em>Shippingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getWebhostingcloud <em>Webhostingcloud</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy()
 * @model
 * @generated
 */
public interface CloudForPharmacy extends GeneralEntity, Privacy_patterns, Encryption {
	/**
	 * Returns the value of the '<em><b>Smartphone</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getCloudforpharmacy <em>Cloudforpharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Smartphone</em>' reference.
	 * @see #setSmartphone(SmartPhone)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Smartphone()
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getCloudforpharmacy
	 * @model opposite="cloudforpharmacy"
	 * @generated
	 */
	SmartPhone getSmartphone();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getSmartphone <em>Smartphone</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Smartphone</em>' reference.
	 * @see #getSmartphone()
	 * @generated
	 */
	void setSmartphone(SmartPhone value);

	/**
	 * Returns the value of the '<em><b>Webbrowser</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.WebBrowser#getCloudforpharmacy <em>Cloudforpharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Webbrowser</em>' reference.
	 * @see #setWebbrowser(WebBrowser)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Webbrowser()
	 * @see com.cardiffuni.pbdproject.cgm3.WebBrowser#getCloudforpharmacy
	 * @model opposite="cloudforpharmacy"
	 * @generated
	 */
	WebBrowser getWebbrowser();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getWebbrowser <em>Webbrowser</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Webbrowser</em>' reference.
	 * @see #getWebbrowser()
	 * @generated
	 */
	void setWebbrowser(WebBrowser value);

	/**
	 * Returns the value of the '<em><b>Storagelocation</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.StorageLocation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Storagelocation</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Storagelocation()
	 * @model containment="true"
	 * @generated
	 */
	EList<StorageLocation> getStoragelocation();

	/**
	 * Returns the value of the '<em><b>Test on dummy</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Test_on_dummy}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Test on dummy</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Test_on_dummy()
	 * @model containment="true"
	 * @generated
	 */
	EList<Test_on_dummy> getTest_on_dummy();

	/**
	 * Returns the value of the '<em><b>Containerisation</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Containerisation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Containerisation</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Containerisation()
	 * @model containment="true"
	 * @generated
	 */
	EList<Containerisation> getContainerisation();

	/**
	 * Returns the value of the '<em><b>Aggregation</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Aggregation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Aggregation</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Aggregation()
	 * @model containment="true"
	 * @generated
	 */
	EList<Aggregation> getAggregation();

	/**
	 * Returns the value of the '<em><b>Datasharing</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.DataSharing}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Datasharing</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Datasharing()
	 * @model containment="true"
	 * @generated
	 */
	EList<DataSharing> getDatasharing();

	/**
	 * Returns the value of the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @generated
	 */
	void setAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you processing data in an incompatible way with the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Are_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you processing data in an incompatible way with the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @generated
	 */
	void setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 */
	void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you sharing data with other parties without having data subject consent</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_sharing_data_with_other_parties_without_having_data_subject_consent(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you sharing data with other parties without having data subject consent</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @generated
	 */
	void setAre_you_sharing_data_with_other_parties_without_having_data_subject_consent(Answer value);

	/**
	 * Returns the value of the '<em><b>Data Retention</b></em>' attribute.
	 * The default value is <code>"NotAccepted"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.DataRetentionEnum}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data Retention</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #setDataRetention(DataRetentionEnum)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_DataRetention()
	 * @model default="NotAccepted"
	 * @generated
	 */
	DataRetentionEnum getDataRetention();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getDataRetention <em>Data Retention</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Retention</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #getDataRetention()
	 * @generated
	 */
	void setDataRetention(DataRetentionEnum value);

	/**
	 * Returns the value of the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 */
	void setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
			Answer value);

	/**
	 * Returns the value of the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you collecting data that are not needed for the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_collecting_data_that_are_not_needed_for_the_purpose(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Are_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_collecting_data_that_are_not_needed_for_the_purpose();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you collecting data that are not needed for the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @generated
	 */
	void setAre_you_collecting_data_that_are_not_needed_for_the_purpose(Answer value);

	/**
	 * Returns the value of the '<em><b>Paymentcloud</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getCloudforpharmacy <em>Cloudforpharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Paymentcloud</em>' reference.
	 * @see #setPaymentcloud(PaymentCloud)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Paymentcloud()
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getCloudforpharmacy
	 * @model opposite="cloudforpharmacy"
	 * @generated
	 */
	PaymentCloud getPaymentcloud();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getPaymentcloud <em>Paymentcloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Paymentcloud</em>' reference.
	 * @see #getPaymentcloud()
	 * @generated
	 */
	void setPaymentcloud(PaymentCloud value);

	/**
	 * Returns the value of the '<em><b>Socialnetworkcloud</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getCloudforpharmacy <em>Cloudforpharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Socialnetworkcloud</em>' reference.
	 * @see #setSocialnetworkcloud(SocialNetworkCloud)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Socialnetworkcloud()
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getCloudforpharmacy
	 * @model opposite="cloudforpharmacy"
	 * @generated
	 */
	SocialNetworkCloud getSocialnetworkcloud();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getSocialnetworkcloud <em>Socialnetworkcloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Socialnetworkcloud</em>' reference.
	 * @see #getSocialnetworkcloud()
	 * @generated
	 */
	void setSocialnetworkcloud(SocialNetworkCloud value);

	/**
	 * Returns the value of the '<em><b>Shippingcloud</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getCloudforpharmacy <em>Cloudforpharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Shippingcloud</em>' reference.
	 * @see #setShippingcloud(ShippingCloud)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Shippingcloud()
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getCloudforpharmacy
	 * @model opposite="cloudforpharmacy"
	 * @generated
	 */
	ShippingCloud getShippingcloud();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getShippingcloud <em>Shippingcloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Shippingcloud</em>' reference.
	 * @see #getShippingcloud()
	 * @generated
	 */
	void setShippingcloud(ShippingCloud value);

	/**
	 * Returns the value of the '<em><b>Webhostingcloud</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getCloudforpharmacy <em>Cloudforpharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Webhostingcloud</em>' reference.
	 * @see #setWebhostingcloud(WebhostingCloud)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCloudForPharmacy_Webhostingcloud()
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getCloudforpharmacy
	 * @model opposite="cloudforpharmacy"
	 * @generated
	 */
	WebhostingCloud getWebhostingcloud();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getWebhostingcloud <em>Webhostingcloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Webhostingcloud</em>' reference.
	 * @see #getWebhostingcloud()
	 * @generated
	 */
	void setWebhostingcloud(WebhostingCloud value);

} // CloudForPharmacy
