/**
 */
package com.cardiffuni.pbdproject.cgm3;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Patient Health Status</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatientHealthStatus()
 * @model
 * @generated
 */
public enum PatientHealthStatus implements Enumerator {
	/**
	 * The '<em><b>Suspected Sick</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SUSPECTED_SICK_VALUE
	 * @generated
	 * @ordered
	 */
	SUSPECTED_SICK(1, "Suspected_Sick", "Suspected_Sick"),

	/**
	 * The '<em><b>Sick</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SICK_VALUE
	 * @generated
	 * @ordered
	 */
	SICK(2, "Sick", "Sick"),

	/**
	 * The '<em><b>Healthy</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #HEALTHY_VALUE
	 * @generated
	 * @ordered
	 */
	HEALTHY(2, "Healthy", "Healthy");

	/**
	 * The '<em><b>Suspected Sick</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SUSPECTED_SICK
	 * @model name="Suspected_Sick"
	 * @generated
	 * @ordered
	 */
	public static final int SUSPECTED_SICK_VALUE = 1;

	/**
	 * The '<em><b>Sick</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SICK
	 * @model name="Sick"
	 * @generated
	 * @ordered
	 */
	public static final int SICK_VALUE = 2;

	/**
	 * The '<em><b>Healthy</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #HEALTHY
	 * @model name="Healthy"
	 * @generated
	 * @ordered
	 */
	public static final int HEALTHY_VALUE = 2;

	/**
	 * An array of all the '<em><b>Patient Health Status</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final PatientHealthStatus[] VALUES_ARRAY = new PatientHealthStatus[] { SUSPECTED_SICK, SICK,
			HEALTHY, };

	/**
	 * A public read-only list of all the '<em><b>Patient Health Status</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<PatientHealthStatus> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Patient Health Status</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static PatientHealthStatus get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			PatientHealthStatus result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Patient Health Status</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static PatientHealthStatus getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			PatientHealthStatus result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Patient Health Status</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static PatientHealthStatus get(int value) {
		switch (value) {
		case SUSPECTED_SICK_VALUE:
			return SUSPECTED_SICK;
		case SICK_VALUE:
			return SICK;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private PatientHealthStatus(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //PatientHealthStatus
