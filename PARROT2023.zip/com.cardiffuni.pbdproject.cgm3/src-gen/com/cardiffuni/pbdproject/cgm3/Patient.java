/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Patient</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Patient#getSmartphone <em>Smartphone</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Patient#getCgmsensor <em>Cgmsensor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Patient#getDoctor <em>Doctor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Patient#getMedicalrecord <em>Medicalrecord</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Patient#getAge <em>Age</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Patient#getConsent_checkedlist <em>Consent checkedlist</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Patient#getPhoneNumber <em>Phone Number</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Patient#getAuthentication <em>Authentication</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Patient#getAuthorization <em>Authorization</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Patient#getDatasharing <em>Datasharing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Patient#getComputerbrowser <em>Computerbrowser</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Patient#getWebbrowser <em>Webbrowser</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatient()
 * @model
 * @generated
 */
public interface Patient extends GeneralEntity, Encryption, Privacy_patterns {
	/**
	 * Returns the value of the '<em><b>Smartphone</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.SmartPhone}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Smartphone</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatient_Smartphone()
	 * @model containment="true"
	 * @generated
	 */
	EList<SmartPhone> getSmartphone();

	/**
	 * Returns the value of the '<em><b>Cgmsensor</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.CGMsensor}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cgmsensor</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatient_Cgmsensor()
	 * @model containment="true"
	 * @generated
	 */
	EList<CGMsensor> getCgmsensor();

	/**
	 * Returns the value of the '<em><b>Doctor</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.Doctor#getPatient <em>Patient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Doctor</em>' reference.
	 * @see #setDoctor(Doctor)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatient_Doctor()
	 * @see com.cardiffuni.pbdproject.cgm3.Doctor#getPatient
	 * @model opposite="patient"
	 * @generated
	 */
	Doctor getDoctor();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Patient#getDoctor <em>Doctor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Doctor</em>' reference.
	 * @see #getDoctor()
	 * @generated
	 */
	void setDoctor(Doctor value);

	/**
	 * Returns the value of the '<em><b>Medicalrecord</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.MedicalRecord}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Medicalrecord</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatient_Medicalrecord()
	 * @model containment="true"
	 * @generated
	 */
	EList<MedicalRecord> getMedicalrecord();

	/**
	 * Returns the value of the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Age</em>' attribute.
	 * @see #setAge(int)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatient_Age()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.Int"
	 * @generated
	 */
	int getAge();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Patient#getAge <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Age</em>' attribute.
	 * @see #getAge()
	 * @generated
	 */
	void setAge(int value);

	/**
	 * Returns the value of the '<em><b>Consent checkedlist</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Consent checkedlist</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatient_Consent_checkedlist()
	 * @model containment="true"
	 * @generated
	 */
	EList<Consent_CheckedList> getConsent_checkedlist();

	/**
	 * Returns the value of the '<em><b>Phone Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Phone Number</em>' attribute.
	 * @see #setPhoneNumber(String)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatient_PhoneNumber()
	 * @model
	 * @generated
	 */
	String getPhoneNumber();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Patient#getPhoneNumber <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Phone Number</em>' attribute.
	 * @see #getPhoneNumber()
	 * @generated
	 */
	void setPhoneNumber(String value);

	/**
	 * Returns the value of the '<em><b>Authentication</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Authentication}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Authentication</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatient_Authentication()
	 * @model containment="true"
	 * @generated
	 */
	EList<Authentication> getAuthentication();

	/**
	 * Returns the value of the '<em><b>Authorization</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Authorization}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Authorization</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatient_Authorization()
	 * @model containment="true"
	 * @generated
	 */
	EList<Authorization> getAuthorization();

	/**
	 * Returns the value of the '<em><b>Datasharing</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.DataSharing}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Datasharing</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatient_Datasharing()
	 * @model containment="true"
	 * @generated
	 */
	EList<DataSharing> getDatasharing();

	/**
	 * Returns the value of the '<em><b>Computerbrowser</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Computerbrowser</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatient_Computerbrowser()
	 * @model containment="true"
	 * @generated
	 */
	EList<ComputerBrowser> getComputerbrowser();

	/**
	 * Returns the value of the '<em><b>Webbrowser</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.WebBrowser}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Webbrowser</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPatient_Webbrowser()
	 * @model containment="true"
	 * @generated
	 */
	EList<WebBrowser> getWebbrowser();

} // Patient
