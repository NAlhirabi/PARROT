/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Phone</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Phone#getUser_info_Retention_Period <em>User info Retention Period</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Phone#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_planning_to_send_all_the_data_to_the_cloud <em>Are you planning to send all the data to the cloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Phone#getConnection <em>Connection</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate <em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Phone#getUserlocation <em>Userlocation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Phone#getCloudservice <em>Cloudservice</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Phone#getCookies <em>Cookies</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPhone()
 * @model
 * @generated
 */
public interface Phone extends GeneralEntity, Encryption, Privacy_patterns {
	/**
	 * Returns the value of the '<em><b>User info Retention Period</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.DataRetentionEnum}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>User info Retention Period</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #setUser_info_Retention_Period(DataRetentionEnum)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPhone_User_info_Retention_Period()
	 * @model
	 * @generated
	 */
	DataRetentionEnum getUser_info_Retention_Period();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Phone#getUser_info_Retention_Period <em>User info Retention Period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>User info Retention Period</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #getUser_info_Retention_Period()
	 * @generated
	 */
	void setUser_info_Retention_Period(DataRetentionEnum value);

	/**
	 * Returns the value of the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPhone_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @model
	 * @generated
	 */
	Answer getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Phone#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 */
	void setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
			Answer value);

	/**
	 * Returns the value of the '<em><b>Are you planning to send all the data to the cloud</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you planning to send all the data to the cloud</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_planning_to_send_all_the_data_to_the_cloud(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPhone_Are_you_planning_to_send_all_the_data_to_the_cloud()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_planning_to_send_all_the_data_to_the_cloud();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_planning_to_send_all_the_data_to_the_cloud <em>Are you planning to send all the data to the cloud</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you planning to send all the data to the cloud</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_planning_to_send_all_the_data_to_the_cloud()
	 * @generated
	 */
	void setAre_you_planning_to_send_all_the_data_to_the_cloud(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you processing data in an incompatible way with the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPhone_Are_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you processing data in an incompatible way with the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @generated
	 */
	void setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(Answer value);

	/**
	 * Returns the value of the '<em><b>Connection</b></em>' attribute.
	 * The default value is <code>"Blutooth_and_WiFi"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.CommunicationProtocols}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connection</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.CommunicationProtocols
	 * @see #setConnection(CommunicationProtocols)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPhone_Connection()
	 * @model default="Blutooth_and_WiFi"
	 * @generated
	 */
	CommunicationProtocols getConnection();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Phone#getConnection <em>Connection</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Connection</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.CommunicationProtocols
	 * @see #getConnection()
	 * @generated
	 */
	void setConnection(CommunicationProtocols value);

	/**
	 * Returns the value of the '<em><b>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPhone_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate <em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate()
	 * @generated
	 */
	void setAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate(
			Answer value);

	/**
	 * Returns the value of the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPhone_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 */
	void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer value);

	/**
	 * Returns the value of the '<em><b>Userlocation</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.UserLocation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Userlocation</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPhone_Userlocation()
	 * @model containment="true"
	 * @generated
	 */
	EList<UserLocation> getUserlocation();

	/**
	 * Returns the value of the '<em><b>Cloudservice</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getPhone <em>Phone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cloudservice</em>' reference.
	 * @see #setCloudservice(CloudService)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPhone_Cloudservice()
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getPhone
	 * @model opposite="phone"
	 * @generated
	 */
	CloudService getCloudservice();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Phone#getCloudservice <em>Cloudservice</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cloudservice</em>' reference.
	 * @see #getCloudservice()
	 * @generated
	 */
	void setCloudservice(CloudService value);

	/**
	 * Returns the value of the '<em><b>Cookies</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Cookies}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cookies</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPhone_Cookies()
	 * @model containment="true"
	 * @generated
	 */
	EList<Cookies> getCookies();

} // Phone
