/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Containerisation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getContainerisation()
 * @model
 * @generated
 */
public interface Containerisation extends GeneralEntity {
} // Containerisation
