/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Nurse</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getNurse()
 * @model
 * @generated
 */
public interface Nurse extends GeneralEntity {
} // Nurse
