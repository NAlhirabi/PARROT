/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Customer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Customer#getGeneral_features <em>General features</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Customer#getConsent_checkedlist <em>Consent checkedlist</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Customer#getDo_people_aware_of_being_recorded <em>Do people aware of being recorded</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Customer#getVideoanalytics <em>Videoanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Customer#getVideowithoutanalytics <em>Videowithoutanalytics</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCustomer()
 * @model
 * @generated
 */
public interface Customer extends GeneralEntity {
	/**
	 * Returns the value of the '<em><b>General features</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>General features</em>' attribute.
	 * @see #setGeneral_features(String)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCustomer_General_features()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 * @generated
	 */
	String getGeneral_features();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Customer#getGeneral_features <em>General features</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>General features</em>' attribute.
	 * @see #getGeneral_features()
	 * @generated
	 */
	void setGeneral_features(String value);

	/**
	 * Returns the value of the '<em><b>Consent checkedlist</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Consent checkedlist</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCustomer_Consent_checkedlist()
	 * @model containment="true"
	 * @generated
	 */
	EList<Consent_CheckedList> getConsent_checkedlist();

	/**
	 * Returns the value of the '<em><b>Do people aware of being recorded</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Do people aware of being recorded</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setDo_people_aware_of_being_recorded(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCustomer_Do_people_aware_of_being_recorded()
	 * @model
	 * @generated
	 */
	Answer getDo_people_aware_of_being_recorded();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Customer#getDo_people_aware_of_being_recorded <em>Do people aware of being recorded</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Do people aware of being recorded</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getDo_people_aware_of_being_recorded()
	 * @generated
	 */
	void setDo_people_aware_of_being_recorded(Answer value);

	/**
	 * Returns the value of the '<em><b>Videoanalytics</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getCustomer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Videoanalytics</em>' reference.
	 * @see #setVideoanalytics(VideoAnalytics)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCustomer_Videoanalytics()
	 * @see com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getCustomer
	 * @model opposite="customer"
	 * @generated
	 */
	VideoAnalytics getVideoanalytics();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Customer#getVideoanalytics <em>Videoanalytics</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Videoanalytics</em>' reference.
	 * @see #getVideoanalytics()
	 * @generated
	 */
	void setVideoanalytics(VideoAnalytics value);

	/**
	 * Returns the value of the '<em><b>Videowithoutanalytics</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getCustomer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Videowithoutanalytics</em>' reference.
	 * @see #setVideowithoutanalytics(VideoWithoutAnalytics)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCustomer_Videowithoutanalytics()
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getCustomer
	 * @model opposite="customer"
	 * @generated
	 */
	VideoWithoutAnalytics getVideowithoutanalytics();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Customer#getVideowithoutanalytics <em>Videowithoutanalytics</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Videowithoutanalytics</em>' reference.
	 * @see #getVideowithoutanalytics()
	 * @generated
	 */
	void setVideowithoutanalytics(VideoWithoutAnalytics value);

} // Customer
