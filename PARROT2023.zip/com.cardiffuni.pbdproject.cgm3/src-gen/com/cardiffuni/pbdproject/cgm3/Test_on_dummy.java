/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Test on dummy</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Test_on_dummy#getTesting_on_dummy_data <em>Testing on dummy data</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getTest_on_dummy()
 * @model
 * @generated
 */
public interface Test_on_dummy extends GeneralEntity {
	/**
	 * Returns the value of the '<em><b>Testing on dummy data</b></em>' attribute.
	 * The default value is <code>" Testing_phase_and_dummy_data"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.TestOnDummyData}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Testing on dummy data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.TestOnDummyData
	 * @see #setTesting_on_dummy_data(TestOnDummyData)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getTest_on_dummy_Testing_on_dummy_data()
	 * @model default=" Testing_phase_and_dummy_data"
	 * @generated
	 */
	TestOnDummyData getTesting_on_dummy_data();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Test_on_dummy#getTesting_on_dummy_data <em>Testing on dummy data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Testing on dummy data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.TestOnDummyData
	 * @see #getTesting_on_dummy_data()
	 * @generated
	 */
	void setTesting_on_dummy_data(TestOnDummyData value);

} // Test_on_dummy
