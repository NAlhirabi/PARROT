/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Authentication</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Authentication#getAuthenticated <em>Authenticated</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAuthentication()
 * @model
 * @generated
 */
public interface Authentication extends GeneralEntity {
	/**
	 * Returns the value of the '<em><b>Authenticated</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Authenticated</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #setAuthenticated(Checked)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAuthentication_Authenticated()
	 * @model
	 * @generated
	 */
	Checked getAuthenticated();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Authentication#getAuthenticated <em>Authenticated</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Authenticated</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #getAuthenticated()
	 * @generated
	 */
	void setAuthenticated(Checked value);

} // Authentication
