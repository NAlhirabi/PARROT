/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Blurring</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Blurring#getDoes_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation <em>Does the face blur feature enabled for individuals to support individual anonymisation</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getBlurring()
 * @model
 * @generated
 */
public interface Blurring extends GeneralEntity {
	/**
	 * Returns the value of the '<em><b>Does the face blur feature enabled for individuals to support individual anonymisation</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Does the face blur feature enabled for individuals to support individual anonymisation</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setDoes_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getBlurring_Does_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation()
	 * @model
	 * @generated
	 */
	Answer getDoes_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Blurring#getDoes_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation <em>Does the face blur feature enabled for individuals to support individual anonymisation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Does the face blur feature enabled for individuals to support individual anonymisation</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getDoes_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation()
	 * @generated
	 */
	void setDoes_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation(Answer value);

} // Blurring
