/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bus</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Bus#getGpstracker <em>Gpstracker</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Bus#getPlate_number <em>Plate number</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Bus#getRoute_number <em>Route number</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Bus#getDriver_name <em>Driver name</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Bus#getVideowithoutanalytics <em>Videowithoutanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Bus#getDriver <em>Driver</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Bus#getVideoanalytics <em>Videoanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Bus#getVideoprocessingcloud <em>Videoprocessingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Bus#getCustomer <em>Customer</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getBus()
 * @model
 * @generated
 */
public interface Bus extends GeneralEntity {
	/**
	 * Returns the value of the '<em><b>Gpstracker</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.GPSTracker}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Gpstracker</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getBus_Gpstracker()
	 * @model containment="true"
	 * @generated
	 */
	EList<GPSTracker> getGpstracker();

	/**
	 * Returns the value of the '<em><b>Plate number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Plate number</em>' attribute.
	 * @see #setPlate_number(String)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getBus_Plate_number()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 * @generated
	 */
	String getPlate_number();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Bus#getPlate_number <em>Plate number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Plate number</em>' attribute.
	 * @see #getPlate_number()
	 * @generated
	 */
	void setPlate_number(String value);

	/**
	 * Returns the value of the '<em><b>Route number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Route number</em>' attribute.
	 * @see #setRoute_number(String)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getBus_Route_number()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 * @generated
	 */
	String getRoute_number();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Bus#getRoute_number <em>Route number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Route number</em>' attribute.
	 * @see #getRoute_number()
	 * @generated
	 */
	void setRoute_number(String value);

	/**
	 * Returns the value of the '<em><b>Driver name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Driver name</em>' attribute.
	 * @see #setDriver_name(String)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getBus_Driver_name()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 * @generated
	 */
	String getDriver_name();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Bus#getDriver_name <em>Driver name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Driver name</em>' attribute.
	 * @see #getDriver_name()
	 * @generated
	 */
	void setDriver_name(String value);

	/**
	 * Returns the value of the '<em><b>Driver</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Driver}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Driver</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getBus_Driver()
	 * @model containment="true"
	 * @generated
	 */
	EList<Driver> getDriver();

	/**
	 * Returns the value of the '<em><b>Videoanalytics</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Videoanalytics</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getBus_Videoanalytics()
	 * @model containment="true"
	 * @generated
	 */
	EList<VideoAnalytics> getVideoanalytics();

	/**
	 * Returns the value of the '<em><b>Videoprocessingcloud</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Videoprocessingcloud</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getBus_Videoprocessingcloud()
	 * @model containment="true"
	 * @generated
	 */
	EList<VideoProcessingCloud> getVideoprocessingcloud();

	/**
	 * Returns the value of the '<em><b>Customer</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Customer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Customer</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getBus_Customer()
	 * @model containment="true"
	 * @generated
	 */
	EList<Customer> getCustomer();

	/**
	 * Returns the value of the '<em><b>Videowithoutanalytics</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Videowithoutanalytics</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getBus_Videowithoutanalytics()
	 * @model containment="true"
	 * @generated
	 */
	EList<VideoWithoutAnalytics> getVideowithoutanalytics();

} // Bus
