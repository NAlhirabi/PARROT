/**
 */
package com.cardiffuni.pbdproject.cgm3.util;

import com.cardiffuni.pbdproject.cgm3.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package
 * @generated
 */
public class Cgm3AdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static Cgm3Package modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cgm3AdapterFactory() {
		if (modelPackage == null) {
			modelPackage = Cgm3Package.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Cgm3Switch<Adapter> modelSwitch = new Cgm3Switch<Adapter>() {
		@Override
		public Adapter caseGeneralEntity(GeneralEntity object) {
			return createGeneralEntityAdapter();
		}

		@Override
		public Adapter caseCGMsensor(CGMsensor object) {
			return createCGMsensorAdapter();
		}

		@Override
		public Adapter caseSmartPhone(SmartPhone object) {
			return createSmartPhoneAdapter();
		}

		@Override
		public Adapter casePatient(Patient object) {
			return createPatientAdapter();
		}

		@Override
		public Adapter caseNurse(Nurse object) {
			return createNurseAdapter();
		}

		@Override
		public Adapter caseDoctor(Doctor object) {
			return createDoctorAdapter();
		}

		@Override
		public Adapter caseNewEClass7(NewEClass7 object) {
			return createNewEClass7Adapter();
		}

		@Override
		public Adapter caseCloud(Cloud object) {
			return createCloudAdapter();
		}

		@Override
		public Adapter caseWebsite(Website object) {
			return createWebsiteAdapter();
		}

		@Override
		public Adapter caseHospital(Hospital object) {
			return createHospitalAdapter();
		}

		@Override
		public Adapter caseResearcher(Researcher object) {
			return createResearcherAdapter();
		}

		@Override
		public Adapter caseMedicalRecord(MedicalRecord object) {
			return createMedicalRecordAdapter();
		}

		@Override
		public Adapter caseConsent_CheckedList(Consent_CheckedList object) {
			return createConsent_CheckedListAdapter();
		}

		@Override
		public Adapter caseStorageLocation(StorageLocation object) {
			return createStorageLocationAdapter();
		}

		@Override
		public Adapter caseUserLocation(UserLocation object) {
			return createUserLocationAdapter();
		}

		@Override
		public Adapter caseRiskCode(RiskCode object) {
			return createRiskCodeAdapter();
		}

		@Override
		public Adapter caseAuthentication(Authentication object) {
			return createAuthenticationAdapter();
		}

		@Override
		public Adapter caseAuthorization(Authorization object) {
			return createAuthorizationAdapter();
		}

		@Override
		public Adapter caseFirewall(Firewall object) {
			return createFirewallAdapter();
		}

		@Override
		public Adapter caseEncryption(Encryption object) {
			return createEncryptionAdapter();
		}

		@Override
		public Adapter caseDataSharing(DataSharing object) {
			return createDataSharingAdapter();
		}

		@Override
		public Adapter caseWarning(Warning object) {
			return createWarningAdapter();
		}

		@Override
		public Adapter caseTest_on_dummy(Test_on_dummy object) {
			return createTest_on_dummyAdapter();
		}

		@Override
		public Adapter caseContainerisation(Containerisation object) {
			return createContainerisationAdapter();
		}

		@Override
		public Adapter caseAggregation(Aggregation object) {
			return createAggregationAdapter();
		}

		@Override
		public Adapter caseNewEClass26(NewEClass26 object) {
			return createNewEClass26Adapter();
		}

		@Override
		public Adapter caseComputerBrowser(ComputerBrowser object) {
			return createComputerBrowserAdapter();
		}

		@Override
		public Adapter caseNewEClass28(NewEClass28 object) {
			return createNewEClass28Adapter();
		}

		@Override
		public Adapter casePharmacyCloudold(PharmacyCloudold object) {
			return createPharmacyCloudoldAdapter();
		}

		@Override
		public Adapter caseShippingCloud(ShippingCloud object) {
			return createShippingCloudAdapter();
		}

		@Override
		public Adapter caseWebhostingCloud(WebhostingCloud object) {
			return createWebhostingCloudAdapter();
		}

		@Override
		public Adapter casePaymentCloud(PaymentCloud object) {
			return createPaymentCloudAdapter();
		}

		@Override
		public Adapter caseSocialNetworkCloud(SocialNetworkCloud object) {
			return createSocialNetworkCloudAdapter();
		}

		@Override
		public Adapter caseRealTimeBiddingCloud(RealTimeBiddingCloud object) {
			return createRealTimeBiddingCloudAdapter();
		}

		@Override
		public Adapter caseWebBrowser(WebBrowser object) {
			return createWebBrowserAdapter();
		}

		@Override
		public Adapter caseCloudForPharmacy(CloudForPharmacy object) {
			return createCloudForPharmacyAdapter();
		}

		@Override
		public Adapter caseBus(Bus object) {
			return createBusAdapter();
		}

		@Override
		public Adapter caseGPSTracker(GPSTracker object) {
			return createGPSTrackerAdapter();
		}

		@Override
		public Adapter caseVideoAnalytics(VideoAnalytics object) {
			return createVideoAnalyticsAdapter();
		}

		@Override
		public Adapter caseVideoWithoutAnalytics(VideoWithoutAnalytics object) {
			return createVideoWithoutAnalyticsAdapter();
		}

		@Override
		public Adapter caseDriver(Driver object) {
			return createDriverAdapter();
		}

		@Override
		public Adapter caseCustomer(Customer object) {
			return createCustomerAdapter();
		}

		@Override
		public Adapter caseAnalytics(Analytics object) {
			return createAnalyticsAdapter();
		}

		@Override
		public Adapter caseBlurring(Blurring object) {
			return createBlurringAdapter();
		}

		@Override
		public Adapter caseVideoProcessingCloud(VideoProcessingCloud object) {
			return createVideoProcessingCloudAdapter();
		}

		@Override
		public Adapter caseClient(Client object) {
			return createClientAdapter();
		}

		@Override
		public Adapter caseCloudService(CloudService object) {
			return createCloudServiceAdapter();
		}

		@Override
		public Adapter caseLightSensor(LightSensor object) {
			return createLightSensorAdapter();
		}

		@Override
		public Adapter casePhone(Phone object) {
			return createPhoneAdapter();
		}

		@Override
		public Adapter caseDoorLock(DoorLock object) {
			return createDoorLockAdapter();
		}

		@Override
		public Adapter caseThermostat(Thermostat object) {
			return createThermostatAdapter();
		}

		@Override
		public Adapter caseCamera(Camera object) {
			return createCameraAdapter();
		}

		@Override
		public Adapter casePrivacy_patterns(Privacy_patterns object) {
			return createPrivacy_patternsAdapter();
		}

		@Override
		public Adapter caseCookies(Cookies object) {
			return createCookiesAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.GeneralEntity <em>General Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.GeneralEntity
	 * @generated
	 */
	public Adapter createGeneralEntityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor <em>CG Msensor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.CGMsensor
	 * @generated
	 */
	public Adapter createCGMsensorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone <em>Smart Phone</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone
	 * @generated
	 */
	public Adapter createSmartPhoneAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Patient <em>Patient</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient
	 * @generated
	 */
	public Adapter createPatientAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Nurse <em>Nurse</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Nurse
	 * @generated
	 */
	public Adapter createNurseAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Doctor <em>Doctor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Doctor
	 * @generated
	 */
	public Adapter createDoctorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.NewEClass7 <em>New EClass7</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.NewEClass7
	 * @generated
	 */
	public Adapter createNewEClass7Adapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Cloud <em>Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud
	 * @generated
	 */
	public Adapter createCloudAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Website <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Website
	 * @generated
	 */
	public Adapter createWebsiteAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Hospital <em>Hospital</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital
	 * @generated
	 */
	public Adapter createHospitalAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Researcher <em>Researcher</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Researcher
	 * @generated
	 */
	public Adapter createResearcherAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.MedicalRecord <em>Medical Record</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.MedicalRecord
	 * @generated
	 */
	public Adapter createMedicalRecordAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList <em>Consent Checked List</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Consent_CheckedList
	 * @generated
	 */
	public Adapter createConsent_CheckedListAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.StorageLocation <em>Storage Location</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.StorageLocation
	 * @generated
	 */
	public Adapter createStorageLocationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.UserLocation <em>User Location</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.UserLocation
	 * @generated
	 */
	public Adapter createUserLocationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.RiskCode <em>Risk Code</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.RiskCode
	 * @generated
	 */
	public Adapter createRiskCodeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Authentication <em>Authentication</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Authentication
	 * @generated
	 */
	public Adapter createAuthenticationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Authorization <em>Authorization</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Authorization
	 * @generated
	 */
	public Adapter createAuthorizationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Firewall <em>Firewall</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Firewall
	 * @generated
	 */
	public Adapter createFirewallAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Encryption <em>Encryption</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Encryption
	 * @generated
	 */
	public Adapter createEncryptionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.DataSharing <em>Data Sharing</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.DataSharing
	 * @generated
	 */
	public Adapter createDataSharingAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Warning <em>Warning</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Warning
	 * @generated
	 */
	public Adapter createWarningAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Test_on_dummy <em>Test on dummy</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Test_on_dummy
	 * @generated
	 */
	public Adapter createTest_on_dummyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Containerisation <em>Containerisation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Containerisation
	 * @generated
	 */
	public Adapter createContainerisationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Aggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Aggregation
	 * @generated
	 */
	public Adapter createAggregationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.NewEClass26 <em>New EClass26</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.NewEClass26
	 * @generated
	 */
	public Adapter createNewEClass26Adapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser <em>Computer Browser</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.ComputerBrowser
	 * @generated
	 */
	public Adapter createComputerBrowserAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.NewEClass28 <em>New EClass28</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.NewEClass28
	 * @generated
	 */
	public Adapter createNewEClass28Adapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold <em>Pharmacy Cloudold</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold
	 * @generated
	 */
	public Adapter createPharmacyCloudoldAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud <em>Shipping Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud
	 * @generated
	 */
	public Adapter createShippingCloudAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud <em>Webhosting Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud
	 * @generated
	 */
	public Adapter createWebhostingCloudAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud <em>Payment Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud
	 * @generated
	 */
	public Adapter createPaymentCloudAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud <em>Social Network Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud
	 * @generated
	 */
	public Adapter createSocialNetworkCloudAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud <em>Real Time Bidding Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud
	 * @generated
	 */
	public Adapter createRealTimeBiddingCloudAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.WebBrowser <em>Web Browser</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.WebBrowser
	 * @generated
	 */
	public Adapter createWebBrowserAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy <em>Cloud For Pharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy
	 * @generated
	 */
	public Adapter createCloudForPharmacyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Bus <em>Bus</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Bus
	 * @generated
	 */
	public Adapter createBusAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker <em>GPS Tracker</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker
	 * @generated
	 */
	public Adapter createGPSTrackerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics <em>Video Analytics</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoAnalytics
	 * @generated
	 */
	public Adapter createVideoAnalyticsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics <em>Video Without Analytics</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics
	 * @generated
	 */
	public Adapter createVideoWithoutAnalyticsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Driver <em>Driver</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Driver
	 * @generated
	 */
	public Adapter createDriverAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Customer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Customer
	 * @generated
	 */
	public Adapter createCustomerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Analytics <em>Analytics</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Analytics
	 * @generated
	 */
	public Adapter createAnalyticsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Blurring <em>Blurring</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Blurring
	 * @generated
	 */
	public Adapter createBlurringAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud <em>Video Processing Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud
	 * @generated
	 */
	public Adapter createVideoProcessingCloudAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Client <em>Client</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Client
	 * @generated
	 */
	public Adapter createClientAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.CloudService <em>Cloud Service</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService
	 * @generated
	 */
	public Adapter createCloudServiceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.LightSensor <em>Light Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.LightSensor
	 * @generated
	 */
	public Adapter createLightSensorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Phone <em>Phone</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Phone
	 * @generated
	 */
	public Adapter createPhoneAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.DoorLock <em>Door Lock</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.DoorLock
	 * @generated
	 */
	public Adapter createDoorLockAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Thermostat <em>Thermostat</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Thermostat
	 * @generated
	 */
	public Adapter createThermostatAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Camera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera
	 * @generated
	 */
	public Adapter createCameraAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Privacy_patterns <em>Privacy patterns</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Privacy_patterns
	 * @generated
	 */
	public Adapter createPrivacy_patternsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link com.cardiffuni.pbdproject.cgm3.Cookies <em>Cookies</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see com.cardiffuni.pbdproject.cgm3.Cookies
	 * @generated
	 */
	public Adapter createCookiesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //Cgm3AdapterFactory
