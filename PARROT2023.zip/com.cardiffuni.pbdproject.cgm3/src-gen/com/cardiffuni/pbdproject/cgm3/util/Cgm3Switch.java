/**
 */
package com.cardiffuni.pbdproject.cgm3.util;

import com.cardiffuni.pbdproject.cgm3.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package
 * @generated
 */
public class Cgm3Switch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static Cgm3Package modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cgm3Switch() {
		if (modelPackage == null) {
			modelPackage = Cgm3Package.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case Cgm3Package.GENERAL_ENTITY: {
			GeneralEntity generalEntity = (GeneralEntity) theEObject;
			T result = caseGeneralEntity(generalEntity);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.CG_MSENSOR: {
			CGMsensor cgMsensor = (CGMsensor) theEObject;
			T result = caseCGMsensor(cgMsensor);
			if (result == null)
				result = caseEncryption(cgMsensor);
			if (result == null)
				result = caseGeneralEntity(cgMsensor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.SMART_PHONE: {
			SmartPhone smartPhone = (SmartPhone) theEObject;
			T result = caseSmartPhone(smartPhone);
			if (result == null)
				result = caseEncryption(smartPhone);
			if (result == null)
				result = casePrivacy_patterns(smartPhone);
			if (result == null)
				result = caseGeneralEntity(smartPhone);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.PATIENT: {
			Patient patient = (Patient) theEObject;
			T result = casePatient(patient);
			if (result == null)
				result = caseEncryption(patient);
			if (result == null)
				result = casePrivacy_patterns(patient);
			if (result == null)
				result = caseGeneralEntity(patient);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.NURSE: {
			Nurse nurse = (Nurse) theEObject;
			T result = caseNurse(nurse);
			if (result == null)
				result = caseGeneralEntity(nurse);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.DOCTOR: {
			Doctor doctor = (Doctor) theEObject;
			T result = caseDoctor(doctor);
			if (result == null)
				result = caseEncryption(doctor);
			if (result == null)
				result = caseGeneralEntity(doctor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.NEW_ECLASS7: {
			NewEClass7 newEClass7 = (NewEClass7) theEObject;
			T result = caseNewEClass7(newEClass7);
			if (result == null)
				result = caseGeneralEntity(newEClass7);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.CLOUD: {
			Cloud cloud = (Cloud) theEObject;
			T result = caseCloud(cloud);
			if (result == null)
				result = caseEncryption(cloud);
			if (result == null)
				result = caseGeneralEntity(cloud);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.WEBSITE: {
			Website website = (Website) theEObject;
			T result = caseWebsite(website);
			if (result == null)
				result = caseEncryption(website);
			if (result == null)
				result = caseGeneralEntity(website);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.HOSPITAL: {
			Hospital hospital = (Hospital) theEObject;
			T result = caseHospital(hospital);
			if (result == null)
				result = caseGeneralEntity(hospital);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.RESEARCHER: {
			Researcher researcher = (Researcher) theEObject;
			T result = caseResearcher(researcher);
			if (result == null)
				result = caseEncryption(researcher);
			if (result == null)
				result = caseGeneralEntity(researcher);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.MEDICAL_RECORD: {
			MedicalRecord medicalRecord = (MedicalRecord) theEObject;
			T result = caseMedicalRecord(medicalRecord);
			if (result == null)
				result = caseGeneralEntity(medicalRecord);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.CONSENT_CHECKED_LIST: {
			Consent_CheckedList consent_CheckedList = (Consent_CheckedList) theEObject;
			T result = caseConsent_CheckedList(consent_CheckedList);
			if (result == null)
				result = caseGeneralEntity(consent_CheckedList);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.STORAGE_LOCATION: {
			StorageLocation storageLocation = (StorageLocation) theEObject;
			T result = caseStorageLocation(storageLocation);
			if (result == null)
				result = caseGeneralEntity(storageLocation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.USER_LOCATION: {
			UserLocation userLocation = (UserLocation) theEObject;
			T result = caseUserLocation(userLocation);
			if (result == null)
				result = caseGeneralEntity(userLocation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.RISK_CODE: {
			RiskCode riskCode = (RiskCode) theEObject;
			T result = caseRiskCode(riskCode);
			if (result == null)
				result = caseGeneralEntity(riskCode);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.AUTHENTICATION: {
			Authentication authentication = (Authentication) theEObject;
			T result = caseAuthentication(authentication);
			if (result == null)
				result = caseGeneralEntity(authentication);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.AUTHORIZATION: {
			Authorization authorization = (Authorization) theEObject;
			T result = caseAuthorization(authorization);
			if (result == null)
				result = caseGeneralEntity(authorization);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.FIREWALL: {
			Firewall firewall = (Firewall) theEObject;
			T result = caseFirewall(firewall);
			if (result == null)
				result = caseGeneralEntity(firewall);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.ENCRYPTION: {
			Encryption encryption = (Encryption) theEObject;
			T result = caseEncryption(encryption);
			if (result == null)
				result = caseGeneralEntity(encryption);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.DATA_SHARING: {
			DataSharing dataSharing = (DataSharing) theEObject;
			T result = caseDataSharing(dataSharing);
			if (result == null)
				result = caseGeneralEntity(dataSharing);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.WARNING: {
			Warning warning = (Warning) theEObject;
			T result = caseWarning(warning);
			if (result == null)
				result = caseGeneralEntity(warning);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.TEST_ON_DUMMY: {
			Test_on_dummy test_on_dummy = (Test_on_dummy) theEObject;
			T result = caseTest_on_dummy(test_on_dummy);
			if (result == null)
				result = caseGeneralEntity(test_on_dummy);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.CONTAINERISATION: {
			Containerisation containerisation = (Containerisation) theEObject;
			T result = caseContainerisation(containerisation);
			if (result == null)
				result = caseGeneralEntity(containerisation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.AGGREGATION: {
			Aggregation aggregation = (Aggregation) theEObject;
			T result = caseAggregation(aggregation);
			if (result == null)
				result = caseGeneralEntity(aggregation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.NEW_ECLASS26: {
			NewEClass26 newEClass26 = (NewEClass26) theEObject;
			T result = caseNewEClass26(newEClass26);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.COMPUTER_BROWSER: {
			ComputerBrowser computerBrowser = (ComputerBrowser) theEObject;
			T result = caseComputerBrowser(computerBrowser);
			if (result == null)
				result = caseEncryption(computerBrowser);
			if (result == null)
				result = caseGeneralEntity(computerBrowser);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.NEW_ECLASS28: {
			NewEClass28 newEClass28 = (NewEClass28) theEObject;
			T result = caseNewEClass28(newEClass28);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.PHARMACY_CLOUDOLD: {
			PharmacyCloudold pharmacyCloudold = (PharmacyCloudold) theEObject;
			T result = casePharmacyCloudold(pharmacyCloudold);
			if (result == null)
				result = caseEncryption(pharmacyCloudold);
			if (result == null)
				result = caseGeneralEntity(pharmacyCloudold);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.SHIPPING_CLOUD: {
			ShippingCloud shippingCloud = (ShippingCloud) theEObject;
			T result = caseShippingCloud(shippingCloud);
			if (result == null)
				result = caseEncryption(shippingCloud);
			if (result == null)
				result = casePrivacy_patterns(shippingCloud);
			if (result == null)
				result = caseGeneralEntity(shippingCloud);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.WEBHOSTING_CLOUD: {
			WebhostingCloud webhostingCloud = (WebhostingCloud) theEObject;
			T result = caseWebhostingCloud(webhostingCloud);
			if (result == null)
				result = caseEncryption(webhostingCloud);
			if (result == null)
				result = casePrivacy_patterns(webhostingCloud);
			if (result == null)
				result = caseGeneralEntity(webhostingCloud);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.PAYMENT_CLOUD: {
			PaymentCloud paymentCloud = (PaymentCloud) theEObject;
			T result = casePaymentCloud(paymentCloud);
			if (result == null)
				result = caseEncryption(paymentCloud);
			if (result == null)
				result = casePrivacy_patterns(paymentCloud);
			if (result == null)
				result = caseGeneralEntity(paymentCloud);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.SOCIAL_NETWORK_CLOUD: {
			SocialNetworkCloud socialNetworkCloud = (SocialNetworkCloud) theEObject;
			T result = caseSocialNetworkCloud(socialNetworkCloud);
			if (result == null)
				result = caseEncryption(socialNetworkCloud);
			if (result == null)
				result = casePrivacy_patterns(socialNetworkCloud);
			if (result == null)
				result = caseGeneralEntity(socialNetworkCloud);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD: {
			RealTimeBiddingCloud realTimeBiddingCloud = (RealTimeBiddingCloud) theEObject;
			T result = caseRealTimeBiddingCloud(realTimeBiddingCloud);
			if (result == null)
				result = caseEncryption(realTimeBiddingCloud);
			if (result == null)
				result = casePrivacy_patterns(realTimeBiddingCloud);
			if (result == null)
				result = caseGeneralEntity(realTimeBiddingCloud);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.WEB_BROWSER: {
			WebBrowser webBrowser = (WebBrowser) theEObject;
			T result = caseWebBrowser(webBrowser);
			if (result == null)
				result = casePrivacy_patterns(webBrowser);
			if (result == null)
				result = caseEncryption(webBrowser);
			if (result == null)
				result = caseGeneralEntity(webBrowser);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.CLOUD_FOR_PHARMACY: {
			CloudForPharmacy cloudForPharmacy = (CloudForPharmacy) theEObject;
			T result = caseCloudForPharmacy(cloudForPharmacy);
			if (result == null)
				result = casePrivacy_patterns(cloudForPharmacy);
			if (result == null)
				result = caseEncryption(cloudForPharmacy);
			if (result == null)
				result = caseGeneralEntity(cloudForPharmacy);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.BUS: {
			Bus bus = (Bus) theEObject;
			T result = caseBus(bus);
			if (result == null)
				result = caseGeneralEntity(bus);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.GPS_TRACKER: {
			GPSTracker gpsTracker = (GPSTracker) theEObject;
			T result = caseGPSTracker(gpsTracker);
			if (result == null)
				result = caseGeneralEntity(gpsTracker);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.VIDEO_ANALYTICS: {
			VideoAnalytics videoAnalytics = (VideoAnalytics) theEObject;
			T result = caseVideoAnalytics(videoAnalytics);
			if (result == null)
				result = caseEncryption(videoAnalytics);
			if (result == null)
				result = caseGeneralEntity(videoAnalytics);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.VIDEO_WITHOUT_ANALYTICS: {
			VideoWithoutAnalytics videoWithoutAnalytics = (VideoWithoutAnalytics) theEObject;
			T result = caseVideoWithoutAnalytics(videoWithoutAnalytics);
			if (result == null)
				result = caseEncryption(videoWithoutAnalytics);
			if (result == null)
				result = caseGeneralEntity(videoWithoutAnalytics);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.DRIVER: {
			Driver driver = (Driver) theEObject;
			T result = caseDriver(driver);
			if (result == null)
				result = caseGeneralEntity(driver);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.CUSTOMER: {
			Customer customer = (Customer) theEObject;
			T result = caseCustomer(customer);
			if (result == null)
				result = caseGeneralEntity(customer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.ANALYTICS: {
			Analytics analytics = (Analytics) theEObject;
			T result = caseAnalytics(analytics);
			if (result == null)
				result = caseGeneralEntity(analytics);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.BLURRING: {
			Blurring blurring = (Blurring) theEObject;
			T result = caseBlurring(blurring);
			if (result == null)
				result = caseGeneralEntity(blurring);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.VIDEO_PROCESSING_CLOUD: {
			VideoProcessingCloud videoProcessingCloud = (VideoProcessingCloud) theEObject;
			T result = caseVideoProcessingCloud(videoProcessingCloud);
			if (result == null)
				result = caseEncryption(videoProcessingCloud);
			if (result == null)
				result = caseGeneralEntity(videoProcessingCloud);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.CLIENT: {
			Client client = (Client) theEObject;
			T result = caseClient(client);
			if (result == null)
				result = caseEncryption(client);
			if (result == null)
				result = casePrivacy_patterns(client);
			if (result == null)
				result = caseGeneralEntity(client);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.CLOUD_SERVICE: {
			CloudService cloudService = (CloudService) theEObject;
			T result = caseCloudService(cloudService);
			if (result == null)
				result = caseEncryption(cloudService);
			if (result == null)
				result = casePrivacy_patterns(cloudService);
			if (result == null)
				result = caseGeneralEntity(cloudService);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.LIGHT_SENSOR: {
			LightSensor lightSensor = (LightSensor) theEObject;
			T result = caseLightSensor(lightSensor);
			if (result == null)
				result = caseEncryption(lightSensor);
			if (result == null)
				result = casePrivacy_patterns(lightSensor);
			if (result == null)
				result = caseGeneralEntity(lightSensor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.PHONE: {
			Phone phone = (Phone) theEObject;
			T result = casePhone(phone);
			if (result == null)
				result = caseEncryption(phone);
			if (result == null)
				result = casePrivacy_patterns(phone);
			if (result == null)
				result = caseGeneralEntity(phone);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.DOOR_LOCK: {
			DoorLock doorLock = (DoorLock) theEObject;
			T result = caseDoorLock(doorLock);
			if (result == null)
				result = caseEncryption(doorLock);
			if (result == null)
				result = casePrivacy_patterns(doorLock);
			if (result == null)
				result = caseGeneralEntity(doorLock);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.THERMOSTAT: {
			Thermostat thermostat = (Thermostat) theEObject;
			T result = caseThermostat(thermostat);
			if (result == null)
				result = caseEncryption(thermostat);
			if (result == null)
				result = casePrivacy_patterns(thermostat);
			if (result == null)
				result = caseGeneralEntity(thermostat);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.CAMERA: {
			Camera camera = (Camera) theEObject;
			T result = caseCamera(camera);
			if (result == null)
				result = caseEncryption(camera);
			if (result == null)
				result = casePrivacy_patterns(camera);
			if (result == null)
				result = caseGeneralEntity(camera);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.PRIVACY_PATTERNS: {
			Privacy_patterns privacy_patterns = (Privacy_patterns) theEObject;
			T result = casePrivacy_patterns(privacy_patterns);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case Cgm3Package.COOKIES: {
			Cookies cookies = (Cookies) theEObject;
			T result = caseCookies(cookies);
			if (result == null)
				result = caseGeneralEntity(cookies);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>General Entity</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>General Entity</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGeneralEntity(GeneralEntity object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>CG Msensor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>CG Msensor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCGMsensor(CGMsensor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Smart Phone</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Smart Phone</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSmartPhone(SmartPhone object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Patient</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Patient</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePatient(Patient object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Nurse</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Nurse</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNurse(Nurse object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Doctor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Doctor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDoctor(Doctor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>New EClass7</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>New EClass7</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNewEClass7(NewEClass7 object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Cloud</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCloud(Cloud object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Website</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Website</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWebsite(Website object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Hospital</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Hospital</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHospital(Hospital object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Researcher</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Researcher</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseResearcher(Researcher object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Medical Record</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Medical Record</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMedicalRecord(MedicalRecord object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Consent Checked List</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Consent Checked List</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConsent_CheckedList(Consent_CheckedList object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Storage Location</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Storage Location</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStorageLocation(StorageLocation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>User Location</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>User Location</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseUserLocation(UserLocation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Risk Code</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Risk Code</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRiskCode(RiskCode object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Authentication</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Authentication</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAuthentication(Authentication object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Authorization</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Authorization</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAuthorization(Authorization object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Firewall</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Firewall</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFirewall(Firewall object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Encryption</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Encryption</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEncryption(Encryption object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Data Sharing</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Data Sharing</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDataSharing(DataSharing object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Warning</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Warning</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWarning(Warning object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Test on dummy</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Test on dummy</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTest_on_dummy(Test_on_dummy object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Containerisation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Containerisation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseContainerisation(Containerisation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Aggregation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Aggregation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAggregation(Aggregation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>New EClass26</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>New EClass26</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNewEClass26(NewEClass26 object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Computer Browser</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Computer Browser</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseComputerBrowser(ComputerBrowser object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>New EClass28</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>New EClass28</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNewEClass28(NewEClass28 object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pharmacy Cloudold</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pharmacy Cloudold</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePharmacyCloudold(PharmacyCloudold object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Shipping Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Shipping Cloud</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseShippingCloud(ShippingCloud object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Webhosting Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Webhosting Cloud</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWebhostingCloud(WebhostingCloud object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Payment Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Payment Cloud</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePaymentCloud(PaymentCloud object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Social Network Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Social Network Cloud</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSocialNetworkCloud(SocialNetworkCloud object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Real Time Bidding Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Real Time Bidding Cloud</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRealTimeBiddingCloud(RealTimeBiddingCloud object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Web Browser</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Web Browser</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWebBrowser(WebBrowser object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Cloud For Pharmacy</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Cloud For Pharmacy</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCloudForPharmacy(CloudForPharmacy object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Bus</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Bus</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBus(Bus object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>GPS Tracker</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>GPS Tracker</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGPSTracker(GPSTracker object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Video Analytics</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Video Analytics</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseVideoAnalytics(VideoAnalytics object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Video Without Analytics</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Video Without Analytics</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseVideoWithoutAnalytics(VideoWithoutAnalytics object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Driver</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Driver</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDriver(Driver object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Customer</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Customer</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCustomer(Customer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Analytics</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Analytics</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAnalytics(Analytics object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Blurring</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Blurring</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBlurring(Blurring object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Video Processing Cloud</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Video Processing Cloud</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseVideoProcessingCloud(VideoProcessingCloud object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Client</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Client</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseClient(Client object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Cloud Service</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Cloud Service</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCloudService(CloudService object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Light Sensor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Light Sensor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLightSensor(LightSensor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Phone</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Phone</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePhone(Phone object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Door Lock</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Door Lock</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDoorLock(DoorLock object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Thermostat</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Thermostat</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseThermostat(Thermostat object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Camera</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Camera</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCamera(Camera object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Privacy patterns</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Privacy patterns</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePrivacy_patterns(Privacy_patterns object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Cookies</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Cookies</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCookies(Cookies object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //Cgm3Switch
