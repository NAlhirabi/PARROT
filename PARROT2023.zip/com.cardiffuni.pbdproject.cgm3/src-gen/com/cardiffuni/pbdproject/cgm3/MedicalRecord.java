/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Medical Record</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.MedicalRecord#getRecordRetentionPeriod <em>Record Retention Period</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getMedicalRecord()
 * @model
 * @generated
 */
public interface MedicalRecord extends GeneralEntity {
	/**
	 * Returns the value of the '<em><b>Record Retention Period</b></em>' attribute.
	 * The default value is <code>"NotAccepted"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.DataRetentionEnum}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Record Retention Period</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #setRecordRetentionPeriod(DataRetentionEnum)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getMedicalRecord_RecordRetentionPeriod()
	 * @model default="NotAccepted"
	 * @generated
	 */
	DataRetentionEnum getRecordRetentionPeriod();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.MedicalRecord#getRecordRetentionPeriod <em>Record Retention Period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Record Retention Period</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #getRecordRetentionPeriod()
	 * @generated
	 */
	void setRecordRetentionPeriod(DataRetentionEnum value);

} // MedicalRecord
