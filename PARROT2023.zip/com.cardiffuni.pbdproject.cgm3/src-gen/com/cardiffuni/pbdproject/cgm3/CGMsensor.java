/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>CG Msensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getSmartphone <em>Smartphone</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getGlucose_amount <em>Glucose amount</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getConnection <em>Connection</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getDataRetention <em>Data Retention</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCGMsensor()
 * @model
 * @generated
 */
public interface CGMsensor extends GeneralEntity, Encryption {
	/**
	 * Returns the value of the '<em><b>Smartphone</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getCgmsensor <em>Cgmsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Smartphone</em>' reference.
	 * @see #setSmartphone(SmartPhone)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCGMsensor_Smartphone()
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getCgmsensor
	 * @model opposite="cgmsensor"
	 * @generated
	 */
	SmartPhone getSmartphone();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getSmartphone <em>Smartphone</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Smartphone</em>' reference.
	 * @see #getSmartphone()
	 * @generated
	 */
	void setSmartphone(SmartPhone value);

	/**
	 * Returns the value of the '<em><b>Glucose amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Glucose amount</em>' attribute.
	 * @see #setGlucose_amount(int)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCGMsensor_Glucose_amount()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.Int"
	 * @generated
	 */
	int getGlucose_amount();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getGlucose_amount <em>Glucose amount</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Glucose amount</em>' attribute.
	 * @see #getGlucose_amount()
	 * @generated
	 */
	void setGlucose_amount(int value);

	/**
	 * Returns the value of the '<em><b>Connection</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.CommunicationProtocols}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connection</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.CommunicationProtocols
	 * @see #setConnection(CommunicationProtocols)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCGMsensor_Connection()
	 * @model
	 * @generated
	 */
	CommunicationProtocols getConnection();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getConnection <em>Connection</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Connection</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.CommunicationProtocols
	 * @see #getConnection()
	 * @generated
	 */
	void setConnection(CommunicationProtocols value);

	/**
	 * Returns the value of the '<em><b>Data Retention</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.DataRetentionEnum}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data Retention</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #setDataRetention(DataRetentionEnum)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCGMsensor_DataRetention()
	 * @model
	 * @generated
	 */
	DataRetentionEnum getDataRetention();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getDataRetention <em>Data Retention</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Retention</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #getDataRetention()
	 * @generated
	 */
	void setDataRetention(DataRetentionEnum value);

	/**
	 * Returns the value of the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCGMsensor_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @model
	 * @generated
	 */
	Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 */
	void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer value);

	/**
	 * Returns the value of the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCGMsensor_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @model
	 * @generated
	 */
	Answer getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 */
	void setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
			Answer value);

} // CGMsensor
