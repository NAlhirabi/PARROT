/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>New EClass7</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getNewEClass7()
 * @model
 * @generated
 */
public interface NewEClass7 extends GeneralEntity {
} // NewEClass7
