/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Data Sharing</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.DataSharing#getApply_anonymisation_for_researcher <em>Apply anonymisation for researcher</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.DataSharing#getEnsure_accessControl <em>Ensure access Control</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDataSharing()
 * @model
 * @generated
 */
public interface DataSharing extends GeneralEntity {

	/**
	 * Returns the value of the '<em><b>Apply anonymisation for researcher</b></em>' attribute.
	 * The default value is <code>"No"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Apply anonymisation for researcher</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #setApply_anonymisation_for_researcher(Checked)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDataSharing_Apply_anonymisation_for_researcher()
	 * @model default="No"
	 * @generated
	 */
	Checked getApply_anonymisation_for_researcher();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.DataSharing#getApply_anonymisation_for_researcher <em>Apply anonymisation for researcher</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Apply anonymisation for researcher</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #getApply_anonymisation_for_researcher()
	 * @generated
	 */
	void setApply_anonymisation_for_researcher(Checked value);

	/**
	 * Returns the value of the '<em><b>Ensure access Control</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ensure access Control</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #setEnsure_accessControl(Checked)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDataSharing_Ensure_accessControl()
	 * @model
	 * @generated
	 */
	Checked getEnsure_accessControl();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.DataSharing#getEnsure_accessControl <em>Ensure access Control</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ensure access Control</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #getEnsure_accessControl()
	 * @generated
	 */
	void setEnsure_accessControl(Checked value);
} // DataSharing
