/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Doctor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Doctor#getPatient <em>Patient</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Doctor#getWebsite <em>Website</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Doctor#getSpecialty <em>Specialty</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Doctor#getAuthentication <em>Authentication</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Doctor#getAuthorization <em>Authorization</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Doctor#getAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data <em>Are you allowing unauthorised doctors to access or process the data subject health data</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDoctor()
 * @model
 * @generated
 */
public interface Doctor extends GeneralEntity, Encryption {

	/**
	 * Returns the value of the '<em><b>Patient</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.Patient#getDoctor <em>Doctor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Patient</em>' reference.
	 * @see #setPatient(Patient)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDoctor_Patient()
	 * @see com.cardiffuni.pbdproject.cgm3.Patient#getDoctor
	 * @model opposite="doctor"
	 * @generated
	 */
	Patient getPatient();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Doctor#getPatient <em>Patient</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Patient</em>' reference.
	 * @see #getPatient()
	 * @generated
	 */
	void setPatient(Patient value);

	/**
	 * Returns the value of the '<em><b>Website</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.Website#getDoctor <em>Doctor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Website</em>' reference.
	 * @see #setWebsite(Website)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDoctor_Website()
	 * @see com.cardiffuni.pbdproject.cgm3.Website#getDoctor
	 * @model opposite="doctor"
	 * @generated
	 */
	Website getWebsite();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Doctor#getWebsite <em>Website</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Website</em>' reference.
	 * @see #getWebsite()
	 * @generated
	 */
	void setWebsite(Website value);

	/**
	 * Returns the value of the '<em><b>Specialty</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Specialty</em>' attribute.
	 * @see #setSpecialty(String)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDoctor_Specialty()
	 * @model
	 * @generated
	 */
	String getSpecialty();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Doctor#getSpecialty <em>Specialty</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Specialty</em>' attribute.
	 * @see #getSpecialty()
	 * @generated
	 */
	void setSpecialty(String value);

	/**
	 * Returns the value of the '<em><b>Authentication</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Authentication}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Authentication</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDoctor_Authentication()
	 * @model containment="true"
	 * @generated
	 */
	EList<Authentication> getAuthentication();

	/**
	 * Returns the value of the '<em><b>Authorization</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Authorization}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Authorization</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDoctor_Authorization()
	 * @model containment="true"
	 * @generated
	 */
	EList<Authorization> getAuthorization();

	/**
	 * Returns the value of the '<em><b>Are you allowing unauthorised doctors to access or process the data subject health data</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you allowing unauthorised doctors to access or process the data subject health data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDoctor_Are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data()
	 * @model
	 * @generated
	 */
	Answer getAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Doctor#getAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data <em>Are you allowing unauthorised doctors to access or process the data subject health data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you allowing unauthorised doctors to access or process the data subject health data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data()
	 * @generated
	 */
	void setAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data(Answer value);
} // Doctor
