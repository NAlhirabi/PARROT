/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Camera</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_sending_data_without_anonymisation <em>Are you sending data without anonymisation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Camera#getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV <em>Does the sign has abrief explanation about the purpose of CCTV</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Camera#getDo_people_aware_of_being_recorded <em>Do people aware of being recorded</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_storing_the_footage_in_a_secure_location <em>Are you storing the footage in asecure location</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Camera#getEnsure_data_minimisation_is_aplied <em>Ensure data minimisation is aplied</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Camera#getDo_you_use_signs_that_say_CCTV_is_in_operation <em>Do you use signs that say CCTV is in operation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Camera#getDoes_the_system_record_information_other_than_the_purpose <em>Does the system record information other than the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Camera#getRecord_retention_period <em>Record retention period</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_allowing_data_unauthorised_access <em>Are you allowing data unauthorised access</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Camera#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Camera#getCloudservice <em>Cloudservice</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera()
 * @model
 * @generated
 */
public interface Camera extends GeneralEntity, Encryption, Privacy_patterns {
	/**
	 * Returns the value of the '<em><b>Are you sending data without anonymisation</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you sending data without anonymisation</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_sending_data_without_anonymisation(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera_Are_you_sending_data_without_anonymisation()
	 * @model
	 * @generated
	 */
	Answer getAre_you_sending_data_without_anonymisation();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_sending_data_without_anonymisation <em>Are you sending data without anonymisation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you sending data without anonymisation</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_sending_data_without_anonymisation()
	 * @generated
	 */
	void setAre_you_sending_data_without_anonymisation(Answer value);

	/**
	 * Returns the value of the '<em><b>Does the sign has abrief explanation about the purpose of CCTV</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Does the sign has abrief explanation about the purpose of CCTV</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Camera#getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV <em>Does the sign has abrief explanation about the purpose of CCTV</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Does the sign has abrief explanation about the purpose of CCTV</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV()
	 * @generated
	 */
	void setDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV(Answer value);

	/**
	 * Returns the value of the '<em><b>Do people aware of being recorded</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Do people aware of being recorded</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setDo_people_aware_of_being_recorded(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera_Do_people_aware_of_being_recorded()
	 * @model
	 * @generated
	 */
	Answer getDo_people_aware_of_being_recorded();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Camera#getDo_people_aware_of_being_recorded <em>Do people aware of being recorded</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Do people aware of being recorded</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getDo_people_aware_of_being_recorded()
	 * @generated
	 */
	void setDo_people_aware_of_being_recorded(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you using appropriate technical or organisational measures to protect the data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @model
	 * @generated
	 */
	Answer getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you using appropriate technical or organisational measures to protect the data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @generated
	 */
	void setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you storing the footage in asecure location</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you storing the footage in asecure location</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_storing_the_footage_in_a_secure_location(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera_Are_you_storing_the_footage_in_a_secure_location()
	 * @model
	 * @generated
	 */
	Answer getAre_you_storing_the_footage_in_a_secure_location();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_storing_the_footage_in_a_secure_location <em>Are you storing the footage in asecure location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you storing the footage in asecure location</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_storing_the_footage_in_a_secure_location()
	 * @generated
	 */
	void setAre_you_storing_the_footage_in_a_secure_location(Answer value);

	/**
	 * Returns the value of the '<em><b>Ensure data minimisation is aplied</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ensure data minimisation is aplied</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setEnsure_data_minimisation_is_aplied(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera_Ensure_data_minimisation_is_aplied()
	 * @model
	 * @generated
	 */
	Answer getEnsure_data_minimisation_is_aplied();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Camera#getEnsure_data_minimisation_is_aplied <em>Ensure data minimisation is aplied</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ensure data minimisation is aplied</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getEnsure_data_minimisation_is_aplied()
	 * @generated
	 */
	void setEnsure_data_minimisation_is_aplied(Answer value);

	/**
	 * Returns the value of the '<em><b>Do you use signs that say CCTV is in operation</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Do you use signs that say CCTV is in operation</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setDo_you_use_signs_that_say_CCTV_is_in_operation(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera_Do_you_use_signs_that_say_CCTV_is_in_operation()
	 * @model
	 * @generated
	 */
	Answer getDo_you_use_signs_that_say_CCTV_is_in_operation();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Camera#getDo_you_use_signs_that_say_CCTV_is_in_operation <em>Do you use signs that say CCTV is in operation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Do you use signs that say CCTV is in operation</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getDo_you_use_signs_that_say_CCTV_is_in_operation()
	 * @generated
	 */
	void setDo_you_use_signs_that_say_CCTV_is_in_operation(Answer value);

	/**
	 * Returns the value of the '<em><b>Does the system record information other than the purpose</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Does the system record information other than the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setDoes_the_system_record_information_other_than_the_purpose(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera_Does_the_system_record_information_other_than_the_purpose()
	 * @model
	 * @generated
	 */
	Answer getDoes_the_system_record_information_other_than_the_purpose();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Camera#getDoes_the_system_record_information_other_than_the_purpose <em>Does the system record information other than the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Does the system record information other than the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getDoes_the_system_record_information_other_than_the_purpose()
	 * @generated
	 */
	void setDoes_the_system_record_information_other_than_the_purpose(Answer value);

	/**
	 * Returns the value of the '<em><b>Record retention period</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.DataRetentionEnum}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Record retention period</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #setRecord_retention_period(DataRetentionEnum)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera_Record_retention_period()
	 * @model
	 * @generated
	 */
	DataRetentionEnum getRecord_retention_period();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Camera#getRecord_retention_period <em>Record retention period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Record retention period</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #getRecord_retention_period()
	 * @generated
	 */
	void setRecord_retention_period(DataRetentionEnum value);

	/**
	 * Returns the value of the '<em><b>Are you allowing data unauthorised access</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you allowing data unauthorised access</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_allowing_data_unauthorised_access(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera_Are_you_allowing_data_unauthorised_access()
	 * @model
	 * @generated
	 */
	Answer getAre_you_allowing_data_unauthorised_access();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_allowing_data_unauthorised_access <em>Are you allowing data unauthorised access</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you allowing data unauthorised access</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_allowing_data_unauthorised_access()
	 * @generated
	 */
	void setAre_you_allowing_data_unauthorised_access(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @model
	 * @generated
	 */
	Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 */
	void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer value);

	/**
	 * Returns the value of the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is data against accidental loss or destruction or damage</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setIs_data_against_accidental_loss_or_destruction_or_damage(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera_Is_data_against_accidental_loss_or_destruction_or_damage()
	 * @model
	 * @generated
	 */
	Answer getIs_data_against_accidental_loss_or_destruction_or_damage();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Camera#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is data against accidental loss or destruction or damage</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @generated
	 */
	void setIs_data_against_accidental_loss_or_destruction_or_damage(Answer value);

	/**
	 * Returns the value of the '<em><b>Cloudservice</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getCamera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cloudservice</em>' reference.
	 * @see #setCloudservice(CloudService)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCamera_Cloudservice()
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getCamera
	 * @model opposite="camera"
	 * @generated
	 */
	CloudService getCloudservice();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Camera#getCloudservice <em>Cloudservice</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cloudservice</em>' reference.
	 * @see #getCloudservice()
	 * @generated
	 */
	void setCloudservice(CloudService value);

} // Camera
