/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Light Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getConnection <em>Connection</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getDataRetention <em>Data Retention</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getCloudservice <em>Cloudservice</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getLightSensor()
 * @model
 * @generated
 */
public interface LightSensor extends GeneralEntity, Encryption, Privacy_patterns {
	/**
	 * Returns the value of the '<em><b>Connection</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.CommunicationProtocols}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connection</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.CommunicationProtocols
	 * @see #setConnection(CommunicationProtocols)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getLightSensor_Connection()
	 * @model
	 * @generated
	 */
	CommunicationProtocols getConnection();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getConnection <em>Connection</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Connection</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.CommunicationProtocols
	 * @see #getConnection()
	 * @generated
	 */
	void setConnection(CommunicationProtocols value);

	/**
	 * Returns the value of the '<em><b>Data Retention</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.DataRetentionEnum}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data Retention</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #setDataRetention(DataRetentionEnum)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getLightSensor_DataRetention()
	 * @model
	 * @generated
	 */
	DataRetentionEnum getDataRetention();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getDataRetention <em>Data Retention</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Retention</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #getDataRetention()
	 * @generated
	 */
	void setDataRetention(DataRetentionEnum value);

	/**
	 * Returns the value of the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getLightSensor_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @model
	 * @generated
	 */
	Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 */
	void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer value);

	/**
	 * Returns the value of the '<em><b>Cloudservice</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getLightsensor <em>Lightsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cloudservice</em>' reference.
	 * @see #setCloudservice(CloudService)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getLightSensor_Cloudservice()
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getLightsensor
	 * @model opposite="lightsensor"
	 * @generated
	 */
	CloudService getCloudservice();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getCloudservice <em>Cloudservice</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cloudservice</em>' reference.
	 * @see #getCloudservice()
	 * @generated
	 */
	void setCloudservice(CloudService value);

	/**
	 * Returns the value of the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you using appropriate technical or organisational measures to protect the data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getLightSensor_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @model
	 * @generated
	 */
	Answer getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you using appropriate technical or organisational measures to protect the data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @generated
	 */
	void setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(Answer value);

	/**
	 * Returns the value of the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is data against accidental loss or destruction or damage</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setIs_data_against_accidental_loss_or_destruction_or_damage(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getLightSensor_Is_data_against_accidental_loss_or_destruction_or_damage()
	 * @model
	 * @generated
	 */
	Answer getIs_data_against_accidental_loss_or_destruction_or_damage();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is data against accidental loss or destruction or damage</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @generated
	 */
	void setIs_data_against_accidental_loss_or_destruction_or_damage(Answer value);

} // LightSensor
