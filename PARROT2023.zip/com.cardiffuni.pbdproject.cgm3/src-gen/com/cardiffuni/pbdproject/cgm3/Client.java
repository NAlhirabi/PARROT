/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Client</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Client#getSmartphone <em>Smartphone</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Client#getConsent_checkedlist <em>Consent checkedlist</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Client#getPhoneNumber <em>Phone Number</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Client#getAuthentication <em>Authentication</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Client#getAuthorization <em>Authorization</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Client#getPhone <em>Phone</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getClient()
 * @model
 * @generated
 */
public interface Client extends GeneralEntity, Encryption, Privacy_patterns {
	/**
	 * Returns the value of the '<em><b>Smartphone</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.SmartPhone}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Smartphone</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getClient_Smartphone()
	 * @model containment="true"
	 * @generated
	 */
	EList<SmartPhone> getSmartphone();

	/**
	 * Returns the value of the '<em><b>Consent checkedlist</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Consent checkedlist</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getClient_Consent_checkedlist()
	 * @model containment="true"
	 * @generated
	 */
	EList<Consent_CheckedList> getConsent_checkedlist();

	/**
	 * Returns the value of the '<em><b>Phone Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Phone Number</em>' attribute.
	 * @see #setPhoneNumber(String)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getClient_PhoneNumber()
	 * @model
	 * @generated
	 */
	String getPhoneNumber();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Client#getPhoneNumber <em>Phone Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Phone Number</em>' attribute.
	 * @see #getPhoneNumber()
	 * @generated
	 */
	void setPhoneNumber(String value);

	/**
	 * Returns the value of the '<em><b>Authentication</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Authentication}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Authentication</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getClient_Authentication()
	 * @model containment="true"
	 * @generated
	 */
	EList<Authentication> getAuthentication();

	/**
	 * Returns the value of the '<em><b>Authorization</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Authorization}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Authorization</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getClient_Authorization()
	 * @model containment="true"
	 * @generated
	 */
	EList<Authorization> getAuthorization();

	/**
	 * Returns the value of the '<em><b>Phone</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Phone}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Phone</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getClient_Phone()
	 * @model containment="true"
	 * @generated
	 */
	EList<Phone> getPhone();

} // Client
