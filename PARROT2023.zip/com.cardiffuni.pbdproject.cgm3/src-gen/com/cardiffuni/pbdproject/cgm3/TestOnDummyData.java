/**
 */
package com.cardiffuni.pbdproject.cgm3;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Test On Dummy Data</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getTestOnDummyData()
 * @model
 * @generated
 */
public enum TestOnDummyData implements Enumerator {
	/**
	 * The '<em><b>Testing phase and dummy data</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TESTING_PHASE_AND_DUMMY_DATA_VALUE
	 * @generated
	 * @ordered
	 */
	TESTING_PHASE_AND_DUMMY_DATA(0, "Testing_phase_and_dummy_data", "Testing_phase_and_dummy_data"),

	/**
	 * The '<em><b>Testing phase and live data</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TESTING_PHASE_AND_LIVE_DATA_VALUE
	 * @generated
	 * @ordered
	 */
	TESTING_PHASE_AND_LIVE_DATA(1, "Testing_phase_and_live_data", "Testing_phase_and_live_data"),

	/**
	 * The '<em><b>Live phase and dummy data</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LIVE_PHASE_AND_DUMMY_DATA_VALUE
	 * @generated
	 * @ordered
	 */
	LIVE_PHASE_AND_DUMMY_DATA(2, "Live_phase_and_dummy_data", "Live_phase_and_dummy_data"),

	/**
	 * The '<em><b>Live phase and live data</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LIVE_PHASE_AND_LIVE_DATA_VALUE
	 * @generated
	 * @ordered
	 */
	LIVE_PHASE_AND_LIVE_DATA(3, "Live_phase_and_live_data", "Live_phase_and_live_data");

	/**
	 * The '<em><b>Testing phase and dummy data</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TESTING_PHASE_AND_DUMMY_DATA
	 * @model name="Testing_phase_and_dummy_data"
	 * @generated
	 * @ordered
	 */
	public static final int TESTING_PHASE_AND_DUMMY_DATA_VALUE = 0;

	/**
	 * The '<em><b>Testing phase and live data</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TESTING_PHASE_AND_LIVE_DATA
	 * @model name="Testing_phase_and_live_data"
	 * @generated
	 * @ordered
	 */
	public static final int TESTING_PHASE_AND_LIVE_DATA_VALUE = 1;

	/**
	 * The '<em><b>Live phase and dummy data</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LIVE_PHASE_AND_DUMMY_DATA
	 * @model name="Live_phase_and_dummy_data"
	 * @generated
	 * @ordered
	 */
	public static final int LIVE_PHASE_AND_DUMMY_DATA_VALUE = 2;

	/**
	 * The '<em><b>Live phase and live data</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LIVE_PHASE_AND_LIVE_DATA
	 * @model name="Live_phase_and_live_data"
	 * @generated
	 * @ordered
	 */
	public static final int LIVE_PHASE_AND_LIVE_DATA_VALUE = 3;

	/**
	 * An array of all the '<em><b>Test On Dummy Data</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final TestOnDummyData[] VALUES_ARRAY = new TestOnDummyData[] { TESTING_PHASE_AND_DUMMY_DATA,
			TESTING_PHASE_AND_LIVE_DATA, LIVE_PHASE_AND_DUMMY_DATA, LIVE_PHASE_AND_LIVE_DATA, };

	/**
	 * A public read-only list of all the '<em><b>Test On Dummy Data</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<TestOnDummyData> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Test On Dummy Data</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static TestOnDummyData get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			TestOnDummyData result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Test On Dummy Data</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static TestOnDummyData getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			TestOnDummyData result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Test On Dummy Data</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static TestOnDummyData get(int value) {
		switch (value) {
		case TESTING_PHASE_AND_DUMMY_DATA_VALUE:
			return TESTING_PHASE_AND_DUMMY_DATA;
		case TESTING_PHASE_AND_LIVE_DATA_VALUE:
			return TESTING_PHASE_AND_LIVE_DATA;
		case LIVE_PHASE_AND_DUMMY_DATA_VALUE:
			return LIVE_PHASE_AND_DUMMY_DATA;
		case LIVE_PHASE_AND_LIVE_DATA_VALUE:
			return LIVE_PHASE_AND_LIVE_DATA;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private TestOnDummyData(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //TestOnDummyData
