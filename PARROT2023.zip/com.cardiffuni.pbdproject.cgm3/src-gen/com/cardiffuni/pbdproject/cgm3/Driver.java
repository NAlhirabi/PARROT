/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Driver</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Driver#getAuthentication <em>Authentication</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Driver#getAuthorization <em>Authorization</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Driver#getAge <em>Age</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Driver#getConsent_checkedlist <em>Consent checkedlist</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Driver#getDo_drivers_aware_of_being_recorded <em>Do drivers aware of being recorded</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDriver()
 * @model
 * @generated
 */
public interface Driver extends GeneralEntity {
	/**
	 * Returns the value of the '<em><b>Authentication</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Authentication}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Authentication</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDriver_Authentication()
	 * @model containment="true"
	 * @generated
	 */
	EList<Authentication> getAuthentication();

	/**
	 * Returns the value of the '<em><b>Authorization</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Authorization}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Authorization</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDriver_Authorization()
	 * @model containment="true"
	 * @generated
	 */
	EList<Authorization> getAuthorization();

	/**
	 * Returns the value of the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Age</em>' attribute.
	 * @see #setAge(String)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDriver_Age()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 * @generated
	 */
	String getAge();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Driver#getAge <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Age</em>' attribute.
	 * @see #getAge()
	 * @generated
	 */
	void setAge(String value);

	/**
	 * Returns the value of the '<em><b>Consent checkedlist</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Consent checkedlist</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDriver_Consent_checkedlist()
	 * @model containment="true"
	 * @generated
	 */
	EList<Consent_CheckedList> getConsent_checkedlist();

	/**
	 * Returns the value of the '<em><b>Do drivers aware of being recorded</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Do drivers aware of being recorded</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setDo_drivers_aware_of_being_recorded(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getDriver_Do_drivers_aware_of_being_recorded()
	 * @model
	 * @generated
	 */
	Answer getDo_drivers_aware_of_being_recorded();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Driver#getDo_drivers_aware_of_being_recorded <em>Do drivers aware of being recorded</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Do drivers aware of being recorded</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getDo_drivers_aware_of_being_recorded()
	 * @generated
	 */
	void setDo_drivers_aware_of_being_recorded(Answer value);

} // Driver
