/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Factory
 * @model kind="package"
 * @generated
 */
public interface Cgm3Package extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "cgm3";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/cgm3";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "cgm3";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Cgm3Package eINSTANCE = com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl.init();

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.GeneralEntityImpl <em>General Entity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.GeneralEntityImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getGeneralEntity()
	 * @generated
	 */
	int GENERAL_ENTITY = 0;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CGMsensorImpl <em>CG Msensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.CGMsensorImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCGMsensor()
	 * @generated
	 */
	int CG_MSENSOR = 1;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl <em>Patient</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.PatientImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getPatient()
	 * @generated
	 */
	int PATIENT = 3;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.NurseImpl <em>Nurse</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.NurseImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getNurse()
	 * @generated
	 */
	int NURSE = 4;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.DoctorImpl <em>Doctor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.DoctorImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getDoctor()
	 * @generated
	 */
	int DOCTOR = 5;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.NewEClass7Impl <em>New EClass7</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.NewEClass7Impl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getNewEClass7()
	 * @generated
	 */
	int NEW_ECLASS7 = 6;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CloudImpl <em>Cloud</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.CloudImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCloud()
	 * @generated
	 */
	int CLOUD = 7;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.WebsiteImpl <em>Website</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.WebsiteImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getWebsite()
	 * @generated
	 */
	int WEBSITE = 8;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl <em>Hospital</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getHospital()
	 * @generated
	 */
	int HOSPITAL = 9;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.ResearcherImpl <em>Researcher</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.ResearcherImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getResearcher()
	 * @generated
	 */
	int RESEARCHER = 10;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.MedicalRecordImpl <em>Medical Record</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.MedicalRecordImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getMedicalRecord()
	 * @generated
	 */
	int MEDICAL_RECORD = 11;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.Consent_CheckedListImpl <em>Consent Checked List</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Consent_CheckedListImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getConsent_CheckedList()
	 * @generated
	 */
	int CONSENT_CHECKED_LIST = 12;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.StorageLocationImpl <em>Storage Location</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.StorageLocationImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getStorageLocation()
	 * @generated
	 */
	int STORAGE_LOCATION = 13;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.UserLocationImpl <em>User Location</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.UserLocationImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getUserLocation()
	 * @generated
	 */
	int USER_LOCATION = 14;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.RiskCodeImpl <em>Risk Code</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.RiskCodeImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getRiskCode()
	 * @generated
	 */
	int RISK_CODE = 15;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.AuthenticationImpl <em>Authentication</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.AuthenticationImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getAuthentication()
	 * @generated
	 */
	int AUTHENTICATION = 16;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.AuthorizationImpl <em>Authorization</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.AuthorizationImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getAuthorization()
	 * @generated
	 */
	int AUTHORIZATION = 17;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.FirewallImpl <em>Firewall</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.FirewallImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getFirewall()
	 * @generated
	 */
	int FIREWALL = 18;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.EncryptionImpl <em>Encryption</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.EncryptionImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getEncryption()
	 * @generated
	 */
	int ENCRYPTION = 19;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.DataSharingImpl <em>Data Sharing</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.DataSharingImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getDataSharing()
	 * @generated
	 */
	int DATA_SHARING = 20;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.WarningImpl <em>Warning</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.WarningImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getWarning()
	 * @generated
	 */
	int WARNING = 21;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.Test_on_dummyImpl <em>Test on dummy</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Test_on_dummyImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getTest_on_dummy()
	 * @generated
	 */
	int TEST_ON_DUMMY = 22;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.ContainerisationImpl <em>Containerisation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.ContainerisationImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getContainerisation()
	 * @generated
	 */
	int CONTAINERISATION = 23;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.AggregationImpl <em>Aggregation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.AggregationImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getAggregation()
	 * @generated
	 */
	int AGGREGATION = 24;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.NewEClass26Impl <em>New EClass26</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.NewEClass26Impl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getNewEClass26()
	 * @generated
	 */
	int NEW_ECLASS26 = 25;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl <em>Computer Browser</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getComputerBrowser()
	 * @generated
	 */
	int COMPUTER_BROWSER = 26;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.NewEClass28Impl <em>New EClass28</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.NewEClass28Impl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getNewEClass28()
	 * @generated
	 */
	int NEW_ECLASS28 = 27;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.PharmacyCloudoldImpl <em>Pharmacy Cloudold</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.PharmacyCloudoldImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getPharmacyCloudold()
	 * @generated
	 */
	int PHARMACY_CLOUDOLD = 28;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl <em>Shipping Cloud</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getShippingCloud()
	 * @generated
	 */
	int SHIPPING_CLOUD = 29;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.WebhostingCloudImpl <em>Webhosting Cloud</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.WebhostingCloudImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getWebhostingCloud()
	 * @generated
	 */
	int WEBHOSTING_CLOUD = 30;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.PaymentCloudImpl <em>Payment Cloud</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.PaymentCloudImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getPaymentCloud()
	 * @generated
	 */
	int PAYMENT_CLOUD = 31;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.SocialNetworkCloudImpl <em>Social Network Cloud</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.SocialNetworkCloudImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getSocialNetworkCloud()
	 * @generated
	 */
	int SOCIAL_NETWORK_CLOUD = 32;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.RealTimeBiddingCloudImpl <em>Real Time Bidding Cloud</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.RealTimeBiddingCloudImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getRealTimeBiddingCloud()
	 * @generated
	 */
	int REAL_TIME_BIDDING_CLOUD = 33;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.WebBrowserImpl <em>Web Browser</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.WebBrowserImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getWebBrowser()
	 * @generated
	 */
	int WEB_BROWSER = 34;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl <em>Cloud For Pharmacy</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCloudForPharmacy()
	 * @generated
	 */
	int CLOUD_FOR_PHARMACY = 35;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.BusImpl <em>Bus</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.BusImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getBus()
	 * @generated
	 */
	int BUS = 36;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl <em>GPS Tracker</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getGPSTracker()
	 * @generated
	 */
	int GPS_TRACKER = 37;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.VideoAnalyticsImpl <em>Video Analytics</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.VideoAnalyticsImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getVideoAnalytics()
	 * @generated
	 */
	int VIDEO_ANALYTICS = 38;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl <em>Video Without Analytics</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getVideoWithoutAnalytics()
	 * @generated
	 */
	int VIDEO_WITHOUT_ANALYTICS = 39;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.DriverImpl <em>Driver</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.DriverImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getDriver()
	 * @generated
	 */
	int DRIVER = 40;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_ENTITY__NAME = 0;

	/**
	 * The number of structural features of the '<em>General Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_ENTITY_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>General Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GENERAL_ENTITY_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CG_MSENSOR__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CG_MSENSOR__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Smartphone</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CG_MSENSOR__SMARTPHONE = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Glucose amount</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CG_MSENSOR__GLUCOSE_AMOUNT = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Connection</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CG_MSENSOR__CONNECTION = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CG_MSENSOR__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CG_MSENSOR__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 5;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CG_MSENSOR__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 6;

	/**
	 * The number of structural features of the '<em>CG Msensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CG_MSENSOR_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The number of operations of the '<em>CG Msensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CG_MSENSOR_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.SmartPhoneImpl <em>Smart Phone</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.SmartPhoneImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getSmartPhone()
	 * @generated
	 */
	int SMART_PHONE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl <em>Cloud Service</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCloudService()
	 * @generated
	 */
	int CLOUD_SERVICE = 46;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.LightSensorImpl <em>Light Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.LightSensorImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getLightSensor()
	 * @generated
	 */
	int LIGHT_SENSOR = 47;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CustomerImpl <em>Customer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.CustomerImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCustomer()
	 * @generated
	 */
	int CUSTOMER = 41;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl <em>Analytics</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getAnalytics()
	 * @generated
	 */
	int ANALYTICS = 42;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.BlurringImpl <em>Blurring</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.BlurringImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getBlurring()
	 * @generated
	 */
	int BLURRING = 43;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.VideoProcessingCloudImpl <em>Video Processing Cloud</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.VideoProcessingCloudImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getVideoProcessingCloud()
	 * @generated
	 */
	int VIDEO_PROCESSING_CLOUD = 44;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.ClientImpl <em>Client</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.ClientImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getClient()
	 * @generated
	 */
	int CLIENT = 45;

	/**
	 * The feature id for the '<em><b>Cgmsensor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__CGMSENSOR = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Cloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__CLOUD = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Blood Sugar Level</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__BLOOD_SUGAR_LEVEL = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Connection</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__CONNECTION = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Patient info Retention Period</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__PATIENT_INFO_RETENTION_PERIOD = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Userlocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__USERLOCATION = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE = GENERAL_ENTITY_FEATURE_COUNT
			+ 8;

	/**
	 * The feature id for the '<em><b>Are you planning to send all the data to the cloud</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 10;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 11;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 12;

	/**
	 * The feature id for the '<em><b>Smartphone</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__SMARTPHONE = GENERAL_ENTITY_FEATURE_COUNT + 13;

	/**
	 * The feature id for the '<em><b>Pharmacycloud</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__PHARMACYCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 14;

	/**
	 * The feature id for the '<em><b>Cloudforpharmacy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__CLOUDFORPHARMACY = GENERAL_ENTITY_FEATURE_COUNT + 15;

	/**
	 * The feature id for the '<em><b>Cookies</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE__COOKIES = GENERAL_ENTITY_FEATURE_COUNT + 16;

	/**
	 * The number of structural features of the '<em>Smart Phone</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 17;

	/**
	 * The number of operations of the '<em>Smart Phone</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PHONE_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Smartphone</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__SMARTPHONE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Cgmsensor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__CGMSENSOR = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Doctor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__DOCTOR = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Medicalrecord</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__MEDICALRECORD = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__AGE = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Consent checkedlist</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__CONSENT_CHECKEDLIST = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Phone Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__PHONE_NUMBER = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Authentication</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__AUTHENTICATION = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Authorization</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__AUTHORIZATION = GENERAL_ENTITY_FEATURE_COUNT + 10;

	/**
	 * The feature id for the '<em><b>Datasharing</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__DATASHARING = GENERAL_ENTITY_FEATURE_COUNT + 11;

	/**
	 * The feature id for the '<em><b>Computerbrowser</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__COMPUTERBROWSER = GENERAL_ENTITY_FEATURE_COUNT + 12;

	/**
	 * The feature id for the '<em><b>Webbrowser</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT__WEBBROWSER = GENERAL_ENTITY_FEATURE_COUNT + 13;

	/**
	 * The number of structural features of the '<em>Patient</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 14;

	/**
	 * The number of operations of the '<em>Patient</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PATIENT_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NURSE__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The number of structural features of the '<em>Nurse</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NURSE_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Nurse</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NURSE_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Patient</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR__PATIENT = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Website</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR__WEBSITE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Specialty</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR__SPECIALTY = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Authentication</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR__AUTHENTICATION = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Authorization</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR__AUTHORIZATION = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Are you allowing unauthorised doctors to access or process the data subject health data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR__ARE_YOU_ALLOWING_UNAUTHORISED_DOCTORS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_HEALTH_DATA = GENERAL_ENTITY_FEATURE_COUNT
			+ 6;

	/**
	 * The number of structural features of the '<em>Doctor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The number of operations of the '<em>Doctor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOCTOR_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEW_ECLASS7__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The number of structural features of the '<em>New EClass7</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEW_ECLASS7_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>New EClass7</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEW_ECLASS7_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Smartphone</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__SMARTPHONE = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Website</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__WEBSITE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Storagelocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__STORAGELOCATION = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Datasharing</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__DATASHARING = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Test on dummy</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__TEST_ON_DUMMY = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Containerisation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__CONTAINERISATION = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Aggregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__AGGREGATION = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT + 10;

	/**
	 * The feature id for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = GENERAL_ENTITY_FEATURE_COUNT
			+ 11;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT + 12;

	/**
	 * The feature id for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = GENERAL_ENTITY_FEATURE_COUNT
			+ 13;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 14;

	/**
	 * The feature id for the '<em><b>Medicalrecord</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD__MEDICALRECORD = GENERAL_ENTITY_FEATURE_COUNT + 15;

	/**
	 * The number of structural features of the '<em>Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 16;

	/**
	 * The number of operations of the '<em>Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBSITE__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBSITE__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Cloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBSITE__CLOUD = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Doctor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBSITE__DOCTOR = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Researcher</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBSITE__RESEARCHER = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>URL</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBSITE__URL = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Videoprocessingcloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBSITE__VIDEOPROCESSINGCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Cookies</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBSITE__COOKIES = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The number of structural features of the '<em>Website</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBSITE_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The number of operations of the '<em>Website</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBSITE_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Patient</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__PATIENT = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Doctor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__DOCTOR = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Researcher</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__RESEARCHER = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Nurse</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__NURSE = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Cloud</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__CLOUD = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Website</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__WEBSITE = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Smartphone</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__SMARTPHONE = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Cgmsensor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__CGMSENSOR = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Medicalrecord</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__MEDICALRECORD = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Consent checkedlist</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__CONSENT_CHECKEDLIST = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Storagelocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__STORAGELOCATION = GENERAL_ENTITY_FEATURE_COUNT + 10;

	/**
	 * The feature id for the '<em><b>Userlocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__USERLOCATION = GENERAL_ENTITY_FEATURE_COUNT + 11;

	/**
	 * The feature id for the '<em><b>Riskcode</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__RISKCODE = GENERAL_ENTITY_FEATURE_COUNT + 12;

	/**
	 * The feature id for the '<em><b>Encryption</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__ENCRYPTION = GENERAL_ENTITY_FEATURE_COUNT + 13;

	/**
	 * The feature id for the '<em><b>Datasharing</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__DATASHARING = GENERAL_ENTITY_FEATURE_COUNT + 14;

	/**
	 * The feature id for the '<em><b>Warning</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__WARNING = GENERAL_ENTITY_FEATURE_COUNT + 15;

	/**
	 * The feature id for the '<em><b>Test on dummy</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__TEST_ON_DUMMY = GENERAL_ENTITY_FEATURE_COUNT + 16;

	/**
	 * The feature id for the '<em><b>Containerisation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__CONTAINERISATION = GENERAL_ENTITY_FEATURE_COUNT + 17;

	/**
	 * The feature id for the '<em><b>Aggregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__AGGREGATION = GENERAL_ENTITY_FEATURE_COUNT + 18;

	/**
	 * The feature id for the '<em><b>Computerbrowser</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__COMPUTERBROWSER = GENERAL_ENTITY_FEATURE_COUNT + 19;

	/**
	 * The feature id for the '<em><b>Pharmacycloud</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__PHARMACYCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 20;

	/**
	 * The feature id for the '<em><b>Shippingcloud</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__SHIPPINGCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 21;

	/**
	 * The feature id for the '<em><b>Webhostingcloud</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__WEBHOSTINGCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 22;

	/**
	 * The feature id for the '<em><b>Paymentcloud</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__PAYMENTCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 23;

	/**
	 * The feature id for the '<em><b>Socialnetworkcloud</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__SOCIALNETWORKCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 24;

	/**
	 * The feature id for the '<em><b>Webbrowser</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__WEBBROWSER = GENERAL_ENTITY_FEATURE_COUNT + 25;

	/**
	 * The feature id for the '<em><b>Cloudforpharmacy</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__CLOUDFORPHARMACY = GENERAL_ENTITY_FEATURE_COUNT + 26;

	/**
	 * The feature id for the '<em><b>Realtimebiddingcloud</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__REALTIMEBIDDINGCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 27;

	/**
	 * The feature id for the '<em><b>Gpstracker</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__GPSTRACKER = GENERAL_ENTITY_FEATURE_COUNT + 28;

	/**
	 * The feature id for the '<em><b>Bus</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__BUS = GENERAL_ENTITY_FEATURE_COUNT + 29;

	/**
	 * The feature id for the '<em><b>Driver</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__DRIVER = GENERAL_ENTITY_FEATURE_COUNT + 30;

	/**
	 * The feature id for the '<em><b>Customer</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__CUSTOMER = GENERAL_ENTITY_FEATURE_COUNT + 31;

	/**
	 * The feature id for the '<em><b>Videoanalytics</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__VIDEOANALYTICS = GENERAL_ENTITY_FEATURE_COUNT + 32;

	/**
	 * The feature id for the '<em><b>Analytics</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__ANALYTICS = GENERAL_ENTITY_FEATURE_COUNT + 33;

	/**
	 * The feature id for the '<em><b>Blurring</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__BLURRING = GENERAL_ENTITY_FEATURE_COUNT + 34;

	/**
	 * The feature id for the '<em><b>Videoprocessingcloud</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__VIDEOPROCESSINGCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 35;

	/**
	 * The feature id for the '<em><b>Videowithoutanalytics</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__VIDEOWITHOUTANALYTICS = GENERAL_ENTITY_FEATURE_COUNT + 36;

	/**
	 * The feature id for the '<em><b>Client</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__CLIENT = GENERAL_ENTITY_FEATURE_COUNT + 37;

	/**
	 * The feature id for the '<em><b>Cloudservice</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__CLOUDSERVICE = GENERAL_ENTITY_FEATURE_COUNT + 38;

	/**
	 * The feature id for the '<em><b>Lightsensor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__LIGHTSENSOR = GENERAL_ENTITY_FEATURE_COUNT + 39;

	/**
	 * The feature id for the '<em><b>Phone</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__PHONE = GENERAL_ENTITY_FEATURE_COUNT + 40;

	/**
	 * The feature id for the '<em><b>Thermostat</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__THERMOSTAT = GENERAL_ENTITY_FEATURE_COUNT + 41;

	/**
	 * The feature id for the '<em><b>Doorlock</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__DOORLOCK = GENERAL_ENTITY_FEATURE_COUNT + 42;

	/**
	 * The feature id for the '<em><b>Camera</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__CAMERA = GENERAL_ENTITY_FEATURE_COUNT + 43;

	/**
	 * The feature id for the '<em><b>Cookies</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL__COOKIES = GENERAL_ENTITY_FEATURE_COUNT + 44;

	/**
	 * The number of structural features of the '<em>Hospital</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 45;

	/**
	 * The number of operations of the '<em>Hospital</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOSPITAL_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESEARCHER__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESEARCHER__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Website</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESEARCHER__WEBSITE = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Authentication</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESEARCHER__AUTHENTICATION = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Authorization</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESEARCHER__AUTHORIZATION = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Are you allowing researchers to access or process the data subject medical data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESEARCHER__ARE_YOU_ALLOWING_RESEARCHERS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_MEDICAL_DATA = GENERAL_ENTITY_FEATURE_COUNT
			+ 4;

	/**
	 * The feature id for the '<em><b>Are you allowing unauthorised researchers to access or process the data subject personal data such as name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESEARCHER__ARE_YOU_ALLOWING_UNAUTHORISED_RESEARCHERS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_PERSONAL_DATA_SUCH_AS_NAME = GENERAL_ENTITY_FEATURE_COUNT
			+ 5;

	/**
	 * The number of structural features of the '<em>Researcher</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESEARCHER_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The number of operations of the '<em>Researcher</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESEARCHER_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEDICAL_RECORD__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Record Retention Period</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEDICAL_RECORD__RECORD_RETENTION_PERIOD = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Medical Record</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEDICAL_RECORD_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Medical Record</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEDICAL_RECORD_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSENT_CHECKED_LIST__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Capture age authorization if age is less than 16</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSENT_CHECKED_LIST__CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16 = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Capture withdrawal log</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSENT_CHECKED_LIST__CAPTURE_WITHDRAWAL_LOG = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Capture log Terms of use AND consent to process</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSENT_CHECKED_LIST__CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Capture consent to process special category data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Capture consent to term of use</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_TERM_OF_USE = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Surface privacy notice</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSENT_CHECKED_LIST__SURFACE_PRIVACY_NOTICE = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Capture consent to the type of marketing if electronic marketing is used</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED = GENERAL_ENTITY_FEATURE_COUNT
			+ 6;

	/**
	 * The number of structural features of the '<em>Consent Checked List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSENT_CHECKED_LIST_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The number of operations of the '<em>Consent Checked List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSENT_CHECKED_LIST_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STORAGE_LOCATION__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Cloud provider and server location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STORAGE_LOCATION__CLOUD_PROVIDER_AND_SERVER_LOCATION = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Storage Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STORAGE_LOCATION_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Storage Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STORAGE_LOCATION_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_LOCATION__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_LOCATION__LOCATION = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Are you planning to collect the exact location of the data subject when the location is not needed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_LOCATION__ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED = GENERAL_ENTITY_FEATURE_COUNT
			+ 1;

	/**
	 * The number of structural features of the '<em>User Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_LOCATION_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>User Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USER_LOCATION_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RISK_CODE__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The number of structural features of the '<em>Risk Code</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RISK_CODE_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Risk Code</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RISK_CODE_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHENTICATION__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Authenticated</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHENTICATION__AUTHENTICATED = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Authentication</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHENTICATION_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Authentication</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHENTICATION_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHORIZATION__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Authorized</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHORIZATION__AUTHORIZED = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Authorization</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHORIZATION_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Authorization</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTHORIZATION_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIREWALL__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The number of structural features of the '<em>Firewall</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIREWALL_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Firewall</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FIREWALL_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCRYPTION__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCRYPTION__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Encryption</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCRYPTION_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Encryption</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCRYPTION_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_SHARING__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Apply anonymisation for researcher</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_SHARING__APPLY_ANONYMISATION_FOR_RESEARCHER = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Ensure access Control</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_SHARING__ENSURE_ACCESS_CONTROL = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Data Sharing</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_SHARING_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Data Sharing</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_SHARING_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WARNING__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The number of structural features of the '<em>Warning</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WARNING_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Warning</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WARNING_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_ON_DUMMY__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Testing on dummy data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_ON_DUMMY__TESTING_ON_DUMMY_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Test on dummy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_ON_DUMMY_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Test on dummy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TEST_ON_DUMMY_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINERISATION__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The number of structural features of the '<em>Containerisation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINERISATION_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Containerisation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTAINERISATION_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The number of structural features of the '<em>Aggregation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Aggregation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGGREGATION_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The number of structural features of the '<em>New EClass26</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEW_ECLASS26_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>New EClass26</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEW_ECLASS26_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Cgmsensor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER__CGMSENSOR = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Cloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER__CLOUD = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Patient info Retention Period</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER__PATIENT_INFO_RETENTION_PERIOD = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Userlocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER__USERLOCATION = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE = GENERAL_ENTITY_FEATURE_COUNT
			+ 5;

	/**
	 * The feature id for the '<em><b>Are you planning to send all the data to the cloud</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 7;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 8;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 9;

	/**
	 * The feature id for the '<em><b>Pharmacycloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER__PHARMACYCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 10;

	/**
	 * The number of structural features of the '<em>Computer Browser</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 11;

	/**
	 * The number of operations of the '<em>Computer Browser</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPUTER_BROWSER_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The number of structural features of the '<em>New EClass28</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEW_ECLASS28_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>New EClass28</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NEW_ECLASS28_OPERATION_COUNT = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Smartphone</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__SMARTPHONE = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Website</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__WEBSITE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Storagelocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__STORAGELOCATION = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Datasharing</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__DATASHARING = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Test on dummy</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__TEST_ON_DUMMY = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Containerisation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__CONTAINERISATION = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Aggregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__AGGREGATION = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 9;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 10;

	/**
	 * The feature id for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = GENERAL_ENTITY_FEATURE_COUNT
			+ 11;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 12;

	/**
	 * The feature id for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = GENERAL_ENTITY_FEATURE_COUNT
			+ 13;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 14;

	/**
	 * The feature id for the '<em><b>Computerbrowser</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD__COMPUTERBROWSER = GENERAL_ENTITY_FEATURE_COUNT + 15;

	/**
	 * The number of structural features of the '<em>Pharmacy Cloudold</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 16;

	/**
	 * The number of operations of the '<em>Pharmacy Cloudold</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHARMACY_CLOUDOLD_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Smartphone</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__SMARTPHONE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Website</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__WEBSITE = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Storagelocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__STORAGELOCATION = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Datasharing</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__DATASHARING = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Test on dummy</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__TEST_ON_DUMMY = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Containerisation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__CONTAINERISATION = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Aggregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__AGGREGATION = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT + 10;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 11;

	/**
	 * The feature id for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = GENERAL_ENTITY_FEATURE_COUNT
			+ 12;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 13;

	/**
	 * The feature id for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = GENERAL_ENTITY_FEATURE_COUNT
			+ 14;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 15;

	/**
	 * The feature id for the '<em><b>Cloudforpharmacy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD__CLOUDFORPHARMACY = GENERAL_ENTITY_FEATURE_COUNT + 16;

	/**
	 * The number of structural features of the '<em>Shipping Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 17;

	/**
	 * The number of operations of the '<em>Shipping Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHIPPING_CLOUD_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Smartphone</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__SMARTPHONE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Website</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__WEBSITE = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Storagelocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__STORAGELOCATION = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Datasharing</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__DATASHARING = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Test on dummy</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__TEST_ON_DUMMY = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Containerisation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__CONTAINERISATION = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Aggregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__AGGREGATION = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 10;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 11;

	/**
	 * The feature id for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = GENERAL_ENTITY_FEATURE_COUNT
			+ 12;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 13;

	/**
	 * The feature id for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = GENERAL_ENTITY_FEATURE_COUNT
			+ 14;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 15;

	/**
	 * The feature id for the '<em><b>Cloudforpharmacy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__CLOUDFORPHARMACY = GENERAL_ENTITY_FEATURE_COUNT + 16;

	/**
	 * The feature id for the '<em><b>Socialnetworkcloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__SOCIALNETWORKCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 17;

	/**
	 * The feature id for the '<em><b>Realtimebiddingcloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD__REALTIMEBIDDINGCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 18;

	/**
	 * The number of structural features of the '<em>Webhosting Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 19;

	/**
	 * The number of operations of the '<em>Webhosting Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEBHOSTING_CLOUD_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Smartphone</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__SMARTPHONE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Website</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__WEBSITE = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Storagelocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__STORAGELOCATION = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Datasharing</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__DATASHARING = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Test on dummy</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__TEST_ON_DUMMY = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Containerisation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__CONTAINERISATION = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Aggregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__AGGREGATION = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT + 10;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 11;

	/**
	 * The feature id for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = GENERAL_ENTITY_FEATURE_COUNT
			+ 12;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 13;

	/**
	 * The feature id for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = GENERAL_ENTITY_FEATURE_COUNT
			+ 14;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 15;

	/**
	 * The feature id for the '<em><b>Cloudforpharmacy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD__CLOUDFORPHARMACY = GENERAL_ENTITY_FEATURE_COUNT + 16;

	/**
	 * The number of structural features of the '<em>Payment Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 17;

	/**
	 * The number of operations of the '<em>Payment Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAYMENT_CLOUD_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Smartphone</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__SMARTPHONE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Website</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__WEBSITE = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Storagelocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__STORAGELOCATION = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Datasharing</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__DATASHARING = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Test on dummy</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__TEST_ON_DUMMY = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Containerisation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__CONTAINERISATION = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Aggregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__AGGREGATION = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 10;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 11;

	/**
	 * The feature id for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = GENERAL_ENTITY_FEATURE_COUNT
			+ 12;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 13;

	/**
	 * The feature id for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = GENERAL_ENTITY_FEATURE_COUNT
			+ 14;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 15;

	/**
	 * The feature id for the '<em><b>Cloudforpharmacy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__CLOUDFORPHARMACY = GENERAL_ENTITY_FEATURE_COUNT + 16;

	/**
	 * The feature id for the '<em><b>Webhostingcloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD__WEBHOSTINGCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 17;

	/**
	 * The number of structural features of the '<em>Social Network Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 18;

	/**
	 * The number of operations of the '<em>Social Network Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SOCIAL_NETWORK_CLOUD_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Smartphone</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__SMARTPHONE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Website</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__WEBSITE = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Storagelocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__STORAGELOCATION = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Datasharing</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__DATASHARING = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Test on dummy</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__TEST_ON_DUMMY = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Containerisation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__CONTAINERISATION = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Aggregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__AGGREGATION = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 10;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 11;

	/**
	 * The feature id for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = GENERAL_ENTITY_FEATURE_COUNT
			+ 12;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 13;

	/**
	 * The feature id for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = GENERAL_ENTITY_FEATURE_COUNT
			+ 14;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 15;

	/**
	 * The feature id for the '<em><b>Webhostingcloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD__WEBHOSTINGCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 16;

	/**
	 * The number of structural features of the '<em>Real Time Bidding Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 17;

	/**
	 * The number of operations of the '<em>Real Time Bidding Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REAL_TIME_BIDDING_CLOUD_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Are you planning to send all the data to the cloud</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 4;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 5;

	/**
	 * The feature id for the '<em><b>Patient info Retention Period</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER__PATIENT_INFO_RETENTION_PERIOD = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE = GENERAL_ENTITY_FEATURE_COUNT
			+ 7;

	/**
	 * The feature id for the '<em><b>Userlocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER__USERLOCATION = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Cloudforpharmacy</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER__CLOUDFORPHARMACY = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Cookies</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER__COOKIES = GENERAL_ENTITY_FEATURE_COUNT + 10;

	/**
	 * The number of structural features of the '<em>Web Browser</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 11;

	/**
	 * The number of operations of the '<em>Web Browser</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_BROWSER_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Smartphone</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__SMARTPHONE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Webbrowser</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__WEBBROWSER = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Storagelocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__STORAGELOCATION = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Test on dummy</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__TEST_ON_DUMMY = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Containerisation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__CONTAINERISATION = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Aggregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__AGGREGATION = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Datasharing</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__DATASHARING = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = GENERAL_ENTITY_FEATURE_COUNT
			+ 9;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 10;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 11;

	/**
	 * The feature id for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = GENERAL_ENTITY_FEATURE_COUNT
			+ 12;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 13;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 14;

	/**
	 * The feature id for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 15;

	/**
	 * The feature id for the '<em><b>Paymentcloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__PAYMENTCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 16;

	/**
	 * The feature id for the '<em><b>Socialnetworkcloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__SOCIALNETWORKCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 17;

	/**
	 * The feature id for the '<em><b>Shippingcloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__SHIPPINGCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 18;

	/**
	 * The feature id for the '<em><b>Webhostingcloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY__WEBHOSTINGCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 19;

	/**
	 * The number of structural features of the '<em>Cloud For Pharmacy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 20;

	/**
	 * The number of operations of the '<em>Cloud For Pharmacy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_FOR_PHARMACY_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUS__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Gpstracker</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUS__GPSTRACKER = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Plate number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUS__PLATE_NUMBER = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Route number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUS__ROUTE_NUMBER = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Driver name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUS__DRIVER_NAME = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Videowithoutanalytics</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUS__VIDEOWITHOUTANALYTICS = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Driver</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUS__DRIVER = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Videoanalytics</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUS__VIDEOANALYTICS = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Videoprocessingcloud</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUS__VIDEOPROCESSINGCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Customer</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUS__CUSTOMER = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The number of structural features of the '<em>Bus</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUS_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The number of operations of the '<em>Bus</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUS_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER__ID = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Coordinates</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER__COORDINATES = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Speed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER__SPEED = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Does the use of GPS is fully explained in company policies and staff handbooks</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER__DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS = GENERAL_ENTITY_FEATURE_COUNT
			+ 3;

	/**
	 * The feature id for the '<em><b>Record retention period</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER__RECORD_RETENTION_PERIOD = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Does consent have been gathered from the staff who used these vehicles</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES = GENERAL_ENTITY_FEATURE_COUNT
			+ 5;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = GENERAL_ENTITY_FEATURE_COUNT
			+ 7;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 8;

	/**
	 * The feature id for the '<em><b>Are you processing data that are not needed for the purpose such employee monitoring</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING = GENERAL_ENTITY_FEATURE_COUNT
			+ 9;

	/**
	 * The feature id for the '<em><b>Does the staff aware of the use of the GPS systems</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER__DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS = GENERAL_ENTITY_FEATURE_COUNT + 10;

	/**
	 * The feature id for the '<em><b>Does the system record information other than the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT + 11;

	/**
	 * The number of structural features of the '<em>GPS Tracker</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 12;

	/**
	 * The number of operations of the '<em>GPS Tracker</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GPS_TRACKER_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_ANALYTICS__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_ANALYTICS__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Serial number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_ANALYTICS__SERIAL_NUMBER = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Blurring</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_ANALYTICS__BLURRING = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Analytics</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_ANALYTICS__ANALYTICS = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Customer</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_ANALYTICS__CUSTOMER = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Videoprocessingcloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_ANALYTICS__VIDEOPROCESSINGCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Video Analytics</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_ANALYTICS_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The number of operations of the '<em>Video Analytics</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_ANALYTICS_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Serial number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__SERIAL_NUMBER = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Record retention period</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__RECORD_RETENTION_PERIOD = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Do people aware of being recorded</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__DO_PEOPLE_AWARE_OF_BEING_RECORDED = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Ensure data minimisation is aplied</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__ENSURE_DATA_MINIMISATION_IS_APLIED = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 5;

	/**
	 * The feature id for the '<em><b>Does consent have been gathered from the staff who used these vehicles</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES = GENERAL_ENTITY_FEATURE_COUNT
			+ 6;

	/**
	 * The feature id for the '<em><b>Does the sign has abrief explanation about the purpose of CCTV</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV = GENERAL_ENTITY_FEATURE_COUNT
			+ 7;

	/**
	 * The feature id for the '<em><b>Does the system record information other than the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 8;

	/**
	 * The feature id for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = GENERAL_ENTITY_FEATURE_COUNT
			+ 9;

	/**
	 * The feature id for the '<em><b>Are you processing data that are not needed for the purpose such employee monitoring</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING = GENERAL_ENTITY_FEATURE_COUNT
			+ 10;

	/**
	 * The feature id for the '<em><b>Do you use signs that say CCTV is in operation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION = GENERAL_ENTITY_FEATURE_COUNT + 11;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = GENERAL_ENTITY_FEATURE_COUNT
			+ 12;

	/**
	 * The feature id for the '<em><b>Does The dynamic masking feature is enabled</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED = GENERAL_ENTITY_FEATURE_COUNT + 13;

	/**
	 * The feature id for the '<em><b>Are you sending data without anonymisation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION = GENERAL_ENTITY_FEATURE_COUNT + 14;

	/**
	 * The feature id for the '<em><b>Are you allowing data unauthorised access</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS = GENERAL_ENTITY_FEATURE_COUNT + 15;

	/**
	 * The feature id for the '<em><b>Are you storing the footage in asecure location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION = GENERAL_ENTITY_FEATURE_COUNT + 16;

	/**
	 * The feature id for the '<em><b>Customer</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__CUSTOMER = GENERAL_ENTITY_FEATURE_COUNT + 17;

	/**
	 * The feature id for the '<em><b>Videoprocessingcloud</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS__VIDEOPROCESSINGCLOUD = GENERAL_ENTITY_FEATURE_COUNT + 18;

	/**
	 * The number of structural features of the '<em>Video Without Analytics</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 19;

	/**
	 * The number of operations of the '<em>Video Without Analytics</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_WITHOUT_ANALYTICS_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVER__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Authentication</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVER__AUTHENTICATION = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Authorization</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVER__AUTHORIZATION = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVER__AGE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Consent checkedlist</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVER__CONSENT_CHECKEDLIST = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Do drivers aware of being recorded</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVER__DO_DRIVERS_AWARE_OF_BEING_RECORDED = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Driver</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVER_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Driver</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRIVER_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>General features</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__GENERAL_FEATURES = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Consent checkedlist</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__CONSENT_CHECKEDLIST = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Do people aware of being recorded</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__DO_PEOPLE_AWARE_OF_BEING_RECORDED = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Videoanalytics</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__VIDEOANALYTICS = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Videowithoutanalytics</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__VIDEOWITHOUTANALYTICS = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Customer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Customer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Record retention period</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS__RECORD_RETENTION_PERIOD = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Does data processing applied on the camera to increase data minimisation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS__DOES_DATA_PROCESSING_APPLIED_ON_THE_CAMERA_TO_INCREASE_DATA_MINIMISATION = GENERAL_ENTITY_FEATURE_COUNT
			+ 1;

	/**
	 * The feature id for the '<em><b>Does consent have been gathered from the staff who used these vehicles</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES = GENERAL_ENTITY_FEATURE_COUNT
			+ 2;

	/**
	 * The feature id for the '<em><b>Does the system record information other than the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Does The dynamic masking feature is enabled</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Are you processing data that are not needed for the purpose such employee monitoring</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING = GENERAL_ENTITY_FEATURE_COUNT
			+ 5;

	/**
	 * The feature id for the '<em><b>Do you use signs that say CCTV is in operation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Does the sign has abrief explanation about the purpose of CCTV</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 8;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = GENERAL_ENTITY_FEATURE_COUNT
			+ 10;

	/**
	 * The number of structural features of the '<em>Analytics</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 11;

	/**
	 * The number of operations of the '<em>Analytics</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANALYTICS_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLURRING__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Does the face blur feature enabled for individuals to support individual anonymisation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLURRING__DOES_THE_FACE_BLUR_FEATURE_ENABLED_FOR_INDIVIDUALS_TO_SUPPORT_INDIVIDUAL_ANONYMISATION = GENERAL_ENTITY_FEATURE_COUNT
			+ 0;

	/**
	 * The number of structural features of the '<em>Blurring</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLURRING_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Blurring</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLURRING_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Storagelocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__STORAGELOCATION = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Datasharing</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__DATASHARING = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Test on dummy</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__TEST_ON_DUMMY = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Containerisation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__CONTAINERISATION = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Aggregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__AGGREGATION = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 7;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 8;

	/**
	 * The feature id for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = GENERAL_ENTITY_FEATURE_COUNT
			+ 9;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 10;

	/**
	 * The feature id for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = GENERAL_ENTITY_FEATURE_COUNT
			+ 11;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 12;

	/**
	 * The feature id for the '<em><b>Gpstracker</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__GPSTRACKER = GENERAL_ENTITY_FEATURE_COUNT + 13;

	/**
	 * The feature id for the '<em><b>Videoanalytics</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__VIDEOANALYTICS = GENERAL_ENTITY_FEATURE_COUNT + 14;

	/**
	 * The feature id for the '<em><b>Videowithoutanalytics</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__VIDEOWITHOUTANALYTICS = GENERAL_ENTITY_FEATURE_COUNT + 15;

	/**
	 * The feature id for the '<em><b>Website</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD__WEBSITE = GENERAL_ENTITY_FEATURE_COUNT + 16;

	/**
	 * The number of structural features of the '<em>Video Processing Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 17;

	/**
	 * The number of operations of the '<em>Video Processing Cloud</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_PROCESSING_CLOUD_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Smartphone</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT__SMARTPHONE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Consent checkedlist</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT__CONSENT_CHECKEDLIST = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Phone Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT__PHONE_NUMBER = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Authentication</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT__AUTHENTICATION = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Authorization</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT__AUTHORIZATION = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Phone</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT__PHONE = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The number of structural features of the '<em>Client</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The number of operations of the '<em>Client</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLIENT_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Storagelocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__STORAGELOCATION = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Datasharing</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__DATASHARING = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Test on dummy</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__TEST_ON_DUMMY = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Containerisation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__CONTAINERISATION = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Aggregation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__AGGREGATION = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT
			+ 9;

	/**
	 * The feature id for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = GENERAL_ENTITY_FEATURE_COUNT
			+ 10;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 11;

	/**
	 * The feature id for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = GENERAL_ENTITY_FEATURE_COUNT
			+ 12;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 13;

	/**
	 * The feature id for the '<em><b>Gpstracker</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__GPSTRACKER = GENERAL_ENTITY_FEATURE_COUNT + 14;

	/**
	 * The feature id for the '<em><b>Videoanalytics</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__VIDEOANALYTICS = GENERAL_ENTITY_FEATURE_COUNT + 15;

	/**
	 * The feature id for the '<em><b>Videowithoutanalytics</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__VIDEOWITHOUTANALYTICS = GENERAL_ENTITY_FEATURE_COUNT + 16;

	/**
	 * The feature id for the '<em><b>Lightsensor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__LIGHTSENSOR = GENERAL_ENTITY_FEATURE_COUNT + 17;

	/**
	 * The feature id for the '<em><b>Phone</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__PHONE = GENERAL_ENTITY_FEATURE_COUNT + 18;

	/**
	 * The feature id for the '<em><b>Camera</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__CAMERA = GENERAL_ENTITY_FEATURE_COUNT + 19;

	/**
	 * The feature id for the '<em><b>Doorlock</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__DOORLOCK = GENERAL_ENTITY_FEATURE_COUNT + 20;

	/**
	 * The feature id for the '<em><b>Thermostat</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE__THERMOSTAT = GENERAL_ENTITY_FEATURE_COUNT + 21;

	/**
	 * The number of structural features of the '<em>Cloud Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 22;

	/**
	 * The number of operations of the '<em>Cloud Service</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLOUD_SERVICE_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_SENSOR__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_SENSOR__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_SENSOR__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Connection</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_SENSOR__CONNECTION = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_SENSOR__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_SENSOR__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 4;

	/**
	 * The feature id for the '<em><b>Cloudservice</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_SENSOR__CLOUDSERVICE = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_SENSOR__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = GENERAL_ENTITY_FEATURE_COUNT
			+ 6;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_SENSOR__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The number of structural features of the '<em>Light Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_SENSOR_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The number of operations of the '<em>Light Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIGHT_SENSOR_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl <em>Phone</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getPhone()
	 * @generated
	 */
	int PHONE = 48;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>User info Retention Period</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE__USER_INFO_RETENTION_PERIOD = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = GENERAL_ENTITY_FEATURE_COUNT
			+ 3;

	/**
	 * The feature id for the '<em><b>Are you planning to send all the data to the cloud</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Connection</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE__CONNECTION = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE = GENERAL_ENTITY_FEATURE_COUNT
			+ 7;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Userlocation</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE__USERLOCATION = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Cloudservice</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE__CLOUDSERVICE = GENERAL_ENTITY_FEATURE_COUNT + 10;

	/**
	 * The feature id for the '<em><b>Cookies</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE__COOKIES = GENERAL_ENTITY_FEATURE_COUNT + 11;

	/**
	 * The number of structural features of the '<em>Phone</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 12;

	/**
	 * The number of operations of the '<em>Phone</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PHONE_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.DoorLockImpl <em>Door Lock</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.DoorLockImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getDoorLock()
	 * @generated
	 */
	int DOOR_LOCK = 49;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR_LOCK__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR_LOCK__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR_LOCK__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Cloudservice</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR_LOCK__CLOUDSERVICE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR_LOCK__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = GENERAL_ENTITY_FEATURE_COUNT
			+ 3;

	/**
	 * The feature id for the '<em><b>Connection</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR_LOCK__CONNECTION = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR_LOCK__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR_LOCK__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 6;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR_LOCK__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The number of structural features of the '<em>Door Lock</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR_LOCK_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The number of operations of the '<em>Door Lock</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOOR_LOCK_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.ThermostatImpl <em>Thermostat</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.ThermostatImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getThermostat()
	 * @generated
	 */
	int THERMOSTAT = 50;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THERMOSTAT__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THERMOSTAT__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THERMOSTAT__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Cloudservice</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THERMOSTAT__CLOUDSERVICE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THERMOSTAT__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = GENERAL_ENTITY_FEATURE_COUNT
			+ 3;

	/**
	 * The feature id for the '<em><b>Connection</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THERMOSTAT__CONNECTION = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Data Retention</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THERMOSTAT__DATA_RETENTION = GENERAL_ENTITY_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THERMOSTAT__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT
			+ 6;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THERMOSTAT__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The number of structural features of the '<em>Thermostat</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THERMOSTAT_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The number of operations of the '<em>Thermostat</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THERMOSTAT_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl <em>Camera</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.CameraImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCamera()
	 * @generated
	 */
	int CAMERA = 51;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Encrypted Data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__ENCRYPTED_DATA = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__PRIVACY_PATTERNS = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Are you sending data without anonymisation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Does the sign has abrief explanation about the purpose of CCTV</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV = GENERAL_ENTITY_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Do people aware of being recorded</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__DO_PEOPLE_AWARE_OF_BEING_RECORDED = GENERAL_ENTITY_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = GENERAL_ENTITY_FEATURE_COUNT
			+ 5;

	/**
	 * The feature id for the '<em><b>Are you storing the footage in asecure location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Ensure data minimisation is aplied</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__ENSURE_DATA_MINIMISATION_IS_APLIED = GENERAL_ENTITY_FEATURE_COUNT + 7;

	/**
	 * The feature id for the '<em><b>Do you use signs that say CCTV is in operation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION = GENERAL_ENTITY_FEATURE_COUNT + 8;

	/**
	 * The feature id for the '<em><b>Does the system record information other than the purpose</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE = GENERAL_ENTITY_FEATURE_COUNT + 9;

	/**
	 * The feature id for the '<em><b>Record retention period</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__RECORD_RETENTION_PERIOD = GENERAL_ENTITY_FEATURE_COUNT + 10;

	/**
	 * The feature id for the '<em><b>Are you allowing data unauthorised access</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS = GENERAL_ENTITY_FEATURE_COUNT + 11;

	/**
	 * The feature id for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = GENERAL_ENTITY_FEATURE_COUNT + 12;

	/**
	 * The feature id for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = GENERAL_ENTITY_FEATURE_COUNT + 13;

	/**
	 * The feature id for the '<em><b>Cloudservice</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA__CLOUDSERVICE = GENERAL_ENTITY_FEATURE_COUNT + 14;

	/**
	 * The number of structural features of the '<em>Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 15;

	/**
	 * The number of operations of the '<em>Camera</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAMERA_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.Privacy_patternsImpl <em>Privacy patterns</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Privacy_patternsImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getPrivacy_patterns()
	 * @generated
	 */
	int PRIVACY_PATTERNS = 52;

	/**
	 * The feature id for the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIVACY_PATTERNS__PRIVACY_PATTERNS = 0;

	/**
	 * The number of structural features of the '<em>Privacy patterns</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIVACY_PATTERNS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Privacy patterns</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PRIVACY_PATTERNS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CookiesImpl <em>Cookies</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.impl.CookiesImpl
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCookies()
	 * @generated
	 */
	int COOKIES = 53;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COOKIES__NAME = GENERAL_ENTITY__NAME;

	/**
	 * The feature id for the '<em><b>Use the surface cookies banner if cookies are placed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COOKIES__USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED = GENERAL_ENTITY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>The cookie banner must be resurfaced if new cookies are added</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED = GENERAL_ENTITY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>The cookie banner must be resurfaced if browser settings change</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE = GENERAL_ENTITY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Capture consent or acceptance if necessary OR Analytics OR Ad targeting cookies are used</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COOKIES__CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED = GENERAL_ENTITY_FEATURE_COUNT
			+ 3;

	/**
	 * The feature id for the '<em><b>Place cookies according to consent if necessary OR Analytics OR Ad targeting cookies are used</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COOKIES__PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED = GENERAL_ENTITY_FEATURE_COUNT
			+ 4;

	/**
	 * The feature id for the '<em><b>Consider the option of using athird party tool such as One Trus or Trust Arc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COOKIES__CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC = GENERAL_ENTITY_FEATURE_COUNT
			+ 5;

	/**
	 * The number of structural features of the '<em>Cookies</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COOKIES_FEATURE_COUNT = GENERAL_ENTITY_FEATURE_COUNT + 6;

	/**
	 * The number of operations of the '<em>Cookies</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COOKIES_OPERATION_COUNT = GENERAL_ENTITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.DataRetentionEnum <em>Data Retention Enum</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getDataRetentionEnum()
	 * @generated
	 */
	int DATA_RETENTION_ENUM = 54;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.PatientHealthStatus <em>Patient Health Status</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.PatientHealthStatus
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getPatientHealthStatus()
	 * @generated
	 */
	int PATIENT_HEALTH_STATUS = 55;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.CommunicationProtocols <em>Communication Protocols</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.CommunicationProtocols
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCommunicationProtocols()
	 * @generated
	 */
	int COMMUNICATION_PROTOCOLS = 56;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.Checked_Consent <em>Checked Consent</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getChecked_Consent()
	 * @generated
	 */
	int CHECKED_CONSENT = 57;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.CloudStorageLocation <em>Cloud Storage Location</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.CloudStorageLocation
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCloudStorageLocation()
	 * @generated
	 */
	int CLOUD_STORAGE_LOCATION = 58;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.LocationGranularity <em>Location Granularity</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.LocationGranularity
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getLocationGranularity()
	 * @generated
	 */
	int LOCATION_GRANULARITY = 59;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.Checked <em>Checked</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getChecked()
	 * @generated
	 */
	int CHECKED = 60;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.CloudProviderServer <em>Cloud Provider Server</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.CloudProviderServer
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCloudProviderServer()
	 * @generated
	 */
	int CLOUD_PROVIDER_SERVER = 61;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.TestOnDummyData <em>Test On Dummy Data</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.TestOnDummyData
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getTestOnDummyData()
	 * @generated
	 */
	int TEST_ON_DUMMY_DATA = 62;

	/**
	 * The meta object id for the '{@link com.cardiffuni.pbdproject.cgm3.Answer <em>Answer</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getAnswer()
	 * @generated
	 */
	int ANSWER = 63;

	/**
	 * The meta object id for the '<em>Consent Data Type</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.Object
	 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getConsentDataType()
	 * @generated
	 */
	int CONSENT_DATA_TYPE = 64;

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.GeneralEntity <em>General Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>General Entity</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GeneralEntity
	 * @generated
	 */
	EClass getGeneralEntity();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.GeneralEntity#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GeneralEntity#getName()
	 * @see #getGeneralEntity()
	 * @generated
	 */
	EAttribute getGeneralEntity_Name();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor <em>CG Msensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>CG Msensor</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CGMsensor
	 * @generated
	 */
	EClass getCGMsensor();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getSmartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Smartphone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CGMsensor#getSmartphone()
	 * @see #getCGMsensor()
	 * @generated
	 */
	EReference getCGMsensor_Smartphone();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getGlucose_amount <em>Glucose amount</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Glucose amount</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CGMsensor#getGlucose_amount()
	 * @see #getCGMsensor()
	 * @generated
	 */
	EAttribute getCGMsensor_Glucose_amount();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getConnection <em>Connection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Connection</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CGMsensor#getConnection()
	 * @see #getCGMsensor()
	 * @generated
	 */
	EAttribute getCGMsensor_Connection();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CGMsensor#getDataRetention()
	 * @see #getCGMsensor()
	 * @generated
	 */
	EAttribute getCGMsensor_DataRetention();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CGMsensor#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getCGMsensor()
	 * @generated
	 */
	EAttribute getCGMsensor_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CGMsensor#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CGMsensor#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getCGMsensor()
	 * @generated
	 */
	EAttribute getCGMsensor_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone <em>Smart Phone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Smart Phone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone
	 * @generated
	 */
	EClass getSmartPhone();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getCgmsensor <em>Cgmsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cgmsensor</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getCgmsensor()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EReference getSmartPhone_Cgmsensor();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getCloud <em>Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getCloud()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EReference getSmartPhone_Cloud();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getBlood_Sugar_Level <em>Blood Sugar Level</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Blood Sugar Level</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getBlood_Sugar_Level()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EAttribute getSmartPhone_Blood_Sugar_Level();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getConnection <em>Connection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Connection</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getConnection()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EAttribute getSmartPhone_Connection();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getPatient_info_Retention_Period <em>Patient info Retention Period</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Patient info Retention Period</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getPatient_info_Retention_Period()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EAttribute getSmartPhone_Patient_info_Retention_Period();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getUserlocation <em>Userlocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Userlocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getUserlocation()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EReference getSmartPhone_Userlocation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate <em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EAttribute getSmartPhone_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getAre_you_planning_to_send_all_the_data_to_the_cloud <em>Are you planning to send all the data to the cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you planning to send all the data to the cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getAre_you_planning_to_send_all_the_data_to_the_cloud()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EAttribute getSmartPhone_Are_you_planning_to_send_all_the_data_to_the_cloud();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EAttribute getSmartPhone_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EAttribute getSmartPhone_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EAttribute getSmartPhone_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getSmartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Smartphone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getSmartphone()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EReference getSmartPhone_Smartphone();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getPharmacycloud <em>Pharmacycloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pharmacycloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getPharmacycloud()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EReference getSmartPhone_Pharmacycloud();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getCloudforpharmacy <em>Cloudforpharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloudforpharmacy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getCloudforpharmacy()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EReference getSmartPhone_Cloudforpharmacy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.SmartPhone#getCookies <em>Cookies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cookies</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SmartPhone#getCookies()
	 * @see #getSmartPhone()
	 * @generated
	 */
	EReference getSmartPhone_Cookies();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Patient <em>Patient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Patient</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient
	 * @generated
	 */
	EClass getPatient();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Patient#getSmartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Smartphone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient#getSmartphone()
	 * @see #getPatient()
	 * @generated
	 */
	EReference getPatient_Smartphone();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Patient#getCgmsensor <em>Cgmsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cgmsensor</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient#getCgmsensor()
	 * @see #getPatient()
	 * @generated
	 */
	EReference getPatient_Cgmsensor();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Patient#getDoctor <em>Doctor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Doctor</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient#getDoctor()
	 * @see #getPatient()
	 * @generated
	 */
	EReference getPatient_Doctor();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Patient#getMedicalrecord <em>Medicalrecord</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Medicalrecord</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient#getMedicalrecord()
	 * @see #getPatient()
	 * @generated
	 */
	EReference getPatient_Medicalrecord();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Patient#getAge <em>Age</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Age</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient#getAge()
	 * @see #getPatient()
	 * @generated
	 */
	EAttribute getPatient_Age();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Patient#getConsent_checkedlist <em>Consent checkedlist</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Consent checkedlist</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient#getConsent_checkedlist()
	 * @see #getPatient()
	 * @generated
	 */
	EReference getPatient_Consent_checkedlist();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Patient#getPhoneNumber <em>Phone Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Phone Number</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient#getPhoneNumber()
	 * @see #getPatient()
	 * @generated
	 */
	EAttribute getPatient_PhoneNumber();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Patient#getAuthentication <em>Authentication</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Authentication</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient#getAuthentication()
	 * @see #getPatient()
	 * @generated
	 */
	EReference getPatient_Authentication();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Patient#getAuthorization <em>Authorization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Authorization</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient#getAuthorization()
	 * @see #getPatient()
	 * @generated
	 */
	EReference getPatient_Authorization();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Patient#getDatasharing <em>Datasharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Datasharing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient#getDatasharing()
	 * @see #getPatient()
	 * @generated
	 */
	EReference getPatient_Datasharing();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Patient#getComputerbrowser <em>Computerbrowser</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Computerbrowser</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient#getComputerbrowser()
	 * @see #getPatient()
	 * @generated
	 */
	EReference getPatient_Computerbrowser();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Patient#getWebbrowser <em>Webbrowser</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Webbrowser</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Patient#getWebbrowser()
	 * @see #getPatient()
	 * @generated
	 */
	EReference getPatient_Webbrowser();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Nurse <em>Nurse</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Nurse</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Nurse
	 * @generated
	 */
	EClass getNurse();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Doctor <em>Doctor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Doctor</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Doctor
	 * @generated
	 */
	EClass getDoctor();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Doctor#getPatient <em>Patient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Patient</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Doctor#getPatient()
	 * @see #getDoctor()
	 * @generated
	 */
	EReference getDoctor_Patient();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Doctor#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Website</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Doctor#getWebsite()
	 * @see #getDoctor()
	 * @generated
	 */
	EReference getDoctor_Website();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Doctor#getSpecialty <em>Specialty</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Specialty</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Doctor#getSpecialty()
	 * @see #getDoctor()
	 * @generated
	 */
	EAttribute getDoctor_Specialty();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Doctor#getAuthentication <em>Authentication</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Authentication</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Doctor#getAuthentication()
	 * @see #getDoctor()
	 * @generated
	 */
	EReference getDoctor_Authentication();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Doctor#getAuthorization <em>Authorization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Authorization</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Doctor#getAuthorization()
	 * @see #getDoctor()
	 * @generated
	 */
	EReference getDoctor_Authorization();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Doctor#getAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data <em>Are you allowing unauthorised doctors to access or process the data subject health data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you allowing unauthorised doctors to access or process the data subject health data</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Doctor#getAre_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data()
	 * @see #getDoctor()
	 * @generated
	 */
	EAttribute getDoctor_Are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.NewEClass7 <em>New EClass7</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>New EClass7</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.NewEClass7
	 * @generated
	 */
	EClass getNewEClass7();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Cloud <em>Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud
	 * @generated
	 */
	EClass getCloud();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getSmartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Smartphone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getSmartphone()
	 * @see #getCloud()
	 * @generated
	 */
	EReference getCloud_Smartphone();

	/**
	 * Returns the meta object for the reference list '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Website</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getWebsite()
	 * @see #getCloud()
	 * @generated
	 */
	EReference getCloud_Website();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getDataRetention()
	 * @see #getCloud()
	 * @generated
	 */
	EAttribute getCloud_DataRetention();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getStoragelocation <em>Storagelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Storagelocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getStoragelocation()
	 * @see #getCloud()
	 * @generated
	 */
	EReference getCloud_Storagelocation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getDatasharing <em>Datasharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Datasharing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getDatasharing()
	 * @see #getCloud()
	 * @generated
	 */
	EReference getCloud_Datasharing();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getTest_on_dummy <em>Test on dummy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Test on dummy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getTest_on_dummy()
	 * @see #getCloud()
	 * @generated
	 */
	EReference getCloud_Test_on_dummy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getContainerisation <em>Containerisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Containerisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getContainerisation()
	 * @see #getCloud()
	 * @generated
	 */
	EReference getCloud_Containerisation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getAggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getAggregation()
	 * @see #getCloud()
	 * @generated
	 */
	EReference getCloud_Aggregation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you collecting data that are not needed for the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @see #getCloud()
	 * @generated
	 */
	EAttribute getCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getCloud()
	 * @generated
	 */
	EAttribute getCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you sharing data with other parties without having data subject consent</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @see #getCloud()
	 * @generated
	 */
	EAttribute getCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getCloud()
	 * @generated
	 */
	EAttribute getCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @see #getCloud()
	 * @generated
	 */
	EAttribute getCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getCloud()
	 * @generated
	 */
	EAttribute getCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getMedicalrecord <em>Medicalrecord</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Medicalrecord</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getMedicalrecord()
	 * @see #getCloud()
	 * @generated
	 */
	EReference getCloud_Medicalrecord();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Website <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Website</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Website
	 * @generated
	 */
	EClass getWebsite();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Website#getCloud <em>Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Website#getCloud()
	 * @see #getWebsite()
	 * @generated
	 */
	EReference getWebsite_Cloud();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Website#getDoctor <em>Doctor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Doctor</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Website#getDoctor()
	 * @see #getWebsite()
	 * @generated
	 */
	EReference getWebsite_Doctor();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Website#getResearcher <em>Researcher</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Researcher</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Website#getResearcher()
	 * @see #getWebsite()
	 * @generated
	 */
	EReference getWebsite_Researcher();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Website#getURL <em>URL</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>URL</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Website#getURL()
	 * @see #getWebsite()
	 * @generated
	 */
	EAttribute getWebsite_URL();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Website#getVideoprocessingcloud <em>Videoprocessingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Videoprocessingcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Website#getVideoprocessingcloud()
	 * @see #getWebsite()
	 * @generated
	 */
	EReference getWebsite_Videoprocessingcloud();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Website#getCookies <em>Cookies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cookies</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Website#getCookies()
	 * @see #getWebsite()
	 * @generated
	 */
	EReference getWebsite_Cookies();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Hospital <em>Hospital</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Hospital</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital
	 * @generated
	 */
	EClass getHospital();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getPatient <em>Patient</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Patient</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getPatient()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Patient();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getDoctor <em>Doctor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Doctor</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getDoctor()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Doctor();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getResearcher <em>Researcher</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Researcher</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getResearcher()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Researcher();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getNurse <em>Nurse</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Nurse</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getNurse()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Nurse();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCloud <em>Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getCloud()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Cloud();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Website</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getWebsite()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Website();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getSmartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Smartphone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getSmartphone()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Smartphone();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCgmsensor <em>Cgmsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cgmsensor</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getCgmsensor()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Cgmsensor();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getMedicalrecord <em>Medicalrecord</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Medicalrecord</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getMedicalrecord()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Medicalrecord();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getConsent_checkedlist <em>Consent checkedlist</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Consent checkedlist</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getConsent_checkedlist()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Consent_checkedlist();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getStoragelocation <em>Storagelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Storagelocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getStoragelocation()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Storagelocation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getUserlocation <em>Userlocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Userlocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getUserlocation()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Userlocation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getRiskcode <em>Riskcode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Riskcode</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getRiskcode()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Riskcode();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getEncryption <em>Encryption</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Encryption</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getEncryption()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Encryption();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getDatasharing <em>Datasharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Datasharing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getDatasharing()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Datasharing();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getWarning <em>Warning</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Warning</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getWarning()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Warning();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getTest_on_dummy <em>Test on dummy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Test on dummy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getTest_on_dummy()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Test_on_dummy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getContainerisation <em>Containerisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Containerisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getContainerisation()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Containerisation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getAggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getAggregation()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Aggregation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getComputerbrowser <em>Computerbrowser</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Computerbrowser</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getComputerbrowser()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Computerbrowser();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getPharmacycloud <em>Pharmacycloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pharmacycloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getPharmacycloud()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Pharmacycloud();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getShippingcloud <em>Shippingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Shippingcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getShippingcloud()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Shippingcloud();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getWebhostingcloud <em>Webhostingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Webhostingcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getWebhostingcloud()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Webhostingcloud();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getPaymentcloud <em>Paymentcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Paymentcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getPaymentcloud()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Paymentcloud();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getSocialnetworkcloud <em>Socialnetworkcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Socialnetworkcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getSocialnetworkcloud()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Socialnetworkcloud();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getWebbrowser <em>Webbrowser</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Webbrowser</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getWebbrowser()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Webbrowser();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCloudforpharmacy <em>Cloudforpharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cloudforpharmacy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getCloudforpharmacy()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Cloudforpharmacy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getRealtimebiddingcloud <em>Realtimebiddingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Realtimebiddingcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getRealtimebiddingcloud()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Realtimebiddingcloud();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getGpstracker <em>Gpstracker</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Gpstracker</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getGpstracker()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Gpstracker();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getBus <em>Bus</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Bus</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getBus()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Bus();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getDriver <em>Driver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Driver</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getDriver()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Driver();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCustomer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Customer</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getCustomer()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Customer();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getVideoanalytics <em>Videoanalytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Videoanalytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getVideoanalytics()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Videoanalytics();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getAnalytics <em>Analytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Analytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getAnalytics()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Analytics();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getBlurring <em>Blurring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Blurring</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getBlurring()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Blurring();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getVideoprocessingcloud <em>Videoprocessingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Videoprocessingcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getVideoprocessingcloud()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Videoprocessingcloud();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getVideowithoutanalytics <em>Videowithoutanalytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Videowithoutanalytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getVideowithoutanalytics()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Videowithoutanalytics();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getClient <em>Client</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Client</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getClient()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Client();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCloudservice <em>Cloudservice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cloudservice</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getCloudservice()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Cloudservice();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getLightsensor <em>Lightsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Lightsensor</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getLightsensor()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Lightsensor();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getPhone <em>Phone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Phone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getPhone()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Phone();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getThermostat <em>Thermostat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Thermostat</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getThermostat()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Thermostat();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getDoorlock <em>Doorlock</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Doorlock</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getDoorlock()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Doorlock();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCamera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Camera</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getCamera()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Camera();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Hospital#getCookies <em>Cookies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cookies</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Hospital#getCookies()
	 * @see #getHospital()
	 * @generated
	 */
	EReference getHospital_Cookies();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Researcher <em>Researcher</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Researcher</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Researcher
	 * @generated
	 */
	EClass getResearcher();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Researcher#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Website</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Researcher#getWebsite()
	 * @see #getResearcher()
	 * @generated
	 */
	EReference getResearcher_Website();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Researcher#getAuthentication <em>Authentication</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Authentication</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Researcher#getAuthentication()
	 * @see #getResearcher()
	 * @generated
	 */
	EReference getResearcher_Authentication();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Researcher#getAuthorization <em>Authorization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Authorization</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Researcher#getAuthorization()
	 * @see #getResearcher()
	 * @generated
	 */
	EReference getResearcher_Authorization();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Researcher#getAre_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data <em>Are you allowing researchers to access or process the data subject medical data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you allowing researchers to access or process the data subject medical data</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Researcher#getAre_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data()
	 * @see #getResearcher()
	 * @generated
	 */
	EAttribute getResearcher_Are_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Researcher#getAre_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name <em>Are you allowing unauthorised researchers to access or process the data subject personal data such as name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you allowing unauthorised researchers to access or process the data subject personal data such as name</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Researcher#getAre_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name()
	 * @see #getResearcher()
	 * @generated
	 */
	EAttribute getResearcher_Are_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.MedicalRecord <em>Medical Record</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Medical Record</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.MedicalRecord
	 * @generated
	 */
	EClass getMedicalRecord();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.MedicalRecord#getRecordRetentionPeriod <em>Record Retention Period</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Record Retention Period</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.MedicalRecord#getRecordRetentionPeriod()
	 * @see #getMedicalRecord()
	 * @generated
	 */
	EAttribute getMedicalRecord_RecordRetentionPeriod();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList <em>Consent Checked List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Consent Checked List</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Consent_CheckedList
	 * @generated
	 */
	EClass getConsent_CheckedList();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_age_authorization_if_age_is_less_than_16 <em>Capture age authorization if age is less than 16</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capture age authorization if age is less than 16</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_age_authorization_if_age_is_less_than_16()
	 * @see #getConsent_CheckedList()
	 * @generated
	 */
	EAttribute getConsent_CheckedList_Capture_age_authorization_if_age_is_less_than_16();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_withdrawal_log <em>Capture withdrawal log</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capture withdrawal log</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_withdrawal_log()
	 * @see #getConsent_CheckedList()
	 * @generated
	 */
	EAttribute getConsent_CheckedList_Capture_withdrawal_log();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_log_Terms_of_use_AND_consent_to_process <em>Capture log Terms of use AND consent to process</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capture log Terms of use AND consent to process</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_log_Terms_of_use_AND_consent_to_process()
	 * @see #getConsent_CheckedList()
	 * @generated
	 */
	EAttribute getConsent_CheckedList_Capture_log_Terms_of_use_AND_consent_to_process();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_consent_to_process_special_category_data <em>Capture consent to process special category data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capture consent to process special category data</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_consent_to_process_special_category_data()
	 * @see #getConsent_CheckedList()
	 * @generated
	 */
	EAttribute getConsent_CheckedList_Capture_consent_to_process_special_category_data();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_consent_to_term_of_use <em>Capture consent to term of use</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capture consent to term of use</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_consent_to_term_of_use()
	 * @see #getConsent_CheckedList()
	 * @generated
	 */
	EAttribute getConsent_CheckedList_Capture_consent_to_term_of_use();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getSurface_privacy_notice <em>Surface privacy notice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Surface privacy notice</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getSurface_privacy_notice()
	 * @see #getConsent_CheckedList()
	 * @generated
	 */
	EAttribute getConsent_CheckedList_Surface_privacy_notice();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used <em>Capture consent to the type of marketing if electronic marketing is used</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capture consent to the type of marketing if electronic marketing is used</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used()
	 * @see #getConsent_CheckedList()
	 * @generated
	 */
	EAttribute getConsent_CheckedList_Capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.StorageLocation <em>Storage Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Storage Location</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.StorageLocation
	 * @generated
	 */
	EClass getStorageLocation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.StorageLocation#getCloud_provider_and_server_location <em>Cloud provider and server location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cloud provider and server location</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.StorageLocation#getCloud_provider_and_server_location()
	 * @see #getStorageLocation()
	 * @generated
	 */
	EAttribute getStorageLocation_Cloud_provider_and_server_location();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.UserLocation <em>User Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>User Location</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.UserLocation
	 * @generated
	 */
	EClass getUserLocation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.UserLocation#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.UserLocation#getLocation()
	 * @see #getUserLocation()
	 * @generated
	 */
	EAttribute getUserLocation_Location();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.UserLocation#getAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed <em>Are you planning to collect the exact location of the data subject when the location is not needed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you planning to collect the exact location of the data subject when the location is not needed</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.UserLocation#getAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed()
	 * @see #getUserLocation()
	 * @generated
	 */
	EAttribute getUserLocation_Are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.RiskCode <em>Risk Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Risk Code</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RiskCode
	 * @generated
	 */
	EClass getRiskCode();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Authentication <em>Authentication</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Authentication</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Authentication
	 * @generated
	 */
	EClass getAuthentication();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Authentication#getAuthenticated <em>Authenticated</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Authenticated</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Authentication#getAuthenticated()
	 * @see #getAuthentication()
	 * @generated
	 */
	EAttribute getAuthentication_Authenticated();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Authorization <em>Authorization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Authorization</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Authorization
	 * @generated
	 */
	EClass getAuthorization();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Authorization#getAuthorized <em>Authorized</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Authorized</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Authorization#getAuthorized()
	 * @see #getAuthorization()
	 * @generated
	 */
	EAttribute getAuthorization_Authorized();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Firewall <em>Firewall</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Firewall</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Firewall
	 * @generated
	 */
	EClass getFirewall();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Encryption <em>Encryption</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Encryption</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Encryption
	 * @generated
	 */
	EClass getEncryption();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Encryption#getEncryptedData <em>Encrypted Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Encrypted Data</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Encryption#getEncryptedData()
	 * @see #getEncryption()
	 * @generated
	 */
	EAttribute getEncryption_EncryptedData();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.DataSharing <em>Data Sharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Data Sharing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.DataSharing
	 * @generated
	 */
	EClass getDataSharing();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.DataSharing#getApply_anonymisation_for_researcher <em>Apply anonymisation for researcher</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Apply anonymisation for researcher</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.DataSharing#getApply_anonymisation_for_researcher()
	 * @see #getDataSharing()
	 * @generated
	 */
	EAttribute getDataSharing_Apply_anonymisation_for_researcher();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.DataSharing#getEnsure_accessControl <em>Ensure access Control</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ensure access Control</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.DataSharing#getEnsure_accessControl()
	 * @see #getDataSharing()
	 * @generated
	 */
	EAttribute getDataSharing_Ensure_accessControl();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Warning <em>Warning</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Warning</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Warning
	 * @generated
	 */
	EClass getWarning();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Test_on_dummy <em>Test on dummy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Test on dummy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Test_on_dummy
	 * @generated
	 */
	EClass getTest_on_dummy();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Test_on_dummy#getTesting_on_dummy_data <em>Testing on dummy data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Testing on dummy data</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Test_on_dummy#getTesting_on_dummy_data()
	 * @see #getTest_on_dummy()
	 * @generated
	 */
	EAttribute getTest_on_dummy_Testing_on_dummy_data();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Containerisation <em>Containerisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Containerisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Containerisation
	 * @generated
	 */
	EClass getContainerisation();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Aggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Aggregation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Aggregation
	 * @generated
	 */
	EClass getAggregation();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.NewEClass26 <em>New EClass26</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>New EClass26</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.NewEClass26
	 * @generated
	 */
	EClass getNewEClass26();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser <em>Computer Browser</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Computer Browser</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ComputerBrowser
	 * @generated
	 */
	EClass getComputerBrowser();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getCgmsensor <em>Cgmsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cgmsensor</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getCgmsensor()
	 * @see #getComputerBrowser()
	 * @generated
	 */
	EReference getComputerBrowser_Cgmsensor();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getCloud <em>Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getCloud()
	 * @see #getComputerBrowser()
	 * @generated
	 */
	EReference getComputerBrowser_Cloud();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getPatient_info_Retention_Period <em>Patient info Retention Period</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Patient info Retention Period</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getPatient_info_Retention_Period()
	 * @see #getComputerBrowser()
	 * @generated
	 */
	EAttribute getComputerBrowser_Patient_info_Retention_Period();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getUserlocation <em>Userlocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Userlocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getUserlocation()
	 * @see #getComputerBrowser()
	 * @generated
	 */
	EReference getComputerBrowser_Userlocation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate <em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate()
	 * @see #getComputerBrowser()
	 * @generated
	 */
	EAttribute getComputerBrowser_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getAre_you_planning_to_send_all_the_data_to_the_cloud <em>Are you planning to send all the data to the cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you planning to send all the data to the cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getAre_you_planning_to_send_all_the_data_to_the_cloud()
	 * @see #getComputerBrowser()
	 * @generated
	 */
	EAttribute getComputerBrowser_Are_you_planning_to_send_all_the_data_to_the_cloud();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getComputerBrowser()
	 * @generated
	 */
	EAttribute getComputerBrowser_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getComputerBrowser()
	 * @generated
	 */
	EAttribute getComputerBrowser_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getComputerBrowser()
	 * @generated
	 */
	EAttribute getComputerBrowser_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getPharmacycloud <em>Pharmacycloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Pharmacycloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ComputerBrowser#getPharmacycloud()
	 * @see #getComputerBrowser()
	 * @generated
	 */
	EReference getComputerBrowser_Pharmacycloud();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.NewEClass28 <em>New EClass28</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>New EClass28</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.NewEClass28
	 * @generated
	 */
	EClass getNewEClass28();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold <em>Pharmacy Cloudold</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pharmacy Cloudold</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold
	 * @generated
	 */
	EClass getPharmacyCloudold();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getSmartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Smartphone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getSmartphone()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EReference getPharmacyCloudold_Smartphone();

	/**
	 * Returns the meta object for the reference list '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Website</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getWebsite()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EReference getPharmacyCloudold_Website();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getDataRetention()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EAttribute getPharmacyCloudold_DataRetention();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getStoragelocation <em>Storagelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Storagelocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getStoragelocation()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EReference getPharmacyCloudold_Storagelocation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getDatasharing <em>Datasharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Datasharing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getDatasharing()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EReference getPharmacyCloudold_Datasharing();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getTest_on_dummy <em>Test on dummy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Test on dummy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getTest_on_dummy()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EReference getPharmacyCloudold_Test_on_dummy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getContainerisation <em>Containerisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Containerisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getContainerisation()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EReference getPharmacyCloudold_Containerisation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getAggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getAggregation()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EReference getPharmacyCloudold_Aggregation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you collecting data that are not needed for the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EAttribute getPharmacyCloudold_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EAttribute getPharmacyCloudold_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you sharing data with other parties without having data subject consent</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EAttribute getPharmacyCloudold_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EAttribute getPharmacyCloudold_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EAttribute getPharmacyCloudold_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EAttribute getPharmacyCloudold_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getComputerbrowser <em>Computerbrowser</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Computerbrowser</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PharmacyCloudold#getComputerbrowser()
	 * @see #getPharmacyCloudold()
	 * @generated
	 */
	EReference getPharmacyCloudold_Computerbrowser();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud <em>Shipping Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Shipping Cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud
	 * @generated
	 */
	EClass getShippingCloud();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getSmartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Smartphone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getSmartphone()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EReference getShippingCloud_Smartphone();

	/**
	 * Returns the meta object for the reference list '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Website</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getWebsite()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EReference getShippingCloud_Website();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getDataRetention()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EAttribute getShippingCloud_DataRetention();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getStoragelocation <em>Storagelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Storagelocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getStoragelocation()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EReference getShippingCloud_Storagelocation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getDatasharing <em>Datasharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Datasharing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getDatasharing()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EReference getShippingCloud_Datasharing();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getTest_on_dummy <em>Test on dummy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Test on dummy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getTest_on_dummy()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EReference getShippingCloud_Test_on_dummy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getContainerisation <em>Containerisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Containerisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getContainerisation()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EReference getShippingCloud_Containerisation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getAggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getAggregation()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EReference getShippingCloud_Aggregation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you collecting data that are not needed for the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EAttribute getShippingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EAttribute getShippingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you sharing data with other parties without having data subject consent</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EAttribute getShippingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EAttribute getShippingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EAttribute getShippingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EAttribute getShippingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.ShippingCloud#getCloudforpharmacy <em>Cloudforpharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloudforpharmacy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.ShippingCloud#getCloudforpharmacy()
	 * @see #getShippingCloud()
	 * @generated
	 */
	EReference getShippingCloud_Cloudforpharmacy();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud <em>Webhosting Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Webhosting Cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud
	 * @generated
	 */
	EClass getWebhostingCloud();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getSmartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Smartphone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getSmartphone()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EReference getWebhostingCloud_Smartphone();

	/**
	 * Returns the meta object for the reference list '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Website</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getWebsite()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EReference getWebhostingCloud_Website();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getDataRetention()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EAttribute getWebhostingCloud_DataRetention();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getStoragelocation <em>Storagelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Storagelocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getStoragelocation()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EReference getWebhostingCloud_Storagelocation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getDatasharing <em>Datasharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Datasharing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getDatasharing()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EReference getWebhostingCloud_Datasharing();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getTest_on_dummy <em>Test on dummy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Test on dummy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getTest_on_dummy()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EReference getWebhostingCloud_Test_on_dummy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getContainerisation <em>Containerisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Containerisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getContainerisation()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EReference getWebhostingCloud_Containerisation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getAggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getAggregation()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EReference getWebhostingCloud_Aggregation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you collecting data that are not needed for the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EAttribute getWebhostingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EAttribute getWebhostingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you sharing data with other parties without having data subject consent</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EAttribute getWebhostingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EAttribute getWebhostingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EAttribute getWebhostingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EAttribute getWebhostingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getCloudforpharmacy <em>Cloudforpharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloudforpharmacy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getCloudforpharmacy()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EReference getWebhostingCloud_Cloudforpharmacy();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getSocialnetworkcloud <em>Socialnetworkcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Socialnetworkcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getSocialnetworkcloud()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EReference getWebhostingCloud_Socialnetworkcloud();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getRealtimebiddingcloud <em>Realtimebiddingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Realtimebiddingcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebhostingCloud#getRealtimebiddingcloud()
	 * @see #getWebhostingCloud()
	 * @generated
	 */
	EReference getWebhostingCloud_Realtimebiddingcloud();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud <em>Payment Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Payment Cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud
	 * @generated
	 */
	EClass getPaymentCloud();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getSmartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Smartphone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getSmartphone()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EReference getPaymentCloud_Smartphone();

	/**
	 * Returns the meta object for the reference list '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Website</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getWebsite()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EReference getPaymentCloud_Website();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getDataRetention()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EAttribute getPaymentCloud_DataRetention();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getStoragelocation <em>Storagelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Storagelocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getStoragelocation()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EReference getPaymentCloud_Storagelocation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getDatasharing <em>Datasharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Datasharing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getDatasharing()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EReference getPaymentCloud_Datasharing();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getTest_on_dummy <em>Test on dummy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Test on dummy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getTest_on_dummy()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EReference getPaymentCloud_Test_on_dummy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getContainerisation <em>Containerisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Containerisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getContainerisation()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EReference getPaymentCloud_Containerisation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getAggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getAggregation()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EReference getPaymentCloud_Aggregation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you collecting data that are not needed for the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EAttribute getPaymentCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EAttribute getPaymentCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you sharing data with other parties without having data subject consent</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EAttribute getPaymentCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EAttribute getPaymentCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EAttribute getPaymentCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EAttribute getPaymentCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.PaymentCloud#getCloudforpharmacy <em>Cloudforpharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloudforpharmacy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PaymentCloud#getCloudforpharmacy()
	 * @see #getPaymentCloud()
	 * @generated
	 */
	EReference getPaymentCloud_Cloudforpharmacy();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud <em>Social Network Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Social Network Cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud
	 * @generated
	 */
	EClass getSocialNetworkCloud();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getSmartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Smartphone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getSmartphone()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EReference getSocialNetworkCloud_Smartphone();

	/**
	 * Returns the meta object for the reference list '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Website</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getWebsite()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EReference getSocialNetworkCloud_Website();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getDataRetention()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EAttribute getSocialNetworkCloud_DataRetention();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getStoragelocation <em>Storagelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Storagelocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getStoragelocation()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EReference getSocialNetworkCloud_Storagelocation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getDatasharing <em>Datasharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Datasharing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getDatasharing()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EReference getSocialNetworkCloud_Datasharing();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getTest_on_dummy <em>Test on dummy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Test on dummy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getTest_on_dummy()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EReference getSocialNetworkCloud_Test_on_dummy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getContainerisation <em>Containerisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Containerisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getContainerisation()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EReference getSocialNetworkCloud_Containerisation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getAggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getAggregation()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EReference getSocialNetworkCloud_Aggregation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you collecting data that are not needed for the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EAttribute getSocialNetworkCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EAttribute getSocialNetworkCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you sharing data with other parties without having data subject consent</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EAttribute getSocialNetworkCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EAttribute getSocialNetworkCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EAttribute getSocialNetworkCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EAttribute getSocialNetworkCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getCloudforpharmacy <em>Cloudforpharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloudforpharmacy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getCloudforpharmacy()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EReference getSocialNetworkCloud_Cloudforpharmacy();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getWebhostingcloud <em>Webhostingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Webhostingcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.SocialNetworkCloud#getWebhostingcloud()
	 * @see #getSocialNetworkCloud()
	 * @generated
	 */
	EReference getSocialNetworkCloud_Webhostingcloud();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud <em>Real Time Bidding Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Real Time Bidding Cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud
	 * @generated
	 */
	EClass getRealTimeBiddingCloud();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getSmartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Smartphone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getSmartphone()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EReference getRealTimeBiddingCloud_Smartphone();

	/**
	 * Returns the meta object for the reference list '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Website</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getWebsite()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EReference getRealTimeBiddingCloud_Website();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getDataRetention()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EAttribute getRealTimeBiddingCloud_DataRetention();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getStoragelocation <em>Storagelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Storagelocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getStoragelocation()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EReference getRealTimeBiddingCloud_Storagelocation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getDatasharing <em>Datasharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Datasharing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getDatasharing()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EReference getRealTimeBiddingCloud_Datasharing();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getTest_on_dummy <em>Test on dummy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Test on dummy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getTest_on_dummy()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EReference getRealTimeBiddingCloud_Test_on_dummy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getContainerisation <em>Containerisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Containerisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getContainerisation()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EReference getRealTimeBiddingCloud_Containerisation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getAggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getAggregation()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EReference getRealTimeBiddingCloud_Aggregation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you collecting data that are not needed for the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EAttribute getRealTimeBiddingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EAttribute getRealTimeBiddingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you sharing data with other parties without having data subject consent</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EAttribute getRealTimeBiddingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EAttribute getRealTimeBiddingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EAttribute getRealTimeBiddingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EAttribute getRealTimeBiddingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getWebhostingcloud <em>Webhostingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Webhostingcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud#getWebhostingcloud()
	 * @see #getRealTimeBiddingCloud()
	 * @generated
	 */
	EReference getRealTimeBiddingCloud_Webhostingcloud();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.WebBrowser <em>Web Browser</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Web Browser</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebBrowser
	 * @generated
	 */
	EClass getWebBrowser();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.WebBrowser#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebBrowser#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getWebBrowser()
	 * @generated
	 */
	EAttribute getWebBrowser_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.WebBrowser#getAre_you_planning_to_send_all_the_data_to_the_cloud <em>Are you planning to send all the data to the cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you planning to send all the data to the cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebBrowser#getAre_you_planning_to_send_all_the_data_to_the_cloud()
	 * @see #getWebBrowser()
	 * @generated
	 */
	EAttribute getWebBrowser_Are_you_planning_to_send_all_the_data_to_the_cloud();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.WebBrowser#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebBrowser#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getWebBrowser()
	 * @generated
	 */
	EAttribute getWebBrowser_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.WebBrowser#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebBrowser#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getWebBrowser()
	 * @generated
	 */
	EAttribute getWebBrowser_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.WebBrowser#getPatient_info_Retention_Period <em>Patient info Retention Period</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Patient info Retention Period</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebBrowser#getPatient_info_Retention_Period()
	 * @see #getWebBrowser()
	 * @generated
	 */
	EAttribute getWebBrowser_Patient_info_Retention_Period();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.WebBrowser#getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate <em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebBrowser#getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate()
	 * @see #getWebBrowser()
	 * @generated
	 */
	EAttribute getWebBrowser_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.WebBrowser#getUserlocation <em>Userlocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Userlocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebBrowser#getUserlocation()
	 * @see #getWebBrowser()
	 * @generated
	 */
	EReference getWebBrowser_Userlocation();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.WebBrowser#getCloudforpharmacy <em>Cloudforpharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloudforpharmacy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebBrowser#getCloudforpharmacy()
	 * @see #getWebBrowser()
	 * @generated
	 */
	EReference getWebBrowser_Cloudforpharmacy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.WebBrowser#getCookies <em>Cookies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cookies</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.WebBrowser#getCookies()
	 * @see #getWebBrowser()
	 * @generated
	 */
	EReference getWebBrowser_Cookies();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy <em>Cloud For Pharmacy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cloud For Pharmacy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy
	 * @generated
	 */
	EClass getCloudForPharmacy();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getSmartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Smartphone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getSmartphone()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EReference getCloudForPharmacy_Smartphone();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getWebbrowser <em>Webbrowser</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Webbrowser</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getWebbrowser()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EReference getCloudForPharmacy_Webbrowser();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getStoragelocation <em>Storagelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Storagelocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getStoragelocation()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EReference getCloudForPharmacy_Storagelocation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getTest_on_dummy <em>Test on dummy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Test on dummy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getTest_on_dummy()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EReference getCloudForPharmacy_Test_on_dummy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getContainerisation <em>Containerisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Containerisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getContainerisation()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EReference getCloudForPharmacy_Containerisation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAggregation()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EReference getCloudForPharmacy_Aggregation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getDatasharing <em>Datasharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Datasharing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getDatasharing()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EReference getCloudForPharmacy_Datasharing();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EAttribute getCloudForPharmacy_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EAttribute getCloudForPharmacy_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EAttribute getCloudForPharmacy_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you sharing data with other parties without having data subject consent</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EAttribute getCloudForPharmacy_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getDataRetention()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EAttribute getCloudForPharmacy_DataRetention();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EAttribute getCloudForPharmacy_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you collecting data that are not needed for the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EAttribute getCloudForPharmacy_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getPaymentcloud <em>Paymentcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Paymentcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getPaymentcloud()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EReference getCloudForPharmacy_Paymentcloud();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getSocialnetworkcloud <em>Socialnetworkcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Socialnetworkcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getSocialnetworkcloud()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EReference getCloudForPharmacy_Socialnetworkcloud();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getShippingcloud <em>Shippingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Shippingcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getShippingcloud()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EReference getCloudForPharmacy_Shippingcloud();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getWebhostingcloud <em>Webhostingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Webhostingcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudForPharmacy#getWebhostingcloud()
	 * @see #getCloudForPharmacy()
	 * @generated
	 */
	EReference getCloudForPharmacy_Webhostingcloud();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Bus <em>Bus</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Bus</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Bus
	 * @generated
	 */
	EClass getBus();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Bus#getGpstracker <em>Gpstracker</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Gpstracker</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Bus#getGpstracker()
	 * @see #getBus()
	 * @generated
	 */
	EReference getBus_Gpstracker();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Bus#getPlate_number <em>Plate number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Plate number</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Bus#getPlate_number()
	 * @see #getBus()
	 * @generated
	 */
	EAttribute getBus_Plate_number();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Bus#getRoute_number <em>Route number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Route number</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Bus#getRoute_number()
	 * @see #getBus()
	 * @generated
	 */
	EAttribute getBus_Route_number();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Bus#getDriver_name <em>Driver name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Driver name</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Bus#getDriver_name()
	 * @see #getBus()
	 * @generated
	 */
	EAttribute getBus_Driver_name();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Bus#getDriver <em>Driver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Driver</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Bus#getDriver()
	 * @see #getBus()
	 * @generated
	 */
	EReference getBus_Driver();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Bus#getVideoanalytics <em>Videoanalytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Videoanalytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Bus#getVideoanalytics()
	 * @see #getBus()
	 * @generated
	 */
	EReference getBus_Videoanalytics();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Bus#getVideoprocessingcloud <em>Videoprocessingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Videoprocessingcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Bus#getVideoprocessingcloud()
	 * @see #getBus()
	 * @generated
	 */
	EReference getBus_Videoprocessingcloud();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Bus#getCustomer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Customer</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Bus#getCustomer()
	 * @see #getBus()
	 * @generated
	 */
	EReference getBus_Customer();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Bus#getVideowithoutanalytics <em>Videowithoutanalytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Videowithoutanalytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Bus#getVideowithoutanalytics()
	 * @see #getBus()
	 * @generated
	 */
	EReference getBus_Videowithoutanalytics();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker <em>GPS Tracker</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>GPS Tracker</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker
	 * @generated
	 */
	EClass getGPSTracker();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker#getID <em>ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>ID</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker#getID()
	 * @see #getGPSTracker()
	 * @generated
	 */
	EAttribute getGPSTracker_ID();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker#getCoordinates <em>Coordinates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Coordinates</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker#getCoordinates()
	 * @see #getGPSTracker()
	 * @generated
	 */
	EAttribute getGPSTracker_Coordinates();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker#getSpeed <em>Speed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Speed</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker#getSpeed()
	 * @see #getGPSTracker()
	 * @generated
	 */
	EAttribute getGPSTracker_Speed();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker#getDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks <em>Does the use of GPS is fully explained in company policies and staff handbooks</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does the use of GPS is fully explained in company policies and staff handbooks</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker#getDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks()
	 * @see #getGPSTracker()
	 * @generated
	 */
	EAttribute getGPSTracker_Does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker#getRecord_retention_period <em>Record retention period</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Record retention period</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker#getRecord_retention_period()
	 * @see #getGPSTracker()
	 * @generated
	 */
	EAttribute getGPSTracker_Record_retention_period();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker#getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles <em>Does consent have been gathered from the staff who used these vehicles</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does consent have been gathered from the staff who used these vehicles</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker#getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles()
	 * @see #getGPSTracker()
	 * @generated
	 */
	EAttribute getGPSTracker_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss or destruction or damage</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker#getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @see #getGPSTracker()
	 * @generated
	 */
	EAttribute getGPSTracker_Is_data_against_accidental_loss_or_destruction_or_damage();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you using appropriate technical or organisational measures to protect the data</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @see #getGPSTracker()
	 * @generated
	 */
	EAttribute getGPSTracker_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getGPSTracker()
	 * @generated
	 */
	EAttribute getGPSTracker_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker#getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data that are not needed for the purpose such employee monitoring</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker#getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring()
	 * @see #getGPSTracker()
	 * @generated
	 */
	EAttribute getGPSTracker_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker#getDoes_the_staff_aware_of_the_use_of_the_GPS_systems <em>Does the staff aware of the use of the GPS systems</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does the staff aware of the use of the GPS systems</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker#getDoes_the_staff_aware_of_the_use_of_the_GPS_systems()
	 * @see #getGPSTracker()
	 * @generated
	 */
	EAttribute getGPSTracker_Does_the_staff_aware_of_the_use_of_the_GPS_systems();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.GPSTracker#getDoes_the_system_record_information_other_than_the_purpose <em>Does the system record information other than the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does the system record information other than the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.GPSTracker#getDoes_the_system_record_information_other_than_the_purpose()
	 * @see #getGPSTracker()
	 * @generated
	 */
	EAttribute getGPSTracker_Does_the_system_record_information_other_than_the_purpose();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics <em>Video Analytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Video Analytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoAnalytics
	 * @generated
	 */
	EClass getVideoAnalytics();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getSerial_number <em>Serial number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Serial number</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getSerial_number()
	 * @see #getVideoAnalytics()
	 * @generated
	 */
	EAttribute getVideoAnalytics_Serial_number();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getBlurring <em>Blurring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Blurring</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getBlurring()
	 * @see #getVideoAnalytics()
	 * @generated
	 */
	EReference getVideoAnalytics_Blurring();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getAnalytics <em>Analytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Analytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getAnalytics()
	 * @see #getVideoAnalytics()
	 * @generated
	 */
	EReference getVideoAnalytics_Analytics();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getCustomer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Customer</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getCustomer()
	 * @see #getVideoAnalytics()
	 * @generated
	 */
	EReference getVideoAnalytics_Customer();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getVideoprocessingcloud <em>Videoprocessingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Videoprocessingcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getVideoprocessingcloud()
	 * @see #getVideoAnalytics()
	 * @generated
	 */
	EReference getVideoAnalytics_Videoprocessingcloud();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics <em>Video Without Analytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Video Without Analytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics
	 * @generated
	 */
	EClass getVideoWithoutAnalytics();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getSerial_number <em>Serial number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Serial number</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getSerial_number()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Serial_number();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getDo_people_aware_of_being_recorded <em>Do people aware of being recorded</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Do people aware of being recorded</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getDo_people_aware_of_being_recorded()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Do_people_aware_of_being_recorded();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getRecord_retention_period <em>Record retention period</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Record retention period</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getRecord_retention_period()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Record_retention_period();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getEnsure_data_minimisation_is_aplied <em>Ensure data minimisation is aplied</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ensure data minimisation is aplied</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getEnsure_data_minimisation_is_aplied()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Ensure_data_minimisation_is_aplied();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles <em>Does consent have been gathered from the staff who used these vehicles</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does consent have been gathered from the staff who used these vehicles</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV <em>Does the sign has abrief explanation about the purpose of CCTV</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does the sign has abrief explanation about the purpose of CCTV</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getDoes_the_system_record_information_other_than_the_purpose <em>Does the system record information other than the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does the system record information other than the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getDoes_the_system_record_information_other_than_the_purpose()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Does_the_system_record_information_other_than_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you using appropriate technical or organisational measures to protect the data</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data that are not needed for the purpose such employee monitoring</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getDo_you_use_signs_that_say_CCTV_is_in_operation <em>Do you use signs that say CCTV is in operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Do you use signs that say CCTV is in operation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getDo_you_use_signs_that_say_CCTV_is_in_operation()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Do_you_use_signs_that_say_CCTV_is_in_operation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss or destruction or damage</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Is_data_against_accidental_loss_or_destruction_or_damage();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getDoes_The_dynamic_masking_feature_is_enabled <em>Does The dynamic masking feature is enabled</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does The dynamic masking feature is enabled</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getDoes_The_dynamic_masking_feature_is_enabled()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Does_The_dynamic_masking_feature_is_enabled();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getAre_you_sending_data_without_anonymisation <em>Are you sending data without anonymisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you sending data without anonymisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getAre_you_sending_data_without_anonymisation()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Are_you_sending_data_without_anonymisation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getAre_you_allowing_data_unauthorised_access <em>Are you allowing data unauthorised access</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you allowing data unauthorised access</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getAre_you_allowing_data_unauthorised_access()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Are_you_allowing_data_unauthorised_access();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getAre_you_storing_the_footage_in_a_secure_location <em>Are you storing the footage in asecure location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the footage in asecure location</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getAre_you_storing_the_footage_in_a_secure_location()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EAttribute getVideoWithoutAnalytics_Are_you_storing_the_footage_in_a_secure_location();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getCustomer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Customer</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getCustomer()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EReference getVideoWithoutAnalytics_Customer();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getVideoprocessingcloud <em>Videoprocessingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Videoprocessingcloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getVideoprocessingcloud()
	 * @see #getVideoWithoutAnalytics()
	 * @generated
	 */
	EReference getVideoWithoutAnalytics_Videoprocessingcloud();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Driver <em>Driver</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Driver</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Driver
	 * @generated
	 */
	EClass getDriver();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Driver#getAuthentication <em>Authentication</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Authentication</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Driver#getAuthentication()
	 * @see #getDriver()
	 * @generated
	 */
	EReference getDriver_Authentication();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Driver#getAuthorization <em>Authorization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Authorization</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Driver#getAuthorization()
	 * @see #getDriver()
	 * @generated
	 */
	EReference getDriver_Authorization();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Driver#getAge <em>Age</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Age</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Driver#getAge()
	 * @see #getDriver()
	 * @generated
	 */
	EAttribute getDriver_Age();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Driver#getConsent_checkedlist <em>Consent checkedlist</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Consent checkedlist</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Driver#getConsent_checkedlist()
	 * @see #getDriver()
	 * @generated
	 */
	EReference getDriver_Consent_checkedlist();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Driver#getDo_drivers_aware_of_being_recorded <em>Do drivers aware of being recorded</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Do drivers aware of being recorded</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Driver#getDo_drivers_aware_of_being_recorded()
	 * @see #getDriver()
	 * @generated
	 */
	EAttribute getDriver_Do_drivers_aware_of_being_recorded();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Customer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Customer</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Customer
	 * @generated
	 */
	EClass getCustomer();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Customer#getGeneral_features <em>General features</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>General features</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Customer#getGeneral_features()
	 * @see #getCustomer()
	 * @generated
	 */
	EAttribute getCustomer_General_features();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Customer#getConsent_checkedlist <em>Consent checkedlist</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Consent checkedlist</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Customer#getConsent_checkedlist()
	 * @see #getCustomer()
	 * @generated
	 */
	EReference getCustomer_Consent_checkedlist();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Customer#getDo_people_aware_of_being_recorded <em>Do people aware of being recorded</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Do people aware of being recorded</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Customer#getDo_people_aware_of_being_recorded()
	 * @see #getCustomer()
	 * @generated
	 */
	EAttribute getCustomer_Do_people_aware_of_being_recorded();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Customer#getVideoanalytics <em>Videoanalytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Videoanalytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Customer#getVideoanalytics()
	 * @see #getCustomer()
	 * @generated
	 */
	EReference getCustomer_Videoanalytics();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Customer#getVideowithoutanalytics <em>Videowithoutanalytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Videowithoutanalytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Customer#getVideowithoutanalytics()
	 * @see #getCustomer()
	 * @generated
	 */
	EReference getCustomer_Videowithoutanalytics();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Analytics <em>Analytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Analytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Analytics
	 * @generated
	 */
	EClass getAnalytics();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getRecord_retention_period <em>Record retention period</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Record retention period</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Analytics#getRecord_retention_period()
	 * @see #getAnalytics()
	 * @generated
	 */
	EAttribute getAnalytics_Record_retention_period();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation <em>Does data processing applied on the camera to increase data minimisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does data processing applied on the camera to increase data minimisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation()
	 * @see #getAnalytics()
	 * @generated
	 */
	EAttribute getAnalytics_Does_data_processing_applied_on_the_camera_to_increase_data_minimisation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles <em>Does consent have been gathered from the staff who used these vehicles</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does consent have been gathered from the staff who used these vehicles</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles()
	 * @see #getAnalytics()
	 * @generated
	 */
	EAttribute getAnalytics_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_the_system_record_information_other_than_the_purpose <em>Does the system record information other than the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does the system record information other than the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_the_system_record_information_other_than_the_purpose()
	 * @see #getAnalytics()
	 * @generated
	 */
	EAttribute getAnalytics_Does_the_system_record_information_other_than_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_The_dynamic_masking_feature_is_enabled <em>Does The dynamic masking feature is enabled</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does The dynamic masking feature is enabled</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_The_dynamic_masking_feature_is_enabled()
	 * @see #getAnalytics()
	 * @generated
	 */
	EAttribute getAnalytics_Does_The_dynamic_masking_feature_is_enabled();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data that are not needed for the purpose such employee monitoring</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Analytics#getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring()
	 * @see #getAnalytics()
	 * @generated
	 */
	EAttribute getAnalytics_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDo_you_use_signs_that_say_CCTV_is_in_operation <em>Do you use signs that say CCTV is in operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Do you use signs that say CCTV is in operation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Analytics#getDo_you_use_signs_that_say_CCTV_is_in_operation()
	 * @see #getAnalytics()
	 * @generated
	 */
	EAttribute getAnalytics_Do_you_use_signs_that_say_CCTV_is_in_operation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV <em>Does the sign has abrief explanation about the purpose of CCTV</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does the sign has abrief explanation about the purpose of CCTV</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV()
	 * @see #getAnalytics()
	 * @generated
	 */
	EAttribute getAnalytics_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Analytics#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getAnalytics()
	 * @generated
	 */
	EAttribute getAnalytics_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss or destruction or damage</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Analytics#getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @see #getAnalytics()
	 * @generated
	 */
	EAttribute getAnalytics_Is_data_against_accidental_loss_or_destruction_or_damage();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you using appropriate technical or organisational measures to protect the data</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Analytics#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @see #getAnalytics()
	 * @generated
	 */
	EAttribute getAnalytics_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Blurring <em>Blurring</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Blurring</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Blurring
	 * @generated
	 */
	EClass getBlurring();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Blurring#getDoes_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation <em>Does the face blur feature enabled for individuals to support individual anonymisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does the face blur feature enabled for individuals to support individual anonymisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Blurring#getDoes_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation()
	 * @see #getBlurring()
	 * @generated
	 */
	EAttribute getBlurring_Does_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud <em>Video Processing Cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Video Processing Cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud
	 * @generated
	 */
	EClass getVideoProcessingCloud();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getDataRetention()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EAttribute getVideoProcessingCloud_DataRetention();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getStoragelocation <em>Storagelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Storagelocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getStoragelocation()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EReference getVideoProcessingCloud_Storagelocation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getDatasharing <em>Datasharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Datasharing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getDatasharing()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EReference getVideoProcessingCloud_Datasharing();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getTest_on_dummy <em>Test on dummy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Test on dummy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getTest_on_dummy()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EReference getVideoProcessingCloud_Test_on_dummy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getContainerisation <em>Containerisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Containerisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getContainerisation()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EReference getVideoProcessingCloud_Containerisation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAggregation()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EReference getVideoProcessingCloud_Aggregation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you collecting data that are not needed for the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EAttribute getVideoProcessingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EAttribute getVideoProcessingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you sharing data with other parties without having data subject consent</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EAttribute getVideoProcessingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EAttribute getVideoProcessingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EAttribute getVideoProcessingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EAttribute getVideoProcessingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getGpstracker <em>Gpstracker</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Gpstracker</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getGpstracker()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EReference getVideoProcessingCloud_Gpstracker();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getVideoanalytics <em>Videoanalytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Videoanalytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getVideoanalytics()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EReference getVideoProcessingCloud_Videoanalytics();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getVideowithoutanalytics <em>Videowithoutanalytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Videowithoutanalytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getVideowithoutanalytics()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EReference getVideoProcessingCloud_Videowithoutanalytics();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Website</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getWebsite()
	 * @see #getVideoProcessingCloud()
	 * @generated
	 */
	EReference getVideoProcessingCloud_Website();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Client <em>Client</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Client</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Client
	 * @generated
	 */
	EClass getClient();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Client#getSmartphone <em>Smartphone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Smartphone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Client#getSmartphone()
	 * @see #getClient()
	 * @generated
	 */
	EReference getClient_Smartphone();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Client#getConsent_checkedlist <em>Consent checkedlist</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Consent checkedlist</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Client#getConsent_checkedlist()
	 * @see #getClient()
	 * @generated
	 */
	EReference getClient_Consent_checkedlist();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Client#getPhoneNumber <em>Phone Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Phone Number</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Client#getPhoneNumber()
	 * @see #getClient()
	 * @generated
	 */
	EAttribute getClient_PhoneNumber();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Client#getAuthentication <em>Authentication</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Authentication</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Client#getAuthentication()
	 * @see #getClient()
	 * @generated
	 */
	EReference getClient_Authentication();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Client#getAuthorization <em>Authorization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Authorization</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Client#getAuthorization()
	 * @see #getClient()
	 * @generated
	 */
	EReference getClient_Authorization();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Client#getPhone <em>Phone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Phone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Client#getPhone()
	 * @see #getClient()
	 * @generated
	 */
	EReference getClient_Phone();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.CloudService <em>Cloud Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cloud Service</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService
	 * @generated
	 */
	EClass getCloudService();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getDataRetention()
	 * @see #getCloudService()
	 * @generated
	 */
	EAttribute getCloudService_DataRetention();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getStoragelocation <em>Storagelocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Storagelocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getStoragelocation()
	 * @see #getCloudService()
	 * @generated
	 */
	EReference getCloudService_Storagelocation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getDatasharing <em>Datasharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Datasharing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getDatasharing()
	 * @see #getCloudService()
	 * @generated
	 */
	EReference getCloudService_Datasharing();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getTest_on_dummy <em>Test on dummy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Test on dummy</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getTest_on_dummy()
	 * @see #getCloudService()
	 * @generated
	 */
	EReference getCloudService_Test_on_dummy();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getContainerisation <em>Containerisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Containerisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getContainerisation()
	 * @see #getCloudService()
	 * @generated
	 */
	EReference getCloudService_Containerisation();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getAggregation <em>Aggregation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Aggregation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getAggregation()
	 * @see #getCloudService()
	 * @generated
	 */
	EReference getCloudService_Aggregation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you collecting data that are not needed for the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @see #getCloudService()
	 * @generated
	 */
	EAttribute getCloudService_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getCloudService()
	 * @generated
	 */
	EAttribute getCloudService_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you sharing data with other parties without having data subject consent</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @see #getCloudService()
	 * @generated
	 */
	EAttribute getCloudService_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getCloudService()
	 * @generated
	 */
	EAttribute getCloudService_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @see #getCloudService()
	 * @generated
	 */
	EAttribute getCloudService_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getCloudService()
	 * @generated
	 */
	EAttribute getCloudService_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getGpstracker <em>Gpstracker</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Gpstracker</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getGpstracker()
	 * @see #getCloudService()
	 * @generated
	 */
	EReference getCloudService_Gpstracker();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getVideoanalytics <em>Videoanalytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Videoanalytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getVideoanalytics()
	 * @see #getCloudService()
	 * @generated
	 */
	EReference getCloudService_Videoanalytics();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getVideowithoutanalytics <em>Videowithoutanalytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Videowithoutanalytics</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getVideowithoutanalytics()
	 * @see #getCloudService()
	 * @generated
	 */
	EReference getCloudService_Videowithoutanalytics();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getLightsensor <em>Lightsensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Lightsensor</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getLightsensor()
	 * @see #getCloudService()
	 * @generated
	 */
	EReference getCloudService_Lightsensor();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getPhone <em>Phone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Phone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getPhone()
	 * @see #getCloudService()
	 * @generated
	 */
	EReference getCloudService_Phone();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getCamera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Camera</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getCamera()
	 * @see #getCloudService()
	 * @generated
	 */
	EReference getCloudService_Camera();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getDoorlock <em>Doorlock</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Doorlock</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getDoorlock()
	 * @see #getCloudService()
	 * @generated
	 */
	EReference getCloudService_Doorlock();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.CloudService#getThermostat <em>Thermostat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Thermostat</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudService#getThermostat()
	 * @see #getCloudService()
	 * @generated
	 */
	EReference getCloudService_Thermostat();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.LightSensor <em>Light Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Light Sensor</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.LightSensor
	 * @generated
	 */
	EClass getLightSensor();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getConnection <em>Connection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Connection</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.LightSensor#getConnection()
	 * @see #getLightSensor()
	 * @generated
	 */
	EAttribute getLightSensor_Connection();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.LightSensor#getDataRetention()
	 * @see #getLightSensor()
	 * @generated
	 */
	EAttribute getLightSensor_DataRetention();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.LightSensor#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getLightSensor()
	 * @generated
	 */
	EAttribute getLightSensor_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getCloudservice <em>Cloudservice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloudservice</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.LightSensor#getCloudservice()
	 * @see #getLightSensor()
	 * @generated
	 */
	EReference getLightSensor_Cloudservice();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you using appropriate technical or organisational measures to protect the data</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.LightSensor#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @see #getLightSensor()
	 * @generated
	 */
	EAttribute getLightSensor_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.LightSensor#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss or destruction or damage</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.LightSensor#getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @see #getLightSensor()
	 * @generated
	 */
	EAttribute getLightSensor_Is_data_against_accidental_loss_or_destruction_or_damage();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Phone <em>Phone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Phone</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Phone
	 * @generated
	 */
	EClass getPhone();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Phone#getUser_info_Retention_Period <em>User info Retention Period</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>User info Retention Period</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Phone#getUser_info_Retention_Period()
	 * @see #getPhone()
	 * @generated
	 */
	EAttribute getPhone_User_info_Retention_Period();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Phone#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Phone#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @see #getPhone()
	 * @generated
	 */
	EAttribute getPhone_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_planning_to_send_all_the_data_to_the_cloud <em>Are you planning to send all the data to the cloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you planning to send all the data to the cloud</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_planning_to_send_all_the_data_to_the_cloud()
	 * @see #getPhone()
	 * @generated
	 */
	EAttribute getPhone_Are_you_planning_to_send_all_the_data_to_the_cloud();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you processing data in an incompatible way with the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @see #getPhone()
	 * @generated
	 */
	EAttribute getPhone_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Phone#getConnection <em>Connection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Connection</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Phone#getConnection()
	 * @see #getPhone()
	 * @generated
	 */
	EAttribute getPhone_Connection();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate <em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate()
	 * @see #getPhone()
	 * @generated
	 */
	EAttribute getPhone_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Phone#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getPhone()
	 * @generated
	 */
	EAttribute getPhone_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Phone#getUserlocation <em>Userlocation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Userlocation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Phone#getUserlocation()
	 * @see #getPhone()
	 * @generated
	 */
	EReference getPhone_Userlocation();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Phone#getCloudservice <em>Cloudservice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloudservice</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Phone#getCloudservice()
	 * @see #getPhone()
	 * @generated
	 */
	EReference getPhone_Cloudservice();

	/**
	 * Returns the meta object for the containment reference list '{@link com.cardiffuni.pbdproject.cgm3.Phone#getCookies <em>Cookies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cookies</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Phone#getCookies()
	 * @see #getPhone()
	 * @generated
	 */
	EReference getPhone_Cookies();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.DoorLock <em>Door Lock</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Door Lock</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.DoorLock
	 * @generated
	 */
	EClass getDoorLock();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.DoorLock#getCloudservice <em>Cloudservice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloudservice</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.DoorLock#getCloudservice()
	 * @see #getDoorLock()
	 * @generated
	 */
	EReference getDoorLock_Cloudservice();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.DoorLock#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you using appropriate technical or organisational measures to protect the data</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.DoorLock#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @see #getDoorLock()
	 * @generated
	 */
	EAttribute getDoorLock_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.DoorLock#getConnection <em>Connection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Connection</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.DoorLock#getConnection()
	 * @see #getDoorLock()
	 * @generated
	 */
	EAttribute getDoorLock_Connection();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.DoorLock#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.DoorLock#getDataRetention()
	 * @see #getDoorLock()
	 * @generated
	 */
	EAttribute getDoorLock_DataRetention();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.DoorLock#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.DoorLock#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getDoorLock()
	 * @generated
	 */
	EAttribute getDoorLock_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.DoorLock#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss or destruction or damage</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.DoorLock#getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @see #getDoorLock()
	 * @generated
	 */
	EAttribute getDoorLock_Is_data_against_accidental_loss_or_destruction_or_damage();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Thermostat <em>Thermostat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Thermostat</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Thermostat
	 * @generated
	 */
	EClass getThermostat();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Thermostat#getCloudservice <em>Cloudservice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloudservice</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Thermostat#getCloudservice()
	 * @see #getThermostat()
	 * @generated
	 */
	EReference getThermostat_Cloudservice();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Thermostat#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you using appropriate technical or organisational measures to protect the data</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Thermostat#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @see #getThermostat()
	 * @generated
	 */
	EAttribute getThermostat_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Thermostat#getConnection <em>Connection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Connection</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Thermostat#getConnection()
	 * @see #getThermostat()
	 * @generated
	 */
	EAttribute getThermostat_Connection();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Thermostat#getDataRetention <em>Data Retention</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Data Retention</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Thermostat#getDataRetention()
	 * @see #getThermostat()
	 * @generated
	 */
	EAttribute getThermostat_DataRetention();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Thermostat#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Thermostat#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getThermostat()
	 * @generated
	 */
	EAttribute getThermostat_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Thermostat#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss or destruction or damage</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Thermostat#getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @see #getThermostat()
	 * @generated
	 */
	EAttribute getThermostat_Is_data_against_accidental_loss_or_destruction_or_damage();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Camera <em>Camera</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Camera</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera
	 * @generated
	 */
	EClass getCamera();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_sending_data_without_anonymisation <em>Are you sending data without anonymisation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you sending data without anonymisation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_sending_data_without_anonymisation()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Are_you_sending_data_without_anonymisation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Camera#getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV <em>Does the sign has abrief explanation about the purpose of CCTV</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does the sign has abrief explanation about the purpose of CCTV</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera#getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Camera#getDo_people_aware_of_being_recorded <em>Do people aware of being recorded</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Do people aware of being recorded</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera#getDo_people_aware_of_being_recorded()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Do_people_aware_of_being_recorded();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you using appropriate technical or organisational measures to protect the data</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_storing_the_footage_in_a_secure_location <em>Are you storing the footage in asecure location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the footage in asecure location</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_storing_the_footage_in_a_secure_location()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Are_you_storing_the_footage_in_a_secure_location();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Camera#getEnsure_data_minimisation_is_aplied <em>Ensure data minimisation is aplied</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ensure data minimisation is aplied</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera#getEnsure_data_minimisation_is_aplied()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Ensure_data_minimisation_is_aplied();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Camera#getDo_you_use_signs_that_say_CCTV_is_in_operation <em>Do you use signs that say CCTV is in operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Do you use signs that say CCTV is in operation</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera#getDo_you_use_signs_that_say_CCTV_is_in_operation()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Do_you_use_signs_that_say_CCTV_is_in_operation();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Camera#getDoes_the_system_record_information_other_than_the_purpose <em>Does the system record information other than the purpose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Does the system record information other than the purpose</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera#getDoes_the_system_record_information_other_than_the_purpose()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Does_the_system_record_information_other_than_the_purpose();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Camera#getRecord_retention_period <em>Record retention period</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Record retention period</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera#getRecord_retention_period()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Record_retention_period();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_allowing_data_unauthorised_access <em>Are you allowing data unauthorised access</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you allowing data unauthorised access</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_allowing_data_unauthorised_access()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Are_you_allowing_data_unauthorised_access();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Are you storing the data longer than is necessary for the purposes</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Camera#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is data against accidental loss or destruction or damage</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera#getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @see #getCamera()
	 * @generated
	 */
	EAttribute getCamera_Is_data_against_accidental_loss_or_destruction_or_damage();

	/**
	 * Returns the meta object for the reference '{@link com.cardiffuni.pbdproject.cgm3.Camera#getCloudservice <em>Cloudservice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cloudservice</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Camera#getCloudservice()
	 * @see #getCamera()
	 * @generated
	 */
	EReference getCamera_Cloudservice();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Privacy_patterns <em>Privacy patterns</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Privacy patterns</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Privacy_patterns
	 * @generated
	 */
	EClass getPrivacy_patterns();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Privacy_patterns#getPrivacy_patterns <em>Privacy patterns</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Privacy patterns</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Privacy_patterns#getPrivacy_patterns()
	 * @see #getPrivacy_patterns()
	 * @generated
	 */
	EAttribute getPrivacy_patterns_Privacy_patterns();

	/**
	 * Returns the meta object for class '{@link com.cardiffuni.pbdproject.cgm3.Cookies <em>Cookies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cookies</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cookies
	 * @generated
	 */
	EClass getCookies();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Cookies#getUse_the_surface_cookies_banner_if_cookies_are_placed <em>Use the surface cookies banner if cookies are placed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Use the surface cookies banner if cookies are placed</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cookies#getUse_the_surface_cookies_banner_if_cookies_are_placed()
	 * @see #getCookies()
	 * @generated
	 */
	EAttribute getCookies_Use_the_surface_cookies_banner_if_cookies_are_placed();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Cookies#getThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added <em>The cookie banner must be resurfaced if new cookies are added</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>The cookie banner must be resurfaced if new cookies are added</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cookies#getThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added()
	 * @see #getCookies()
	 * @generated
	 */
	EAttribute getCookies_The_cookie_banner_must_be_resurfaced_if_new_cookies_are_added();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Cookies#getThe_cookie_banner_must_be_resurfaced_if_browser_settings_change <em>The cookie banner must be resurfaced if browser settings change</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>The cookie banner must be resurfaced if browser settings change</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cookies#getThe_cookie_banner_must_be_resurfaced_if_browser_settings_change()
	 * @see #getCookies()
	 * @generated
	 */
	EAttribute getCookies_The_cookie_banner_must_be_resurfaced_if_browser_settings_change();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Cookies#getCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used <em>Capture consent or acceptance if necessary OR Analytics OR Ad targeting cookies are used</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Capture consent or acceptance if necessary OR Analytics OR Ad targeting cookies are used</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cookies#getCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used()
	 * @see #getCookies()
	 * @generated
	 */
	EAttribute getCookies_Capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Cookies#getPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used <em>Place cookies according to consent if necessary OR Analytics OR Ad targeting cookies are used</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Place cookies according to consent if necessary OR Analytics OR Ad targeting cookies are used</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cookies#getPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used()
	 * @see #getCookies()
	 * @generated
	 */
	EAttribute getCookies_Place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used();

	/**
	 * Returns the meta object for the attribute '{@link com.cardiffuni.pbdproject.cgm3.Cookies#getConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc <em>Consider the option of using athird party tool such as One Trus or Trust Arc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Consider the option of using athird party tool such as One Trus or Trust Arc</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Cookies#getConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc()
	 * @see #getCookies()
	 * @generated
	 */
	EAttribute getCookies_Consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc();

	/**
	 * Returns the meta object for enum '{@link com.cardiffuni.pbdproject.cgm3.DataRetentionEnum <em>Data Retention Enum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Data Retention Enum</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @generated
	 */
	EEnum getDataRetentionEnum();

	/**
	 * Returns the meta object for enum '{@link com.cardiffuni.pbdproject.cgm3.PatientHealthStatus <em>Patient Health Status</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Patient Health Status</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.PatientHealthStatus
	 * @generated
	 */
	EEnum getPatientHealthStatus();

	/**
	 * Returns the meta object for enum '{@link com.cardiffuni.pbdproject.cgm3.CommunicationProtocols <em>Communication Protocols</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Communication Protocols</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CommunicationProtocols
	 * @generated
	 */
	EEnum getCommunicationProtocols();

	/**
	 * Returns the meta object for enum '{@link com.cardiffuni.pbdproject.cgm3.Checked_Consent <em>Checked Consent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Checked Consent</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @generated
	 */
	EEnum getChecked_Consent();

	/**
	 * Returns the meta object for enum '{@link com.cardiffuni.pbdproject.cgm3.CloudStorageLocation <em>Cloud Storage Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Cloud Storage Location</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudStorageLocation
	 * @generated
	 */
	EEnum getCloudStorageLocation();

	/**
	 * Returns the meta object for enum '{@link com.cardiffuni.pbdproject.cgm3.LocationGranularity <em>Location Granularity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Location Granularity</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.LocationGranularity
	 * @generated
	 */
	EEnum getLocationGranularity();

	/**
	 * Returns the meta object for enum '{@link com.cardiffuni.pbdproject.cgm3.Checked <em>Checked</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Checked</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @generated
	 */
	EEnum getChecked();

	/**
	 * Returns the meta object for enum '{@link com.cardiffuni.pbdproject.cgm3.CloudProviderServer <em>Cloud Provider Server</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Cloud Provider Server</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudProviderServer
	 * @generated
	 */
	EEnum getCloudProviderServer();

	/**
	 * Returns the meta object for enum '{@link com.cardiffuni.pbdproject.cgm3.TestOnDummyData <em>Test On Dummy Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Test On Dummy Data</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.TestOnDummyData
	 * @generated
	 */
	EEnum getTestOnDummyData();

	/**
	 * Returns the meta object for enum '{@link com.cardiffuni.pbdproject.cgm3.Answer <em>Answer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Answer</em>'.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @generated
	 */
	EEnum getAnswer();

	/**
	 * Returns the meta object for data type '{@link java.lang.Object <em>Consent Data Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Consent Data Type</em>'.
	 * @see java.lang.Object
	 * @model instanceClass="java.lang.Object"
	 * @generated
	 */
	EDataType getConsentDataType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	Cgm3Factory getCgm3Factory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.GeneralEntityImpl <em>General Entity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.GeneralEntityImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getGeneralEntity()
		 * @generated
		 */
		EClass GENERAL_ENTITY = eINSTANCE.getGeneralEntity();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GENERAL_ENTITY__NAME = eINSTANCE.getGeneralEntity_Name();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CGMsensorImpl <em>CG Msensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.CGMsensorImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCGMsensor()
		 * @generated
		 */
		EClass CG_MSENSOR = eINSTANCE.getCGMsensor();

		/**
		 * The meta object literal for the '<em><b>Smartphone</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CG_MSENSOR__SMARTPHONE = eINSTANCE.getCGMsensor_Smartphone();

		/**
		 * The meta object literal for the '<em><b>Glucose amount</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CG_MSENSOR__GLUCOSE_AMOUNT = eINSTANCE.getCGMsensor_Glucose_amount();

		/**
		 * The meta object literal for the '<em><b>Connection</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CG_MSENSOR__CONNECTION = eINSTANCE.getCGMsensor_Connection();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CG_MSENSOR__DATA_RETENTION = eINSTANCE.getCGMsensor_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CG_MSENSOR__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getCGMsensor_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CG_MSENSOR__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getCGMsensor_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.SmartPhoneImpl <em>Smart Phone</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.SmartPhoneImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getSmartPhone()
		 * @generated
		 */
		EClass SMART_PHONE = eINSTANCE.getSmartPhone();

		/**
		 * The meta object literal for the '<em><b>Cgmsensor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SMART_PHONE__CGMSENSOR = eINSTANCE.getSmartPhone_Cgmsensor();

		/**
		 * The meta object literal for the '<em><b>Cloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SMART_PHONE__CLOUD = eINSTANCE.getSmartPhone_Cloud();

		/**
		 * The meta object literal for the '<em><b>Blood Sugar Level</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SMART_PHONE__BLOOD_SUGAR_LEVEL = eINSTANCE.getSmartPhone_Blood_Sugar_Level();

		/**
		 * The meta object literal for the '<em><b>Connection</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SMART_PHONE__CONNECTION = eINSTANCE.getSmartPhone_Connection();

		/**
		 * The meta object literal for the '<em><b>Patient info Retention Period</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SMART_PHONE__PATIENT_INFO_RETENTION_PERIOD = eINSTANCE.getSmartPhone_Patient_info_Retention_Period();

		/**
		 * The meta object literal for the '<em><b>Userlocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SMART_PHONE__USERLOCATION = eINSTANCE.getSmartPhone_Userlocation();

		/**
		 * The meta object literal for the '<em><b>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SMART_PHONE__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE = eINSTANCE
				.getSmartPhone_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate();

		/**
		 * The meta object literal for the '<em><b>Are you planning to send all the data to the cloud</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SMART_PHONE__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD = eINSTANCE
				.getSmartPhone_Are_you_planning_to_send_all_the_data_to_the_cloud();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SMART_PHONE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getSmartPhone_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SMART_PHONE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getSmartPhone_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SMART_PHONE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getSmartPhone_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Smartphone</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SMART_PHONE__SMARTPHONE = eINSTANCE.getSmartPhone_Smartphone();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl <em>Cloud Service</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.CloudServiceImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCloudService()
		 * @generated
		 */
		EClass CLOUD_SERVICE = eINSTANCE.getCloudService();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_SERVICE__DATA_RETENTION = eINSTANCE.getCloudService_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Storagelocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_SERVICE__STORAGELOCATION = eINSTANCE.getCloudService_Storagelocation();

		/**
		 * The meta object literal for the '<em><b>Datasharing</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_SERVICE__DATASHARING = eINSTANCE.getCloudService_Datasharing();

		/**
		 * The meta object literal for the '<em><b>Test on dummy</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_SERVICE__TEST_ON_DUMMY = eINSTANCE.getCloudService_Test_on_dummy();

		/**
		 * The meta object literal for the '<em><b>Containerisation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_SERVICE__CONTAINERISATION = eINSTANCE.getCloudService_Containerisation();

		/**
		 * The meta object literal for the '<em><b>Aggregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_SERVICE__AGGREGATION = eINSTANCE.getCloudService_Aggregation();

		/**
		 * The meta object literal for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_SERVICE__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = eINSTANCE
				.getCloudService_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_SERVICE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getCloudService_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_SERVICE__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = eINSTANCE
				.getCloudService_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_SERVICE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getCloudService_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_SERVICE__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = eINSTANCE
				.getCloudService_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_SERVICE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getCloudService_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Gpstracker</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_SERVICE__GPSTRACKER = eINSTANCE.getCloudService_Gpstracker();

		/**
		 * The meta object literal for the '<em><b>Videoanalytics</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_SERVICE__VIDEOANALYTICS = eINSTANCE.getCloudService_Videoanalytics();

		/**
		 * The meta object literal for the '<em><b>Videowithoutanalytics</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_SERVICE__VIDEOWITHOUTANALYTICS = eINSTANCE.getCloudService_Videowithoutanalytics();

		/**
		 * The meta object literal for the '<em><b>Lightsensor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_SERVICE__LIGHTSENSOR = eINSTANCE.getCloudService_Lightsensor();

		/**
		 * The meta object literal for the '<em><b>Phone</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_SERVICE__PHONE = eINSTANCE.getCloudService_Phone();

		/**
		 * The meta object literal for the '<em><b>Camera</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_SERVICE__CAMERA = eINSTANCE.getCloudService_Camera();

		/**
		 * The meta object literal for the '<em><b>Doorlock</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_SERVICE__DOORLOCK = eINSTANCE.getCloudService_Doorlock();

		/**
		 * The meta object literal for the '<em><b>Thermostat</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_SERVICE__THERMOSTAT = eINSTANCE.getCloudService_Thermostat();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.LightSensorImpl <em>Light Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.LightSensorImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getLightSensor()
		 * @generated
		 */
		EClass LIGHT_SENSOR = eINSTANCE.getLightSensor();

		/**
		 * The meta object literal for the '<em><b>Connection</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIGHT_SENSOR__CONNECTION = eINSTANCE.getLightSensor_Connection();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIGHT_SENSOR__DATA_RETENTION = eINSTANCE.getLightSensor_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIGHT_SENSOR__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getLightSensor_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Cloudservice</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LIGHT_SENSOR__CLOUDSERVICE = eINSTANCE.getLightSensor_Cloudservice();

		/**
		 * The meta object literal for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIGHT_SENSOR__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = eINSTANCE
				.getLightSensor_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LIGHT_SENSOR__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = eINSTANCE
				.getLightSensor_Is_data_against_accidental_loss_or_destruction_or_damage();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl <em>Phone</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.PhoneImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getPhone()
		 * @generated
		 */
		EClass PHONE = eINSTANCE.getPhone();

		/**
		 * The meta object literal for the '<em><b>User info Retention Period</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHONE__USER_INFO_RETENTION_PERIOD = eINSTANCE.getPhone_User_info_Retention_Period();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHONE__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getPhone_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Are you planning to send all the data to the cloud</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHONE__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD = eINSTANCE
				.getPhone_Are_you_planning_to_send_all_the_data_to_the_cloud();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHONE__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getPhone_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Connection</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHONE__CONNECTION = eINSTANCE.getPhone_Connection();

		/**
		 * The meta object literal for the '<em><b>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHONE__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE = eINSTANCE
				.getPhone_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHONE__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getPhone_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Userlocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHONE__USERLOCATION = eINSTANCE.getPhone_Userlocation();

		/**
		 * The meta object literal for the '<em><b>Cloudservice</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHONE__CLOUDSERVICE = eINSTANCE.getPhone_Cloudservice();

		/**
		 * The meta object literal for the '<em><b>Cookies</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHONE__COOKIES = eINSTANCE.getPhone_Cookies();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.DoorLockImpl <em>Door Lock</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.DoorLockImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getDoorLock()
		 * @generated
		 */
		EClass DOOR_LOCK = eINSTANCE.getDoorLock();

		/**
		 * The meta object literal for the '<em><b>Cloudservice</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOOR_LOCK__CLOUDSERVICE = eINSTANCE.getDoorLock_Cloudservice();

		/**
		 * The meta object literal for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOOR_LOCK__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = eINSTANCE
				.getDoorLock_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

		/**
		 * The meta object literal for the '<em><b>Connection</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOOR_LOCK__CONNECTION = eINSTANCE.getDoorLock_Connection();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOOR_LOCK__DATA_RETENTION = eINSTANCE.getDoorLock_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOOR_LOCK__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getDoorLock_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOOR_LOCK__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = eINSTANCE
				.getDoorLock_Is_data_against_accidental_loss_or_destruction_or_damage();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.ThermostatImpl <em>Thermostat</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.ThermostatImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getThermostat()
		 * @generated
		 */
		EClass THERMOSTAT = eINSTANCE.getThermostat();

		/**
		 * The meta object literal for the '<em><b>Cloudservice</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THERMOSTAT__CLOUDSERVICE = eINSTANCE.getThermostat_Cloudservice();

		/**
		 * The meta object literal for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute THERMOSTAT__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = eINSTANCE
				.getThermostat_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

		/**
		 * The meta object literal for the '<em><b>Connection</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute THERMOSTAT__CONNECTION = eINSTANCE.getThermostat_Connection();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute THERMOSTAT__DATA_RETENTION = eINSTANCE.getThermostat_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute THERMOSTAT__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getThermostat_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute THERMOSTAT__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = eINSTANCE
				.getThermostat_Is_data_against_accidental_loss_or_destruction_or_damage();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CameraImpl <em>Camera</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.CameraImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCamera()
		 * @generated
		 */
		EClass CAMERA = eINSTANCE.getCamera();

		/**
		 * The meta object literal for the '<em><b>Are you sending data without anonymisation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION = eINSTANCE
				.getCamera_Are_you_sending_data_without_anonymisation();

		/**
		 * The meta object literal for the '<em><b>Does the sign has abrief explanation about the purpose of CCTV</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV = eINSTANCE
				.getCamera_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV();

		/**
		 * The meta object literal for the '<em><b>Do people aware of being recorded</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__DO_PEOPLE_AWARE_OF_BEING_RECORDED = eINSTANCE.getCamera_Do_people_aware_of_being_recorded();

		/**
		 * The meta object literal for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = eINSTANCE
				.getCamera_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

		/**
		 * The meta object literal for the '<em><b>Are you storing the footage in asecure location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION = eINSTANCE
				.getCamera_Are_you_storing_the_footage_in_a_secure_location();

		/**
		 * The meta object literal for the '<em><b>Ensure data minimisation is aplied</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__ENSURE_DATA_MINIMISATION_IS_APLIED = eINSTANCE
				.getCamera_Ensure_data_minimisation_is_aplied();

		/**
		 * The meta object literal for the '<em><b>Do you use signs that say CCTV is in operation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION = eINSTANCE
				.getCamera_Do_you_use_signs_that_say_CCTV_is_in_operation();

		/**
		 * The meta object literal for the '<em><b>Does the system record information other than the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE = eINSTANCE
				.getCamera_Does_the_system_record_information_other_than_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Record retention period</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__RECORD_RETENTION_PERIOD = eINSTANCE.getCamera_Record_retention_period();

		/**
		 * The meta object literal for the '<em><b>Are you allowing data unauthorised access</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS = eINSTANCE
				.getCamera_Are_you_allowing_data_unauthorised_access();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getCamera_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAMERA__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = eINSTANCE
				.getCamera_Is_data_against_accidental_loss_or_destruction_or_damage();

		/**
		 * The meta object literal for the '<em><b>Cloudservice</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CAMERA__CLOUDSERVICE = eINSTANCE.getCamera_Cloudservice();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.Privacy_patternsImpl <em>Privacy patterns</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Privacy_patternsImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getPrivacy_patterns()
		 * @generated
		 */
		EClass PRIVACY_PATTERNS = eINSTANCE.getPrivacy_patterns();

		/**
		 * The meta object literal for the '<em><b>Privacy patterns</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PRIVACY_PATTERNS__PRIVACY_PATTERNS = eINSTANCE.getPrivacy_patterns_Privacy_patterns();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CookiesImpl <em>Cookies</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.CookiesImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCookies()
		 * @generated
		 */
		EClass COOKIES = eINSTANCE.getCookies();

		/**
		 * The meta object literal for the '<em><b>Use the surface cookies banner if cookies are placed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COOKIES__USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED = eINSTANCE
				.getCookies_Use_the_surface_cookies_banner_if_cookies_are_placed();

		/**
		 * The meta object literal for the '<em><b>The cookie banner must be resurfaced if new cookies are added</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED = eINSTANCE
				.getCookies_The_cookie_banner_must_be_resurfaced_if_new_cookies_are_added();

		/**
		 * The meta object literal for the '<em><b>The cookie banner must be resurfaced if browser settings change</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE = eINSTANCE
				.getCookies_The_cookie_banner_must_be_resurfaced_if_browser_settings_change();

		/**
		 * The meta object literal for the '<em><b>Capture consent or acceptance if necessary OR Analytics OR Ad targeting cookies are used</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COOKIES__CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED = eINSTANCE
				.getCookies_Capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used();

		/**
		 * The meta object literal for the '<em><b>Place cookies according to consent if necessary OR Analytics OR Ad targeting cookies are used</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COOKIES__PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED = eINSTANCE
				.getCookies_Place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used();

		/**
		 * The meta object literal for the '<em><b>Consider the option of using athird party tool such as One Trus or Trust Arc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COOKIES__CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC = eINSTANCE
				.getCookies_Consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc();

		/**
		 * The meta object literal for the '<em><b>Pharmacycloud</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SMART_PHONE__PHARMACYCLOUD = eINSTANCE.getSmartPhone_Pharmacycloud();

		/**
		 * The meta object literal for the '<em><b>Cloudforpharmacy</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SMART_PHONE__CLOUDFORPHARMACY = eINSTANCE.getSmartPhone_Cloudforpharmacy();

		/**
		 * The meta object literal for the '<em><b>Cookies</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SMART_PHONE__COOKIES = eINSTANCE.getSmartPhone_Cookies();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.PatientImpl <em>Patient</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.PatientImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getPatient()
		 * @generated
		 */
		EClass PATIENT = eINSTANCE.getPatient();

		/**
		 * The meta object literal for the '<em><b>Smartphone</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENT__SMARTPHONE = eINSTANCE.getPatient_Smartphone();

		/**
		 * The meta object literal for the '<em><b>Cgmsensor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENT__CGMSENSOR = eINSTANCE.getPatient_Cgmsensor();

		/**
		 * The meta object literal for the '<em><b>Doctor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENT__DOCTOR = eINSTANCE.getPatient_Doctor();

		/**
		 * The meta object literal for the '<em><b>Medicalrecord</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENT__MEDICALRECORD = eINSTANCE.getPatient_Medicalrecord();

		/**
		 * The meta object literal for the '<em><b>Age</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PATIENT__AGE = eINSTANCE.getPatient_Age();

		/**
		 * The meta object literal for the '<em><b>Consent checkedlist</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENT__CONSENT_CHECKEDLIST = eINSTANCE.getPatient_Consent_checkedlist();

		/**
		 * The meta object literal for the '<em><b>Phone Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PATIENT__PHONE_NUMBER = eINSTANCE.getPatient_PhoneNumber();

		/**
		 * The meta object literal for the '<em><b>Authentication</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENT__AUTHENTICATION = eINSTANCE.getPatient_Authentication();

		/**
		 * The meta object literal for the '<em><b>Authorization</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENT__AUTHORIZATION = eINSTANCE.getPatient_Authorization();

		/**
		 * The meta object literal for the '<em><b>Datasharing</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENT__DATASHARING = eINSTANCE.getPatient_Datasharing();

		/**
		 * The meta object literal for the '<em><b>Computerbrowser</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENT__COMPUTERBROWSER = eINSTANCE.getPatient_Computerbrowser();

		/**
		 * The meta object literal for the '<em><b>Webbrowser</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PATIENT__WEBBROWSER = eINSTANCE.getPatient_Webbrowser();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.NurseImpl <em>Nurse</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.NurseImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getNurse()
		 * @generated
		 */
		EClass NURSE = eINSTANCE.getNurse();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.DoctorImpl <em>Doctor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.DoctorImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getDoctor()
		 * @generated
		 */
		EClass DOCTOR = eINSTANCE.getDoctor();

		/**
		 * The meta object literal for the '<em><b>Patient</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCTOR__PATIENT = eINSTANCE.getDoctor_Patient();

		/**
		 * The meta object literal for the '<em><b>Website</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCTOR__WEBSITE = eINSTANCE.getDoctor_Website();

		/**
		 * The meta object literal for the '<em><b>Specialty</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCTOR__SPECIALTY = eINSTANCE.getDoctor_Specialty();

		/**
		 * The meta object literal for the '<em><b>Authentication</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCTOR__AUTHENTICATION = eINSTANCE.getDoctor_Authentication();

		/**
		 * The meta object literal for the '<em><b>Authorization</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOCTOR__AUTHORIZATION = eINSTANCE.getDoctor_Authorization();

		/**
		 * The meta object literal for the '<em><b>Are you allowing unauthorised doctors to access or process the data subject health data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DOCTOR__ARE_YOU_ALLOWING_UNAUTHORISED_DOCTORS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_HEALTH_DATA = eINSTANCE
				.getDoctor_Are_you_allowing_unauthorised_doctors_to_access_or_process_the_data_subject_health_data();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.NewEClass7Impl <em>New EClass7</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.NewEClass7Impl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getNewEClass7()
		 * @generated
		 */
		EClass NEW_ECLASS7 = eINSTANCE.getNewEClass7();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CloudImpl <em>Cloud</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.CloudImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCloud()
		 * @generated
		 */
		EClass CLOUD = eINSTANCE.getCloud();

		/**
		 * The meta object literal for the '<em><b>Smartphone</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD__SMARTPHONE = eINSTANCE.getCloud_Smartphone();

		/**
		 * The meta object literal for the '<em><b>Website</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD__WEBSITE = eINSTANCE.getCloud_Website();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD__DATA_RETENTION = eINSTANCE.getCloud_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Storagelocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD__STORAGELOCATION = eINSTANCE.getCloud_Storagelocation();

		/**
		 * The meta object literal for the '<em><b>Datasharing</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD__DATASHARING = eINSTANCE.getCloud_Datasharing();

		/**
		 * The meta object literal for the '<em><b>Test on dummy</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD__TEST_ON_DUMMY = eINSTANCE.getCloud_Test_on_dummy();

		/**
		 * The meta object literal for the '<em><b>Containerisation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD__CONTAINERISATION = eINSTANCE.getCloud_Containerisation();

		/**
		 * The meta object literal for the '<em><b>Aggregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD__AGGREGATION = eINSTANCE.getCloud_Aggregation();

		/**
		 * The meta object literal for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = eINSTANCE
				.getCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = eINSTANCE
				.getCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = eINSTANCE
				.getCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Medicalrecord</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD__MEDICALRECORD = eINSTANCE.getCloud_Medicalrecord();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.WebsiteImpl <em>Website</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.WebsiteImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getWebsite()
		 * @generated
		 */
		EClass WEBSITE = eINSTANCE.getWebsite();

		/**
		 * The meta object literal for the '<em><b>Cloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBSITE__CLOUD = eINSTANCE.getWebsite_Cloud();

		/**
		 * The meta object literal for the '<em><b>Doctor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBSITE__DOCTOR = eINSTANCE.getWebsite_Doctor();

		/**
		 * The meta object literal for the '<em><b>Researcher</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBSITE__RESEARCHER = eINSTANCE.getWebsite_Researcher();

		/**
		 * The meta object literal for the '<em><b>URL</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEBSITE__URL = eINSTANCE.getWebsite_URL();

		/**
		 * The meta object literal for the '<em><b>Videoprocessingcloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBSITE__VIDEOPROCESSINGCLOUD = eINSTANCE.getWebsite_Videoprocessingcloud();

		/**
		 * The meta object literal for the '<em><b>Cookies</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBSITE__COOKIES = eINSTANCE.getWebsite_Cookies();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl <em>Hospital</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.HospitalImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getHospital()
		 * @generated
		 */
		EClass HOSPITAL = eINSTANCE.getHospital();

		/**
		 * The meta object literal for the '<em><b>Patient</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__PATIENT = eINSTANCE.getHospital_Patient();

		/**
		 * The meta object literal for the '<em><b>Doctor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__DOCTOR = eINSTANCE.getHospital_Doctor();

		/**
		 * The meta object literal for the '<em><b>Researcher</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__RESEARCHER = eINSTANCE.getHospital_Researcher();

		/**
		 * The meta object literal for the '<em><b>Nurse</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__NURSE = eINSTANCE.getHospital_Nurse();

		/**
		 * The meta object literal for the '<em><b>Cloud</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__CLOUD = eINSTANCE.getHospital_Cloud();

		/**
		 * The meta object literal for the '<em><b>Website</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__WEBSITE = eINSTANCE.getHospital_Website();

		/**
		 * The meta object literal for the '<em><b>Smartphone</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__SMARTPHONE = eINSTANCE.getHospital_Smartphone();

		/**
		 * The meta object literal for the '<em><b>Cgmsensor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__CGMSENSOR = eINSTANCE.getHospital_Cgmsensor();

		/**
		 * The meta object literal for the '<em><b>Medicalrecord</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__MEDICALRECORD = eINSTANCE.getHospital_Medicalrecord();

		/**
		 * The meta object literal for the '<em><b>Consent checkedlist</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__CONSENT_CHECKEDLIST = eINSTANCE.getHospital_Consent_checkedlist();

		/**
		 * The meta object literal for the '<em><b>Storagelocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__STORAGELOCATION = eINSTANCE.getHospital_Storagelocation();

		/**
		 * The meta object literal for the '<em><b>Userlocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__USERLOCATION = eINSTANCE.getHospital_Userlocation();

		/**
		 * The meta object literal for the '<em><b>Riskcode</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__RISKCODE = eINSTANCE.getHospital_Riskcode();

		/**
		 * The meta object literal for the '<em><b>Encryption</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__ENCRYPTION = eINSTANCE.getHospital_Encryption();

		/**
		 * The meta object literal for the '<em><b>Datasharing</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__DATASHARING = eINSTANCE.getHospital_Datasharing();

		/**
		 * The meta object literal for the '<em><b>Warning</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__WARNING = eINSTANCE.getHospital_Warning();

		/**
		 * The meta object literal for the '<em><b>Test on dummy</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__TEST_ON_DUMMY = eINSTANCE.getHospital_Test_on_dummy();

		/**
		 * The meta object literal for the '<em><b>Containerisation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__CONTAINERISATION = eINSTANCE.getHospital_Containerisation();

		/**
		 * The meta object literal for the '<em><b>Aggregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__AGGREGATION = eINSTANCE.getHospital_Aggregation();

		/**
		 * The meta object literal for the '<em><b>Computerbrowser</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__COMPUTERBROWSER = eINSTANCE.getHospital_Computerbrowser();

		/**
		 * The meta object literal for the '<em><b>Pharmacycloud</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__PHARMACYCLOUD = eINSTANCE.getHospital_Pharmacycloud();

		/**
		 * The meta object literal for the '<em><b>Shippingcloud</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__SHIPPINGCLOUD = eINSTANCE.getHospital_Shippingcloud();

		/**
		 * The meta object literal for the '<em><b>Webhostingcloud</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__WEBHOSTINGCLOUD = eINSTANCE.getHospital_Webhostingcloud();

		/**
		 * The meta object literal for the '<em><b>Paymentcloud</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__PAYMENTCLOUD = eINSTANCE.getHospital_Paymentcloud();

		/**
		 * The meta object literal for the '<em><b>Socialnetworkcloud</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__SOCIALNETWORKCLOUD = eINSTANCE.getHospital_Socialnetworkcloud();

		/**
		 * The meta object literal for the '<em><b>Webbrowser</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__WEBBROWSER = eINSTANCE.getHospital_Webbrowser();

		/**
		 * The meta object literal for the '<em><b>Cloudforpharmacy</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__CLOUDFORPHARMACY = eINSTANCE.getHospital_Cloudforpharmacy();

		/**
		 * The meta object literal for the '<em><b>Realtimebiddingcloud</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__REALTIMEBIDDINGCLOUD = eINSTANCE.getHospital_Realtimebiddingcloud();

		/**
		 * The meta object literal for the '<em><b>Gpstracker</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__GPSTRACKER = eINSTANCE.getHospital_Gpstracker();

		/**
		 * The meta object literal for the '<em><b>Bus</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__BUS = eINSTANCE.getHospital_Bus();

		/**
		 * The meta object literal for the '<em><b>Driver</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__DRIVER = eINSTANCE.getHospital_Driver();

		/**
		 * The meta object literal for the '<em><b>Customer</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__CUSTOMER = eINSTANCE.getHospital_Customer();

		/**
		 * The meta object literal for the '<em><b>Videoanalytics</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__VIDEOANALYTICS = eINSTANCE.getHospital_Videoanalytics();

		/**
		 * The meta object literal for the '<em><b>Analytics</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__ANALYTICS = eINSTANCE.getHospital_Analytics();

		/**
		 * The meta object literal for the '<em><b>Blurring</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__BLURRING = eINSTANCE.getHospital_Blurring();

		/**
		 * The meta object literal for the '<em><b>Videoprocessingcloud</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__VIDEOPROCESSINGCLOUD = eINSTANCE.getHospital_Videoprocessingcloud();

		/**
		 * The meta object literal for the '<em><b>Videowithoutanalytics</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__VIDEOWITHOUTANALYTICS = eINSTANCE.getHospital_Videowithoutanalytics();

		/**
		 * The meta object literal for the '<em><b>Client</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__CLIENT = eINSTANCE.getHospital_Client();

		/**
		 * The meta object literal for the '<em><b>Cloudservice</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__CLOUDSERVICE = eINSTANCE.getHospital_Cloudservice();

		/**
		 * The meta object literal for the '<em><b>Lightsensor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__LIGHTSENSOR = eINSTANCE.getHospital_Lightsensor();

		/**
		 * The meta object literal for the '<em><b>Phone</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__PHONE = eINSTANCE.getHospital_Phone();

		/**
		 * The meta object literal for the '<em><b>Thermostat</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__THERMOSTAT = eINSTANCE.getHospital_Thermostat();

		/**
		 * The meta object literal for the '<em><b>Doorlock</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__DOORLOCK = eINSTANCE.getHospital_Doorlock();

		/**
		 * The meta object literal for the '<em><b>Camera</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__CAMERA = eINSTANCE.getHospital_Camera();

		/**
		 * The meta object literal for the '<em><b>Cookies</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOSPITAL__COOKIES = eINSTANCE.getHospital_Cookies();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.ResearcherImpl <em>Researcher</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.ResearcherImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getResearcher()
		 * @generated
		 */
		EClass RESEARCHER = eINSTANCE.getResearcher();

		/**
		 * The meta object literal for the '<em><b>Website</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RESEARCHER__WEBSITE = eINSTANCE.getResearcher_Website();

		/**
		 * The meta object literal for the '<em><b>Authentication</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RESEARCHER__AUTHENTICATION = eINSTANCE.getResearcher_Authentication();

		/**
		 * The meta object literal for the '<em><b>Authorization</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RESEARCHER__AUTHORIZATION = eINSTANCE.getResearcher_Authorization();

		/**
		 * The meta object literal for the '<em><b>Are you allowing researchers to access or process the data subject medical data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RESEARCHER__ARE_YOU_ALLOWING_RESEARCHERS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_MEDICAL_DATA = eINSTANCE
				.getResearcher_Are_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data();

		/**
		 * The meta object literal for the '<em><b>Are you allowing unauthorised researchers to access or process the data subject personal data such as name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RESEARCHER__ARE_YOU_ALLOWING_UNAUTHORISED_RESEARCHERS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_PERSONAL_DATA_SUCH_AS_NAME = eINSTANCE
				.getResearcher_Are_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.MedicalRecordImpl <em>Medical Record</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.MedicalRecordImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getMedicalRecord()
		 * @generated
		 */
		EClass MEDICAL_RECORD = eINSTANCE.getMedicalRecord();

		/**
		 * The meta object literal for the '<em><b>Record Retention Period</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MEDICAL_RECORD__RECORD_RETENTION_PERIOD = eINSTANCE.getMedicalRecord_RecordRetentionPeriod();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.Consent_CheckedListImpl <em>Consent Checked List</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Consent_CheckedListImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getConsent_CheckedList()
		 * @generated
		 */
		EClass CONSENT_CHECKED_LIST = eINSTANCE.getConsent_CheckedList();

		/**
		 * The meta object literal for the '<em><b>Capture age authorization if age is less than 16</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONSENT_CHECKED_LIST__CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16 = eINSTANCE
				.getConsent_CheckedList_Capture_age_authorization_if_age_is_less_than_16();

		/**
		 * The meta object literal for the '<em><b>Capture withdrawal log</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONSENT_CHECKED_LIST__CAPTURE_WITHDRAWAL_LOG = eINSTANCE
				.getConsent_CheckedList_Capture_withdrawal_log();

		/**
		 * The meta object literal for the '<em><b>Capture log Terms of use AND consent to process</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONSENT_CHECKED_LIST__CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS = eINSTANCE
				.getConsent_CheckedList_Capture_log_Terms_of_use_AND_consent_to_process();

		/**
		 * The meta object literal for the '<em><b>Capture consent to process special category data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA = eINSTANCE
				.getConsent_CheckedList_Capture_consent_to_process_special_category_data();

		/**
		 * The meta object literal for the '<em><b>Capture consent to term of use</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_TERM_OF_USE = eINSTANCE
				.getConsent_CheckedList_Capture_consent_to_term_of_use();

		/**
		 * The meta object literal for the '<em><b>Surface privacy notice</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONSENT_CHECKED_LIST__SURFACE_PRIVACY_NOTICE = eINSTANCE
				.getConsent_CheckedList_Surface_privacy_notice();

		/**
		 * The meta object literal for the '<em><b>Capture consent to the type of marketing if electronic marketing is used</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED = eINSTANCE
				.getConsent_CheckedList_Capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.StorageLocationImpl <em>Storage Location</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.StorageLocationImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getStorageLocation()
		 * @generated
		 */
		EClass STORAGE_LOCATION = eINSTANCE.getStorageLocation();

		/**
		 * The meta object literal for the '<em><b>Cloud provider and server location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STORAGE_LOCATION__CLOUD_PROVIDER_AND_SERVER_LOCATION = eINSTANCE
				.getStorageLocation_Cloud_provider_and_server_location();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.UserLocationImpl <em>User Location</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.UserLocationImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getUserLocation()
		 * @generated
		 */
		EClass USER_LOCATION = eINSTANCE.getUserLocation();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USER_LOCATION__LOCATION = eINSTANCE.getUserLocation_Location();

		/**
		 * The meta object literal for the '<em><b>Are you planning to collect the exact location of the data subject when the location is not needed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USER_LOCATION__ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED = eINSTANCE
				.getUserLocation_Are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.RiskCodeImpl <em>Risk Code</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.RiskCodeImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getRiskCode()
		 * @generated
		 */
		EClass RISK_CODE = eINSTANCE.getRiskCode();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.AuthenticationImpl <em>Authentication</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.AuthenticationImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getAuthentication()
		 * @generated
		 */
		EClass AUTHENTICATION = eINSTANCE.getAuthentication();

		/**
		 * The meta object literal for the '<em><b>Authenticated</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUTHENTICATION__AUTHENTICATED = eINSTANCE.getAuthentication_Authenticated();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.AuthorizationImpl <em>Authorization</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.AuthorizationImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getAuthorization()
		 * @generated
		 */
		EClass AUTHORIZATION = eINSTANCE.getAuthorization();

		/**
		 * The meta object literal for the '<em><b>Authorized</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AUTHORIZATION__AUTHORIZED = eINSTANCE.getAuthorization_Authorized();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.FirewallImpl <em>Firewall</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.FirewallImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getFirewall()
		 * @generated
		 */
		EClass FIREWALL = eINSTANCE.getFirewall();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.EncryptionImpl <em>Encryption</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.EncryptionImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getEncryption()
		 * @generated
		 */
		EClass ENCRYPTION = eINSTANCE.getEncryption();

		/**
		 * The meta object literal for the '<em><b>Encrypted Data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENCRYPTION__ENCRYPTED_DATA = eINSTANCE.getEncryption_EncryptedData();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.DataSharingImpl <em>Data Sharing</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.DataSharingImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getDataSharing()
		 * @generated
		 */
		EClass DATA_SHARING = eINSTANCE.getDataSharing();

		/**
		 * The meta object literal for the '<em><b>Apply anonymisation for researcher</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATA_SHARING__APPLY_ANONYMISATION_FOR_RESEARCHER = eINSTANCE
				.getDataSharing_Apply_anonymisation_for_researcher();

		/**
		 * The meta object literal for the '<em><b>Ensure access Control</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATA_SHARING__ENSURE_ACCESS_CONTROL = eINSTANCE.getDataSharing_Ensure_accessControl();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.WarningImpl <em>Warning</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.WarningImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getWarning()
		 * @generated
		 */
		EClass WARNING = eINSTANCE.getWarning();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.Test_on_dummyImpl <em>Test on dummy</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Test_on_dummyImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getTest_on_dummy()
		 * @generated
		 */
		EClass TEST_ON_DUMMY = eINSTANCE.getTest_on_dummy();

		/**
		 * The meta object literal for the '<em><b>Testing on dummy data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TEST_ON_DUMMY__TESTING_ON_DUMMY_DATA = eINSTANCE.getTest_on_dummy_Testing_on_dummy_data();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.ContainerisationImpl <em>Containerisation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.ContainerisationImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getContainerisation()
		 * @generated
		 */
		EClass CONTAINERISATION = eINSTANCE.getContainerisation();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.AggregationImpl <em>Aggregation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.AggregationImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getAggregation()
		 * @generated
		 */
		EClass AGGREGATION = eINSTANCE.getAggregation();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.NewEClass26Impl <em>New EClass26</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.NewEClass26Impl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getNewEClass26()
		 * @generated
		 */
		EClass NEW_ECLASS26 = eINSTANCE.getNewEClass26();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl <em>Computer Browser</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.ComputerBrowserImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getComputerBrowser()
		 * @generated
		 */
		EClass COMPUTER_BROWSER = eINSTANCE.getComputerBrowser();

		/**
		 * The meta object literal for the '<em><b>Cgmsensor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPUTER_BROWSER__CGMSENSOR = eINSTANCE.getComputerBrowser_Cgmsensor();

		/**
		 * The meta object literal for the '<em><b>Cloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPUTER_BROWSER__CLOUD = eINSTANCE.getComputerBrowser_Cloud();

		/**
		 * The meta object literal for the '<em><b>Patient info Retention Period</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPUTER_BROWSER__PATIENT_INFO_RETENTION_PERIOD = eINSTANCE
				.getComputerBrowser_Patient_info_Retention_Period();

		/**
		 * The meta object literal for the '<em><b>Userlocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPUTER_BROWSER__USERLOCATION = eINSTANCE.getComputerBrowser_Userlocation();

		/**
		 * The meta object literal for the '<em><b>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE = eINSTANCE
				.getComputerBrowser_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate();

		/**
		 * The meta object literal for the '<em><b>Are you planning to send all the data to the cloud</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPUTER_BROWSER__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD = eINSTANCE
				.getComputerBrowser_Are_you_planning_to_send_all_the_data_to_the_cloud();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPUTER_BROWSER__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getComputerBrowser_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPUTER_BROWSER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getComputerBrowser_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPUTER_BROWSER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getComputerBrowser_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Pharmacycloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPUTER_BROWSER__PHARMACYCLOUD = eINSTANCE.getComputerBrowser_Pharmacycloud();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.NewEClass28Impl <em>New EClass28</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.NewEClass28Impl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getNewEClass28()
		 * @generated
		 */
		EClass NEW_ECLASS28 = eINSTANCE.getNewEClass28();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.PharmacyCloudoldImpl <em>Pharmacy Cloudold</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.PharmacyCloudoldImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getPharmacyCloudold()
		 * @generated
		 */
		EClass PHARMACY_CLOUDOLD = eINSTANCE.getPharmacyCloudold();

		/**
		 * The meta object literal for the '<em><b>Smartphone</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHARMACY_CLOUDOLD__SMARTPHONE = eINSTANCE.getPharmacyCloudold_Smartphone();

		/**
		 * The meta object literal for the '<em><b>Website</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHARMACY_CLOUDOLD__WEBSITE = eINSTANCE.getPharmacyCloudold_Website();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHARMACY_CLOUDOLD__DATA_RETENTION = eINSTANCE.getPharmacyCloudold_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Storagelocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHARMACY_CLOUDOLD__STORAGELOCATION = eINSTANCE.getPharmacyCloudold_Storagelocation();

		/**
		 * The meta object literal for the '<em><b>Datasharing</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHARMACY_CLOUDOLD__DATASHARING = eINSTANCE.getPharmacyCloudold_Datasharing();

		/**
		 * The meta object literal for the '<em><b>Test on dummy</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHARMACY_CLOUDOLD__TEST_ON_DUMMY = eINSTANCE.getPharmacyCloudold_Test_on_dummy();

		/**
		 * The meta object literal for the '<em><b>Containerisation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHARMACY_CLOUDOLD__CONTAINERISATION = eINSTANCE.getPharmacyCloudold_Containerisation();

		/**
		 * The meta object literal for the '<em><b>Aggregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHARMACY_CLOUDOLD__AGGREGATION = eINSTANCE.getPharmacyCloudold_Aggregation();

		/**
		 * The meta object literal for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHARMACY_CLOUDOLD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = eINSTANCE
				.getPharmacyCloudold_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHARMACY_CLOUDOLD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getPharmacyCloudold_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHARMACY_CLOUDOLD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = eINSTANCE
				.getPharmacyCloudold_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHARMACY_CLOUDOLD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getPharmacyCloudold_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHARMACY_CLOUDOLD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = eINSTANCE
				.getPharmacyCloudold_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PHARMACY_CLOUDOLD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getPharmacyCloudold_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Computerbrowser</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PHARMACY_CLOUDOLD__COMPUTERBROWSER = eINSTANCE.getPharmacyCloudold_Computerbrowser();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl <em>Shipping Cloud</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.ShippingCloudImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getShippingCloud()
		 * @generated
		 */
		EClass SHIPPING_CLOUD = eINSTANCE.getShippingCloud();

		/**
		 * The meta object literal for the '<em><b>Smartphone</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHIPPING_CLOUD__SMARTPHONE = eINSTANCE.getShippingCloud_Smartphone();

		/**
		 * The meta object literal for the '<em><b>Website</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHIPPING_CLOUD__WEBSITE = eINSTANCE.getShippingCloud_Website();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHIPPING_CLOUD__DATA_RETENTION = eINSTANCE.getShippingCloud_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Storagelocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHIPPING_CLOUD__STORAGELOCATION = eINSTANCE.getShippingCloud_Storagelocation();

		/**
		 * The meta object literal for the '<em><b>Datasharing</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHIPPING_CLOUD__DATASHARING = eINSTANCE.getShippingCloud_Datasharing();

		/**
		 * The meta object literal for the '<em><b>Test on dummy</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHIPPING_CLOUD__TEST_ON_DUMMY = eINSTANCE.getShippingCloud_Test_on_dummy();

		/**
		 * The meta object literal for the '<em><b>Containerisation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHIPPING_CLOUD__CONTAINERISATION = eINSTANCE.getShippingCloud_Containerisation();

		/**
		 * The meta object literal for the '<em><b>Aggregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHIPPING_CLOUD__AGGREGATION = eINSTANCE.getShippingCloud_Aggregation();

		/**
		 * The meta object literal for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHIPPING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = eINSTANCE
				.getShippingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHIPPING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getShippingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHIPPING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = eINSTANCE
				.getShippingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHIPPING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getShippingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHIPPING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = eINSTANCE
				.getShippingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHIPPING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getShippingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Cloudforpharmacy</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SHIPPING_CLOUD__CLOUDFORPHARMACY = eINSTANCE.getShippingCloud_Cloudforpharmacy();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.WebhostingCloudImpl <em>Webhosting Cloud</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.WebhostingCloudImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getWebhostingCloud()
		 * @generated
		 */
		EClass WEBHOSTING_CLOUD = eINSTANCE.getWebhostingCloud();

		/**
		 * The meta object literal for the '<em><b>Smartphone</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBHOSTING_CLOUD__SMARTPHONE = eINSTANCE.getWebhostingCloud_Smartphone();

		/**
		 * The meta object literal for the '<em><b>Website</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBHOSTING_CLOUD__WEBSITE = eINSTANCE.getWebhostingCloud_Website();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEBHOSTING_CLOUD__DATA_RETENTION = eINSTANCE.getWebhostingCloud_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Storagelocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBHOSTING_CLOUD__STORAGELOCATION = eINSTANCE.getWebhostingCloud_Storagelocation();

		/**
		 * The meta object literal for the '<em><b>Datasharing</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBHOSTING_CLOUD__DATASHARING = eINSTANCE.getWebhostingCloud_Datasharing();

		/**
		 * The meta object literal for the '<em><b>Test on dummy</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBHOSTING_CLOUD__TEST_ON_DUMMY = eINSTANCE.getWebhostingCloud_Test_on_dummy();

		/**
		 * The meta object literal for the '<em><b>Containerisation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBHOSTING_CLOUD__CONTAINERISATION = eINSTANCE.getWebhostingCloud_Containerisation();

		/**
		 * The meta object literal for the '<em><b>Aggregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBHOSTING_CLOUD__AGGREGATION = eINSTANCE.getWebhostingCloud_Aggregation();

		/**
		 * The meta object literal for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEBHOSTING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = eINSTANCE
				.getWebhostingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEBHOSTING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getWebhostingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEBHOSTING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = eINSTANCE
				.getWebhostingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEBHOSTING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getWebhostingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEBHOSTING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = eINSTANCE
				.getWebhostingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEBHOSTING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getWebhostingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Cloudforpharmacy</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBHOSTING_CLOUD__CLOUDFORPHARMACY = eINSTANCE.getWebhostingCloud_Cloudforpharmacy();

		/**
		 * The meta object literal for the '<em><b>Socialnetworkcloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBHOSTING_CLOUD__SOCIALNETWORKCLOUD = eINSTANCE.getWebhostingCloud_Socialnetworkcloud();

		/**
		 * The meta object literal for the '<em><b>Realtimebiddingcloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEBHOSTING_CLOUD__REALTIMEBIDDINGCLOUD = eINSTANCE.getWebhostingCloud_Realtimebiddingcloud();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.PaymentCloudImpl <em>Payment Cloud</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.PaymentCloudImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getPaymentCloud()
		 * @generated
		 */
		EClass PAYMENT_CLOUD = eINSTANCE.getPaymentCloud();

		/**
		 * The meta object literal for the '<em><b>Smartphone</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENT_CLOUD__SMARTPHONE = eINSTANCE.getPaymentCloud_Smartphone();

		/**
		 * The meta object literal for the '<em><b>Website</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENT_CLOUD__WEBSITE = eINSTANCE.getPaymentCloud_Website();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENT_CLOUD__DATA_RETENTION = eINSTANCE.getPaymentCloud_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Storagelocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENT_CLOUD__STORAGELOCATION = eINSTANCE.getPaymentCloud_Storagelocation();

		/**
		 * The meta object literal for the '<em><b>Datasharing</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENT_CLOUD__DATASHARING = eINSTANCE.getPaymentCloud_Datasharing();

		/**
		 * The meta object literal for the '<em><b>Test on dummy</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENT_CLOUD__TEST_ON_DUMMY = eINSTANCE.getPaymentCloud_Test_on_dummy();

		/**
		 * The meta object literal for the '<em><b>Containerisation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENT_CLOUD__CONTAINERISATION = eINSTANCE.getPaymentCloud_Containerisation();

		/**
		 * The meta object literal for the '<em><b>Aggregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENT_CLOUD__AGGREGATION = eINSTANCE.getPaymentCloud_Aggregation();

		/**
		 * The meta object literal for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENT_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = eINSTANCE
				.getPaymentCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENT_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getPaymentCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENT_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = eINSTANCE
				.getPaymentCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENT_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getPaymentCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENT_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = eINSTANCE
				.getPaymentCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAYMENT_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getPaymentCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Cloudforpharmacy</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAYMENT_CLOUD__CLOUDFORPHARMACY = eINSTANCE.getPaymentCloud_Cloudforpharmacy();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.SocialNetworkCloudImpl <em>Social Network Cloud</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.SocialNetworkCloudImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getSocialNetworkCloud()
		 * @generated
		 */
		EClass SOCIAL_NETWORK_CLOUD = eINSTANCE.getSocialNetworkCloud();

		/**
		 * The meta object literal for the '<em><b>Smartphone</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOCIAL_NETWORK_CLOUD__SMARTPHONE = eINSTANCE.getSocialNetworkCloud_Smartphone();

		/**
		 * The meta object literal for the '<em><b>Website</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOCIAL_NETWORK_CLOUD__WEBSITE = eINSTANCE.getSocialNetworkCloud_Website();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOCIAL_NETWORK_CLOUD__DATA_RETENTION = eINSTANCE.getSocialNetworkCloud_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Storagelocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOCIAL_NETWORK_CLOUD__STORAGELOCATION = eINSTANCE.getSocialNetworkCloud_Storagelocation();

		/**
		 * The meta object literal for the '<em><b>Datasharing</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOCIAL_NETWORK_CLOUD__DATASHARING = eINSTANCE.getSocialNetworkCloud_Datasharing();

		/**
		 * The meta object literal for the '<em><b>Test on dummy</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOCIAL_NETWORK_CLOUD__TEST_ON_DUMMY = eINSTANCE.getSocialNetworkCloud_Test_on_dummy();

		/**
		 * The meta object literal for the '<em><b>Containerisation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOCIAL_NETWORK_CLOUD__CONTAINERISATION = eINSTANCE.getSocialNetworkCloud_Containerisation();

		/**
		 * The meta object literal for the '<em><b>Aggregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOCIAL_NETWORK_CLOUD__AGGREGATION = eINSTANCE.getSocialNetworkCloud_Aggregation();

		/**
		 * The meta object literal for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOCIAL_NETWORK_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = eINSTANCE
				.getSocialNetworkCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOCIAL_NETWORK_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getSocialNetworkCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOCIAL_NETWORK_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = eINSTANCE
				.getSocialNetworkCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOCIAL_NETWORK_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getSocialNetworkCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOCIAL_NETWORK_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = eINSTANCE
				.getSocialNetworkCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SOCIAL_NETWORK_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getSocialNetworkCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Cloudforpharmacy</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOCIAL_NETWORK_CLOUD__CLOUDFORPHARMACY = eINSTANCE.getSocialNetworkCloud_Cloudforpharmacy();

		/**
		 * The meta object literal for the '<em><b>Webhostingcloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SOCIAL_NETWORK_CLOUD__WEBHOSTINGCLOUD = eINSTANCE.getSocialNetworkCloud_Webhostingcloud();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.RealTimeBiddingCloudImpl <em>Real Time Bidding Cloud</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.RealTimeBiddingCloudImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getRealTimeBiddingCloud()
		 * @generated
		 */
		EClass REAL_TIME_BIDDING_CLOUD = eINSTANCE.getRealTimeBiddingCloud();

		/**
		 * The meta object literal for the '<em><b>Smartphone</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REAL_TIME_BIDDING_CLOUD__SMARTPHONE = eINSTANCE.getRealTimeBiddingCloud_Smartphone();

		/**
		 * The meta object literal for the '<em><b>Website</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REAL_TIME_BIDDING_CLOUD__WEBSITE = eINSTANCE.getRealTimeBiddingCloud_Website();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REAL_TIME_BIDDING_CLOUD__DATA_RETENTION = eINSTANCE.getRealTimeBiddingCloud_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Storagelocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REAL_TIME_BIDDING_CLOUD__STORAGELOCATION = eINSTANCE.getRealTimeBiddingCloud_Storagelocation();

		/**
		 * The meta object literal for the '<em><b>Datasharing</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REAL_TIME_BIDDING_CLOUD__DATASHARING = eINSTANCE.getRealTimeBiddingCloud_Datasharing();

		/**
		 * The meta object literal for the '<em><b>Test on dummy</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REAL_TIME_BIDDING_CLOUD__TEST_ON_DUMMY = eINSTANCE.getRealTimeBiddingCloud_Test_on_dummy();

		/**
		 * The meta object literal for the '<em><b>Containerisation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REAL_TIME_BIDDING_CLOUD__CONTAINERISATION = eINSTANCE.getRealTimeBiddingCloud_Containerisation();

		/**
		 * The meta object literal for the '<em><b>Aggregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REAL_TIME_BIDDING_CLOUD__AGGREGATION = eINSTANCE.getRealTimeBiddingCloud_Aggregation();

		/**
		 * The meta object literal for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REAL_TIME_BIDDING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = eINSTANCE
				.getRealTimeBiddingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REAL_TIME_BIDDING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getRealTimeBiddingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REAL_TIME_BIDDING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = eINSTANCE
				.getRealTimeBiddingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REAL_TIME_BIDDING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getRealTimeBiddingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REAL_TIME_BIDDING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = eINSTANCE
				.getRealTimeBiddingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REAL_TIME_BIDDING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getRealTimeBiddingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Webhostingcloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REAL_TIME_BIDDING_CLOUD__WEBHOSTINGCLOUD = eINSTANCE.getRealTimeBiddingCloud_Webhostingcloud();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.WebBrowserImpl <em>Web Browser</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.WebBrowserImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getWebBrowser()
		 * @generated
		 */
		EClass WEB_BROWSER = eINSTANCE.getWebBrowser();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEB_BROWSER__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getWebBrowser_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you planning to send all the data to the cloud</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEB_BROWSER__ARE_YOU_PLANNING_TO_SEND_ALL_THE_DATA_TO_THE_CLOUD = eINSTANCE
				.getWebBrowser_Are_you_planning_to_send_all_the_data_to_the_cloud();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEB_BROWSER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getWebBrowser_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEB_BROWSER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getWebBrowser_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Patient info Retention Period</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEB_BROWSER__PATIENT_INFO_RETENTION_PERIOD = eINSTANCE.getWebBrowser_Patient_info_Retention_Period();

		/**
		 * The meta object literal for the '<em><b>Are you planning to collect data other than the needed one for the purpose such as collecting heart beat rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEB_BROWSER__ARE_YOU_PLANNING_TO_COLLECT_DATA_OTHER_THAN_THE_NEEDED_ONE_FOR_THE_PURPOSE_SUCH_AS_COLLECTING_HEART_BEAT_RATE = eINSTANCE
				.getWebBrowser_Are_you_planning_to_collect_data_other_than_the_needed_one_for_the_purpose_such_as_collecting_heart_beat_rate();

		/**
		 * The meta object literal for the '<em><b>Userlocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEB_BROWSER__USERLOCATION = eINSTANCE.getWebBrowser_Userlocation();

		/**
		 * The meta object literal for the '<em><b>Cloudforpharmacy</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEB_BROWSER__CLOUDFORPHARMACY = eINSTANCE.getWebBrowser_Cloudforpharmacy();

		/**
		 * The meta object literal for the '<em><b>Cookies</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEB_BROWSER__COOKIES = eINSTANCE.getWebBrowser_Cookies();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl <em>Cloud For Pharmacy</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.CloudForPharmacyImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCloudForPharmacy()
		 * @generated
		 */
		EClass CLOUD_FOR_PHARMACY = eINSTANCE.getCloudForPharmacy();

		/**
		 * The meta object literal for the '<em><b>Smartphone</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_FOR_PHARMACY__SMARTPHONE = eINSTANCE.getCloudForPharmacy_Smartphone();

		/**
		 * The meta object literal for the '<em><b>Webbrowser</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_FOR_PHARMACY__WEBBROWSER = eINSTANCE.getCloudForPharmacy_Webbrowser();

		/**
		 * The meta object literal for the '<em><b>Storagelocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_FOR_PHARMACY__STORAGELOCATION = eINSTANCE.getCloudForPharmacy_Storagelocation();

		/**
		 * The meta object literal for the '<em><b>Test on dummy</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_FOR_PHARMACY__TEST_ON_DUMMY = eINSTANCE.getCloudForPharmacy_Test_on_dummy();

		/**
		 * The meta object literal for the '<em><b>Containerisation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_FOR_PHARMACY__CONTAINERISATION = eINSTANCE.getCloudForPharmacy_Containerisation();

		/**
		 * The meta object literal for the '<em><b>Aggregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_FOR_PHARMACY__AGGREGATION = eINSTANCE.getCloudForPharmacy_Aggregation();

		/**
		 * The meta object literal for the '<em><b>Datasharing</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_FOR_PHARMACY__DATASHARING = eINSTANCE.getCloudForPharmacy_Datasharing();

		/**
		 * The meta object literal for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_FOR_PHARMACY__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = eINSTANCE
				.getCloudForPharmacy_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_FOR_PHARMACY__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getCloudForPharmacy_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_FOR_PHARMACY__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getCloudForPharmacy_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_FOR_PHARMACY__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = eINSTANCE
				.getCloudForPharmacy_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_FOR_PHARMACY__DATA_RETENTION = eINSTANCE.getCloudForPharmacy_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_FOR_PHARMACY__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getCloudForPharmacy_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLOUD_FOR_PHARMACY__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = eINSTANCE
				.getCloudForPharmacy_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Paymentcloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_FOR_PHARMACY__PAYMENTCLOUD = eINSTANCE.getCloudForPharmacy_Paymentcloud();

		/**
		 * The meta object literal for the '<em><b>Socialnetworkcloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_FOR_PHARMACY__SOCIALNETWORKCLOUD = eINSTANCE.getCloudForPharmacy_Socialnetworkcloud();

		/**
		 * The meta object literal for the '<em><b>Shippingcloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_FOR_PHARMACY__SHIPPINGCLOUD = eINSTANCE.getCloudForPharmacy_Shippingcloud();

		/**
		 * The meta object literal for the '<em><b>Webhostingcloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLOUD_FOR_PHARMACY__WEBHOSTINGCLOUD = eINSTANCE.getCloudForPharmacy_Webhostingcloud();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.BusImpl <em>Bus</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.BusImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getBus()
		 * @generated
		 */
		EClass BUS = eINSTANCE.getBus();

		/**
		 * The meta object literal for the '<em><b>Gpstracker</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUS__GPSTRACKER = eINSTANCE.getBus_Gpstracker();

		/**
		 * The meta object literal for the '<em><b>Plate number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BUS__PLATE_NUMBER = eINSTANCE.getBus_Plate_number();

		/**
		 * The meta object literal for the '<em><b>Route number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BUS__ROUTE_NUMBER = eINSTANCE.getBus_Route_number();

		/**
		 * The meta object literal for the '<em><b>Driver name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BUS__DRIVER_NAME = eINSTANCE.getBus_Driver_name();

		/**
		 * The meta object literal for the '<em><b>Driver</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUS__DRIVER = eINSTANCE.getBus_Driver();

		/**
		 * The meta object literal for the '<em><b>Videoanalytics</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUS__VIDEOANALYTICS = eINSTANCE.getBus_Videoanalytics();

		/**
		 * The meta object literal for the '<em><b>Videoprocessingcloud</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUS__VIDEOPROCESSINGCLOUD = eINSTANCE.getBus_Videoprocessingcloud();

		/**
		 * The meta object literal for the '<em><b>Customer</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUS__CUSTOMER = eINSTANCE.getBus_Customer();

		/**
		 * The meta object literal for the '<em><b>Videowithoutanalytics</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUS__VIDEOWITHOUTANALYTICS = eINSTANCE.getBus_Videowithoutanalytics();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl <em>GPS Tracker</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.GPSTrackerImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getGPSTracker()
		 * @generated
		 */
		EClass GPS_TRACKER = eINSTANCE.getGPSTracker();

		/**
		 * The meta object literal for the '<em><b>ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GPS_TRACKER__ID = eINSTANCE.getGPSTracker_ID();

		/**
		 * The meta object literal for the '<em><b>Coordinates</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GPS_TRACKER__COORDINATES = eINSTANCE.getGPSTracker_Coordinates();

		/**
		 * The meta object literal for the '<em><b>Speed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GPS_TRACKER__SPEED = eINSTANCE.getGPSTracker_Speed();

		/**
		 * The meta object literal for the '<em><b>Does the use of GPS is fully explained in company policies and staff handbooks</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GPS_TRACKER__DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS = eINSTANCE
				.getGPSTracker_Does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks();

		/**
		 * The meta object literal for the '<em><b>Record retention period</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GPS_TRACKER__RECORD_RETENTION_PERIOD = eINSTANCE.getGPSTracker_Record_retention_period();

		/**
		 * The meta object literal for the '<em><b>Does consent have been gathered from the staff who used these vehicles</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GPS_TRACKER__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES = eINSTANCE
				.getGPSTracker_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GPS_TRACKER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = eINSTANCE
				.getGPSTracker_Is_data_against_accidental_loss_or_destruction_or_damage();

		/**
		 * The meta object literal for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GPS_TRACKER__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = eINSTANCE
				.getGPSTracker_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GPS_TRACKER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getGPSTracker_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Are you processing data that are not needed for the purpose such employee monitoring</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GPS_TRACKER__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING = eINSTANCE
				.getGPSTracker_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring();

		/**
		 * The meta object literal for the '<em><b>Does the staff aware of the use of the GPS systems</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GPS_TRACKER__DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS = eINSTANCE
				.getGPSTracker_Does_the_staff_aware_of_the_use_of_the_GPS_systems();

		/**
		 * The meta object literal for the '<em><b>Does the system record information other than the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GPS_TRACKER__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE = eINSTANCE
				.getGPSTracker_Does_the_system_record_information_other_than_the_purpose();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.VideoAnalyticsImpl <em>Video Analytics</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.VideoAnalyticsImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getVideoAnalytics()
		 * @generated
		 */
		EClass VIDEO_ANALYTICS = eINSTANCE.getVideoAnalytics();

		/**
		 * The meta object literal for the '<em><b>Serial number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_ANALYTICS__SERIAL_NUMBER = eINSTANCE.getVideoAnalytics_Serial_number();

		/**
		 * The meta object literal for the '<em><b>Blurring</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_ANALYTICS__BLURRING = eINSTANCE.getVideoAnalytics_Blurring();

		/**
		 * The meta object literal for the '<em><b>Analytics</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_ANALYTICS__ANALYTICS = eINSTANCE.getVideoAnalytics_Analytics();

		/**
		 * The meta object literal for the '<em><b>Customer</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_ANALYTICS__CUSTOMER = eINSTANCE.getVideoAnalytics_Customer();

		/**
		 * The meta object literal for the '<em><b>Videoprocessingcloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_ANALYTICS__VIDEOPROCESSINGCLOUD = eINSTANCE.getVideoAnalytics_Videoprocessingcloud();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl <em>Video Without Analytics</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.VideoWithoutAnalyticsImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getVideoWithoutAnalytics()
		 * @generated
		 */
		EClass VIDEO_WITHOUT_ANALYTICS = eINSTANCE.getVideoWithoutAnalytics();

		/**
		 * The meta object literal for the '<em><b>Serial number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__SERIAL_NUMBER = eINSTANCE.getVideoWithoutAnalytics_Serial_number();

		/**
		 * The meta object literal for the '<em><b>Do people aware of being recorded</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__DO_PEOPLE_AWARE_OF_BEING_RECORDED = eINSTANCE
				.getVideoWithoutAnalytics_Do_people_aware_of_being_recorded();

		/**
		 * The meta object literal for the '<em><b>Record retention period</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__RECORD_RETENTION_PERIOD = eINSTANCE
				.getVideoWithoutAnalytics_Record_retention_period();

		/**
		 * The meta object literal for the '<em><b>Ensure data minimisation is aplied</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__ENSURE_DATA_MINIMISATION_IS_APLIED = eINSTANCE
				.getVideoWithoutAnalytics_Ensure_data_minimisation_is_aplied();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getVideoWithoutAnalytics_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Does consent have been gathered from the staff who used these vehicles</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES = eINSTANCE
				.getVideoWithoutAnalytics_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles();

		/**
		 * The meta object literal for the '<em><b>Does the sign has abrief explanation about the purpose of CCTV</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV = eINSTANCE
				.getVideoWithoutAnalytics_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV();

		/**
		 * The meta object literal for the '<em><b>Does the system record information other than the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE = eINSTANCE
				.getVideoWithoutAnalytics_Does_the_system_record_information_other_than_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = eINSTANCE
				.getVideoWithoutAnalytics_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

		/**
		 * The meta object literal for the '<em><b>Are you processing data that are not needed for the purpose such employee monitoring</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING = eINSTANCE
				.getVideoWithoutAnalytics_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring();

		/**
		 * The meta object literal for the '<em><b>Do you use signs that say CCTV is in operation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION = eINSTANCE
				.getVideoWithoutAnalytics_Do_you_use_signs_that_say_CCTV_is_in_operation();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = eINSTANCE
				.getVideoWithoutAnalytics_Is_data_against_accidental_loss_or_destruction_or_damage();

		/**
		 * The meta object literal for the '<em><b>Does The dynamic masking feature is enabled</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED = eINSTANCE
				.getVideoWithoutAnalytics_Does_The_dynamic_masking_feature_is_enabled();

		/**
		 * The meta object literal for the '<em><b>Are you sending data without anonymisation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION = eINSTANCE
				.getVideoWithoutAnalytics_Are_you_sending_data_without_anonymisation();

		/**
		 * The meta object literal for the '<em><b>Are you allowing data unauthorised access</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS = eINSTANCE
				.getVideoWithoutAnalytics_Are_you_allowing_data_unauthorised_access();

		/**
		 * The meta object literal for the '<em><b>Are you storing the footage in asecure location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_WITHOUT_ANALYTICS__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION = eINSTANCE
				.getVideoWithoutAnalytics_Are_you_storing_the_footage_in_a_secure_location();

		/**
		 * The meta object literal for the '<em><b>Customer</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_WITHOUT_ANALYTICS__CUSTOMER = eINSTANCE.getVideoWithoutAnalytics_Customer();

		/**
		 * The meta object literal for the '<em><b>Videoprocessingcloud</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_WITHOUT_ANALYTICS__VIDEOPROCESSINGCLOUD = eINSTANCE
				.getVideoWithoutAnalytics_Videoprocessingcloud();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.DriverImpl <em>Driver</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.DriverImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getDriver()
		 * @generated
		 */
		EClass DRIVER = eINSTANCE.getDriver();

		/**
		 * The meta object literal for the '<em><b>Authentication</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DRIVER__AUTHENTICATION = eINSTANCE.getDriver_Authentication();

		/**
		 * The meta object literal for the '<em><b>Authorization</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DRIVER__AUTHORIZATION = eINSTANCE.getDriver_Authorization();

		/**
		 * The meta object literal for the '<em><b>Age</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRIVER__AGE = eINSTANCE.getDriver_Age();

		/**
		 * The meta object literal for the '<em><b>Consent checkedlist</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DRIVER__CONSENT_CHECKEDLIST = eINSTANCE.getDriver_Consent_checkedlist();

		/**
		 * The meta object literal for the '<em><b>Do drivers aware of being recorded</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRIVER__DO_DRIVERS_AWARE_OF_BEING_RECORDED = eINSTANCE
				.getDriver_Do_drivers_aware_of_being_recorded();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.CustomerImpl <em>Customer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.CustomerImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCustomer()
		 * @generated
		 */
		EClass CUSTOMER = eINSTANCE.getCustomer();

		/**
		 * The meta object literal for the '<em><b>General features</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CUSTOMER__GENERAL_FEATURES = eINSTANCE.getCustomer_General_features();

		/**
		 * The meta object literal for the '<em><b>Consent checkedlist</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CUSTOMER__CONSENT_CHECKEDLIST = eINSTANCE.getCustomer_Consent_checkedlist();

		/**
		 * The meta object literal for the '<em><b>Do people aware of being recorded</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CUSTOMER__DO_PEOPLE_AWARE_OF_BEING_RECORDED = eINSTANCE
				.getCustomer_Do_people_aware_of_being_recorded();

		/**
		 * The meta object literal for the '<em><b>Videoanalytics</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CUSTOMER__VIDEOANALYTICS = eINSTANCE.getCustomer_Videoanalytics();

		/**
		 * The meta object literal for the '<em><b>Videowithoutanalytics</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CUSTOMER__VIDEOWITHOUTANALYTICS = eINSTANCE.getCustomer_Videowithoutanalytics();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl <em>Analytics</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.AnalyticsImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getAnalytics()
		 * @generated
		 */
		EClass ANALYTICS = eINSTANCE.getAnalytics();

		/**
		 * The meta object literal for the '<em><b>Record retention period</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYTICS__RECORD_RETENTION_PERIOD = eINSTANCE.getAnalytics_Record_retention_period();

		/**
		 * The meta object literal for the '<em><b>Does data processing applied on the camera to increase data minimisation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYTICS__DOES_DATA_PROCESSING_APPLIED_ON_THE_CAMERA_TO_INCREASE_DATA_MINIMISATION = eINSTANCE
				.getAnalytics_Does_data_processing_applied_on_the_camera_to_increase_data_minimisation();

		/**
		 * The meta object literal for the '<em><b>Does consent have been gathered from the staff who used these vehicles</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYTICS__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES = eINSTANCE
				.getAnalytics_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles();

		/**
		 * The meta object literal for the '<em><b>Does the system record information other than the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYTICS__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE = eINSTANCE
				.getAnalytics_Does_the_system_record_information_other_than_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Does The dynamic masking feature is enabled</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYTICS__DOES_THE_DYNAMIC_MASKING_FEATURE_IS_ENABLED = eINSTANCE
				.getAnalytics_Does_The_dynamic_masking_feature_is_enabled();

		/**
		 * The meta object literal for the '<em><b>Are you processing data that are not needed for the purpose such employee monitoring</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYTICS__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING = eINSTANCE
				.getAnalytics_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring();

		/**
		 * The meta object literal for the '<em><b>Do you use signs that say CCTV is in operation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYTICS__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION = eINSTANCE
				.getAnalytics_Do_you_use_signs_that_say_CCTV_is_in_operation();

		/**
		 * The meta object literal for the '<em><b>Does the sign has abrief explanation about the purpose of CCTV</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYTICS__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV = eINSTANCE
				.getAnalytics_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYTICS__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getAnalytics_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYTICS__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE = eINSTANCE
				.getAnalytics_Is_data_against_accidental_loss_or_destruction_or_damage();

		/**
		 * The meta object literal for the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANALYTICS__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA = eINSTANCE
				.getAnalytics_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.BlurringImpl <em>Blurring</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.BlurringImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getBlurring()
		 * @generated
		 */
		EClass BLURRING = eINSTANCE.getBlurring();

		/**
		 * The meta object literal for the '<em><b>Does the face blur feature enabled for individuals to support individual anonymisation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BLURRING__DOES_THE_FACE_BLUR_FEATURE_ENABLED_FOR_INDIVIDUALS_TO_SUPPORT_INDIVIDUAL_ANONYMISATION = eINSTANCE
				.getBlurring_Does_the_face_blur_feature_enabled_for_individuals_to_support_individual_anonymisation();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.VideoProcessingCloudImpl <em>Video Processing Cloud</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.VideoProcessingCloudImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getVideoProcessingCloud()
		 * @generated
		 */
		EClass VIDEO_PROCESSING_CLOUD = eINSTANCE.getVideoProcessingCloud();

		/**
		 * The meta object literal for the '<em><b>Data Retention</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_PROCESSING_CLOUD__DATA_RETENTION = eINSTANCE.getVideoProcessingCloud_DataRetention();

		/**
		 * The meta object literal for the '<em><b>Storagelocation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_PROCESSING_CLOUD__STORAGELOCATION = eINSTANCE.getVideoProcessingCloud_Storagelocation();

		/**
		 * The meta object literal for the '<em><b>Datasharing</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_PROCESSING_CLOUD__DATASHARING = eINSTANCE.getVideoProcessingCloud_Datasharing();

		/**
		 * The meta object literal for the '<em><b>Test on dummy</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_PROCESSING_CLOUD__TEST_ON_DUMMY = eINSTANCE.getVideoProcessingCloud_Test_on_dummy();

		/**
		 * The meta object literal for the '<em><b>Containerisation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_PROCESSING_CLOUD__CONTAINERISATION = eINSTANCE.getVideoProcessingCloud_Containerisation();

		/**
		 * The meta object literal for the '<em><b>Aggregation</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_PROCESSING_CLOUD__AGGREGATION = eINSTANCE.getVideoProcessingCloud_Aggregation();

		/**
		 * The meta object literal for the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_PROCESSING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE = eINSTANCE
				.getVideoProcessingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_PROCESSING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE = eINSTANCE
				.getVideoProcessingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose();

		/**
		 * The meta object literal for the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_PROCESSING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT = eINSTANCE
				.getVideoProcessingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent();

		/**
		 * The meta object literal for the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_PROCESSING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES = eINSTANCE
				.getVideoProcessingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

		/**
		 * The meta object literal for the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_PROCESSING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING = eINSTANCE
				.getVideoProcessingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

		/**
		 * The meta object literal for the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VIDEO_PROCESSING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES = eINSTANCE
				.getVideoProcessingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

		/**
		 * The meta object literal for the '<em><b>Gpstracker</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_PROCESSING_CLOUD__GPSTRACKER = eINSTANCE.getVideoProcessingCloud_Gpstracker();

		/**
		 * The meta object literal for the '<em><b>Videoanalytics</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_PROCESSING_CLOUD__VIDEOANALYTICS = eINSTANCE.getVideoProcessingCloud_Videoanalytics();

		/**
		 * The meta object literal for the '<em><b>Videowithoutanalytics</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_PROCESSING_CLOUD__VIDEOWITHOUTANALYTICS = eINSTANCE
				.getVideoProcessingCloud_Videowithoutanalytics();

		/**
		 * The meta object literal for the '<em><b>Website</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference VIDEO_PROCESSING_CLOUD__WEBSITE = eINSTANCE.getVideoProcessingCloud_Website();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.impl.ClientImpl <em>Client</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.impl.ClientImpl
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getClient()
		 * @generated
		 */
		EClass CLIENT = eINSTANCE.getClient();

		/**
		 * The meta object literal for the '<em><b>Smartphone</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLIENT__SMARTPHONE = eINSTANCE.getClient_Smartphone();

		/**
		 * The meta object literal for the '<em><b>Consent checkedlist</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLIENT__CONSENT_CHECKEDLIST = eINSTANCE.getClient_Consent_checkedlist();

		/**
		 * The meta object literal for the '<em><b>Phone Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CLIENT__PHONE_NUMBER = eINSTANCE.getClient_PhoneNumber();

		/**
		 * The meta object literal for the '<em><b>Authentication</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLIENT__AUTHENTICATION = eINSTANCE.getClient_Authentication();

		/**
		 * The meta object literal for the '<em><b>Authorization</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLIENT__AUTHORIZATION = eINSTANCE.getClient_Authorization();

		/**
		 * The meta object literal for the '<em><b>Phone</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLIENT__PHONE = eINSTANCE.getClient_Phone();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.DataRetentionEnum <em>Data Retention Enum</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getDataRetentionEnum()
		 * @generated
		 */
		EEnum DATA_RETENTION_ENUM = eINSTANCE.getDataRetentionEnum();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.PatientHealthStatus <em>Patient Health Status</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.PatientHealthStatus
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getPatientHealthStatus()
		 * @generated
		 */
		EEnum PATIENT_HEALTH_STATUS = eINSTANCE.getPatientHealthStatus();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.CommunicationProtocols <em>Communication Protocols</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.CommunicationProtocols
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCommunicationProtocols()
		 * @generated
		 */
		EEnum COMMUNICATION_PROTOCOLS = eINSTANCE.getCommunicationProtocols();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.Checked_Consent <em>Checked Consent</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getChecked_Consent()
		 * @generated
		 */
		EEnum CHECKED_CONSENT = eINSTANCE.getChecked_Consent();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.CloudStorageLocation <em>Cloud Storage Location</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.CloudStorageLocation
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCloudStorageLocation()
		 * @generated
		 */
		EEnum CLOUD_STORAGE_LOCATION = eINSTANCE.getCloudStorageLocation();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.LocationGranularity <em>Location Granularity</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.LocationGranularity
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getLocationGranularity()
		 * @generated
		 */
		EEnum LOCATION_GRANULARITY = eINSTANCE.getLocationGranularity();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.Checked <em>Checked</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.Checked
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getChecked()
		 * @generated
		 */
		EEnum CHECKED = eINSTANCE.getChecked();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.CloudProviderServer <em>Cloud Provider Server</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.CloudProviderServer
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getCloudProviderServer()
		 * @generated
		 */
		EEnum CLOUD_PROVIDER_SERVER = eINSTANCE.getCloudProviderServer();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.TestOnDummyData <em>Test On Dummy Data</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.TestOnDummyData
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getTestOnDummyData()
		 * @generated
		 */
		EEnum TEST_ON_DUMMY_DATA = eINSTANCE.getTestOnDummyData();

		/**
		 * The meta object literal for the '{@link com.cardiffuni.pbdproject.cgm3.Answer <em>Answer</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see com.cardiffuni.pbdproject.cgm3.Answer
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getAnswer()
		 * @generated
		 */
		EEnum ANSWER = eINSTANCE.getAnswer();

		/**
		 * The meta object literal for the '<em>Consent Data Type</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.Object
		 * @see com.cardiffuni.pbdproject.cgm3.impl.Cgm3PackageImpl#getConsentDataType()
		 * @generated
		 */
		EDataType CONSENT_DATA_TYPE = eINSTANCE.getConsentDataType();

	}

} //Cgm3Package
