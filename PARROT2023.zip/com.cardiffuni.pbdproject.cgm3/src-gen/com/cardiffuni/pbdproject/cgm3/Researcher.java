/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Researcher</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Researcher#getWebsite <em>Website</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Researcher#getAuthentication <em>Authentication</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Researcher#getAuthorization <em>Authorization</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Researcher#getAre_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data <em>Are you allowing researchers to access or process the data subject medical data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Researcher#getAre_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name <em>Are you allowing unauthorised researchers to access or process the data subject personal data such as name</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getResearcher()
 * @model
 * @generated
 */
public interface Researcher extends GeneralEntity, Encryption {

	/**
	 * Returns the value of the '<em><b>Website</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.Website#getResearcher <em>Researcher</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Website</em>' reference.
	 * @see #setWebsite(Website)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getResearcher_Website()
	 * @see com.cardiffuni.pbdproject.cgm3.Website#getResearcher
	 * @model opposite="researcher"
	 * @generated
	 */
	Website getWebsite();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Researcher#getWebsite <em>Website</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Website</em>' reference.
	 * @see #getWebsite()
	 * @generated
	 */
	void setWebsite(Website value);

	/**
	 * Returns the value of the '<em><b>Authentication</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Authentication}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Authentication</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getResearcher_Authentication()
	 * @model containment="true"
	 * @generated
	 */
	EList<Authentication> getAuthentication();

	/**
	 * Returns the value of the '<em><b>Authorization</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Authorization}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Authorization</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getResearcher_Authorization()
	 * @model containment="true"
	 * @generated
	 */
	EList<Authorization> getAuthorization();

	/**
	 * Returns the value of the '<em><b>Are you allowing researchers to access or process the data subject medical data</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you allowing researchers to access or process the data subject medical data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getResearcher_Are_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data()
	 * @model
	 * @generated
	 */
	Answer getAre_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Researcher#getAre_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data <em>Are you allowing researchers to access or process the data subject medical data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you allowing researchers to access or process the data subject medical data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data()
	 * @generated
	 */
	void setAre_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you allowing unauthorised researchers to access or process the data subject personal data such as name</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you allowing unauthorised researchers to access or process the data subject personal data such as name</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getResearcher_Are_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name()
	 * @model
	 * @generated
	 */
	Answer getAre_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Researcher#getAre_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name <em>Are you allowing unauthorised researchers to access or process the data subject personal data such as name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you allowing unauthorised researchers to access or process the data subject personal data such as name</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name()
	 * @generated
	 */
	void setAre_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name(
			Answer value);
} // Researcher
