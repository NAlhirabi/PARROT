/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Privacy patterns</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Privacy_patterns#getPrivacy_patterns <em>Privacy patterns</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPrivacy_patterns()
 * @model abstract="true"
 * @generated
 */
public interface Privacy_patterns extends EObject {

	/**
	 * Returns the value of the '<em><b>Privacy patterns</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Privacy patterns</em>' attribute.
	 * @see #setPrivacy_patterns(String)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getPrivacy_patterns_Privacy_patterns()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 * @generated
	 */
	String getPrivacy_patterns();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Privacy_patterns#getPrivacy_patterns <em>Privacy patterns</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Privacy patterns</em>' attribute.
	 * @see #getPrivacy_patterns()
	 * @generated
	 */
	void setPrivacy_patterns(String value);
} // Privacy_patterns
