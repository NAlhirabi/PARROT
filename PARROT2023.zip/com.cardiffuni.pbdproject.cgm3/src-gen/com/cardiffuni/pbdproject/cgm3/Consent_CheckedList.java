/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Consent Checked List</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_age_authorization_if_age_is_less_than_16 <em>Capture age authorization if age is less than 16</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_withdrawal_log <em>Capture withdrawal log</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_log_Terms_of_use_AND_consent_to_process <em>Capture log Terms of use AND consent to process</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_consent_to_process_special_category_data <em>Capture consent to process special category data</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_consent_to_term_of_use <em>Capture consent to term of use</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getSurface_privacy_notice <em>Surface privacy notice</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used <em>Capture consent to the type of marketing if electronic marketing is used</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getConsent_CheckedList()
 * @model
 * @generated
 */
public interface Consent_CheckedList extends GeneralEntity {
	/**
	 * Returns the value of the '<em><b>Capture age authorization if age is less than 16</b></em>' attribute.
	 * The default value is <code>"No"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked_Consent}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capture age authorization if age is less than 16</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #setCapture_age_authorization_if_age_is_less_than_16(Checked_Consent)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getConsent_CheckedList_Capture_age_authorization_if_age_is_less_than_16()
	 * @model default="No"
	 * @generated
	 */
	Checked_Consent getCapture_age_authorization_if_age_is_less_than_16();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_age_authorization_if_age_is_less_than_16 <em>Capture age authorization if age is less than 16</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Capture age authorization if age is less than 16</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #getCapture_age_authorization_if_age_is_less_than_16()
	 * @generated
	 */
	void setCapture_age_authorization_if_age_is_less_than_16(Checked_Consent value);

	/**
	 * Returns the value of the '<em><b>Capture withdrawal log</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked_Consent}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capture withdrawal log</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #setCapture_withdrawal_log(Checked_Consent)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getConsent_CheckedList_Capture_withdrawal_log()
	 * @model
	 * @generated
	 */
	Checked_Consent getCapture_withdrawal_log();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_withdrawal_log <em>Capture withdrawal log</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Capture withdrawal log</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #getCapture_withdrawal_log()
	 * @generated
	 */
	void setCapture_withdrawal_log(Checked_Consent value);

	/**
	 * Returns the value of the '<em><b>Capture log Terms of use AND consent to process</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked_Consent}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capture log Terms of use AND consent to process</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #setCapture_log_Terms_of_use_AND_consent_to_process(Checked_Consent)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getConsent_CheckedList_Capture_log_Terms_of_use_AND_consent_to_process()
	 * @model
	 * @generated
	 */
	Checked_Consent getCapture_log_Terms_of_use_AND_consent_to_process();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_log_Terms_of_use_AND_consent_to_process <em>Capture log Terms of use AND consent to process</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Capture log Terms of use AND consent to process</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #getCapture_log_Terms_of_use_AND_consent_to_process()
	 * @generated
	 */
	void setCapture_log_Terms_of_use_AND_consent_to_process(Checked_Consent value);

	/**
	 * Returns the value of the '<em><b>Capture consent to process special category data</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked_Consent}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capture consent to process special category data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #setCapture_consent_to_process_special_category_data(Checked_Consent)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getConsent_CheckedList_Capture_consent_to_process_special_category_data()
	 * @model
	 * @generated
	 */
	Checked_Consent getCapture_consent_to_process_special_category_data();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_consent_to_process_special_category_data <em>Capture consent to process special category data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Capture consent to process special category data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #getCapture_consent_to_process_special_category_data()
	 * @generated
	 */
	void setCapture_consent_to_process_special_category_data(Checked_Consent value);

	/**
	 * Returns the value of the '<em><b>Capture consent to term of use</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked_Consent}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capture consent to term of use</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #setCapture_consent_to_term_of_use(Checked_Consent)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getConsent_CheckedList_Capture_consent_to_term_of_use()
	 * @model
	 * @generated
	 */
	Checked_Consent getCapture_consent_to_term_of_use();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_consent_to_term_of_use <em>Capture consent to term of use</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Capture consent to term of use</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #getCapture_consent_to_term_of_use()
	 * @generated
	 */
	void setCapture_consent_to_term_of_use(Checked_Consent value);

	/**
	 * Returns the value of the '<em><b>Surface privacy notice</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked_Consent}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Surface privacy notice</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #setSurface_privacy_notice(Checked_Consent)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getConsent_CheckedList_Surface_privacy_notice()
	 * @model
	 * @generated
	 */
	Checked_Consent getSurface_privacy_notice();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getSurface_privacy_notice <em>Surface privacy notice</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Surface privacy notice</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #getSurface_privacy_notice()
	 * @generated
	 */
	void setSurface_privacy_notice(Checked_Consent value);

	/**
	 * Returns the value of the '<em><b>Capture consent to the type of marketing if electronic marketing is used</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked_Consent}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capture consent to the type of marketing if electronic marketing is used</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #setCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used(Checked_Consent)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getConsent_CheckedList_Capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used()
	 * @model
	 * @generated
	 */
	Checked_Consent getCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList#getCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used <em>Capture consent to the type of marketing if electronic marketing is used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Capture consent to the type of marketing if electronic marketing is used</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked_Consent
	 * @see #getCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used()
	 * @generated
	 */
	void setCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used(Checked_Consent value);

} // Consent_CheckedList
