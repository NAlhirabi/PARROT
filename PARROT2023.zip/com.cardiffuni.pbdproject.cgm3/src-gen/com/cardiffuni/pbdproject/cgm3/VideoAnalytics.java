/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Video Analytics</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getSerial_number <em>Serial number</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getBlurring <em>Blurring</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getAnalytics <em>Analytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getCustomer <em>Customer</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getVideoprocessingcloud <em>Videoprocessingcloud</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoAnalytics()
 * @model
 * @generated
 */
public interface VideoAnalytics extends GeneralEntity, Encryption {
	/**
	 * Returns the value of the '<em><b>Serial number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Serial number</em>' attribute.
	 * @see #setSerial_number(String)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoAnalytics_Serial_number()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.String"
	 * @generated
	 */
	String getSerial_number();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getSerial_number <em>Serial number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Serial number</em>' attribute.
	 * @see #getSerial_number()
	 * @generated
	 */
	void setSerial_number(String value);

	/**
	 * Returns the value of the '<em><b>Blurring</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Blurring}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Blurring</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoAnalytics_Blurring()
	 * @model containment="true"
	 * @generated
	 */
	EList<Blurring> getBlurring();

	/**
	 * Returns the value of the '<em><b>Analytics</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Analytics}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Analytics</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoAnalytics_Analytics()
	 * @model containment="true"
	 * @generated
	 */
	EList<Analytics> getAnalytics();

	/**
	 * Returns the value of the '<em><b>Customer</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.Customer#getVideoanalytics <em>Videoanalytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Customer</em>' reference.
	 * @see #setCustomer(Customer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoAnalytics_Customer()
	 * @see com.cardiffuni.pbdproject.cgm3.Customer#getVideoanalytics
	 * @model opposite="videoanalytics"
	 * @generated
	 */
	Customer getCustomer();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getCustomer <em>Customer</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Customer</em>' reference.
	 * @see #getCustomer()
	 * @generated
	 */
	void setCustomer(Customer value);

	/**
	 * Returns the value of the '<em><b>Videoprocessingcloud</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getVideoanalytics <em>Videoanalytics</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Videoprocessingcloud</em>' reference.
	 * @see #setVideoprocessingcloud(VideoProcessingCloud)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoAnalytics_Videoprocessingcloud()
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getVideoanalytics
	 * @model opposite="videoanalytics"
	 * @generated
	 */
	VideoProcessingCloud getVideoprocessingcloud();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getVideoprocessingcloud <em>Videoprocessingcloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Videoprocessingcloud</em>' reference.
	 * @see #getVideoprocessingcloud()
	 * @generated
	 */
	void setVideoprocessingcloud(VideoProcessingCloud value);

} // VideoAnalytics
