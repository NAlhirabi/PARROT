/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cookies</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Cookies#getUse_the_surface_cookies_banner_if_cookies_are_placed <em>Use the surface cookies banner if cookies are placed</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Cookies#getThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added <em>The cookie banner must be resurfaced if new cookies are added</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Cookies#getThe_cookie_banner_must_be_resurfaced_if_browser_settings_change <em>The cookie banner must be resurfaced if browser settings change</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Cookies#getCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used <em>Capture consent or acceptance if necessary OR Analytics OR Ad targeting cookies are used</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Cookies#getPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used <em>Place cookies according to consent if necessary OR Analytics OR Ad targeting cookies are used</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Cookies#getConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc <em>Consider the option of using athird party tool such as One Trus or Trust Arc</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCookies()
 * @model
 * @generated
 */
public interface Cookies extends GeneralEntity {
	/**
	 * Returns the value of the '<em><b>Use the surface cookies banner if cookies are placed</b></em>' attribute.
	 * The default value is <code>"No"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Use the surface cookies banner if cookies are placed</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #setUse_the_surface_cookies_banner_if_cookies_are_placed(Checked)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCookies_Use_the_surface_cookies_banner_if_cookies_are_placed()
	 * @model default="No"
	 * @generated
	 */
	Checked getUse_the_surface_cookies_banner_if_cookies_are_placed();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Cookies#getUse_the_surface_cookies_banner_if_cookies_are_placed <em>Use the surface cookies banner if cookies are placed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Use the surface cookies banner if cookies are placed</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #getUse_the_surface_cookies_banner_if_cookies_are_placed()
	 * @generated
	 */
	void setUse_the_surface_cookies_banner_if_cookies_are_placed(Checked value);

	/**
	 * Returns the value of the '<em><b>The cookie banner must be resurfaced if new cookies are added</b></em>' attribute.
	 * The default value is <code>"No"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>The cookie banner must be resurfaced if new cookies are added</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #setThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added(Checked)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCookies_The_cookie_banner_must_be_resurfaced_if_new_cookies_are_added()
	 * @model default="No"
	 * @generated
	 */
	Checked getThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Cookies#getThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added <em>The cookie banner must be resurfaced if new cookies are added</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>The cookie banner must be resurfaced if new cookies are added</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #getThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added()
	 * @generated
	 */
	void setThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_added(Checked value);

	/**
	 * Returns the value of the '<em><b>The cookie banner must be resurfaced if browser settings change</b></em>' attribute.
	 * The default value is <code>"No"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>The cookie banner must be resurfaced if browser settings change</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #setThe_cookie_banner_must_be_resurfaced_if_browser_settings_change(Checked)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCookies_The_cookie_banner_must_be_resurfaced_if_browser_settings_change()
	 * @model default="No"
	 * @generated
	 */
	Checked getThe_cookie_banner_must_be_resurfaced_if_browser_settings_change();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Cookies#getThe_cookie_banner_must_be_resurfaced_if_browser_settings_change <em>The cookie banner must be resurfaced if browser settings change</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>The cookie banner must be resurfaced if browser settings change</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #getThe_cookie_banner_must_be_resurfaced_if_browser_settings_change()
	 * @generated
	 */
	void setThe_cookie_banner_must_be_resurfaced_if_browser_settings_change(Checked value);

	/**
	 * Returns the value of the '<em><b>Capture consent or acceptance if necessary OR Analytics OR Ad targeting cookies are used</b></em>' attribute.
	 * The default value is <code>"No"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capture consent or acceptance if necessary OR Analytics OR Ad targeting cookies are used</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #setCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used(Checked)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCookies_Capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used()
	 * @model default="No"
	 * @generated
	 */
	Checked getCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Cookies#getCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used <em>Capture consent or acceptance if necessary OR Analytics OR Ad targeting cookies are used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Capture consent or acceptance if necessary OR Analytics OR Ad targeting cookies are used</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #getCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used()
	 * @generated
	 */
	void setCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used(Checked value);

	/**
	 * Returns the value of the '<em><b>Place cookies according to consent if necessary OR Analytics OR Ad targeting cookies are used</b></em>' attribute.
	 * The default value is <code>"No"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Place cookies according to consent if necessary OR Analytics OR Ad targeting cookies are used</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #setPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used(Checked)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCookies_Place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used()
	 * @model default="No"
	 * @generated
	 */
	Checked getPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Cookies#getPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used <em>Place cookies according to consent if necessary OR Analytics OR Ad targeting cookies are used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Place cookies according to consent if necessary OR Analytics OR Ad targeting cookies are used</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #getPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used()
	 * @generated
	 */
	void setPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used(
			Checked value);

	/**
	 * Returns the value of the '<em><b>Consider the option of using athird party tool such as One Trus or Trust Arc</b></em>' attribute.
	 * The default value is <code>"No"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Consider the option of using athird party tool such as One Trus or Trust Arc</em>' attribute.
	 * @see #setConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc(String)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getCookies_Consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc()
	 * @model default="No" dataType="org.eclipse.emf.ecore.xml.type.String"
	 * @generated
	 */
	String getConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Cookies#getConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc <em>Consider the option of using athird party tool such as One Trus or Trust Arc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Consider the option of using athird party tool such as One Trus or Trust Arc</em>' attribute.
	 * @see #getConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc()
	 * @generated
	 */
	void setConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc(String value);

} // Cookies
