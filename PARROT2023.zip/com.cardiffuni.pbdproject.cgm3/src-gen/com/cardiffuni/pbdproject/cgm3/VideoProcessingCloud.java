/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Video Processing Cloud</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getDataRetention <em>Data Retention</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getStoragelocation <em>Storagelocation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getDatasharing <em>Datasharing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getTest_on_dummy <em>Test on dummy</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getContainerisation <em>Containerisation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAggregation <em>Aggregation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getGpstracker <em>Gpstracker</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getVideoanalytics <em>Videoanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getVideowithoutanalytics <em>Videowithoutanalytics</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getWebsite <em>Website</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud()
 * @model
 * @generated
 */
public interface VideoProcessingCloud extends GeneralEntity, Encryption {
	/**
	 * Returns the value of the '<em><b>Data Retention</b></em>' attribute.
	 * The default value is <code>"NotAccepted"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.DataRetentionEnum}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Data Retention</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #setDataRetention(DataRetentionEnum)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_DataRetention()
	 * @model default="NotAccepted"
	 * @generated
	 */
	DataRetentionEnum getDataRetention();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getDataRetention <em>Data Retention</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Data Retention</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #getDataRetention()
	 * @generated
	 */
	void setDataRetention(DataRetentionEnum value);

	/**
	 * Returns the value of the '<em><b>Storagelocation</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.StorageLocation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Storagelocation</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Storagelocation()
	 * @model containment="true"
	 * @generated
	 */
	EList<StorageLocation> getStoragelocation();

	/**
	 * Returns the value of the '<em><b>Datasharing</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.DataSharing}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Datasharing</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Datasharing()
	 * @model containment="true"
	 * @generated
	 */
	EList<DataSharing> getDatasharing();

	/**
	 * Returns the value of the '<em><b>Test on dummy</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Test_on_dummy}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Test on dummy</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Test_on_dummy()
	 * @model containment="true"
	 * @generated
	 */
	EList<Test_on_dummy> getTest_on_dummy();

	/**
	 * Returns the value of the '<em><b>Containerisation</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Containerisation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Containerisation</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Containerisation()
	 * @model containment="true"
	 * @generated
	 */
	EList<Containerisation> getContainerisation();

	/**
	 * Returns the value of the '<em><b>Aggregation</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Aggregation}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Aggregation</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Aggregation()
	 * @model containment="true"
	 * @generated
	 */
	EList<Aggregation> getAggregation();

	/**
	 * Returns the value of the '<em><b>Are you collecting data that are not needed for the purpose</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you collecting data that are not needed for the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_collecting_data_that_are_not_needed_for_the_purpose(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_collecting_data_that_are_not_needed_for_the_purpose();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_collecting_data_that_are_not_needed_for_the_purpose <em>Are you collecting data that are not needed for the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you collecting data that are not needed for the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_collecting_data_that_are_not_needed_for_the_purpose()
	 * @generated
	 */
	void setAre_you_collecting_data_that_are_not_needed_for_the_purpose(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you processing data in an incompatible way with the purpose</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you processing data in an incompatible way with the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_processing_data_in_an_incompatible_way_with_the_purpose();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_processing_data_in_an_incompatible_way_with_the_purpose <em>Are you processing data in an incompatible way with the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you processing data in an incompatible way with the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_processing_data_in_an_incompatible_way_with_the_purpose()
	 * @generated
	 */
	void setAre_you_processing_data_in_an_incompatible_way_with_the_purpose(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you sharing data with other parties without having data subject consent</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you sharing data with other parties without having data subject consent</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_sharing_data_with_other_parties_without_having_data_subject_consent(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent <em>Are you sharing data with other parties without having data subject consent</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you sharing data with other parties without having data subject consent</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_sharing_data_with_other_parties_without_having_data_subject_consent()
	 * @generated
	 */
	void setAre_you_sharing_data_with_other_parties_without_having_data_subject_consent(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 */
	void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing <em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you overlooking appropriate security and allowing unauthorised or unlawful processing</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing()
	 * @generated
	 */
	void setAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing(Answer value);

	/**
	 * Returns the value of the '<em><b>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures <em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures()
	 * @generated
	 */
	void setIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures(
			Answer value);

	/**
	 * Returns the value of the '<em><b>Gpstracker</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.GPSTracker}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Gpstracker</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Gpstracker()
	 * @model containment="true"
	 * @generated
	 */
	EList<GPSTracker> getGpstracker();

	/**
	 * Returns the value of the '<em><b>Videoanalytics</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getVideoprocessingcloud <em>Videoprocessingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Videoanalytics</em>' reference.
	 * @see #setVideoanalytics(VideoAnalytics)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Videoanalytics()
	 * @see com.cardiffuni.pbdproject.cgm3.VideoAnalytics#getVideoprocessingcloud
	 * @model opposite="videoprocessingcloud"
	 * @generated
	 */
	VideoAnalytics getVideoanalytics();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getVideoanalytics <em>Videoanalytics</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Videoanalytics</em>' reference.
	 * @see #getVideoanalytics()
	 * @generated
	 */
	void setVideoanalytics(VideoAnalytics value);

	/**
	 * Returns the value of the '<em><b>Videowithoutanalytics</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getVideoprocessingcloud <em>Videoprocessingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Videowithoutanalytics</em>' reference.
	 * @see #setVideowithoutanalytics(VideoWithoutAnalytics)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Videowithoutanalytics()
	 * @see com.cardiffuni.pbdproject.cgm3.VideoWithoutAnalytics#getVideoprocessingcloud
	 * @model opposite="videoprocessingcloud"
	 * @generated
	 */
	VideoWithoutAnalytics getVideowithoutanalytics();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getVideowithoutanalytics <em>Videowithoutanalytics</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Videowithoutanalytics</em>' reference.
	 * @see #getVideowithoutanalytics()
	 * @generated
	 */
	void setVideowithoutanalytics(VideoWithoutAnalytics value);

	/**
	 * Returns the value of the '<em><b>Website</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.Website#getVideoprocessingcloud <em>Videoprocessingcloud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Website</em>' reference.
	 * @see #setWebsite(Website)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getVideoProcessingCloud_Website()
	 * @see com.cardiffuni.pbdproject.cgm3.Website#getVideoprocessingcloud
	 * @model opposite="videoprocessingcloud"
	 * @generated
	 */
	Website getWebsite();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getWebsite <em>Website</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Website</em>' reference.
	 * @see #getWebsite()
	 * @generated
	 */
	void setWebsite(Website value);

} // VideoProcessingCloud
