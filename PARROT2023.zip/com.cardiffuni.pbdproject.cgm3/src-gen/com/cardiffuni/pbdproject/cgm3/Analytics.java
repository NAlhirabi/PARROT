/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Analytics</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Analytics#getRecord_retention_period <em>Record retention period</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation <em>Does data processing applied on the camera to increase data minimisation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles <em>Does consent have been gathered from the staff who used these vehicles</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_the_system_record_information_other_than_the_purpose <em>Does the system record information other than the purpose</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_The_dynamic_masking_feature_is_enabled <em>Does The dynamic masking feature is enabled</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Analytics#getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDo_you_use_signs_that_say_CCTV_is_in_operation <em>Do you use signs that say CCTV is in operation</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV <em>Does the sign has abrief explanation about the purpose of CCTV</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Analytics#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Analytics#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Analytics#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAnalytics()
 * @model
 * @generated
 */
public interface Analytics extends GeneralEntity {
	/**
	 * Returns the value of the '<em><b>Record retention period</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.DataRetentionEnum}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Record retention period</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #setRecord_retention_period(DataRetentionEnum)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAnalytics_Record_retention_period()
	 * @model
	 * @generated
	 */
	DataRetentionEnum getRecord_retention_period();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getRecord_retention_period <em>Record retention period</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Record retention period</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.DataRetentionEnum
	 * @see #getRecord_retention_period()
	 * @generated
	 */
	void setRecord_retention_period(DataRetentionEnum value);

	/**
	 * Returns the value of the '<em><b>Does data processing applied on the camera to increase data minimisation</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Does data processing applied on the camera to increase data minimisation</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAnalytics_Does_data_processing_applied_on_the_camera_to_increase_data_minimisation()
	 * @model
	 * @generated
	 */
	Answer getDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation <em>Does data processing applied on the camera to increase data minimisation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Does data processing applied on the camera to increase data minimisation</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation()
	 * @generated
	 */
	void setDoes_data_processing_applied_on_the_camera_to_increase_data_minimisation(Answer value);

	/**
	 * Returns the value of the '<em><b>Does consent have been gathered from the staff who used these vehicles</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Does consent have been gathered from the staff who used these vehicles</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAnalytics_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles()
	 * @model
	 * @generated
	 */
	Answer getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles <em>Does consent have been gathered from the staff who used these vehicles</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Does consent have been gathered from the staff who used these vehicles</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles()
	 * @generated
	 */
	void setDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehicles(Answer value);

	/**
	 * Returns the value of the '<em><b>Does the system record information other than the purpose</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Does the system record information other than the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setDoes_the_system_record_information_other_than_the_purpose(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAnalytics_Does_the_system_record_information_other_than_the_purpose()
	 * @model
	 * @generated
	 */
	Answer getDoes_the_system_record_information_other_than_the_purpose();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_the_system_record_information_other_than_the_purpose <em>Does the system record information other than the purpose</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Does the system record information other than the purpose</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getDoes_the_system_record_information_other_than_the_purpose()
	 * @generated
	 */
	void setDoes_the_system_record_information_other_than_the_purpose(Answer value);

	/**
	 * Returns the value of the '<em><b>Does The dynamic masking feature is enabled</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Does The dynamic masking feature is enabled</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setDoes_The_dynamic_masking_feature_is_enabled(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAnalytics_Does_The_dynamic_masking_feature_is_enabled()
	 * @model
	 * @generated
	 */
	Answer getDoes_The_dynamic_masking_feature_is_enabled();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_The_dynamic_masking_feature_is_enabled <em>Does The dynamic masking feature is enabled</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Does The dynamic masking feature is enabled</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getDoes_The_dynamic_masking_feature_is_enabled()
	 * @generated
	 */
	void setDoes_The_dynamic_masking_feature_is_enabled(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you processing data that are not needed for the purpose such employee monitoring</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you processing data that are not needed for the purpose such employee monitoring</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAnalytics_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring()
	 * @model
	 * @generated
	 */
	Answer getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring <em>Are you processing data that are not needed for the purpose such employee monitoring</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you processing data that are not needed for the purpose such employee monitoring</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring()
	 * @generated
	 */
	void setAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring(Answer value);

	/**
	 * Returns the value of the '<em><b>Do you use signs that say CCTV is in operation</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Do you use signs that say CCTV is in operation</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setDo_you_use_signs_that_say_CCTV_is_in_operation(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAnalytics_Do_you_use_signs_that_say_CCTV_is_in_operation()
	 * @model
	 * @generated
	 */
	Answer getDo_you_use_signs_that_say_CCTV_is_in_operation();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDo_you_use_signs_that_say_CCTV_is_in_operation <em>Do you use signs that say CCTV is in operation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Do you use signs that say CCTV is in operation</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getDo_you_use_signs_that_say_CCTV_is_in_operation()
	 * @generated
	 */
	void setDo_you_use_signs_that_say_CCTV_is_in_operation(Answer value);

	/**
	 * Returns the value of the '<em><b>Does the sign has abrief explanation about the purpose of CCTV</b></em>' attribute.
	 * The default value is <code>"Not_Answered"</code>.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Does the sign has abrief explanation about the purpose of CCTV</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAnalytics_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV()
	 * @model default="Not_Answered"
	 * @generated
	 */
	Answer getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV <em>Does the sign has abrief explanation about the purpose of CCTV</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Does the sign has abrief explanation about the purpose of CCTV</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV()
	 * @generated
	 */
	void setDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you storing the data longer than is necessary for the purposes</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAnalytics_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @model
	 * @generated
	 */
	Answer getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes <em>Are you storing the data longer than is necessary for the purposes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you storing the data longer than is necessary for the purposes</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes()
	 * @generated
	 */
	void setAre_you_storing_the_data_longer_than_is_necessary_for_the_purposes(Answer value);

	/**
	 * Returns the value of the '<em><b>Is data against accidental loss or destruction or damage</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is data against accidental loss or destruction or damage</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setIs_data_against_accidental_loss_or_destruction_or_damage(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAnalytics_Is_data_against_accidental_loss_or_destruction_or_damage()
	 * @model
	 * @generated
	 */
	Answer getIs_data_against_accidental_loss_or_destruction_or_damage();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getIs_data_against_accidental_loss_or_destruction_or_damage <em>Is data against accidental loss or destruction or damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is data against accidental loss or destruction or damage</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getIs_data_against_accidental_loss_or_destruction_or_damage()
	 * @generated
	 */
	void setIs_data_against_accidental_loss_or_destruction_or_damage(Answer value);

	/**
	 * Returns the value of the '<em><b>Are you using appropriate technical or organisational measures to protect the data</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you using appropriate technical or organisational measures to protect the data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAnalytics_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @model
	 * @generated
	 */
	Answer getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Analytics#getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data <em>Are you using appropriate technical or organisational measures to protect the data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you using appropriate technical or organisational measures to protect the data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data()
	 * @generated
	 */
	void setAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data(Answer value);

} // Analytics
