/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Authorization</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Authorization#getAuthorized <em>Authorized</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAuthorization()
 * @model
 * @generated
 */
public interface Authorization extends GeneralEntity {
	/**
	 * Returns the value of the '<em><b>Authorized</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Authorized</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #setAuthorized(Checked)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getAuthorization_Authorized()
	 * @model
	 * @generated
	 */
	Checked getAuthorized();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Authorization#getAuthorized <em>Authorized</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Authorized</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #getAuthorized()
	 * @generated
	 */
	void setAuthorized(Checked value);

} // Authorization
