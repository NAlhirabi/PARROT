/**
 */
package com.cardiffuni.pbdproject.cgm3;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Website</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Website#getCloud <em>Cloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Website#getDoctor <em>Doctor</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Website#getResearcher <em>Researcher</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Website#getURL <em>URL</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Website#getVideoprocessingcloud <em>Videoprocessingcloud</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Website#getCookies <em>Cookies</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getWebsite()
 * @model
 * @generated
 */
public interface Website extends GeneralEntity, Encryption {
	/**
	 * Returns the value of the '<em><b>Cloud</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.Cloud#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cloud</em>' reference.
	 * @see #setCloud(Cloud)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getWebsite_Cloud()
	 * @see com.cardiffuni.pbdproject.cgm3.Cloud#getWebsite
	 * @model opposite="website"
	 * @generated
	 */
	Cloud getCloud();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Website#getCloud <em>Cloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cloud</em>' reference.
	 * @see #getCloud()
	 * @generated
	 */
	void setCloud(Cloud value);

	/**
	 * Returns the value of the '<em><b>Doctor</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.Doctor#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Doctor</em>' reference.
	 * @see #setDoctor(Doctor)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getWebsite_Doctor()
	 * @see com.cardiffuni.pbdproject.cgm3.Doctor#getWebsite
	 * @model opposite="website"
	 * @generated
	 */
	Doctor getDoctor();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Website#getDoctor <em>Doctor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Doctor</em>' reference.
	 * @see #getDoctor()
	 * @generated
	 */
	void setDoctor(Doctor value);

	/**
	 * Returns the value of the '<em><b>Researcher</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.Researcher#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Researcher</em>' reference.
	 * @see #setResearcher(Researcher)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getWebsite_Researcher()
	 * @see com.cardiffuni.pbdproject.cgm3.Researcher#getWebsite
	 * @model opposite="website"
	 * @generated
	 */
	Researcher getResearcher();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Website#getResearcher <em>Researcher</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Researcher</em>' reference.
	 * @see #getResearcher()
	 * @generated
	 */
	void setResearcher(Researcher value);

	/**
	 * Returns the value of the '<em><b>URL</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>URL</em>' attribute.
	 * @see #setURL(String)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getWebsite_URL()
	 * @model
	 * @generated
	 */
	String getURL();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Website#getURL <em>URL</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>URL</em>' attribute.
	 * @see #getURL()
	 * @generated
	 */
	void setURL(String value);

	/**
	 * Returns the value of the '<em><b>Videoprocessingcloud</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getWebsite <em>Website</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Videoprocessingcloud</em>' reference.
	 * @see #setVideoprocessingcloud(VideoProcessingCloud)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getWebsite_Videoprocessingcloud()
	 * @see com.cardiffuni.pbdproject.cgm3.VideoProcessingCloud#getWebsite
	 * @model opposite="website"
	 * @generated
	 */
	VideoProcessingCloud getVideoprocessingcloud();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Website#getVideoprocessingcloud <em>Videoprocessingcloud</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Videoprocessingcloud</em>' reference.
	 * @see #getVideoprocessingcloud()
	 * @generated
	 */
	void setVideoprocessingcloud(VideoProcessingCloud value);

	/**
	 * Returns the value of the '<em><b>Cookies</b></em>' containment reference list.
	 * The list contents are of type {@link com.cardiffuni.pbdproject.cgm3.Cookies}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cookies</em>' containment reference list.
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getWebsite_Cookies()
	 * @model containment="true"
	 * @generated
	 */
	EList<Cookies> getCookies();

} // Website
