/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Storage Location</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.StorageLocation#getCloud_provider_and_server_location <em>Cloud provider and server location</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getStorageLocation()
 * @model
 * @generated
 */
public interface StorageLocation extends GeneralEntity {

	/**
	 * Returns the value of the '<em><b>Cloud provider and server location</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.CloudProviderServer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cloud provider and server location</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudProviderServer
	 * @see #setCloud_provider_and_server_location(CloudProviderServer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getStorageLocation_Cloud_provider_and_server_location()
	 * @model
	 * @generated
	 */
	CloudProviderServer getCloud_provider_and_server_location();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.StorageLocation#getCloud_provider_and_server_location <em>Cloud provider and server location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cloud provider and server location</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.CloudProviderServer
	 * @see #getCloud_provider_and_server_location()
	 * @generated
	 */
	void setCloud_provider_and_server_location(CloudProviderServer value);

} // StorageLocation
