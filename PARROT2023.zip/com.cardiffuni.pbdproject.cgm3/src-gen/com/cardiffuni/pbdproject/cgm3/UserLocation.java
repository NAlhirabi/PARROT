/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>User Location</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.UserLocation#getLocation <em>Location</em>}</li>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.UserLocation#getAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed <em>Are you planning to collect the exact location of the data subject when the location is not needed</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getUserLocation()
 * @model
 * @generated
 */
public interface UserLocation extends GeneralEntity {

	/**
	 * Returns the value of the '<em><b>Location</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.LocationGranularity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Location</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.LocationGranularity
	 * @see #setLocation(LocationGranularity)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getUserLocation_Location()
	 * @model
	 * @generated
	 */
	LocationGranularity getLocation();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.UserLocation#getLocation <em>Location</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Location</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.LocationGranularity
	 * @see #getLocation()
	 * @generated
	 */
	void setLocation(LocationGranularity value);

	/**
	 * Returns the value of the '<em><b>Are you planning to collect the exact location of the data subject when the location is not needed</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Answer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Are you planning to collect the exact location of the data subject when the location is not needed</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #setAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed(Answer)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getUserLocation_Are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed()
	 * @model
	 * @generated
	 */
	Answer getAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.UserLocation#getAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed <em>Are you planning to collect the exact location of the data subject when the location is not needed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Are you planning to collect the exact location of the data subject when the location is not needed</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Answer
	 * @see #getAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed()
	 * @generated
	 */
	void setAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed(
			Answer value);

} // UserLocation
