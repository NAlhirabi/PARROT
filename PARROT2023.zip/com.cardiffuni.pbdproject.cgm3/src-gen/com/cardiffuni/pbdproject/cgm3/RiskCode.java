/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Risk Code</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getRiskCode()
 * @model
 * @generated
 */
public interface RiskCode extends GeneralEntity {
} // RiskCode
