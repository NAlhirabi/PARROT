/**
 */
package com.cardiffuni.pbdproject.cgm3;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Encryption</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link com.cardiffuni.pbdproject.cgm3.Encryption#getEncryptedData <em>Encrypted Data</em>}</li>
 * </ul>
 *
 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getEncryption()
 * @model abstract="true"
 * @generated
 */
public interface Encryption extends GeneralEntity {
	/**
	 * Returns the value of the '<em><b>Encrypted Data</b></em>' attribute.
	 * The literals are from the enumeration {@link com.cardiffuni.pbdproject.cgm3.Checked}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Encrypted Data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #setEncryptedData(Checked)
	 * @see com.cardiffuni.pbdproject.cgm3.Cgm3Package#getEncryption_EncryptedData()
	 * @model
	 * @generated
	 */
	Checked getEncryptedData();

	/**
	 * Sets the value of the '{@link com.cardiffuni.pbdproject.cgm3.Encryption#getEncryptedData <em>Encrypted Data</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Encrypted Data</em>' attribute.
	 * @see com.cardiffuni.pbdproject.cgm3.Checked
	 * @see #getEncryptedData()
	 * @generated
	 */
	void setEncryptedData(Checked value);

} // Encryption
