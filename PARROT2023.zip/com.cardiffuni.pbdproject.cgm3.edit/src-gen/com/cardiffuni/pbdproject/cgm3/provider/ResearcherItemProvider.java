/**
 */
package com.cardiffuni.pbdproject.cgm3.provider;

import com.cardiffuni.pbdproject.cgm3.Cgm3Factory;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Researcher;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.cardiffuni.pbdproject.cgm3.Researcher} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class ResearcherItemProvider extends GeneralEntityItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ResearcherItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addEncryptedDataPropertyDescriptor(object);
			addWebsitePropertyDescriptor(object);
			addAre_you_allowing_researchers_to_access_or_process_the_data_subject_medical_dataPropertyDescriptor(
					object);
			addAre_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_namePropertyDescriptor(
					object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Encrypted Data feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addEncryptedDataPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Encryption_EncryptedData_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Encryption_EncryptedData_feature",
								"_UI_Encryption_type"),
						Cgm3Package.Literals.ENCRYPTION__ENCRYPTED_DATA, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Website feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addWebsitePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Researcher_website_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Researcher_website_feature",
								"_UI_Researcher_type"),
						Cgm3Package.Literals.RESEARCHER__WEBSITE, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you allowing researchers to access or process the data subject medical data feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_allowing_researchers_to_access_or_process_the_data_subject_medical_dataPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_Researcher_Are_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Researcher_Are_you_allowing_researchers_to_access_or_process_the_data_subject_medical_data_feature",
						"_UI_Researcher_type"),
				Cgm3Package.Literals.RESEARCHER__ARE_YOU_ALLOWING_RESEARCHERS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_MEDICAL_DATA,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you allowing unauthorised researchers to access or process the data subject personal data such as name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_namePropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_Researcher_Are_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Researcher_Are_you_allowing_unauthorised_researchers_to_access_or_process_the_data_subject_personal_data_such_as_name_feature",
						"_UI_Researcher_type"),
				Cgm3Package.Literals.RESEARCHER__ARE_YOU_ALLOWING_UNAUTHORISED_RESEARCHERS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_PERSONAL_DATA_SUCH_AS_NAME,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(Cgm3Package.Literals.RESEARCHER__AUTHENTICATION);
			childrenFeatures.add(Cgm3Package.Literals.RESEARCHER__AUTHORIZATION);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns Researcher.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Researcher"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Researcher) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_Researcher_type")
				: getString("_UI_Researcher_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Researcher.class)) {
		case Cgm3Package.RESEARCHER__ENCRYPTED_DATA:
		case Cgm3Package.RESEARCHER__ARE_YOU_ALLOWING_RESEARCHERS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_MEDICAL_DATA:
		case Cgm3Package.RESEARCHER__ARE_YOU_ALLOWING_UNAUTHORISED_RESEARCHERS_TO_ACCESS_OR_PROCESS_THE_DATA_SUBJECT_PERSONAL_DATA_SUCH_AS_NAME:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		case Cgm3Package.RESEARCHER__AUTHENTICATION:
		case Cgm3Package.RESEARCHER__AUTHORIZATION:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.RESEARCHER__AUTHENTICATION,
				Cgm3Factory.eINSTANCE.createAuthentication()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.RESEARCHER__AUTHORIZATION,
				Cgm3Factory.eINSTANCE.createAuthorization()));
	}

}
