/**
 */
package com.cardiffuni.pbdproject.cgm3.provider;

import com.cardiffuni.pbdproject.cgm3.Cgm3Factory;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.cardiffuni.pbdproject.cgm3.RealTimeBiddingCloud} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class RealTimeBiddingCloudItemProvider extends GeneralEntityItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RealTimeBiddingCloudItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addEncryptedDataPropertyDescriptor(object);
			addPrivacy_patternsPropertyDescriptor(object);
			addSmartphonePropertyDescriptor(object);
			addWebsitePropertyDescriptor(object);
			addDataRetentionPropertyDescriptor(object);
			addAre_you_collecting_data_that_are_not_needed_for_the_purposePropertyDescriptor(object);
			addAre_you_processing_data_in_an_incompatible_way_with_the_purposePropertyDescriptor(object);
			addAre_you_sharing_data_with_other_parties_without_having_data_subject_consentPropertyDescriptor(object);
			addAre_you_storing_the_data_longer_than_is_necessary_for_the_purposesPropertyDescriptor(object);
			addAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processingPropertyDescriptor(
					object);
			addIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measuresPropertyDescriptor(
					object);
			addWebhostingcloudPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Encrypted Data feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addEncryptedDataPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Encryption_EncryptedData_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Encryption_EncryptedData_feature",
								"_UI_Encryption_type"),
						Cgm3Package.Literals.ENCRYPTION__ENCRYPTED_DATA, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Privacy patterns feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPrivacy_patternsPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Privacy_patterns_Privacy_patterns_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Privacy_patterns_Privacy_patterns_feature",
								"_UI_Privacy_patterns_type"),
						Cgm3Package.Literals.PRIVACY_PATTERNS__PRIVACY_PATTERNS, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Smartphone feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addSmartphonePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_RealTimeBiddingCloud_smartphone_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_RealTimeBiddingCloud_smartphone_feature",
								"_UI_RealTimeBiddingCloud_type"),
						Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__SMARTPHONE, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Website feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addWebsitePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_RealTimeBiddingCloud_website_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_RealTimeBiddingCloud_website_feature",
								"_UI_RealTimeBiddingCloud_type"),
						Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__WEBSITE, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Data Retention feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDataRetentionPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_RealTimeBiddingCloud_DataRetention_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_RealTimeBiddingCloud_DataRetention_feature",
						"_UI_RealTimeBiddingCloud_type"),
				Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__DATA_RETENTION, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you collecting data that are not needed for the purpose feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_collecting_data_that_are_not_needed_for_the_purposePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_RealTimeBiddingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_RealTimeBiddingCloud_Are_you_collecting_data_that_are_not_needed_for_the_purpose_feature",
						"_UI_RealTimeBiddingCloud_type"),
				Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you processing data in an incompatible way with the purpose feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_processing_data_in_an_incompatible_way_with_the_purposePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_RealTimeBiddingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_RealTimeBiddingCloud_Are_you_processing_data_in_an_incompatible_way_with_the_purpose_feature",
						"_UI_RealTimeBiddingCloud_type"),
				Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you sharing data with other parties without having data subject consent feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_sharing_data_with_other_parties_without_having_data_subject_consentPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_RealTimeBiddingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_RealTimeBiddingCloud_Are_you_sharing_data_with_other_parties_without_having_data_subject_consent_feature",
						"_UI_RealTimeBiddingCloud_type"),
				Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you storing the data longer than is necessary for the purposes feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_storing_the_data_longer_than_is_necessary_for_the_purposesPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_RealTimeBiddingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_RealTimeBiddingCloud_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes_feature",
						"_UI_RealTimeBiddingCloud_type"),
				Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you overlooking appropriate security and allowing unauthorised or unlawful processing feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processingPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_RealTimeBiddingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_RealTimeBiddingCloud_Are_you_overlooking_appropriate_security_and_allowing_unauthorised_or_unlawful_processing_feature",
						"_UI_RealTimeBiddingCloud_type"),
				Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measuresPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_RealTimeBiddingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_RealTimeBiddingCloud_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures_feature",
						"_UI_RealTimeBiddingCloud_type"),
				Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Webhostingcloud feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addWebhostingcloudPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_RealTimeBiddingCloud_webhostingcloud_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_RealTimeBiddingCloud_webhostingcloud_feature",
						"_UI_RealTimeBiddingCloud_type"),
				Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__WEBHOSTINGCLOUD, true, false, true, null, null, null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__STORAGELOCATION);
			childrenFeatures.add(Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__DATASHARING);
			childrenFeatures.add(Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__TEST_ON_DUMMY);
			childrenFeatures.add(Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__CONTAINERISATION);
			childrenFeatures.add(Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__AGGREGATION);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns RealTimeBiddingCloud.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/RealTimeBiddingCloud"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((RealTimeBiddingCloud) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_RealTimeBiddingCloud_type")
				: getString("_UI_RealTimeBiddingCloud_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(RealTimeBiddingCloud.class)) {
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__ENCRYPTED_DATA:
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__PRIVACY_PATTERNS:
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__DATA_RETENTION:
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__ARE_YOU_COLLECTING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE:
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__ARE_YOU_PROCESSING_DATA_IN_AN_INCOMPATIBLE_WAY_WITH_THE_PURPOSE:
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__ARE_YOU_SHARING_DATA_WITH_OTHER_PARTIES_WITHOUT_HAVING_DATA_SUBJECT_CONSENT:
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__ARE_YOU_OVERLOOKING_APPROPRIATE_SECURITY_AND_ALLOWING_UNAUTHORISED_OR_UNLAWFUL_PROCESSING:
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__STORAGELOCATION:
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__DATASHARING:
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__TEST_ON_DUMMY:
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__CONTAINERISATION:
		case Cgm3Package.REAL_TIME_BIDDING_CLOUD__AGGREGATION:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__STORAGELOCATION,
				Cgm3Factory.eINSTANCE.createStorageLocation()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__DATASHARING,
				Cgm3Factory.eINSTANCE.createDataSharing()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__TEST_ON_DUMMY,
				Cgm3Factory.eINSTANCE.createTest_on_dummy()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__CONTAINERISATION,
				Cgm3Factory.eINSTANCE.createContainerisation()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.REAL_TIME_BIDDING_CLOUD__AGGREGATION,
				Cgm3Factory.eINSTANCE.createAggregation()));
	}

}
