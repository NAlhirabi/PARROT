/**
 */
package com.cardiffuni.pbdproject.cgm3.provider;

import com.cardiffuni.pbdproject.cgm3.Cgm3Factory;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Patient;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.cardiffuni.pbdproject.cgm3.Patient} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class PatientItemProvider extends GeneralEntityItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PatientItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addEncryptedDataPropertyDescriptor(object);
			addPrivacy_patternsPropertyDescriptor(object);
			addDoctorPropertyDescriptor(object);
			addAgePropertyDescriptor(object);
			addPhoneNumberPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Encrypted Data feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addEncryptedDataPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Encryption_EncryptedData_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Encryption_EncryptedData_feature",
								"_UI_Encryption_type"),
						Cgm3Package.Literals.ENCRYPTION__ENCRYPTED_DATA, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Privacy patterns feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPrivacy_patternsPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Privacy_patterns_Privacy_patterns_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Privacy_patterns_Privacy_patterns_feature",
								"_UI_Privacy_patterns_type"),
						Cgm3Package.Literals.PRIVACY_PATTERNS__PRIVACY_PATTERNS, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Doctor feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDoctorPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Patient_doctor_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Patient_doctor_feature",
								"_UI_Patient_type"),
						Cgm3Package.Literals.PATIENT__DOCTOR, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Age feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAgePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Patient_Age_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Patient_Age_feature", "_UI_Patient_type"),
						Cgm3Package.Literals.PATIENT__AGE, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Phone Number feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPhoneNumberPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Patient_PhoneNumber_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Patient_PhoneNumber_feature",
								"_UI_Patient_type"),
						Cgm3Package.Literals.PATIENT__PHONE_NUMBER, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(Cgm3Package.Literals.PATIENT__SMARTPHONE);
			childrenFeatures.add(Cgm3Package.Literals.PATIENT__CGMSENSOR);
			childrenFeatures.add(Cgm3Package.Literals.PATIENT__MEDICALRECORD);
			childrenFeatures.add(Cgm3Package.Literals.PATIENT__CONSENT_CHECKEDLIST);
			childrenFeatures.add(Cgm3Package.Literals.PATIENT__AUTHENTICATION);
			childrenFeatures.add(Cgm3Package.Literals.PATIENT__AUTHORIZATION);
			childrenFeatures.add(Cgm3Package.Literals.PATIENT__DATASHARING);
			childrenFeatures.add(Cgm3Package.Literals.PATIENT__COMPUTERBROWSER);
			childrenFeatures.add(Cgm3Package.Literals.PATIENT__WEBBROWSER);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns Patient.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Patient"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Patient) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_Patient_type")
				: getString("_UI_Patient_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Patient.class)) {
		case Cgm3Package.PATIENT__ENCRYPTED_DATA:
		case Cgm3Package.PATIENT__PRIVACY_PATTERNS:
		case Cgm3Package.PATIENT__AGE:
		case Cgm3Package.PATIENT__PHONE_NUMBER:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		case Cgm3Package.PATIENT__SMARTPHONE:
		case Cgm3Package.PATIENT__CGMSENSOR:
		case Cgm3Package.PATIENT__MEDICALRECORD:
		case Cgm3Package.PATIENT__CONSENT_CHECKEDLIST:
		case Cgm3Package.PATIENT__AUTHENTICATION:
		case Cgm3Package.PATIENT__AUTHORIZATION:
		case Cgm3Package.PATIENT__DATASHARING:
		case Cgm3Package.PATIENT__COMPUTERBROWSER:
		case Cgm3Package.PATIENT__WEBBROWSER:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.PATIENT__SMARTPHONE,
				Cgm3Factory.eINSTANCE.createSmartPhone()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.PATIENT__CGMSENSOR, Cgm3Factory.eINSTANCE.createCGMsensor()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.PATIENT__MEDICALRECORD,
				Cgm3Factory.eINSTANCE.createMedicalRecord()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.PATIENT__CONSENT_CHECKEDLIST,
				Cgm3Factory.eINSTANCE.createConsent_CheckedList()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.PATIENT__AUTHENTICATION,
				Cgm3Factory.eINSTANCE.createAuthentication()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.PATIENT__AUTHORIZATION,
				Cgm3Factory.eINSTANCE.createAuthorization()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.PATIENT__DATASHARING,
				Cgm3Factory.eINSTANCE.createDataSharing()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.PATIENT__COMPUTERBROWSER,
				Cgm3Factory.eINSTANCE.createComputerBrowser()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.PATIENT__WEBBROWSER,
				Cgm3Factory.eINSTANCE.createWebBrowser()));
	}

}
