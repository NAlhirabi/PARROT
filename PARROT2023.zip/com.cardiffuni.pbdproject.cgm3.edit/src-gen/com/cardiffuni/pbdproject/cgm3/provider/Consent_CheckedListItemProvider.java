/**
 */
package com.cardiffuni.pbdproject.cgm3.provider;

import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Consent_CheckedList;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.cardiffuni.pbdproject.cgm3.Consent_CheckedList} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class Consent_CheckedListItemProvider extends GeneralEntityItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Consent_CheckedListItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addCapture_age_authorization_if_age_is_less_than_16PropertyDescriptor(object);
			addCapture_withdrawal_logPropertyDescriptor(object);
			addCapture_log_Terms_of_use_AND_consent_to_processPropertyDescriptor(object);
			addCapture_consent_to_process_special_category_dataPropertyDescriptor(object);
			addCapture_consent_to_term_of_usePropertyDescriptor(object);
			addSurface_privacy_noticePropertyDescriptor(object);
			addCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_usedPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Capture age authorization if age is less than 16 feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCapture_age_authorization_if_age_is_less_than_16PropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Consent_CheckedList_Capture_age_authorization_if_age_is_less_than_16_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Consent_CheckedList_Capture_age_authorization_if_age_is_less_than_16_feature",
						"_UI_Consent_CheckedList_type"),
				Cgm3Package.Literals.CONSENT_CHECKED_LIST__CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16, true,
				false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Capture withdrawal log feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCapture_withdrawal_logPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Consent_CheckedList_Capture_withdrawal_log_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Consent_CheckedList_Capture_withdrawal_log_feature", "_UI_Consent_CheckedList_type"),
				Cgm3Package.Literals.CONSENT_CHECKED_LIST__CAPTURE_WITHDRAWAL_LOG, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Capture log Terms of use AND consent to process feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCapture_log_Terms_of_use_AND_consent_to_processPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Consent_CheckedList_Capture_log_Terms_of_use_AND_consent_to_process_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Consent_CheckedList_Capture_log_Terms_of_use_AND_consent_to_process_feature",
						"_UI_Consent_CheckedList_type"),
				Cgm3Package.Literals.CONSENT_CHECKED_LIST__CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS, true, false,
				false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Capture consent to process special category data feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCapture_consent_to_process_special_category_dataPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Consent_CheckedList_Capture_consent_to_process_special_category_data_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Consent_CheckedList_Capture_consent_to_process_special_category_data_feature",
						"_UI_Consent_CheckedList_type"),
				Cgm3Package.Literals.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA, true,
				false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Capture consent to term of use feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCapture_consent_to_term_of_usePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Consent_CheckedList_Capture_consent_to_term_of_use_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Consent_CheckedList_Capture_consent_to_term_of_use_feature",
						"_UI_Consent_CheckedList_type"),
				Cgm3Package.Literals.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_TERM_OF_USE, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Surface privacy notice feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addSurface_privacy_noticePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Consent_CheckedList_Surface_privacy_notice_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Consent_CheckedList_Surface_privacy_notice_feature", "_UI_Consent_CheckedList_type"),
				Cgm3Package.Literals.CONSENT_CHECKED_LIST__SURFACE_PRIVACY_NOTICE, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Capture consent to the type of marketing if electronic marketing is used feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCapture_consent_to_the_type_of_marketing_if_electronic_marketing_is_usedPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_Consent_CheckedList_Capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Consent_CheckedList_Capture_consent_to_the_type_of_marketing_if_electronic_marketing_is_used_feature",
						"_UI_Consent_CheckedList_type"),
				Cgm3Package.Literals.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This returns Consent_CheckedList.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Consent_CheckedList"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Consent_CheckedList) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_Consent_CheckedList_type")
				: getString("_UI_Consent_CheckedList_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Consent_CheckedList.class)) {
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_AGE_AUTHORIZATION_IF_AGE_IS_LESS_THAN_16:
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_WITHDRAWAL_LOG:
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_LOG_TERMS_OF_USE_AND_CONSENT_TO_PROCESS:
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_PROCESS_SPECIAL_CATEGORY_DATA:
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_TERM_OF_USE:
		case Cgm3Package.CONSENT_CHECKED_LIST__SURFACE_PRIVACY_NOTICE:
		case Cgm3Package.CONSENT_CHECKED_LIST__CAPTURE_CONSENT_TO_THE_TYPE_OF_MARKETING_IF_ELECTRONIC_MARKETING_IS_USED:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

}
