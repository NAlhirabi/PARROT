/**
 */
package com.cardiffuni.pbdproject.cgm3.provider;

import com.cardiffuni.pbdproject.cgm3.Bus;
import com.cardiffuni.pbdproject.cgm3.Cgm3Factory;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.cardiffuni.pbdproject.cgm3.Bus} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class BusItemProvider extends GeneralEntityItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BusItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addPlate_numberPropertyDescriptor(object);
			addRoute_numberPropertyDescriptor(object);
			addDriver_namePropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Plate number feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPlate_numberPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Bus_Plate_number_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Bus_Plate_number_feature", "_UI_Bus_type"),
						Cgm3Package.Literals.BUS__PLATE_NUMBER, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Route number feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addRoute_numberPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Bus_Route_number_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Bus_Route_number_feature", "_UI_Bus_type"),
						Cgm3Package.Literals.BUS__ROUTE_NUMBER, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Driver name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDriver_namePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Bus_Driver_name_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Bus_Driver_name_feature", "_UI_Bus_type"),
						Cgm3Package.Literals.BUS__DRIVER_NAME, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(Cgm3Package.Literals.BUS__GPSTRACKER);
			childrenFeatures.add(Cgm3Package.Literals.BUS__VIDEOWITHOUTANALYTICS);
			childrenFeatures.add(Cgm3Package.Literals.BUS__DRIVER);
			childrenFeatures.add(Cgm3Package.Literals.BUS__VIDEOANALYTICS);
			childrenFeatures.add(Cgm3Package.Literals.BUS__VIDEOPROCESSINGCLOUD);
			childrenFeatures.add(Cgm3Package.Literals.BUS__CUSTOMER);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns Bus.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Bus"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Bus) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_Bus_type")
				: getString("_UI_Bus_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Bus.class)) {
		case Cgm3Package.BUS__PLATE_NUMBER:
		case Cgm3Package.BUS__ROUTE_NUMBER:
		case Cgm3Package.BUS__DRIVER_NAME:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		case Cgm3Package.BUS__GPSTRACKER:
		case Cgm3Package.BUS__VIDEOWITHOUTANALYTICS:
		case Cgm3Package.BUS__DRIVER:
		case Cgm3Package.BUS__VIDEOANALYTICS:
		case Cgm3Package.BUS__VIDEOPROCESSINGCLOUD:
		case Cgm3Package.BUS__CUSTOMER:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.BUS__GPSTRACKER, Cgm3Factory.eINSTANCE.createGPSTracker()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.BUS__VIDEOWITHOUTANALYTICS,
				Cgm3Factory.eINSTANCE.createVideoWithoutAnalytics()));

		newChildDescriptors
				.add(createChildParameter(Cgm3Package.Literals.BUS__DRIVER, Cgm3Factory.eINSTANCE.createDriver()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.BUS__VIDEOANALYTICS,
				Cgm3Factory.eINSTANCE.createVideoAnalytics()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.BUS__VIDEOPROCESSINGCLOUD,
				Cgm3Factory.eINSTANCE.createVideoProcessingCloud()));

		newChildDescriptors
				.add(createChildParameter(Cgm3Package.Literals.BUS__CUSTOMER, Cgm3Factory.eINSTANCE.createCustomer()));
	}

}
