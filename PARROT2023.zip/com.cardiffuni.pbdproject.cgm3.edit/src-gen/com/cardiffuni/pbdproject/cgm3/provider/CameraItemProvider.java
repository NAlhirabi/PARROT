/**
 */
package com.cardiffuni.pbdproject.cgm3.provider;

import com.cardiffuni.pbdproject.cgm3.Camera;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.cardiffuni.pbdproject.cgm3.Camera} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class CameraItemProvider extends GeneralEntityItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CameraItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addEncryptedDataPropertyDescriptor(object);
			addPrivacy_patternsPropertyDescriptor(object);
			addAre_you_sending_data_without_anonymisationPropertyDescriptor(object);
			addDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTVPropertyDescriptor(object);
			addDo_people_aware_of_being_recordedPropertyDescriptor(object);
			addAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_dataPropertyDescriptor(
					object);
			addAre_you_storing_the_footage_in_a_secure_locationPropertyDescriptor(object);
			addEnsure_data_minimisation_is_apliedPropertyDescriptor(object);
			addDo_you_use_signs_that_say_CCTV_is_in_operationPropertyDescriptor(object);
			addDoes_the_system_record_information_other_than_the_purposePropertyDescriptor(object);
			addRecord_retention_periodPropertyDescriptor(object);
			addAre_you_allowing_data_unauthorised_accessPropertyDescriptor(object);
			addAre_you_storing_the_data_longer_than_is_necessary_for_the_purposesPropertyDescriptor(object);
			addIs_data_against_accidental_loss_or_destruction_or_damagePropertyDescriptor(object);
			addCloudservicePropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Encrypted Data feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addEncryptedDataPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Encryption_EncryptedData_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Encryption_EncryptedData_feature",
								"_UI_Encryption_type"),
						Cgm3Package.Literals.ENCRYPTION__ENCRYPTED_DATA, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Privacy patterns feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPrivacy_patternsPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Privacy_patterns_Privacy_patterns_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Privacy_patterns_Privacy_patterns_feature",
								"_UI_Privacy_patterns_type"),
						Cgm3Package.Literals.PRIVACY_PATTERNS__PRIVACY_PATTERNS, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you sending data without anonymisation feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_sending_data_without_anonymisationPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Camera_Are_you_sending_data_without_anonymisation_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Camera_Are_you_sending_data_without_anonymisation_feature", "_UI_Camera_type"),
				Cgm3Package.Literals.CAMERA__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Does the sign has abrief explanation about the purpose of CCTV feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDoes_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTVPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Camera_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Camera_Does_the_sign_has_a_brief_explanation_about_the_purpose_of_CCTV_feature",
						"_UI_Camera_type"),
				Cgm3Package.Literals.CAMERA__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV, true,
				false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Do people aware of being recorded feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDo_people_aware_of_being_recordedPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Camera_Do_people_aware_of_being_recorded_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_Camera_Do_people_aware_of_being_recorded_feature",
						"_UI_Camera_type"),
				Cgm3Package.Literals.CAMERA__DO_PEOPLE_AWARE_OF_BEING_RECORDED, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you using appropriate technical or organisational measures to protect the data feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_dataPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_Camera_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Camera_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data_feature",
						"_UI_Camera_type"),
				Cgm3Package.Literals.CAMERA__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you storing the footage in asecure location feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_storing_the_footage_in_a_secure_locationPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Camera_Are_you_storing_the_footage_in_a_secure_location_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Camera_Are_you_storing_the_footage_in_a_secure_location_feature", "_UI_Camera_type"),
				Cgm3Package.Literals.CAMERA__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Ensure data minimisation is aplied feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addEnsure_data_minimisation_is_apliedPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Camera_Ensure_data_minimisation_is_aplied_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_Camera_Ensure_data_minimisation_is_aplied_feature",
						"_UI_Camera_type"),
				Cgm3Package.Literals.CAMERA__ENSURE_DATA_MINIMISATION_IS_APLIED, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Do you use signs that say CCTV is in operation feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDo_you_use_signs_that_say_CCTV_is_in_operationPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Camera_Do_you_use_signs_that_say_CCTV_is_in_operation_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Camera_Do_you_use_signs_that_say_CCTV_is_in_operation_feature", "_UI_Camera_type"),
				Cgm3Package.Literals.CAMERA__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Does the system record information other than the purpose feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDoes_the_system_record_information_other_than_the_purposePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Camera_Does_the_system_record_information_other_than_the_purpose_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Camera_Does_the_system_record_information_other_than_the_purpose_feature",
						"_UI_Camera_type"),
				Cgm3Package.Literals.CAMERA__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE, true, false,
				false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Record retention period feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addRecord_retention_periodPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Camera_Record_retention_period_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Camera_Record_retention_period_feature",
								"_UI_Camera_type"),
						Cgm3Package.Literals.CAMERA__RECORD_RETENTION_PERIOD, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you allowing data unauthorised access feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_allowing_data_unauthorised_accessPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Camera_Are_you_allowing_data_unauthorised_access_feature"),
						getString("_UI_PropertyDescriptor_description",
								"_UI_Camera_Are_you_allowing_data_unauthorised_access_feature", "_UI_Camera_type"),
						Cgm3Package.Literals.CAMERA__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you storing the data longer than is necessary for the purposes feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_storing_the_data_longer_than_is_necessary_for_the_purposesPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Camera_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Camera_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes_feature",
						"_UI_Camera_type"),
				Cgm3Package.Literals.CAMERA__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES, true,
				false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Is data against accidental loss or destruction or damage feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addIs_data_against_accidental_loss_or_destruction_or_damagePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Camera_Is_data_against_accidental_loss_or_destruction_or_damage_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Camera_Is_data_against_accidental_loss_or_destruction_or_damage_feature",
						"_UI_Camera_type"),
				Cgm3Package.Literals.CAMERA__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE, true, false,
				false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Cloudservice feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCloudservicePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Camera_cloudservice_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Camera_cloudservice_feature",
								"_UI_Camera_type"),
						Cgm3Package.Literals.CAMERA__CLOUDSERVICE, true, false, true, null, null, null));
	}

	/**
	 * This returns Camera.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Camera"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Camera) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_Camera_type")
				: getString("_UI_Camera_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Camera.class)) {
		case Cgm3Package.CAMERA__ENCRYPTED_DATA:
		case Cgm3Package.CAMERA__PRIVACY_PATTERNS:
		case Cgm3Package.CAMERA__ARE_YOU_SENDING_DATA_WITHOUT_ANONYMISATION:
		case Cgm3Package.CAMERA__DOES_THE_SIGN_HAS_ABRIEF_EXPLANATION_ABOUT_THE_PURPOSE_OF_CCTV:
		case Cgm3Package.CAMERA__DO_PEOPLE_AWARE_OF_BEING_RECORDED:
		case Cgm3Package.CAMERA__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
		case Cgm3Package.CAMERA__ARE_YOU_STORING_THE_FOOTAGE_IN_ASECURE_LOCATION:
		case Cgm3Package.CAMERA__ENSURE_DATA_MINIMISATION_IS_APLIED:
		case Cgm3Package.CAMERA__DO_YOU_USE_SIGNS_THAT_SAY_CCTV_IS_IN_OPERATION:
		case Cgm3Package.CAMERA__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
		case Cgm3Package.CAMERA__RECORD_RETENTION_PERIOD:
		case Cgm3Package.CAMERA__ARE_YOU_ALLOWING_DATA_UNAUTHORISED_ACCESS:
		case Cgm3Package.CAMERA__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
		case Cgm3Package.CAMERA__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

}
