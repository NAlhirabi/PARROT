/**
 */
package com.cardiffuni.pbdproject.cgm3.provider;

import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Cookies;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.cardiffuni.pbdproject.cgm3.Cookies} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class CookiesItemProvider extends GeneralEntityItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CookiesItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addUse_the_surface_cookies_banner_if_cookies_are_placedPropertyDescriptor(object);
			addThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_addedPropertyDescriptor(object);
			addThe_cookie_banner_must_be_resurfaced_if_browser_settings_changePropertyDescriptor(object);
			addCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_usedPropertyDescriptor(
					object);
			addPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_usedPropertyDescriptor(
					object);
			addConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArcPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Use the surface cookies banner if cookies are placed feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addUse_the_surface_cookies_banner_if_cookies_are_placedPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Cookies_Use_the_surface_cookies_banner_if_cookies_are_placed_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Cookies_Use_the_surface_cookies_banner_if_cookies_are_placed_feature", "_UI_Cookies_type"),
				Cgm3Package.Literals.COOKIES__USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the The cookie banner must be resurfaced if new cookies are added feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addThe_cookie_banner_must_be_resurfaced_if_new_cookies_are_addedPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Cookies_The_cookie_banner_must_be_resurfaced_if_new_cookies_are_added_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Cookies_The_cookie_banner_must_be_resurfaced_if_new_cookies_are_added_feature",
						"_UI_Cookies_type"),
				Cgm3Package.Literals.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED, true,
				false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the The cookie banner must be resurfaced if browser settings change feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addThe_cookie_banner_must_be_resurfaced_if_browser_settings_changePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Cookies_The_cookie_banner_must_be_resurfaced_if_browser_settings_change_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Cookies_The_cookie_banner_must_be_resurfaced_if_browser_settings_change_feature",
						"_UI_Cookies_type"),
				Cgm3Package.Literals.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE, true,
				false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Capture consent or acceptance if necessary OR Analytics OR Ad targeting cookies are used feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCapture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_usedPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_Cookies_Capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Cookies_Capture_consent_or_acceptance_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used_feature",
						"_UI_Cookies_type"),
				Cgm3Package.Literals.COOKIES__CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Place cookies according to consent if necessary OR Analytics OR Ad targeting cookies are used feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPlace_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_usedPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_Cookies_Place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Cookies_Place_cookies_according_to_consent_if_necessary_OR_Analytics_OR_Ad_targeting_cookies_are_used_feature",
						"_UI_Cookies_type"),
				Cgm3Package.Literals.COOKIES__PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Consider the option of using athird party tool such as One Trus or Trust Arc feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addConsider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArcPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_Cookies_Consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Cookies_Consider_the_option_of_using_a_third_party_tool_such_as_OneTrus_or_TrustArc_feature",
						"_UI_Cookies_type"),
				Cgm3Package.Literals.COOKIES__CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This returns Cookies.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Cookies"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Cookies) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_Cookies_type")
				: getString("_UI_Cookies_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Cookies.class)) {
		case Cgm3Package.COOKIES__USE_THE_SURFACE_COOKIES_BANNER_IF_COOKIES_ARE_PLACED:
		case Cgm3Package.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_NEW_COOKIES_ARE_ADDED:
		case Cgm3Package.COOKIES__THE_COOKIE_BANNER_MUST_BE_RESURFACED_IF_BROWSER_SETTINGS_CHANGE:
		case Cgm3Package.COOKIES__CAPTURE_CONSENT_OR_ACCEPTANCE_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED:
		case Cgm3Package.COOKIES__PLACE_COOKIES_ACCORDING_TO_CONSENT_IF_NECESSARY_OR_ANALYTICS_OR_AD_TARGETING_COOKIES_ARE_USED:
		case Cgm3Package.COOKIES__CONSIDER_THE_OPTION_OF_USING_ATHIRD_PARTY_TOOL_SUCH_AS_ONE_TRUS_OR_TRUST_ARC:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

}
