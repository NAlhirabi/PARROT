/**
 */
package com.cardiffuni.pbdproject.cgm3.provider;

import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.UserLocation;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.cardiffuni.pbdproject.cgm3.UserLocation} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class UserLocationItemProvider extends GeneralEntityItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public UserLocationItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addLocationPropertyDescriptor(object);
			addAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_neededPropertyDescriptor(
					object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Location feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addLocationPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_UserLocation_Location_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_UserLocation_Location_feature",
								"_UI_UserLocation_type"),
						Cgm3Package.Literals.USER_LOCATION__LOCATION, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you planning to collect the exact location of the data subject when the location is not needed feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_neededPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_UserLocation_Are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_UserLocation_Are_you_planning_to_collect_the_exact_location_of_the_data_subject_when_the_location_is_not_needed_feature",
						"_UI_UserLocation_type"),
				Cgm3Package.Literals.USER_LOCATION__ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This returns UserLocation.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/UserLocation"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((UserLocation) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_UserLocation_type")
				: getString("_UI_UserLocation_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(UserLocation.class)) {
		case Cgm3Package.USER_LOCATION__LOCATION:
		case Cgm3Package.USER_LOCATION__ARE_YOU_PLANNING_TO_COLLECT_THE_EXACT_LOCATION_OF_THE_DATA_SUBJECT_WHEN_THE_LOCATION_IS_NOT_NEEDED:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

}
