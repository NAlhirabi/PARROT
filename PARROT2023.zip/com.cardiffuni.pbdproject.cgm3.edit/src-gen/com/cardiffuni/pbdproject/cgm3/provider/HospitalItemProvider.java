/**
 */
package com.cardiffuni.pbdproject.cgm3.provider;

import com.cardiffuni.pbdproject.cgm3.Cgm3Factory;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Hospital;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EStructuralFeature;

import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.cardiffuni.pbdproject.cgm3.Hospital} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class HospitalItemProvider extends GeneralEntityItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HospitalItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

		}
		return itemPropertyDescriptors;
	}

	/**
	 * This specifies how to implement {@link #getChildren} and is used to deduce an appropriate feature for an
	 * {@link org.eclipse.emf.edit.command.AddCommand}, {@link org.eclipse.emf.edit.command.RemoveCommand} or
	 * {@link org.eclipse.emf.edit.command.MoveCommand} in {@link #createCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Collection<? extends EStructuralFeature> getChildrenFeatures(Object object) {
		if (childrenFeatures == null) {
			super.getChildrenFeatures(object);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__PATIENT);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__DOCTOR);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__RESEARCHER);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__NURSE);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__CLOUD);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__WEBSITE);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__SMARTPHONE);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__CGMSENSOR);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__MEDICALRECORD);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__CONSENT_CHECKEDLIST);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__STORAGELOCATION);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__USERLOCATION);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__RISKCODE);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__ENCRYPTION);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__DATASHARING);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__WARNING);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__TEST_ON_DUMMY);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__CONTAINERISATION);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__AGGREGATION);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__COMPUTERBROWSER);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__PHARMACYCLOUD);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__SHIPPINGCLOUD);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__WEBHOSTINGCLOUD);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__PAYMENTCLOUD);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__SOCIALNETWORKCLOUD);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__WEBBROWSER);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__CLOUDFORPHARMACY);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__REALTIMEBIDDINGCLOUD);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__GPSTRACKER);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__BUS);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__DRIVER);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__CUSTOMER);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__VIDEOANALYTICS);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__ANALYTICS);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__BLURRING);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__VIDEOPROCESSINGCLOUD);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__VIDEOWITHOUTANALYTICS);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__CLIENT);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__CLOUDSERVICE);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__LIGHTSENSOR);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__PHONE);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__THERMOSTAT);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__DOORLOCK);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__CAMERA);
			childrenFeatures.add(Cgm3Package.Literals.HOSPITAL__COOKIES);
		}
		return childrenFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EStructuralFeature getChildFeature(Object object, Object child) {
		// Check the type of the specified child object and return the proper feature to use for
		// adding (see {@link AddCommand}) it as a child.

		return super.getChildFeature(object, child);
	}

	/**
	 * This returns Hospital.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Hospital"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Hospital) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_Hospital_type")
				: getString("_UI_Hospital_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Hospital.class)) {
		case Cgm3Package.HOSPITAL__PATIENT:
		case Cgm3Package.HOSPITAL__DOCTOR:
		case Cgm3Package.HOSPITAL__RESEARCHER:
		case Cgm3Package.HOSPITAL__NURSE:
		case Cgm3Package.HOSPITAL__CLOUD:
		case Cgm3Package.HOSPITAL__WEBSITE:
		case Cgm3Package.HOSPITAL__SMARTPHONE:
		case Cgm3Package.HOSPITAL__CGMSENSOR:
		case Cgm3Package.HOSPITAL__MEDICALRECORD:
		case Cgm3Package.HOSPITAL__CONSENT_CHECKEDLIST:
		case Cgm3Package.HOSPITAL__STORAGELOCATION:
		case Cgm3Package.HOSPITAL__USERLOCATION:
		case Cgm3Package.HOSPITAL__RISKCODE:
		case Cgm3Package.HOSPITAL__ENCRYPTION:
		case Cgm3Package.HOSPITAL__DATASHARING:
		case Cgm3Package.HOSPITAL__WARNING:
		case Cgm3Package.HOSPITAL__TEST_ON_DUMMY:
		case Cgm3Package.HOSPITAL__CONTAINERISATION:
		case Cgm3Package.HOSPITAL__AGGREGATION:
		case Cgm3Package.HOSPITAL__COMPUTERBROWSER:
		case Cgm3Package.HOSPITAL__PHARMACYCLOUD:
		case Cgm3Package.HOSPITAL__SHIPPINGCLOUD:
		case Cgm3Package.HOSPITAL__WEBHOSTINGCLOUD:
		case Cgm3Package.HOSPITAL__PAYMENTCLOUD:
		case Cgm3Package.HOSPITAL__SOCIALNETWORKCLOUD:
		case Cgm3Package.HOSPITAL__WEBBROWSER:
		case Cgm3Package.HOSPITAL__CLOUDFORPHARMACY:
		case Cgm3Package.HOSPITAL__REALTIMEBIDDINGCLOUD:
		case Cgm3Package.HOSPITAL__GPSTRACKER:
		case Cgm3Package.HOSPITAL__BUS:
		case Cgm3Package.HOSPITAL__DRIVER:
		case Cgm3Package.HOSPITAL__CUSTOMER:
		case Cgm3Package.HOSPITAL__VIDEOANALYTICS:
		case Cgm3Package.HOSPITAL__ANALYTICS:
		case Cgm3Package.HOSPITAL__BLURRING:
		case Cgm3Package.HOSPITAL__VIDEOPROCESSINGCLOUD:
		case Cgm3Package.HOSPITAL__VIDEOWITHOUTANALYTICS:
		case Cgm3Package.HOSPITAL__CLIENT:
		case Cgm3Package.HOSPITAL__CLOUDSERVICE:
		case Cgm3Package.HOSPITAL__LIGHTSENSOR:
		case Cgm3Package.HOSPITAL__PHONE:
		case Cgm3Package.HOSPITAL__THERMOSTAT:
		case Cgm3Package.HOSPITAL__DOORLOCK:
		case Cgm3Package.HOSPITAL__CAMERA:
		case Cgm3Package.HOSPITAL__COOKIES:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), true, false));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__PATIENT, Cgm3Factory.eINSTANCE.createPatient()));

		newChildDescriptors
				.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__DOCTOR, Cgm3Factory.eINSTANCE.createDoctor()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__RESEARCHER,
				Cgm3Factory.eINSTANCE.createResearcher()));

		newChildDescriptors
				.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__NURSE, Cgm3Factory.eINSTANCE.createNurse()));

		newChildDescriptors
				.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__CLOUD, Cgm3Factory.eINSTANCE.createCloud()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__WEBSITE, Cgm3Factory.eINSTANCE.createWebsite()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__SMARTPHONE,
				Cgm3Factory.eINSTANCE.createSmartPhone()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__CGMSENSOR,
				Cgm3Factory.eINSTANCE.createCGMsensor()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__MEDICALRECORD,
				Cgm3Factory.eINSTANCE.createMedicalRecord()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__CONSENT_CHECKEDLIST,
				Cgm3Factory.eINSTANCE.createConsent_CheckedList()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__STORAGELOCATION,
				Cgm3Factory.eINSTANCE.createStorageLocation()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__USERLOCATION,
				Cgm3Factory.eINSTANCE.createUserLocation()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__RISKCODE, Cgm3Factory.eINSTANCE.createRiskCode()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createCGMsensor()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createSmartPhone()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION, Cgm3Factory.eINSTANCE.createPatient()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION, Cgm3Factory.eINSTANCE.createDoctor()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION, Cgm3Factory.eINSTANCE.createCloud()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION, Cgm3Factory.eINSTANCE.createWebsite()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createResearcher()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createComputerBrowser()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createPharmacyCloudold()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createShippingCloud()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createWebhostingCloud()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createPaymentCloud()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createSocialNetworkCloud()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createRealTimeBiddingCloud()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createWebBrowser()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createCloudForPharmacy()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createVideoAnalytics()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createVideoWithoutAnalytics()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createVideoProcessingCloud()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION, Cgm3Factory.eINSTANCE.createClient()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createCloudService()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createLightSensor()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION, Cgm3Factory.eINSTANCE.createPhone()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createDoorLock()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION,
				Cgm3Factory.eINSTANCE.createThermostat()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__ENCRYPTION, Cgm3Factory.eINSTANCE.createCamera()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__DATASHARING,
				Cgm3Factory.eINSTANCE.createDataSharing()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__WARNING, Cgm3Factory.eINSTANCE.createWarning()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__TEST_ON_DUMMY,
				Cgm3Factory.eINSTANCE.createTest_on_dummy()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__CONTAINERISATION,
				Cgm3Factory.eINSTANCE.createContainerisation()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__AGGREGATION,
				Cgm3Factory.eINSTANCE.createAggregation()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__COMPUTERBROWSER,
				Cgm3Factory.eINSTANCE.createComputerBrowser()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__PHARMACYCLOUD,
				Cgm3Factory.eINSTANCE.createPharmacyCloudold()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__SHIPPINGCLOUD,
				Cgm3Factory.eINSTANCE.createShippingCloud()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__WEBHOSTINGCLOUD,
				Cgm3Factory.eINSTANCE.createWebhostingCloud()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__PAYMENTCLOUD,
				Cgm3Factory.eINSTANCE.createPaymentCloud()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__SOCIALNETWORKCLOUD,
				Cgm3Factory.eINSTANCE.createSocialNetworkCloud()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__WEBBROWSER,
				Cgm3Factory.eINSTANCE.createWebBrowser()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__CLOUDFORPHARMACY,
				Cgm3Factory.eINSTANCE.createCloudForPharmacy()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__REALTIMEBIDDINGCLOUD,
				Cgm3Factory.eINSTANCE.createRealTimeBiddingCloud()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__GPSTRACKER,
				Cgm3Factory.eINSTANCE.createGPSTracker()));

		newChildDescriptors
				.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__BUS, Cgm3Factory.eINSTANCE.createBus()));

		newChildDescriptors
				.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__DRIVER, Cgm3Factory.eINSTANCE.createDriver()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__CUSTOMER, Cgm3Factory.eINSTANCE.createCustomer()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__VIDEOANALYTICS,
				Cgm3Factory.eINSTANCE.createVideoAnalytics()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__ANALYTICS,
				Cgm3Factory.eINSTANCE.createAnalytics()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__BLURRING, Cgm3Factory.eINSTANCE.createBlurring()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__VIDEOPROCESSINGCLOUD,
				Cgm3Factory.eINSTANCE.createVideoProcessingCloud()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__VIDEOWITHOUTANALYTICS,
				Cgm3Factory.eINSTANCE.createVideoWithoutAnalytics()));

		newChildDescriptors
				.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__CLIENT, Cgm3Factory.eINSTANCE.createClient()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__CLOUDSERVICE,
				Cgm3Factory.eINSTANCE.createCloudService()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__LIGHTSENSOR,
				Cgm3Factory.eINSTANCE.createLightSensor()));

		newChildDescriptors
				.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__PHONE, Cgm3Factory.eINSTANCE.createPhone()));

		newChildDescriptors.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__THERMOSTAT,
				Cgm3Factory.eINSTANCE.createThermostat()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__DOORLOCK, Cgm3Factory.eINSTANCE.createDoorLock()));

		newChildDescriptors
				.add(createChildParameter(Cgm3Package.Literals.HOSPITAL__CAMERA, Cgm3Factory.eINSTANCE.createCamera()));

		newChildDescriptors.add(
				createChildParameter(Cgm3Package.Literals.HOSPITAL__COOKIES, Cgm3Factory.eINSTANCE.createCookies()));
	}

	/**
	 * This returns the label text for {@link org.eclipse.emf.edit.command.CreateChildCommand}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getCreateChildText(Object owner, Object feature, Object child, Collection<?> selection) {
		Object childFeature = feature;
		Object childObject = child;

		boolean qualify = childFeature == Cgm3Package.Literals.HOSPITAL__PATIENT
				|| childFeature == Cgm3Package.Literals.HOSPITAL__ENCRYPTION
				|| childFeature == Cgm3Package.Literals.HOSPITAL__DOCTOR
				|| childFeature == Cgm3Package.Literals.HOSPITAL__RESEARCHER
				|| childFeature == Cgm3Package.Literals.HOSPITAL__CLOUD
				|| childFeature == Cgm3Package.Literals.HOSPITAL__WEBSITE
				|| childFeature == Cgm3Package.Literals.HOSPITAL__SMARTPHONE
				|| childFeature == Cgm3Package.Literals.HOSPITAL__CGMSENSOR
				|| childFeature == Cgm3Package.Literals.HOSPITAL__COMPUTERBROWSER
				|| childFeature == Cgm3Package.Literals.HOSPITAL__PHARMACYCLOUD
				|| childFeature == Cgm3Package.Literals.HOSPITAL__SHIPPINGCLOUD
				|| childFeature == Cgm3Package.Literals.HOSPITAL__WEBHOSTINGCLOUD
				|| childFeature == Cgm3Package.Literals.HOSPITAL__PAYMENTCLOUD
				|| childFeature == Cgm3Package.Literals.HOSPITAL__SOCIALNETWORKCLOUD
				|| childFeature == Cgm3Package.Literals.HOSPITAL__REALTIMEBIDDINGCLOUD
				|| childFeature == Cgm3Package.Literals.HOSPITAL__WEBBROWSER
				|| childFeature == Cgm3Package.Literals.HOSPITAL__CLOUDFORPHARMACY
				|| childFeature == Cgm3Package.Literals.HOSPITAL__VIDEOANALYTICS
				|| childFeature == Cgm3Package.Literals.HOSPITAL__VIDEOWITHOUTANALYTICS
				|| childFeature == Cgm3Package.Literals.HOSPITAL__VIDEOPROCESSINGCLOUD
				|| childFeature == Cgm3Package.Literals.HOSPITAL__CLIENT
				|| childFeature == Cgm3Package.Literals.HOSPITAL__CLOUDSERVICE
				|| childFeature == Cgm3Package.Literals.HOSPITAL__LIGHTSENSOR
				|| childFeature == Cgm3Package.Literals.HOSPITAL__PHONE
				|| childFeature == Cgm3Package.Literals.HOSPITAL__DOORLOCK
				|| childFeature == Cgm3Package.Literals.HOSPITAL__THERMOSTAT
				|| childFeature == Cgm3Package.Literals.HOSPITAL__CAMERA;

		if (qualify) {
			return getString("_UI_CreateChild_text2",
					new Object[] { getTypeText(childObject), getFeatureText(childFeature), getTypeText(owner) });
		}
		return super.getCreateChildText(owner, feature, child, selection);
	}

}
