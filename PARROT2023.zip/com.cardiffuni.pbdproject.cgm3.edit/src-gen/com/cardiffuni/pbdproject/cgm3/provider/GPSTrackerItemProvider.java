/**
 */
package com.cardiffuni.pbdproject.cgm3.provider;

import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.GPSTracker;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.cardiffuni.pbdproject.cgm3.GPSTracker} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class GPSTrackerItemProvider extends GeneralEntityItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GPSTrackerItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addIDPropertyDescriptor(object);
			addCoordinatesPropertyDescriptor(object);
			addSpeedPropertyDescriptor(object);
			addDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooksPropertyDescriptor(object);
			addRecord_retention_periodPropertyDescriptor(object);
			addDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehiclesPropertyDescriptor(object);
			addIs_data_against_accidental_loss_or_destruction_or_damagePropertyDescriptor(object);
			addAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_dataPropertyDescriptor(
					object);
			addAre_you_storing_the_data_longer_than_is_necessary_for_the_purposesPropertyDescriptor(object);
			addAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoringPropertyDescriptor(
					object);
			addDoes_the_staff_aware_of_the_use_of_the_GPS_systemsPropertyDescriptor(object);
			addDoes_the_system_record_information_other_than_the_purposePropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the ID feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addIDPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_GPSTracker_ID_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_GPSTracker_ID_feature",
								"_UI_GPSTracker_type"),
						Cgm3Package.Literals.GPS_TRACKER__ID, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Coordinates feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCoordinatesPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_GPSTracker_Coordinates_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_GPSTracker_Coordinates_feature",
								"_UI_GPSTracker_type"),
						Cgm3Package.Literals.GPS_TRACKER__COORDINATES, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Speed feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addSpeedPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_GPSTracker_Speed_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_GPSTracker_Speed_feature",
								"_UI_GPSTracker_type"),
						Cgm3Package.Literals.GPS_TRACKER__SPEED, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Does the use of GPS is fully explained in company policies and staff handbooks feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDoes_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooksPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_GPSTracker_Does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_GPSTracker_Does_the_use_of_GPS_is_fully_explained_in_company_policies_and_staff_handbooks_feature",
						"_UI_GPSTracker_type"),
				Cgm3Package.Literals.GPS_TRACKER__DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Record retention period feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addRecord_retention_periodPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_GPSTracker_Record_retention_period_feature"),
				getString("_UI_PropertyDescriptor_description", "_UI_GPSTracker_Record_retention_period_feature",
						"_UI_GPSTracker_type"),
				Cgm3Package.Literals.GPS_TRACKER__RECORD_RETENTION_PERIOD, true, false, false,
				ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Does consent have been gathered from the staff who used these vehicles feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDoes_consent_have_been_gathered_from_the_staff_who_used_these_vehiclesPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_GPSTracker_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_GPSTracker_Does_consent_have_been_gathered_from_the_staff_who_used_these_vehicles_feature",
						"_UI_GPSTracker_type"),
				Cgm3Package.Literals.GPS_TRACKER__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Is data against accidental loss or destruction or damage feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addIs_data_against_accidental_loss_or_destruction_or_damagePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_GPSTracker_Is_data_against_accidental_loss_or_destruction_or_damage_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_GPSTracker_Is_data_against_accidental_loss_or_destruction_or_damage_feature",
						"_UI_GPSTracker_type"),
				Cgm3Package.Literals.GPS_TRACKER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE, true, false,
				false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you using appropriate technical or organisational measures to protect the data feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_dataPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_GPSTracker_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_GPSTracker_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data_feature",
						"_UI_GPSTracker_type"),
				Cgm3Package.Literals.GPS_TRACKER__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you storing the data longer than is necessary for the purposes feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_storing_the_data_longer_than_is_necessary_for_the_purposesPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_GPSTracker_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_GPSTracker_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes_feature",
						"_UI_GPSTracker_type"),
				Cgm3Package.Literals.GPS_TRACKER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you processing data that are not needed for the purpose such employee monitoring feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoringPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_GPSTracker_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_GPSTracker_Are_you_processing_data_that_are_not_needed_for_the_purpose_such_employee_monitoring_feature",
						"_UI_GPSTracker_type"),
				Cgm3Package.Literals.GPS_TRACKER__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Does the staff aware of the use of the GPS systems feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDoes_the_staff_aware_of_the_use_of_the_GPS_systemsPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_GPSTracker_Does_the_staff_aware_of_the_use_of_the_GPS_systems_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_GPSTracker_Does_the_staff_aware_of_the_use_of_the_GPS_systems_feature",
						"_UI_GPSTracker_type"),
				Cgm3Package.Literals.GPS_TRACKER__DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS, true, false,
				false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Does the system record information other than the purpose feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDoes_the_system_record_information_other_than_the_purposePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_GPSTracker_Does_the_system_record_information_other_than_the_purpose_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_GPSTracker_Does_the_system_record_information_other_than_the_purpose_feature",
						"_UI_GPSTracker_type"),
				Cgm3Package.Literals.GPS_TRACKER__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE, true,
				false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This returns GPSTracker.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/GPSTracker"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((GPSTracker) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_GPSTracker_type")
				: getString("_UI_GPSTracker_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(GPSTracker.class)) {
		case Cgm3Package.GPS_TRACKER__ID:
		case Cgm3Package.GPS_TRACKER__COORDINATES:
		case Cgm3Package.GPS_TRACKER__SPEED:
		case Cgm3Package.GPS_TRACKER__DOES_THE_USE_OF_GPS_IS_FULLY_EXPLAINED_IN_COMPANY_POLICIES_AND_STAFF_HANDBOOKS:
		case Cgm3Package.GPS_TRACKER__RECORD_RETENTION_PERIOD:
		case Cgm3Package.GPS_TRACKER__DOES_CONSENT_HAVE_BEEN_GATHERED_FROM_THE_STAFF_WHO_USED_THESE_VEHICLES:
		case Cgm3Package.GPS_TRACKER__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
		case Cgm3Package.GPS_TRACKER__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
		case Cgm3Package.GPS_TRACKER__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
		case Cgm3Package.GPS_TRACKER__ARE_YOU_PROCESSING_DATA_THAT_ARE_NOT_NEEDED_FOR_THE_PURPOSE_SUCH_EMPLOYEE_MONITORING:
		case Cgm3Package.GPS_TRACKER__DOES_THE_STAFF_AWARE_OF_THE_USE_OF_THE_GPS_SYSTEMS:
		case Cgm3Package.GPS_TRACKER__DOES_THE_SYSTEM_RECORD_INFORMATION_OTHER_THAN_THE_PURPOSE:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

}
