/**
 */
package com.cardiffuni.pbdproject.cgm3.provider;

import com.cardiffuni.pbdproject.cgm3.CGMsensor;
import com.cardiffuni.pbdproject.cgm3.Cgm3Package;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.cardiffuni.pbdproject.cgm3.CGMsensor} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class CGMsensorItemProvider extends GeneralEntityItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CGMsensorItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addEncryptedDataPropertyDescriptor(object);
			addSmartphonePropertyDescriptor(object);
			addGlucose_amountPropertyDescriptor(object);
			addConnectionPropertyDescriptor(object);
			addDataRetentionPropertyDescriptor(object);
			addAre_you_storing_the_data_longer_than_is_necessary_for_the_purposesPropertyDescriptor(object);
			addIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measuresPropertyDescriptor(
					object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Encrypted Data feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addEncryptedDataPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Encryption_EncryptedData_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Encryption_EncryptedData_feature",
								"_UI_Encryption_type"),
						Cgm3Package.Literals.ENCRYPTION__ENCRYPTED_DATA, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Smartphone feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addSmartphonePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_CGMsensor_smartphone_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_CGMsensor_smartphone_feature",
								"_UI_CGMsensor_type"),
						Cgm3Package.Literals.CG_MSENSOR__SMARTPHONE, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Glucose amount feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addGlucose_amountPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_CGMsensor_Glucose_amount_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_CGMsensor_Glucose_amount_feature",
								"_UI_CGMsensor_type"),
						Cgm3Package.Literals.CG_MSENSOR__GLUCOSE_AMOUNT, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Connection feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addConnectionPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_CGMsensor_Connection_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_CGMsensor_Connection_feature",
								"_UI_CGMsensor_type"),
						Cgm3Package.Literals.CG_MSENSOR__CONNECTION, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Data Retention feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDataRetentionPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_CGMsensor_DataRetention_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_CGMsensor_DataRetention_feature",
								"_UI_CGMsensor_type"),
						Cgm3Package.Literals.CG_MSENSOR__DATA_RETENTION, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you storing the data longer than is necessary for the purposes feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_storing_the_data_longer_than_is_necessary_for_the_purposesPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_CGMsensor_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_CGMsensor_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes_feature",
						"_UI_CGMsensor_type"),
				Cgm3Package.Literals.CG_MSENSOR__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Is data against accidental loss and destruction and damage AND you are using appropriate technical or organisational measures feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addIs_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measuresPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_CGMsensor_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_CGMsensor_Is_data_against_accidental_loss_and_destruction_and_damage_AND_you_are_using_appropriate_technical_or_organisational_measures_feature",
						"_UI_CGMsensor_type"),
				Cgm3Package.Literals.CG_MSENSOR__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This returns CGMsensor.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/CGMsensor"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((CGMsensor) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_CGMsensor_type")
				: getString("_UI_CGMsensor_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(CGMsensor.class)) {
		case Cgm3Package.CG_MSENSOR__ENCRYPTED_DATA:
		case Cgm3Package.CG_MSENSOR__GLUCOSE_AMOUNT:
		case Cgm3Package.CG_MSENSOR__CONNECTION:
		case Cgm3Package.CG_MSENSOR__DATA_RETENTION:
		case Cgm3Package.CG_MSENSOR__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
		case Cgm3Package.CG_MSENSOR__IS_DATA_AGAINST_ACCIDENTAL_LOSS_AND_DESTRUCTION_AND_DAMAGE_AND_YOU_ARE_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

}
