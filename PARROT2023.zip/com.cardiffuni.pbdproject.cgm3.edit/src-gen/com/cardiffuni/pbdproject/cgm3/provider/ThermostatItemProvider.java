/**
 */
package com.cardiffuni.pbdproject.cgm3.provider;

import com.cardiffuni.pbdproject.cgm3.Cgm3Package;
import com.cardiffuni.pbdproject.cgm3.Thermostat;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link com.cardiffuni.pbdproject.cgm3.Thermostat} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class ThermostatItemProvider extends GeneralEntityItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ThermostatItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addEncryptedDataPropertyDescriptor(object);
			addPrivacy_patternsPropertyDescriptor(object);
			addCloudservicePropertyDescriptor(object);
			addAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_dataPropertyDescriptor(
					object);
			addConnectionPropertyDescriptor(object);
			addDataRetentionPropertyDescriptor(object);
			addAre_you_storing_the_data_longer_than_is_necessary_for_the_purposesPropertyDescriptor(object);
			addIs_data_against_accidental_loss_or_destruction_or_damagePropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Encrypted Data feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addEncryptedDataPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Encryption_EncryptedData_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Encryption_EncryptedData_feature",
								"_UI_Encryption_type"),
						Cgm3Package.Literals.ENCRYPTION__ENCRYPTED_DATA, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Privacy patterns feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPrivacy_patternsPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Privacy_patterns_Privacy_patterns_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Privacy_patterns_Privacy_patterns_feature",
								"_UI_Privacy_patterns_type"),
						Cgm3Package.Literals.PRIVACY_PATTERNS__PRIVACY_PATTERNS, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Cloudservice feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addCloudservicePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Thermostat_cloudservice_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Thermostat_cloudservice_feature",
								"_UI_Thermostat_type"),
						Cgm3Package.Literals.THERMOSTAT__CLOUDSERVICE, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you using appropriate technical or organisational measures to protect the data feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_using_appropriate_technical_or_organisational_measures_to_protect_the_dataPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString(
						"_UI_Thermostat_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Thermostat_Are_you_using_appropriate_technical_or_organisational_measures_to_protect_the_data_feature",
						"_UI_Thermostat_type"),
				Cgm3Package.Literals.THERMOSTAT__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Connection feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addConnectionPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Thermostat_Connection_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Thermostat_Connection_feature",
								"_UI_Thermostat_type"),
						Cgm3Package.Literals.THERMOSTAT__CONNECTION, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Data Retention feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDataRetentionPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_Thermostat_DataRetention_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_Thermostat_DataRetention_feature",
								"_UI_Thermostat_type"),
						Cgm3Package.Literals.THERMOSTAT__DATA_RETENTION, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Are you storing the data longer than is necessary for the purposes feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAre_you_storing_the_data_longer_than_is_necessary_for_the_purposesPropertyDescriptor(
			Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Thermostat_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Thermostat_Are_you_storing_the_data_longer_than_is_necessary_for_the_purposes_feature",
						"_UI_Thermostat_type"),
				Cgm3Package.Literals.THERMOSTAT__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES,
				true, false, false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Is data against accidental loss or destruction or damage feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addIs_data_against_accidental_loss_or_destruction_or_damagePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add(createItemPropertyDescriptor(
				((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(), getResourceLocator(),
				getString("_UI_Thermostat_Is_data_against_accidental_loss_or_destruction_or_damage_feature"),
				getString("_UI_PropertyDescriptor_description",
						"_UI_Thermostat_Is_data_against_accidental_loss_or_destruction_or_damage_feature",
						"_UI_Thermostat_type"),
				Cgm3Package.Literals.THERMOSTAT__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE, true, false,
				false, ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This returns Thermostat.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/Thermostat"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((Thermostat) object).getName();
		return label == null || label.length() == 0 ? getString("_UI_Thermostat_type")
				: getString("_UI_Thermostat_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(Thermostat.class)) {
		case Cgm3Package.THERMOSTAT__ENCRYPTED_DATA:
		case Cgm3Package.THERMOSTAT__PRIVACY_PATTERNS:
		case Cgm3Package.THERMOSTAT__ARE_YOU_USING_APPROPRIATE_TECHNICAL_OR_ORGANISATIONAL_MEASURES_TO_PROTECT_THE_DATA:
		case Cgm3Package.THERMOSTAT__CONNECTION:
		case Cgm3Package.THERMOSTAT__DATA_RETENTION:
		case Cgm3Package.THERMOSTAT__ARE_YOU_STORING_THE_DATA_LONGER_THAN_IS_NECESSARY_FOR_THE_PURPOSES:
		case Cgm3Package.THERMOSTAT__IS_DATA_AGAINST_ACCIDENTAL_LOSS_OR_DESTRUCTION_OR_DAMAGE:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

}
